//
// The replicated nullhttpd webserver
//

#include <getopt.h>
#include "lib.h"

FILE *logfile = NULL;

// sockets
static Socket req_sock;   // wait for requests via two-phase commit here
static Socket resp_sock;  // send responses here
static pthread_mutex_t resp_lock = PTHREAD_MUTEX_INITIALIZER;

// requests
static pthread_mutex_t glock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  gsig = PTHREAD_COND_INITIALIZER;
static queue<Buffer> pendingrequests;

//------------------------------------------------------------------------------
// Worker Threads
//------------------------------------------------------------------------------

static void* ClientWorker(void*)
{
	char *tmp;

	// don't allocate these on the stack: not enough room!
	char *buffer = new char[MAX_REQSIZE];
	Request *req = new Request;
	Response *resp = new Response;

	for (;;)
	{
		Buffer buf;
		char* buffer;

		// Wait for a request
		LOG_LEVEL(2, "Waiting for a request\n");
		pthread_mutex_lock(&glock);
		while (pendingrequests.empty()) {
			pthread_cond_wait(&gsig, &glock);
		}
		buf = pendingrequests.front();
		pendingrequests.pop();
		pthread_mutex_unlock(&glock);

		// Parse the request.
		buffer = buf.buf;

		ResetRequest(req);
		req->ClientID      = *((int *)buffer);
		req->ContentLength = *((int *)(buffer + sizeof(int)));

		tmp = buffer + 2 * sizeof(int);
		req->Method          = string(tmp);   tmp += strlen(tmp) + 1;
		req->URI             = string(tmp);   tmp += strlen(tmp) + 1;
		req->Protocol        = string(tmp);   tmp += strlen(tmp) + 1;
		req->Connection      = string(tmp);   tmp += strlen(tmp) + 1;
		req->ContentType     = string(tmp);   tmp += strlen(tmp) + 1;
		req->Cookie          = string(tmp);   tmp += strlen(tmp) + 1;
		req->Host            = string(tmp);   tmp += strlen(tmp) + 1;
		req->IfModifiedSince = string(tmp);   tmp += strlen(tmp) + 1;
		req->UserAgent       = string(tmp);   tmp += strlen(tmp) + 1;
		strncpy(req->postbuf, tmp, req->ContentLength);

		LOG_LEVEL(2, "Request: id=%d length=%d method=%s URI=%s\n",
			req->ClientID, req->ContentLength, req->Method.c_str(), req->URI.c_str());

		/* Build the response */
		DoRequest(req, resp);

		/* Ignore nullHTTPd for now; send static responses */
		//string respstr = "HTTP/1.1 200 OK\r\n\r\nIt worked!\r\n";
		//resp->reply.clear();
		//resp->reply.insert(resp->reply.end(), respstr.begin(), respstr.end());

		/* Forward the response to the arbiter */
		size_t sz = resp->reply.size();

		pthread_mutex_lock(&resp_lock);
		SocketWrite(&resp_sock, (char *)&req->ClientID, sizeof(req->ClientID));
		SocketWrite(&resp_sock, (char *)&sz, sizeof(sz));
		SocketWrite(&resp_sock, &resp->reply[0], sz);
		pthread_mutex_unlock(&resp_lock);
	}

	delete req;
	delete resp;
	delete [] buffer;

	return NULL;
}

//------------------------------------------------------------------------------
// Listener
// (Two-Phase Commit)
//------------------------------------------------------------------------------

static void ReadRequest(Socket *sock, Buffer *out_reqbuf)
{
	assert(sock && out_reqbuf);

	// Get the total request length
	SocketReadBuffer(sock, (char *)&out_reqbuf->size, sizeof(out_reqbuf->size));
	LOG_LEVEL(2, "Request is %ld bytes\n", out_reqbuf->size);

	// Will be freed by do_recv.
	out_reqbuf->buf = (char *)calloc(1, out_reqbuf->size);
	assert(out_reqbuf);

	// Read the request
	SocketReadBuffer(sock, out_reqbuf->buf, out_reqbuf->size);
}

static void ReceiveRequestsFromArbiter(Socket *sock)
{
	int nreqs, i;

	SocketReadBuffer(sock, (char *)&nreqs, sizeof(nreqs));
	LOG_LEVEL(2, "reading %d requests\n", nreqs);

	for (i = 0; i < nreqs; i++) {
		Buffer reqbuf;
		ReadRequest(sock, &reqbuf);

		pthread_mutex_lock(&glock);
		pendingrequests.push(reqbuf);
		pthread_cond_signal(&gsig);
		pthread_mutex_unlock(&glock);
	}
}

static void* Listener(void*)
{
	const uint64_t epoch = 0;
	uint64_t final_epoch = 0;
	uint32_t magic = 0;

	printf("Made it to listener\n");

	for (;;)
	{
		LOG_LEVEL(2, "2phase wait\n");

		// PHASE 0
		// Wait for a "start" msg
		SocketReadBuffer(&req_sock, (char *)&magic, sizeof(magic));
		magic = ntohl(magic);
		assert(magic == REPLICA_MAGIC_NUM);

		LOG_LEVEL(2, "2phase start\n");

		// PHASE 1
		// Fake the barrier.
		SocketWrite(&req_sock, (char *)&epoch, sizeof(epoch));

		// Wait for the arbiter to decide on an actual epoch.
		SocketReadBuffer(&req_sock, (char *)&final_epoch, sizeof(final_epoch));
		LOG_LEVEL(2, "2phase final epoch: %lu\n", final_epoch);
		
		// PHASE 2
		// Recv all the requests
		ReceiveRequestsFromArbiter(&req_sock);
	}
}

//------------------------------------------------------------------------------
// Main
//------------------------------------------------------------------------------

static void SpawnWorkers()
{
	pthread_t thread;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		if (pthread_create(&thread, &attr, ClientWorker, NULL) < 0) {
			PERROR("pthread_create ClientWorker");
			exit(1);
		}
	}

	if (pthread_create(&thread, &attr, Listener, NULL) < 0) {
		PERROR("pthread_create Listener");
		exit(1);
	}
}

static void ConnectToArbiter()
{
	char ip[16];
	Lookup(config.server_arbiter.c_str(), ip, 16);

	// Connect to the arbiter
	OpenConnectSocket("server-req",  ip, config.server_req_port,  &req_sock);
	OpenConnectSocket("server-resp", ip, config.server_resp_port, &resp_sock);
}

int main(int argc, char* argv[])
{
	ParseHttpdCommandLine(argc, argv);
	ConnectToArbiter();
	SpawnWorkers();

	char foo[10];
	printf("Press enter to exit...\n");
	fgets(foo, 10, stdin);

	exit(EXIT_SUCCESS);
}
