//
// The nullhttpd shim
//

#include "shim.h"

namespace DMP {

typedef set<ReplicaShim*, BasicShim::UniqueSort> ReplicaShimSet;
typedef set<ReplicaShim*, BasicShim::UniqueSort>::iterator ReplicaShimSetIter;

// sockets
static Socket req_sock;   // wait for requests via two-phase commit here
static Socket resp_sock;  // send responses here

// requests
static pthread_mutex_t glock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  sigaccepting = PTHREAD_COND_INITIALIZER;

static ReplicaShim* accepting;  // shim blocked on an "ACCEPT" shimcall
static ReplicaShimSet waiting;  // shims blocked on a "RECV" shimcall

static queue<Buffer> pendingrequests;

// Shim calls
// -- ACCEPT: thread that waits for new requests
// -- RECV: recieve a new request
// -- SEND: send a response

//------------------------------------------------------------------------------
// Two-Phase Commit
//------------------------------------------------------------------------------

static void ReadRequest(Socket *sock, Buffer *out_reqbuf)
{
	assert(sock && out_reqbuf);

	// Get the total request length
	SocketReadBuffer(sock, (char *)&out_reqbuf->size, sizeof(out_reqbuf->size));
	LOG_LEVEL(2, "Request is %ld bytes\n", out_reqbuf->size);

	// Will be freed by do_recv.
	out_reqbuf->buf = (char *)calloc(1, out_reqbuf->size);
	assert(out_reqbuf);

	// Read the request
	SocketReadBuffer(sock, out_reqbuf->buf, out_reqbuf->size);
}

static void ReceiveRequestsFromArbiter(Socket *sock)
{
	int nreqs, i;

	SocketReadBuffer(sock, (char *)&nreqs, sizeof(nreqs));
	LOG_LEVEL(2, "reading %d requests\n", nreqs);

	for (i = 0; i < nreqs; i++) {
		Buffer reqbuf;
		ReadRequest(sock, &reqbuf);

		pthread_mutex_lock(&glock);
		pendingrequests.push(reqbuf);
		pthread_mutex_unlock(&glock);
	}
}

static void* BgWorker(void*)
{
	uint64_t epoch = 0;
	uint64_t final_epoch = 0;
	uint32_t magic = 0;

	for (;;)
	{
		LOG_LEVEL(2, "2phase wait\n");

		// PHASE 0
		// Wait for a "start" msg
		SocketReadBuffer(&req_sock, (char *)&magic, sizeof(magic));
		magic = ntohl(magic);
		assert(magic == REPLICA_MAGIC_NUM);

		LOG_LEVEL(2, "2phase start\n");

		// Wait for a thread to block on an "ACCEPT" call
		pthread_mutex_lock(&glock);
		while (accepting == NULL) {
			pthread_cond_wait(&sigaccepting, &glock);
		}
		pthread_mutex_unlock(&glock);

		// PHASE 1
		// Set the first barrier and let the arbiter know our current logical time
		epoch = __dmp_shim_set_barrier(accepting->_dmp_pid, SHIM_BARRIER_OFFSET_SERIAL, 10);
		LOG_LEVEL(2, "2phase first epoch: %lu\n", epoch);
		SocketWrite(&req_sock, (char *)&epoch, sizeof(epoch));

		// Wait for the arbiter to decide on an actual epoch.
		SocketReadBuffer(&req_sock, (char *)&final_epoch, sizeof(final_epoch));
		LOG_LEVEL(2, "2phase final epoch: %lu\n", final_epoch);

		if (final_epoch != epoch) {
			LOG_ASSERT(final_epoch > epoch, "%ld > %ld", final_epoch, epoch);

			LOG_LEVEL(2, "2phase waiting for final epoch\n");
			
			// advance past the 1st epoch
			pthread_mutex_lock(&accepting->_lock);
			accepting->_skip_epoch = epoch;
			pthread_cond_signal(&accepting->_sig);
			pthread_mutex_unlock(&accepting->_lock);

			// register a barrier for the 2nd epoch
			__dmp_shim_set_barrier(accepting->_dmp_pid, SHIM_BARRIER_FIXED_TIME, final_epoch);
		}
		
		// PHASE 2
		// Recv all the requests
		ReceiveRequestsFromArbiter(&req_sock);

		LOG_LEVEL(2, "2phase distributing\n");

		// distribute
		pthread_mutex_lock(&accepting->_lock);
		accepting->_recv_epoch = final_epoch;
		pthread_cond_signal(&accepting->_sig);
		pthread_mutex_unlock(&accepting->_lock);
	}
}

//------------------------------------------------------------------------------
// Shim Threads
//------------------------------------------------------------------------------

ReplicaShim::ReplicaShim(ReplicaShim* parent, int clone_flags)
	: BasicShim(parent, clone_flags), _skip_epoch(0), _recv_epoch(0)
{
	pthread_mutex_init(&_lock, NULL);
	pthread_cond_init(&_sig, NULL);
}

ReplicaShim::~ReplicaShim()
{}

ReplicaShim* ReplicaShim::clone(int clone_flags)
{
	return new ReplicaShim(this, clone_flags);
}

void ReplicaShim::trace_shimcall(shim_event* event)
{
	unsigned long shimcall_type = shim_syscall_arg0(&event->regs);

	switch (shimcall_type) {
	case SERVER_ACCEPT:
		do_accept(event);
		break;
	case SERVER_RECV:
		do_recv(event);
		break;
	case SERVER_SEND:
		do_send(event);
		break;

	default:
		BasicShim::trace_shimcall(event);
		return;
	}
}

void ReplicaShim::do_accept(shim_event* event)
{
	if (dmp_shim_sleep() != 0)
		SHIM_PERROR("dmp_shim_sleep");

	// Notify BgWorker.
	pthread_mutex_lock(&glock);
	assert(accepting == NULL || accepting == this);
	accepting = this;
	pthread_cond_signal(&sigaccepting);
	pthread_mutex_unlock(&glock);

 again:
	// Wait for a barrier (set by BgWorker).
	LOG_LEVEL(2, "waiting for barrier\n");
	if (dmp_shim_trace(event) < 0)
		SHIM_PERROR("dmp_shim_trace");

	LOG_LEVEL(2, "@%ld: event received\n", event->logical_time);
	if (event->event_type != DMP_SHIM_BARRIER)
		LOG("expected a serial event, got: %d", event->event_type);

	pthread_mutex_lock(&_lock);
	for (;;) {
		LOG_LEVEL(2, "q=%ld skip=%ld recv=%ld",
			 event->logical_time, _skip_epoch, _recv_epoch);

		// need to catch up?
		if (event->logical_time == _skip_epoch) {
			pthread_mutex_unlock(&_lock);

			if (dmp_shim_sleep() != 0)
				SHIM_PERROR("dmp_shim_sleep");

			goto again;
		}

		// ready to recv?
		if (event->logical_time == _recv_epoch) {
			break;
		}

		pthread_cond_wait(&_sig, &_lock);
	}
	pthread_mutex_unlock(&_lock);

	// Distribute requests
	ReplicaShimSetIter iter;
	int per, remainder;

	pthread_mutex_lock(&glock);

	if (waiting.size() == 0) {
		pthread_mutex_unlock(&glock);
		LOG("not distributing requests: nobody waiting (FIXME!)\n");
		return;
	}

	per       = pendingrequests.size() / waiting.size();
	remainder = pendingrequests.size() % waiting.size();

	LOG_LEVEL(2, "distributing %ld requests to %ld workers\n",
		 pendingrequests.size(), waiting.size());

	for (iter = waiting.begin(); iter != waiting.end(); iter++) {
		ReplicaShim* worker = *iter;

		pthread_mutex_lock(&worker->_lock);
		for (int i = 0; i < per; i++) {
			worker->_readyqueue.push(pendingrequests.front());
			pendingrequests.pop();
		}

		if (remainder > 0) {
			worker->_readyqueue.push(pendingrequests.front());
			pendingrequests.pop();
			remainder--;
		}

		pthread_cond_signal(&worker->_sig);
		pthread_mutex_unlock(&worker->_lock);
	}
	pthread_mutex_unlock(&glock);
}

void ReplicaShim::do_recv(shim_event* event /* , char *buffer, int maxlen*/ )
{
	void*  user_buffer = (void*)shim_syscall_arg1(&event->regs);
	size_t user_maxlen = (size_t)shim_syscall_arg2(&event->regs);

	Buffer out;
	out.buf = NULL;

	if (user_maxlen < MAX_POSTSIZE) {
		LOG("Bad user_maxlen: %lu < %lu\n", user_maxlen, MAX_REQSIZE);
		dmp_shim_emulate_syscall(-EINVAL, &event->regs);
		return;
	}

	// Pull from our local queue, if not empty.
	pthread_mutex_lock(&_lock);
	if (!_readyqueue.empty()) {
		out = _readyqueue.front();
		_readyqueue.pop();
	}
	pthread_mutex_unlock(&_lock);

	if (out.buf != NULL)
		goto done;

	LOG_LEVEL(2, "waiting for request...\n");
	start_io_op(-1 /* unbounded */);

	// Wait for new requests.
	pthread_mutex_lock(&glock);
	waiting.insert(this);
	pthread_mutex_unlock(&glock);

	pthread_mutex_lock(&_lock);
	while (_readyqueue.empty()) {
		pthread_cond_wait(&_sig, &_lock);
	}
	out = _readyqueue.front();
	_readyqueue.pop();
	pthread_mutex_unlock(&_lock);

	// No longer waiting 
	pthread_mutex_lock(&glock);
	waiting.erase(waiting.find(this));
	pthread_mutex_unlock(&glock);

	finish_io_op(-1 /* unbounded */);

 done:
	// Success: returns 0 by default.
	assert(out.buf != NULL);
	LOG_LEVEL(2, "delivering request of size %lu\n", out.size);

	dmp_shim_memcpy_sync((void*)out.buf, user_buffer, out.size, TO_DMP, NULL);
	free(out.buf);
}

void ReplicaShim::do_send(shim_event* event /* , int client_id, char *buffer, ssize_t len */ )
{
	int user_client_id = (int)shim_syscall_arg1(&event->regs);
	void* user_buffer = (void*)shim_syscall_arg2(&event->regs);
	size_t user_len = (size_t)shim_syscall_arg3(&event->regs);

	char *response = (char *)calloc(1, user_len);
	assert(response);

	// Get the response from the dmp thread.
	// This should be a complete HTTP response, as a string.
	dmp_shim_memcpy_sync(response, user_buffer, user_len, FROM_DMP, NULL);

	SocketWrite(&resp_sock, (char *)&user_client_id, sizeof(user_client_id));
	SocketWrite(&resp_sock, (char *)&user_len, sizeof(user_len));
	SocketWrite(&resp_sock, response, user_len);
	free(response);
}

void ReplicaShim::init_all(const char* arbiter, int arbiter_req_port, int arbiter_resp_port)
{
	pthread_t thread;
	pthread_attr_t attr;

	char ip[16];
	Lookup(arbiter, ip, 16);

	// Connect to the arbiter
	OpenConnectSocket("arbiter-req",  ip, arbiter_req_port,  &req_sock);
	OpenConnectSocket("arbiter-resp", ip, arbiter_resp_port, &resp_sock);

	// Open the background worker thread
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_create(&thread, &attr, BgWorker, NULL) < 0) {
		PERROR("pthread_create BgWorker");
		exit(1);
	}
}

}  // namespace DMP
