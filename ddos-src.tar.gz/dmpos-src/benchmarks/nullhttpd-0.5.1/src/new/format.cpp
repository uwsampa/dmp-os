/*
    Null httpd -- simple http server
    Copyright (C) 2001-2002 Dan Cahill

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "lib.h"

void decodeurl(string *url)
{
	char *a, *b;
	char *first = &(*url)[0];
	char *end = first + url->size();

	for (b = first; b < end; ++b) {
		if (*b=='+')
			*b=' ';
	}

	a = first;
	b = first;
	while (a < end) {
		if (*a == '%') {
			a++;
			if (isxdigit(a[0]) && isxdigit(a[1])) {
				*b++ = (char)hex2int(a);
				a += 2;
			}
		} else {
			*b++ = *a++;
		}
	}

	url->resize(b - first);
}

int hex2int(char *pChars)
{
	int Hi;
	int Lo;
	int Result;

	Hi=pChars[0];
	if ('0'<=Hi&&Hi<='9') {
		Hi-='0';
	} else if ('a'<=Hi&&Hi<='f') {
		Hi-=('a'-10);
	} else if ('A'<=Hi&&Hi<='F') {
		Hi-=('A'-10);
	}
	Lo = pChars[1];
	if ('0'<=Lo&&Lo<='9') {
		Lo-='0';
	} else if ('a'<=Lo&&Lo<='f') {
		Lo-=('a'-10);
	} else if ('A'<=Lo&&Lo<='F') {
		Lo-=('A'-10);
	}
	Result=Lo+(16*Hi);
	return (Result);
}

void striprn(char *string)
{
	while ((string[strlen(string)-1]=='\r')||(string[strlen(string)-1]=='\n')) {
		string[strlen(string)-1]='\0';
	}
}

void swapchar(char *string, char oldchar, char newchar)
{
 	while (*string) {
 		if (*string==oldchar) *string=newchar;
		string++;
	}
}

char *strcatf(char *dest, const char *format, ...)
{
	char catbuffer[1024];
	va_list ap;

	memset(catbuffer, 0, sizeof(catbuffer));
	va_start(ap, format);
	vsnprintf(catbuffer, sizeof(catbuffer)-1, format, ap);
	va_end(ap);
	strcat(dest, catbuffer);
	return dest;
}

/*
 * Print a msg directly into the http reply.
 */

void Response::print(const char *text)
{
	// just append
	reply.insert(reply.end(), text, text + strlen(text));
}

void Response::prints(const char *format, ...)
{
	const size_t maxsize = 2048;
	const size_t oldlen = reply.size();

	// temporarily resize for printing
	reply.resize(oldlen + maxsize);

	va_list ap;
	va_start(ap, format);
	size_t len = vsnprintf(&reply[oldlen], maxsize, format, ap);
	va_end(ap);

	// shrink to the actual printed size
	reply.resize(oldlen + std::min(maxsize, len));
}

void Response::printhex(const char *format, ...)
{
	char *hex=(char *)"0123456789ABCDEF";
	char buffer[1024];
	int offset=0;
	va_list ap;

	va_start(ap, format);
	vsnprintf(buffer, sizeof(buffer)-1, format, ap);
	va_end(ap);
	while (buffer[offset]) {
		if ((buffer[offset]>32)&&(buffer[offset]<128)&&(buffer[offset]!='<')&&(buffer[offset]!='>')) {
			prints("%c", buffer[offset]);
		} else {
			prints("%%%c%c", hex[(unsigned int)buffer[offset]/16], hex[(unsigned int)buffer[offset]&15]);
		}
		offset++;
	}
}

void Response::printht(const char *format, ...)
{
	char buffer[1024];
	va_list ap;

	va_start(ap, format);
	size_t len = vsnprintf(buffer, sizeof(buffer)-1, format, ap);
	va_end(ap);
	reply.reserve(reply.size() + len);

	for (char *c = buffer; *c; ++c) {
		if (*c == '<') {
			print("&lt;");
		} else if (*c == '>') {
			print("&gt;");
		} else if (*c == '&') {
			print("&amp;");
		} else if (*c == '"') {
			print("&quot;");
		} else {
			prints("%c", *c);
		}
	}
}
