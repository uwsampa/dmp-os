/*
    Null httpd -- simple http server
    Copyright (C) 2001-2002 Dan Cahill

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "lib.h"

static const char *GetMimeType(const char *name)
{
	const char *mime_types[40][2] = {
		{ ".html", "text/html" },
		{ ".htm",  "text/html" },
		{ ".shtml","text/html" },
		{ ".css",  "text/css" },
		{ ".txt",  "text/plain" },
		{ ".mdb",  "application/msaccess" },
		{ ".xls",  "application/msexcel" },
		{ ".doc",  "application/msword" },
		{ ".exe",  "application/octet-stream" },
		{ ".pdf",  "application/pdf" },
		{ ".rtf",  "application/rtf" },
		{ ".tgz",  "application/x-compressed" },
		{ ".gz",   "application/x-compressed" },
		{ ".z",    "application/x-compress" },
		{ ".swf",  "application/x-shockwave-flash" },
		{ ".tar",  "application/x-tar" },
		{ ".rar",  "application/x-rar-compressed" },
		{ ".zip",  "application/x-zip-compressed" },
		{ ".ra",   "audio/x-pn-realaudio" },
		{ ".ram",  "audio/x-pn-realaudio" },
		{ ".wav",  "audio/x-wav" },
		{ ".gif",  "image/gif" },
		{ ".jpeg", "image/jpeg" },
		{ ".jpe",  "image/jpeg" },
		{ ".jpg",  "image/jpeg" },
		{ ".png",  "image/png" },
		{ ".avi",  "video/avi" },
		{ ".mp3",  "video/mpeg" },
		{ ".mpeg", "video/mpeg" },
		{ ".mpg",  "video/mpeg" },
		{ ".qt",   "video/quicktime" },
		{ ".mov",  "video/quicktime" },
		{ "",      "" }
	};
	const char *extension;
	int i;

	extension = strrchr(name, '.');
	if (extension == NULL) {
		return "text/plain";
	}
	i = 0;
	while (strlen(mime_types[i][0]) > 0) {
		if (strcmp(extension, mime_types[i][0]) == 0) {
			return mime_types[i][1];
		}
		i++;
	}
	return "application/octet-stream";
}

/*
 *******************************************************************************
 * Files
 *******************************************************************************
 */

static bool FindFile(Request *req, Response *resp, const string& file, struct stat *sb)
{
	// Open the file.
	const int fd = open(file.c_str(), O_RDONLY);
	if (fd < 0) {
		PERROR("open");
		return false;
	}

	/*
	SET THIS TO PARSE THE DATE AND ACTUALLY CHECK FOR AN UPDATE
	if (strlen(conn[sid].dat->in_IfModifiedSince)) {
		send_fileheader(sid, 1, 304, "OK", "1", GetMimeType(file), sb.st_size, sb.st_mtime);
		conn[sid].dat->out_headdone=1;
		conn[sid].dat->out_bodydone=1;
		conn[sid].dat->out_flushed=1;
		conn[sid].dat->out_ReplyData[0]='\0';
		flushbuffer(sid);
		return 0;
	}
	*/

	//
	// Setup the headers
	//

	resp->ContentLength = sb->st_size;
	resp->ContentType = GetMimeType(file.c_str());

	// We won't rely on mtime being deterministic across replicas.
	if (false) {
		char timebuf[128];
		strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime(&sb->st_mtime));
		resp->LastModified = string(timebuf);
	}

	// Can't call time().
	// Really we should get the time from the arbiter.
	if (false) {
		char timebuf[128];
		long now = time((time_t*)0)+604800;
		strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime(&now));
		resp->Expires = string(timebuf);
		resp->CacheControl = "public";
		resp->Pragma = "public";

	} else {
		resp->CacheControl = "no-store";
		resp->Pragma = "no-cache";
	}

	AddHeaders(req, resp);

	//
	// Read the file
	//

	size_t oldsz = resp->reply.size();
	size_t bufsz = sb->st_size;
	resp->reply.resize(oldsz + bufsz);

	char* buffer = &resp->reply[oldsz];

	while (bufsz != 0) {
		size_t r = read(fd, buffer, bufsz);
		if (r < 0)
			PERROR("read");
		if (r <= 0)
			break;
		bufsz -= r;
		buffer += r;
	}

	memset(buffer, 0, bufsz);

	close(fd);
	return true;
}

/*
 *******************************************************************************
 * Directory listing
 *******************************************************************************
 */

static bool FindDir(Request *req, Response *resp, const string& directory)
{
	DIR *dir;
	struct dirent *dentry;
	struct stat sb;
	char timebuf[128];

	//
	// Generate the page
	//

	resp->print("<CENTER>\n<TABLE BORDER=1 CELLPADDING=2 CELLSPACING=0 WIDTH=90%>\n");
	resp->prints("<TR BGCOLOR=#00A5D0><TH COLSPAN=4>Index of %s</TH></TR>\n", req->URI.c_str());
	resp->print("<TR BGCOLOR=#E0E0E0>");
	resp->print("<TH width=20%>Filename</TH><TH width=10%>Size</TH>");
	resp->print("<TH width=10%>Date</TH><TH width=60%>Description</TH></TR>\n");

	string file;
	dir = opendir(directory.c_str());

	while ((dentry = readdir(dir)) != NULL) {
		if (strcmp(".", dentry->d_name) == 0)
			continue;
		if ((strcmp("..", dentry->d_name) == 0) && (strcmp("/files/", req->URI.c_str())==0))
			continue;
		if (strcmp("..", dentry->d_name)==0) {
			resp->print("<TR BGCOLOR=#F0F0F0><TD COLSPAN=4><IMG SRC=/images/foldero.gif>");
			resp->prints("<A HREF='%s'/> Parent Directory</A></TD>\n", dentry->d_name);
			continue;
		}

		file = (directory + "/") + dentry->d_name;
		stat(file.c_str(), &sb);

		// We won't rely on mtime being deterministic across replicas.
		if (false) {
			strftime(timebuf, sizeof(timebuf), "%b %d %Y %H:%M", localtime(&sb.st_mtime));
		}

		resp->prints("<TR BGCOLOR=#F0F0F0><TD ALIGN=left NOWRAP>");

		if (sb.st_mode & S_IFDIR) {
			resp->print("<IMG SRC=/images/folder.gif>&nbsp;<A HREF='");
			resp->printhex("%s", dentry->d_name);
			resp->prints("'/>%s/</A></TD>", dentry->d_name);
		} else {
			resp->print("<IMG SRC=/images/default.gif>&nbsp;<A HREF='");
			resp->printhex("%s", dentry->d_name);
			resp->prints("'>%s</A></TD>", dentry->d_name);
		}

		if (sb.st_size > 1048576) {
			resp->prints("<TD ALIGN=right NOWRAP>%10.1f M</TD>\n", (float)sb.st_size/1048576.0);
		} else {
			resp->prints("<TD ALIGN=right NOWRAP>%10.1f K</TD>\n", (float)sb.st_size/1024.0);
		}

		resp->prints("<TD ALIGN=right NOWRAP>(no date)</TD>\n");
		resp->print("<TD ALIGN=left NOWRAP>&nbsp;</TD></TR>\n");
	}

	closedir(dir);
	resp->print("</TABLE>\n");
	resp->print("</CENTER>\n");
	resp->print("</BODY></HTML>\n");

	//
	// Generate the reply
	// NOTE: we don't know the ContentLength until the page is generated!
	// Thus we have to generate the reply *after* generating the page.
	//

	vector<char> tmp;
	tmp.reserve(resp->reply.capacity());
	tmp.swap(resp->reply);

	resp->ContentType = "text/html";
	resp->ContentLength = tmp.size();
	resp->CacheControl = "no-store";
	resp->Pragma = "no-cache";

	AddHeaders(req, resp);
	resp->reply.insert(resp->reply.end(), tmp.begin(), tmp.end());
	return true;
}

/*
 *******************************************************************************
 * Cacheing
 *******************************************************************************
 */

// TODO!
static bool FindCached(Request *req, Response *resp, const string& file)
{
	return false;
}

/*
 *******************************************************************************
 * Name resolution
 *******************************************************************************
 */

static bool FindFromFileSystem(Request *req, Response *resp, const string& file)
{
	// Security check.
	if (strstr(file.c_str(), "..") != NULL)
		return false;

	// Stat the file.
	struct stat sb;
	if (stat(file.c_str(), &sb) != 0) {
		PERROR("stat file");
		return false;
	}

	if (sb.st_mode & S_IFDIR) {
		string index = file + "/index.html";
		if (stat(index.c_str(), &sb) == 0)
			return FindFile(req, resp, file, &sb);
		else
			return FindDir(req, resp, file);
	} else {
		return FindFile(req, resp, file, &sb);
	}
}

bool MakeFilePage(Request *req, Response *resp)
{
	string file = config.server_htdocs_dir + req->URI;
	decodeurl(&file);

	if (FindCached(req, resp, file))
		return true;
	if (FindFromFileSystem(req, resp, file))
		return true;
	return false;
}
