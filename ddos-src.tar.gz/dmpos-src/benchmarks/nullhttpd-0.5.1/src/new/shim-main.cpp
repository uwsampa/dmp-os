//
// The nullhttpd shim process.
//
// NOTE: by the time the shim is invoked, we have already been
// attached to the DMP thread, and that thread is stopped.
//

#include <stdlib.h>
#include <stdio.h>
#include <syscall.h>
#include <sys/user.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>

#include "dmp.h"
#include "basicshim.h"
#include "shim.h"

using namespace DMP;

FILE *logfile = NULL;

//-------------------------------------------------------------------------
// Commandline parsing
//-------------------------------------------------------------------------

static int argc;
static char** argv;
static const char* arbiter;
static map<int, FileTimingInfo> localfds;

#define USAGE \
"Usage: %s [opts]					\n\
Options:						\n\
   --localdir=dir,rdtime,wrtime,opentime,closetime	\n\
   --localfd=dir,rdtime,wrtime,opentime,closetime	\n\
   --cfg=file						\n\
   --arbiter=hostname					\n\
"

static void usage()
{
	fprintf(stderr, USAGE, argv[0]);
	exit(1);
}

enum option_t {
	OPT_LOCAL_DIR = 0x100,
	OPT_LOCAL_FD,
	OPT_CFG,
	OPT_ARBITER,
	OPT_ARBITER_REQ,
	OPT_ARBITER_RESP,
};

static struct option options[] = {
	{ "localdir",     required_argument, NULL, OPT_LOCAL_DIR },
	{ "localfd",      required_argument, NULL, OPT_LOCAL_FD },
	{ "cfg",          required_argument, NULL, OPT_CFG },
	{ "arbiter",      required_argument, NULL, OPT_ARBITER },
	{ "arbiter-req",  required_argument, NULL, OPT_ARBITER_REQ },
	{ "arbiter-resp", required_argument, NULL, OPT_ARBITER_RESP },
	{ NULL, 0, NULL, 0 },
};

static void parseFileTimingInfo(char *opt, char **path, FileTimingInfo *timing)
{
	char *tmp;
	char *rdtime, *wrtime, *optime, *cltime;

	if (!path)
		return;

	*path  = strtok_r(opt,  ",", &tmp);
	rdtime = strtok_r(NULL, ",", &tmp);
	wrtime = strtok_r(NULL, ",", &tmp);
	optime = strtok_r(NULL, ",", &tmp);
	cltime = strtok_r(NULL, ",", &tmp);

	if (!path || !rdtime || !wrtime || !optime || !cltime)
		usage();

	timing->read  = atoi(rdtime);
	timing->write = atoi(wrtime);
	timing->open  = atoi(optime);
	timing->close = atoi(cltime);
}

static void parseLocalFile(char *opt)
{
	FileTimingInfo timing;
	char *path;

	parseFileTimingInfo(optarg, &path, &timing);
	if (!add_deterministic_file_path(path, timing))
		usage();
}

static void parseLocalFd(char *opt)
{
	FileTimingInfo timing;
	char *path;

	parseFileTimingInfo(optarg, &path, &timing);
	int fd = atoi(path);
	if (0 < fd)
		usage();

	localfds[fd] = timing;
}

static void parseCommandLine()
{
	int opt;
	ConfigInit();

	// Stop at first unknown arg.
	while ((opt = getopt_long(argc, argv, "", options, NULL)) != -1) {
		switch (opt) {
		case OPT_LOCAL_DIR:
			parseLocalFile(optarg);
			break;
		case OPT_LOCAL_FD:
			parseLocalFd(optarg);
			break;
		case OPT_CFG:
			if (!ConfigRead(optarg))
				usage();
			break;
		case OPT_ARBITER:
			arbiter = optarg;
			break;
		default:
			usage();
		}
	}

	if (arbiter == NULL)
		usage();

	LOG_LEVEL(1, "Attemting to connect to %s at %d,%d\n", arbiter, config.server_req_port,
		config.server_resp_port);

	// Rest of the commandline should be empty.
	if (optind != argc)
		usage();
}

static void initShim(ReplicaShim *shim)
{
	// Setup deterministic fds
	for (map<int,FileTimingInfo>::const_iterator
			iter = localfds.begin();
			iter != localfds.end();
			++iter) {
		shim->add_deterministic_fd(iter->first, iter->second);
	}

	// Get the pid from environ
	char* pid = getenv("INITIAL_DMP_PID");
	if (pid != NULL) {
		shim->_dmp_pid = atoi(pid);
		LOG_LEVEL(1, "connected to dmp task with pid=%d", shim->_dmp_pid);
	} else {
		LOG_LEVEL(1, "warning: no INITIAL_DMP_PID specified");
	}

	ReplicaShim::init_all(arbiter, config.server_req_port,
		config.server_resp_port);
}

//-------------------------------------------------------------------------
// Main
//-------------------------------------------------------------------------

int main(int _argc, char *_argv[])
{
	ReplicaShim* shim = NULL;

	char filename[] = "/tmp/shim.log.XXXXXX";
	int fd = mkstemp(filename);
	logfile = fdopen(fd, "w");
	setbuf(logfile, NULL);

	// Initialize.
	argc = _argc;
	argv = _argv;
	parseCommandLine();

	// Run the shim.
	shim = new ReplicaShim(NULL, 0);

	initShim(shim);
	shim->loop();
	WaitForThreadsToDie(false);
	return 0;
}
