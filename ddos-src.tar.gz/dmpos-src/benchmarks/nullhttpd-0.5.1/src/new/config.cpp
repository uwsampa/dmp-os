/*
    Null httpd -- simple http server
    Copyright (C) 2001-2002 Dan Cahill

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <getopt.h>

#include "lib.h"

Config config;

//------------------------------------------------------------------------------
// config
//------------------------------------------------------------------------------

void ConfigInit()
{
	/* define default values */
	char dir[512];
	if (getcwd(dir, sizeof(dir)-1) == NULL)
		return;
	
	config.config_filename = string("");
	config.server_base_dir = string(dir);
	config.server_bin_dir = config.server_base_dir + "/bin";
	config.server_cgi_dir = config.server_base_dir + "/cgi-bin";
	config.server_etc_dir = config.server_base_dir + "/etc";
	config.server_htdocs_dir = config.server_base_dir + "/htdocs";
	config.server_hostname = "any";
	config.server_arbiter = "localhost";
	config.server_port = 80;
	config.server_maxconn = 50;
	config.server_maxidle = 120;
	config.server_nreplicas = 1;
	config.server_req_port  = 5000;
	config.server_resp_port = 5001;
}

bool ConfigRead(const char* cfgfile)
{
	char line[512];
	char *pVar;
	char *pVal;

	config.config_filename = string(cfgfile);

	/* try to open the config file */
	FILE* fp = fopen(cfgfile, "r");
	if (fp == NULL) {
		LOG("Couldn't open config file: %s\n", cfgfile);
		return false;
	}

	/* read it */
	while (fgets(line, sizeof(line)-1, fp)!=NULL) {
		while ((line[strlen(line)-1]=='\n')||(line[strlen(line)-1]=='\r')) {
			line[strlen(line)-1]='\0';
		}
		if (isalpha(line[0])) {
			pVar=line;
			pVal=line;
			while ((*pVal!='=')&&((char *)&pVal+1!='\0')) pVal++;
			*pVal='\0';
			pVal++;
			while (*pVar==' ') pVar++;
			while (pVar[strlen(pVar)-1]==' ') pVar[strlen(pVar)-1]='\0';
			while (*pVal==' ') pVal++;
			while (pVal[strlen(pVal)-1]==' ') pVal[strlen(pVal)-1]='\0';
			while (*pVal=='"') pVal++;
			while (pVal[strlen(pVal)-1]=='"') pVal[strlen(pVal)-1]='\0';
			if (strcmp(pVar, "SERVER_BASE_DIR")==0) {
				config.server_base_dir = string(pVal);
			} else if (strcmp(pVar, "SERVER_BIN_DIR")==0) {
				config.server_bin_dir = string(pVal);
			} else if (strcmp(pVar, "SERVER_CGI_DIR")==0) {
				config.server_cgi_dir = string(pVal);
			} else if (strcmp(pVar, "SERVER_ETC_DIR")==0) {
				config.server_etc_dir = string(pVal);
			} else if (strcmp(pVar, "SERVER_HTTP_DIR")==0) {
				config.server_htdocs_dir = string(pVal);
			} else if (strcmp(pVar, "SERVER_HOSTNAME")==0) {
				config.server_hostname = string(pVal);
			} else if (strcmp(pVar, "SERVER_ARBITER")==0) {
				config.server_arbiter = string(pVal);
			} else if (strcmp(pVar, "SERVER_PORT")==0) {
				config.server_port = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_MAXCONN")==0) {
				config.server_maxconn = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_MAXIDLE")==0) {
				config.server_maxidle = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_REPLICAS")==0) {
				config.server_nreplicas = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_REQ_PORT")==0) {
				config.server_req_port = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_RESP_PORT")==0) {
				config.server_resp_port = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_LOGLEVEL")==0) {
				config.server_loglevel = atoi(pVal);
			} else if (strcmp(pVar, "SERVER_SLEEPTIME") == 0) {
				config.sleeptime = atoi(pVal);
			}
			*pVal='\0';
			*pVar='\0';
		}
	}

	fclose(fp);

	/* sanity check */
	if (config.server_port < 0) {
		LOG("Bad port: %d\n", config.server_port);
		return false;
	}
	if (config.server_maxconn < 1 || 100000 < config.server_maxconn) {
		LOG("Bad maxconn: %d\n", config.server_maxconn);
		return false;
	}
	if (config.server_maxidle < 1) {
		LOG("Bad maxidle: %d\n", config.server_maxidle);
		return false;
	}
	if (config.server_nreplicas < 1) {
		LOG("Bad nreplicas: %d\n", config.server_nreplicas);
		return false;
	}

	return true;
}

//------------------------------------------------------------------------------
// command line
//------------------------------------------------------------------------------

#define USAGE \
"Usage: %s [opts]		\n\
Options:			\n\
   --cfg=file [REQUIRED]	\n\
"

static void usage(char *argv[])
{
	fprintf(stderr, USAGE, argv[0]);
	exit(1);
}

enum option_t {
	OPT_CFG = 0x100,
};

static struct option options[] = {
	{ "cfg", required_argument, NULL, OPT_CFG },
	{ NULL, 0, NULL, 0 },
};

int ParseHttpdCommandLine(int argc, char** argv)
{
	int opt;
	bool gotcfg = false;
	ConfigInit();

	// Stop at first unknown arg.
	while ((opt = getopt_long(argc, argv, "", options, NULL)) != -1) {
		switch (opt) {
		case OPT_CFG:
			if (!ConfigRead(optarg))
				usage(argv);
			gotcfg = true;
			break;
		default:
			usage(argv);
		}
	}

	if (!gotcfg)
		usage(argv);

	// Rest of the commandline should be empty.
	if (optind != argc)
		usage(argv);

	return 0;
}
