//
// Utils
//

#include "lib.h"

void Lookup(const char *hostname, char *out, int len)
{
	struct addrinfo *result, *cur;
	struct sockaddr *sa = NULL;
	struct sockaddr_in *sin = NULL;

	memset(out, 0, len);
	
	/* Attempt to lookup the hostname */
	LOG_LEVEL(1, "Looking up %s... ", hostname);
	if (getaddrinfo(hostname, NULL, NULL, &result) != 0) {
		PERROR("getaddrinfo");
		exit(1);
	}

	/* Use the first IP address */
	for (cur = result; cur; cur = result->ai_next) {
		sa = cur->ai_addr;

		if (sa->sa_family == AF_INET) {
			sin = (struct sockaddr_in *)sa;
			break;
		}
	}

	if (sin == NULL) {
		LOG_CONT("not found\n");

	} else {
		char *ip = strdup(inet_ntoa(sin->sin_addr));
		assert(ip);

		LOG_CONT("%s\n", ip);
		strncpy(out, ip, len-1);
		out[len-1] = '\0'; /* Make sure its null terminated */

		free(ip);
	}

	freeaddrinfo(result);
}

void OpenListenSocket(const char* dbgmsg, int localport, Socket* sock)
{
	int yes = 1;

	sock->s = socket(PF_INET, SOCK_STREAM, 0);
	if (sock->s < 0) {
		PERROR("socket");
		exit(1);
	}

	sock->addr.sin_family = AF_INET;
	sock->addr.sin_port = htons(localport);
	sock->addr.sin_addr.s_addr = htonl(INADDR_ANY);
	sock->addrlen = sizeof sock->addr;

	setsockopt(sock->s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

	if (bind(sock->s, (sockaddr *)&sock->addr, sock->addrlen) < 0) {
		PERROR("bind");
		exit(1);
	}
	
	if (listen(sock->s, 50) < 0) {
		PERROR("listen");
		exit(1);
	}

	if (getsockname(sock->s, (sockaddr *)&sock->addr, (socklen_t *)&sock->addrlen) < 0) {
		PERROR("getsockname");
		exit(1);
	}

	localport = ntohs(sock->addr.sin_port);
	LOG_LEVEL(1, "Opened %s socket at %s:%d\n",
		dbgmsg, inet_ntoa(sock->addr.sin_addr), localport);
}

void OpenConnectSocket(const char* dbgmsg, const char* ip, int port, Socket* sock)
{
	sock->s = socket(PF_INET, SOCK_STREAM, 0);
	if (sock->s < 0) {
		PERROR("socket");
		exit(1);
	}

	sock->addr.sin_family = AF_INET;
	sock->addr.sin_port = htons(port);
	sock->addr.sin_addr.s_addr = inet_addr(ip);
	sock->addrlen = sizeof sock->addr;

	if (connect(sock->s, (sockaddr *)&sock->addr, sock->addrlen) < 0) {
		PERROR("connect");
		exit(1);
	}

	LOG_LEVEL(1, "Opened %s socket at %s:%d\n", dbgmsg, ip, port);
}

void AcceptSocket(const char* dbgmsg, int listen, Socket* sock)
{
	// Wait for a connection.
	sock->addrlen = sizeof sock->addr;
	sock->s = -1;

	while (sock->s < 0)
	{
		sock->s = accept(listen, (sockaddr *)&sock->addr, (socklen_t *)&sock->addrlen);
		if (sock->s >= 0)
			break;
		PERROR("accept");
	}

	LOG_LEVEL(1, "Connected to %s at %s:%d\n",
		dbgmsg, inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
}

void CloseSocket(Socket* sock)
{
	if (sock->s >= 0) {
		close(sock->s);
		sock->s = -1;
	}
}

//
// Usage of SocketReadLine:
//
//   for (Reset(line); SocketReadLine(sock, line); AdvanceLine(line))
//       ...

void ResetLine(LineBuf* line)
{
	line->size = 0;
	line->next = -1;
}

static bool FindNextLine(LineBuf* line)
{
	char* c = (char *)memchr(line->buf, '\n', line->size);
	if (c != NULL) {
		line->next = (c - line->buf) + 1;
		// Strip '\r\n'.
		for (; c >= line->buf && (*c == '\n' || *c == '\r'); c--) {
			*c = '\0';
		}
		return true;
	}

	line->next = -1;
	return false;
}

void AdvanceLine(LineBuf* line)
{
	LOG_ASSERT(line->next <= line->size, "%ld !<= %ld\n", line->next, line->size);
	LOG_ASSERT(line->next > 0,           "%ld !>0\n", line->next);

	if (line->size == 0)
		return;

	line->size -= line->next;
	memmove(line->buf, line->buf + line->next, line->size);
	FindNextLine(line);
}

bool SocketReadLine(Socket* sock, LineBuf* line)
{
	if (sock->s < 0)
		return false;
	if (line->next >= 0)
		return true;

	ssize_t szleft = sizeof(line->buf) - line->size;
	for (;;)
	{
		ssize_t n = recv(sock->s, line->buf + line->size, szleft, 0);
		LOG_LEVEL(3, "socket read %lu bytes: %s:%d\n",
			n, inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
		if (n == 0) {
			LOG_LEVEL(1, "socket closed: %s:%d\n",
				inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
			return false;
		}
		if (n < 0) {
			PERROR("recv");
			return false;
		}
		line->size += n;
		szleft -= n;

		// Did we get a line?
		if (FindNextLine(line))
			return true;

		if (szleft <= 0) {
			LOG("socket overflow: %s:%d\n",
				inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
			return false;
		}
	}
}

ssize_t SocketWrite(Socket* sock, const char *buf, ssize_t nbytes)
{
	ssize_t left, sofar, last;
	int sockfd;

	assert(sock);
	sockfd = sock->s;

	left = nbytes;
	sofar = 0;
	while (left > 0) {
		last = send(sockfd, buf + sofar, left, 0);
		LOG_LEVEL(3, "SOCKET SEND: %ld bytes %ld left\n", last, left - last);
		if (last < 0)
			break;

		sofar += last;
		left  -= last;
	}

	return sofar;
}

//
// Read exactly 'size' bytes, or fail.
//

bool SocketReadBuffer(Socket* sock, char* buf, ssize_t size)
{
	if (sock->s < 0)
		return false;

	while (size > 0)
	{
		ssize_t n = recv(sock->s, buf, size, 0);
		LOG_LEVEL(3, "SOCKET RECV: %ld bytes %ld left\n", n, size - n);
		if (n == 0) {
			LOG_LEVEL(1, "socket closed: %s:%d\n",
				inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
			exit(1);
			return false;
		}
		if (n < 0) {
			PERROR("recv");
			return false;
		}
		buf += n;
		size -= n;
	}

	return true;
}
