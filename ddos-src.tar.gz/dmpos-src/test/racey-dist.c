/*
 * RACEY: a program print a result which is very sensitive to the
 * ordering between processors (races).
 *
 * It is important to "align" the short parallel executions in the
 * simulated environment. First, a simple barrier is used to make sure
 * thread on different processors are starting at roughly the same time.
 * Second, each thread is bound to a physical cpu. Third, before the main
 * loop starts, each thread use a tight loop to gain the long time slice
 * from the OS scheduler.
 *
 * Author: Min Xu <mxu@cae.wisc.edu>
 * Main idea: Due to Mark Hill
 * Created: 09/20/02
 *
 * Compile (on Solaris for Simics) :
 *   cc -mt -o racey racey.c magic.o
 * (on linux with gcc)
 *   gcc -m32 -lpthread -o racey racey.c
 *
 * DMP CHANGES:
 * - PHASE_MARKER is removed
 * - ProcessorIds is removed
 * - MaxLoop is an optional command line parameter
 * - Can spawn 32 threads (previous max was 15)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include "utils.h"
#include "dmpshim.h"

#define MAX_ELEM 64
#define PAGE_SZ (1 << 10)

#define PRIME1   103072243
#define PRIME2   103995407

#define PRINTF(fmt, args...) do { \
		printf(fmt, ##args); \
		fflush(stdout); \
	} while (0)

/*
 * Global variables
 */
int               serverMode =  1;
int               MaxLoop = 50000;
int               NumProcs = 2;
int               numClients = 2;
int               port = 1987;
int               nrounds = 5;
char             *server = "127.0.0.1";
volatile int      startCounter;
int global_sig    = 0;
pthread_mutex_t   threadLock;   /* counter mutex */

/* shared variables */
unsigned sig[33] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                     16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
                     30, 31, 32 };
union {
	/* 64 bytes cache line */
	char b[64];
	int value;
} m[MAX_ELEM];


/* the mix function */
unsigned mix(unsigned i, unsigned j) {
	return (i + j * PRIME2) % PRIME1;
}

/* The function which is called once the thread is created */
void* ThreadBody(void* tid)
{
	int threadId = *(int *) tid;
	int i;

	PRINTF("SEIZING CPU: %d\n", threadId);
	/* seize the cpu, roughly 0.5-1 second on ironsides */
	for(i=0; i<0x07ffffff; i++) {};
	PRINTF("WAIT FOR BARRIER: %d\n", threadId);

	/* simple barrier, pass only once */
	pthread_mutex_lock(&threadLock);
	startCounter--;
	if(startCounter == 0) {
		 /* start of parallel phase */
	}
	pthread_mutex_unlock(&threadLock);
	while(startCounter) {};
	PRINTF("STARTING LOOP: %d\n", threadId);

	/*
	 * main loop:
	 *
	 * Repeatedly using function "mix" to obtain two array indices, read two 
	 * array elements, mix and store into the 2nd
	 *
	 * If mix() is good, any race (except read-read, which can tell by software)
	 * should change the final value of mix
	 */
	for(i = 0 ; i < MaxLoop; i++) {
		unsigned num = sig[threadId];
		unsigned index1 = num%MAX_ELEM;
		unsigned index2;
		num = mix(num, m[index1].value);
		index2 = num%MAX_ELEM;
		num = mix(num, m[index2].value);
		m[index2].value = num;
		sig[threadId] = num;
	}
	PRINTF("DONE WITH LOOP: %d\n", threadId);
	return NULL;
}

int server_main(void)
{
	int key = -1;
	int nconns, i, newfd, fd, sig;
	uint64_t now;

	nconns = nrounds * numClients;
	PRINTF("Server starting: key %x\n", key);

	fd = create_listening_socket(port);
	assert(fd >= 0);
	
	/* Barrier */
	PRINTF("Waiting for clients...\n");
	int fds[numClients];
	for (i = 0; i < numClients; i++) {
		PRINTF(" ... %d of %d\n", i+1, numClients);
		fds[i] = accept_connection(fd, NULL, NULL);
	}

	PRINTF("Sending go message...\n");
	for (i = 0; i < numClients; i++) {
		int go = 1;
		PRINTF(" ... %d of %d\n", i+1, numClients);
		writen(fds[i], (char *)&go, sizeof go);
		close(fds[i]);
	}

	/* Computation */
	PRINTF("Beginning computation...\n");
	for (i = 0; i < nconns; i++) {
		newfd = accept_connection(fd, NULL, NULL);

		now = 10;//dmp_shim_get_logical_time();
		readn(newfd, (char *)&sig, sizeof sig);
		key <<= 8;
		key ^= mix(sig, now);
		writen(newfd, (char *)&key, sizeof key);

		close(newfd);
	}

	PRINTF("Final signature: %x\n", key);

	return 0;
}

/**
 * client_local_round --
 *
 *   Perform one round of local deterministic stress testing
 */
int client_local_round(void)
{
	pthread_t*     threads;
	int*           tids;
	pthread_attr_t attr;
	int            ret;
	int            mix_sig, i;

	/*
	 * Initialize barrier counter
	 */
	startCounter = NumProcs;

	/*
	 * Initialize array of thread structures
	 */
	threads = (pthread_t *) malloc(sizeof(pthread_t) * NumProcs);
	assert(threads != NULL);
	tids = (int *) malloc(sizeof (int) * NumProcs);
	assert(tids != NULL);

	/* Initialize thread attribute */
	pthread_attr_init(&attr);
	pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

	ret = pthread_mutex_init(&threadLock, NULL);
	assert(ret == 0);

	for(i=0; i < NumProcs; i++) {
		/* ************************************************************
		 * pthread_create takes 4 parameters
		 *  p1: threads(output)
		 *  p2: thread attribute
		 *  p3: start routine, where new thread begins
		 *  p4: arguments to the thread
		 * ************************************************************ */
		tids[i] = i+1;
		ret = pthread_create(&threads[i], &attr, ThreadBody, &tids[i]);
		assert(ret == 0);
	}

	/* Wait for each of the threads to terminate */
	for(i=0; i < NumProcs; i++) {
		ret = pthread_join(threads[i], NULL);
		assert(ret == 0);
	}

	/* compute the result */
	mix_sig = sig[0];
	for(i = 1; i < NumProcs ; i++) {
		mix_sig = mix(sig[i], mix_sig);
	}
	global_sig = mix(global_sig, mix_sig);

	/* end of parallel phase */

	/* ************************************************************
	 * print results
	 *  1. mix_sig  : deterministic race?
	 *  2. &mix_sig : deterministic stack layout?
	 *  3. malloc   : deterministic heap layout?
	 * ************************************************************ */
	/*PRINTF("\n\nShort signature: %08x @ %p @ %p\n\n\n",
				 mix_sig, &mix_sig, (void*)malloc(PAGE_SZ/5));*/
	PRINTF("\n\nShort signature: %08x @ %p @ %p\n\n\n",
				 global_sig, &mix_sig, (void*)malloc(PAGE_SZ/5));
	fflush(stdout);
	usleep(5);

	pthread_mutex_destroy(&threadLock);
	pthread_attr_destroy(&attr);

	return 0;
}

/**
 * client_net_sync --
 *
 *   Synchronize with the server; should be called at the end of each local
 *   round. Upon accepting our connection, the server responds with a key we
 *   should XOR with our sig array. The key is derived from the logical time of
 *   our connection, as well as the order the client connections are accepted.
 */
int client_net_sync(void)
{
	unsigned int key;
	int i;

	PRINTF("  Synchronizing with the server...\n");
	int fd = connect_to(server, port);
	assert(fd >= 0);

	writen(fd, (char *)&global_sig, sizeof global_sig);
	readn(fd, (char *)&key, sizeof key);
	close(fd);

	PRINTF("    Got key %x\n", key);
	PRINTF("    Updating our sig...\n");
	for (i = 0; i < sizeof(sig)/sizeof(sig[0]); i++)
		sig[i] ^= key;
	PRINTF("    Done.\n");

	return 0;
}

int client_main(void)
{
	int i, round, fd, go;

	/* 
	 * Initialize the mix array
	 */
	for(i = 0; i < MAX_ELEM; i++)
		m[i].value = mix(i,i);

	/*
	 * Barrier for the other programs
	 */
	PRINTF("Waiting for go message...\n");
	fd = connect_to(server, port);
	readn(fd, (char *)&go, sizeof go);
	close(fd);
	PRINTF(" ... done\n");

	/*
	 * Perform each round
	 */
	for (round = 0; round < nrounds; round++) {
		PRINTF("Beginning round %d of %d...\n", round+1, nrounds);

		/*
		 * Perform our local stress test
		 */
		client_local_round();

		/*
		 * Synchronize with the server
		 */
		client_net_sync();
	}

	return 0;
}

int
main(int argc, char* argv[])
{
	int            curopt;

	/*
	 * Parse the command line arguments 
	 */
	while ((curopt = getopt(argc, argv, "p:s:c:n:m:r:")) != -1) {
		switch (curopt) {
		case 'p': port = atoi(optarg); break;
		case 's': server = optarg; serverMode = 0; break;
		case 'c': numClients = atoi(optarg); break;
		case 'n': NumProcs = atoi(optarg); break;
		case 'm': MaxLoop = atoi(optarg); break;
		case 'r': nrounds = atoi(optarg); break;
		}
	}

	/*
	 * Show our configuration
	 */
	PRINTF("%s mode, addr %s, port %d, nclients %d, nrounds %d\n", serverMode ?
	       "Server" : "Client", server, port, numClients, nrounds);
	PRINTF("nprocs %d, maxloop %d\n", NumProcs, MaxLoop);

	if (serverMode) {
		PRINTF("Entering server mode\n");
		server_main();

	} else {
		PRINTF("Entering client mode\n");
		client_main();
	}

	return 0;
}

