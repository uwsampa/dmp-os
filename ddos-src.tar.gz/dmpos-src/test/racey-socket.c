/*
 * RACEY: a program print a result which is very sensitive to the
 * ordering between processors (races).
 *
 * It is important to "align" the short parallel executions in the
 * simulated environment. First, a simple barrier is used to make sure
 * thread on different processors are starting at roughly the same time.
 * Second, each thread is bound to a physical cpu. Third, before the main
 * loop starts, each thread use a tight loop to gain the long time slice
 * from the OS scheduler.
 *
 * Author: Min Xu <mxu@cae.wisc.edu>
 * Main idea: Due to Mark Hill
 * Created: 09/20/02
 *
 * Compile (on Solaris for Simics) :
 *   cc -mt -o racey racey.c magic.o
 * (on linux with gcc)
 *   gcc -m32 -lpthread -o racey racey.c
 *
 * DMP CHANGES:
 * - PHASE_MARKER is removed
 * - ProcessorIds is removed
 * - MaxLoop is an optional command line parameter
 * - Can spawn 32 threads (previous max was 15)
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <unistd.h>
#include <assert.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <poll.h>
#include <time.h>
#include <sys/time.h>

#define MAX_ELEM 64
#define PAGE_SIZE (1 << 10)

#define PRIME1   103072243
#define PRIME2   103995407

int SLACK = 100;
int MaxLoop = 50000;
int NumProcs;
unsigned MyId;

char *hosts[33];
int ports[33];

int listenSock;
int channels[33];
int closed[33];

/**
 * listen_on(port) --
 *
 *   Create a listening socket on the provided port.
 *
 *   Parameters:
 *     port  -- The port to begin listening on
 *
 *   Returns:
 *     The listening socket fd on success or -1 on error
 */
static int listen_on(uint16_t port)
{
        int ret, sockfd;
        struct sockaddr_in sin;
	int yes = 1;
 
        sockfd = socket(AF_INET, SOCK_STREAM, 0); 
        if (sockfd < 0)
                goto err_ret;

	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);
 
        memset(&sin, 0, sizeof sin);
        sin.sin_family      = AF_INET;
        sin.sin_port        = htons(port);
        sin.sin_addr.s_addr = INADDR_ANY;
 
        ret = bind(sockfd, (struct sockaddr *)&sin, sizeof sin);
        if (ret < 0)
                goto err_close;
 
        ret = listen(sockfd, 10);
        if (ret < 0)
                goto err_close;
 
        return sockfd;
 
 err_close:
        close(sockfd);
 err_ret:
        return -1;
}

/**
 * connect_to(host, port) --
 *
 *   Connect to the given host and port. Connection will be retried numerous
 *   times.
 *
 *   Parameters:
 *     host  -- Hostname or IP to connect to
 *     port  -- TCP port to connect on
 *
 *   Returns:
 *     The connected socket on success or -1 on error.
 */
static int connect_to(const char *host, uint16_t port)
{
        int ret, sockfd;
        int attempt;
        struct addrinfo *res = NULL, hints;
        char portstr[32];
	int yes = 1;

	/*
 
        memset(&hints, 0, sizeof hints);
        hints.ai_family   = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
 
        snprintf(portstr, sizeof portstr, "%d", port);
 
        ret = getaddrinfo(host, portstr, &hints, &res);
        if (ret != 0)
                goto err_ret;
	*/

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0)
                goto err_free;

	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

	struct sockaddr_in sin;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port   = htons(port);
	inet_aton(host, &sin.sin_addr.s_addr);
 
        for (attempt = 0; attempt < 16; attempt++) {
		uint64_t j;
		//usleep(500000 * attempt);
                for (j = 0; j < 5000000 * attempt; j++)
			/* spin */;

                //ret = connect(sockfd, res->ai_addr, res->ai_addrlen);
                ret = connect(sockfd, (struct sockaddr *)&sin, sizeof(sin));
                if (ret >= 0)
                        break;
        }
 
        if (ret < 0)
                goto err_close;
 
        //freeaddrinfo(res);
        return sockfd;
 
 err_close:
        close(sockfd);
 err_free:
        //freeaddrinfo(res);
 err_ret:
        return -1;
}

/**
 * writen --
 *
 *   Write exactly n bytes of a buffer to an fd.
 *
 *   Parameters:
 *       fd   -- Fd to write the buffer to
 *       buf  -- Pointer to beginning of buffer
 *       n    -- Number of bytes to write
 *
 *   Returns:
 *       Number of bytes actually written; less than n indicates failure
 */
int writen(int fd, void *_buf, int n)
{
	int left = n, sofar = 0, last = 0;
	char *buf = (char *)_buf;

	while (left > 0) {
		if ((last = write(fd, buf + sofar, left)) < 0) {
			sofar = last;
			break;
		}
 
		if (last == 0)
			break;
 
		sofar += last;
		left  -= last;
	}
 
	return sofar;
}
 
/**
 * readn --
 *
 *   Read exactly n bytes from an fd
 *
 *   Parameters:
 *       fd   -- Fd to read from
 *       buf  -- Pointer to beginning of buffer
 *       n    -- Number of bytes to read
 *
 *   Returns:
 *       Number of bytes actually read; less than n indicates failure
 */
int readn(int fd, void *_buf, int n)
{
	int left = n, sofar = 0, last = 0;
	char *buf = (char *)_buf;

	while (left > 0) {
		char *dest = (buf + sofar);
 
		if ((last = read(fd, dest, left)) < 0) {
			perror("read failed");
			sofar = last;
			break;
		}
 
		if (last == 0)
			break;
 
		sofar += last;
		left  -= last;
	}
 
	return sofar;
}

/**
 * timeval_diff(s, e, res) --
 *
 *   Compute the difference in two timeval structs, storing the result in the
 *   provided timeval struct.
 *
 *   Parameters:
 *     s    -- Starting time
 *     e    -- Ending time
 *     res  -- Where to store the resulting difference
 *
 *   Returns:
 *     0 on success, -1 on failure.
 */
int timeval_diff(struct timeval *s, struct timeval *e, struct timeval *res)
{
	if (res == NULL)
		return -1;
 
	res->tv_usec = e->tv_usec - s->tv_usec;
	res->tv_sec  = e->tv_sec - s->tv_sec;
 
	if (s->tv_usec > e->tv_usec)
	{
		res->tv_usec += 1000000;
		res->tv_sec--;
	}
 
	return 0;
}
 
/**
 * timeval_diff_ms(s, e) --
 *
 *   Compute the difference in two timeval structs, returning the result as the
 *   number of milliseconds elapsed between the two values.
 *
 *   Parameters:
 *     s  -- Starting time
 *     e  -- Ending time
 * 
 *   Returns:
 *     The difference in ms between the two times in ms
 */
int timeval_diff_ms(struct timeval *s, struct timeval *e)
{
	struct timeval tmp;
	timeval_diff(s, e, &tmp);
	return 1000 * tmp.tv_sec + (tmp.tv_usec / 1000);
}

/* the mix function */
unsigned mix(unsigned i, unsigned j) {
	return (i + j * PRIME2) % PRIME1;
}

void mixIntoBuffer(int *num, int buffer[16])
{
	int k;
	for (k = 0; k < sizeof(buffer)/sizeof(*buffer); ++k) {
		*num = mix(*num, k * PRIME1);
		*num = mix(*num, PRIME2 / (k+1));
		buffer[k] = *num;
	}
}

void mixFromBuffer(int *num, int buffer[16], int source)
{ 
	int k;
	for (k = 0; k < sizeof(buffer)/sizeof(*buffer); ++k) {
		*num = mix(*num, buffer[k]);
	}
	*num = mix(*num, source);
}

void makeCloseBuffer(int buffer[16]) {
	int k;
	for (k = 0; k < sizeof(buffer)/sizeof(*buffer); ++k) {
		buffer[k] = -1;
	}
}

int isCloseBuffer(int buffer[16]) {
	int k;
	for (k = 0; k < sizeof(buffer)/sizeof(*buffer); ++k) {
		if (buffer[k] != -1)
			return 0;
	}
	return 1;
}

void recvBufferFromOne(int *num, int source) {
	int buffer[16];

	if (closed[source])
		return;

	if (readn(channels[source], buffer, sizeof buffer) < sizeof buffer) {
		perror("recv");
		return;
	}

	if (isCloseBuffer(buffer)) {
		closed[source] = 1;
	} else {
		mixFromBuffer(num, buffer, source);
	}
}

int recvBufferFromAny(int *num) {
	struct pollfd fds[33];
	int i, k, r, r2;

	/* Is there a pending message from any other proc? */
	memset(fds, 0, sizeof fds);
	for (i=0, k=0; i < NumProcs; ++i) {
		if (i == MyId)
			continue;
		fds[k].fd = channels[i];
		fds[k].events = POLLIN;
		++k;
	}

	if ((r = poll(fds, k, 0)) < 0) {
		perror("poll");
		return r;
	}
	//fprintf(stderr, "Poll returned %d\n", r);

	r2 = r;

	/* Read one buffer from each pending fd */
	for (i=0; i < k && r > 0; ++i) {
		if ((fds[i].revents & POLLIN) != 0) {
			//fprintf(stderr, "%d receiving from %d\n", *num, i);
			recvBufferFromOne(num, (i < MyId) ? i : i+1);
			--r;
		}
	}

	return r2;
}

int MixItUp()
{
	int buffer[16];
	int num = MyId;
	int slack = SLACK;
	int i, r;

	/*
	 * main loop:
	 *
	 * Send up to MaxLoop messages.
	 * Stop to recv every 'SLACK' iterations.
	 */
	for (i = 0; i < MaxLoop; ++i, --slack) {
		int target = num % NumProcs;
		if (target == MyId)
			target = (target+1) % NumProcs;

		mixIntoBuffer(&num, buffer);
		if (writen(channels[target], buffer, sizeof buffer) < sizeof buffer) {
			perror("send");
		}

		//fprintf(stderr, "i %d maxloop %d slack %d\n", i, MaxLoop, slack);
		if (slack == 0) {
			//fprintf(stderr, "Receiving from any...\n");
			while ((r = recvBufferFromAny(&num)) > 0)
				/* spin */;
			slack = SLACK;
		}
	}

	/*
	 * Send "close" messages.
	 */
	makeCloseBuffer(buffer);

	for (i=0; i < NumProcs; ++i) {
		if (i == MyId)
			continue;
		if (writen(channels[i], buffer, sizeof buffer) < sizeof buffer) {
			perror("send");
		}
	}

	/*
	 * Flush buffers.
	 */
	for (i=0; i < NumProcs; ++i) {
		if (i == MyId)
			continue;
		while (!closed[i])
			recvBufferFromOne(&num, i);
	}

	/*
	 * Everyone sends their final 'num' to p0, who does a mix.
	 */
	if (MyId != 0) {
		if (writen(channels[0], &num, sizeof num) < sizeof num) {
			perror("send");
		}

	} else {
		for (i=1; i < NumProcs; ++i) {
			int k;
			if (readn(channels[i], &k, sizeof k) < sizeof k) {
				perror("recv");
				exit(1);
			}
			num = mix(num, k);
		}
	}

	return num;
}

int main(int argc, char* argv[])
{
	int                mix_sig, i, ms;
	int               *pids;
	struct sockaddr_in sa;
	struct timeval     before, after;
	int curopt;

	/* Parse arguments */
	if(argc < 4) {
		fprintf(stderr, "%s <numServers> <maxLoop> <myId> <srv1-ip> <src1-port> ...\n", argv[0]);
		exit(1);
	}

	while ((curopt = getopt(argc, argv, "s:")) != -1) {
		switch (curopt) {
		case 's': SLACK = atoi(optarg); break;
		}
	}

	NumProcs = atoi(argv[optind]);
	MaxLoop  = atoi(argv[optind+1]);
	MyId     = atoi(argv[optind+2]);

	assert(0 < NumProcs && NumProcs <= 32);
	assert(0 < MaxLoop);
	assert(0 <= MyId && MyId < NumProcs);

	if ((argc - optind) < 2*NumProcs + 3) {
		fprintf(stderr, "%s <numServers> <maxLoop> <myId> <srv1-ip> <src1-port> ...\n", argv[0]);
		exit(1);
	}

	/* Read listener ips/ports */
	for (i = 0; i < NumProcs; i++) {
		int k = 3 + i*2;
		hosts[i] = argv[optind + k];
		ports[i] = atoi(argv[optind + k+1]);
	}

	/* Open listener socket */
	if ((listenSock = listen_on(ports[MyId])) < 0) {
		perror("listen_on");
		exit(1);
	}

	/************************************************/
	/********** Setup N-to-N connections ************/
	/************************************************/

	/* Connect to all procs with id < MyId */
	for (i = 0; i < MyId; i++) {
		int sock, len, id;

		//printf("%d connecting to %d\n", MyId, i);
		if ((sock = connect_to(hosts[i], ports[i])) < 0) {
			perror("connect");
			exit(1);
		}
		//printf("%d connected to %d\n", MyId, i);
		channels[i] = sock;

		//printf("%d sending id to %d\n", MyId, i);
		if (writen(sock, &MyId, sizeof MyId) < sizeof MyId) {
			perror("send");
			exit(1);
		}
		//printf("%d done sending id to %d\n", MyId, i);
	}
	//printf("%d done connecting\n", MyId);

	/* Wait for connection from all procs with id > MyId */
	//printf("%d waiting for connections...\n", MyId);
	for (i = MyId+1; i < NumProcs; i++) {
		int sock, len, id;
		memset(&sa, 0, sizeof sa);
		len = sizeof sa;

		//printf("%d waiting for %d...\n", MyId, i);
		if ((sock = accept(listenSock, (struct sockaddr*)&sa, &len)) < 0) {
			perror("accept");
			exit(1);
		}

		//printf("	%d got %d\n", MyId, i);
		if (readn(sock, &id, sizeof id) < sizeof id) {
			perror("recv");
			exit(1);
		}
		channels[id] = sock;
	}
	//printf("%d done accepting\n", MyId);

	/************************************************/
	/******************** Exec **********************/
	/************************************************/

	//printf("%d Execing!\n", MyId);
	gettimeofday(&before, NULL);
	mix_sig = MixItUp();
	gettimeofday(&after, NULL);

	ms = timeval_diff_ms(&before, &after);
	printf("\nSignature: %08x\n", mix_sig);
	printf("Time: %d.%03d s\n", ms/1000, ms%1000);
	fflush(stdout);

	return 0;
}

