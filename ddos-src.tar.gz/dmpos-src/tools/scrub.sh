#!/bin/bash

# Simple script to do a quick sanity check on logs (to make sure they're
# not munged) and to remove non-deterministic values that make comparing
# diffs more tedious (for example, physical addresses of pages). Unless
# the -d option is specified, scrub.sh assumes the log is in syslog format.
# Otherwise, it expects the output of dmesg.
#
# Produces the clean version on stdout.
#
# Usage: ./scrub.sh [-d] <log file>
# Options:
#     -d    Parse `dmesg' output instead of syslog output
#

MODE=syslog
FILE=
A=$(mktemp /tmp/scrub.XXXXXXXXXXXX)
B=$(mktemp /tmp/scrub.XXXXXXXXXXXX)

function do_exit() {
	if [ ! -z "$A" ]; then rm -f $A; fi
	if [ ! -z "$B" ]; then rm -f $B; fi
	exit $1
}

function usage() {
	echo "Usage: $0 [opts] file"
	do_exit 1
}

function do_sed() {
	EXP=$1
	A=$2
	B=$3

	sed -e "$EXP" $A > $B
	cp $B $A
}

#
# Make sure the beginning of each line looks sensible; if the log is munged
# for some reason, this heuristic should catch it.
#
function check_file() {
	if [ "$MODE" = "syslog" ]; then
		exp="^$(date +%b)"
	else
		exp="^\[[^]]*] "
	fi

	ct=$(grep -v "\($exp\|^$\)" $1 | wc -l)
	if [ "$ct" -ne "0" ]; then
		echo "Munged log" >&2
		#grep --color -v $exp $1
		do_exit 1
	fi

	ct=$(grep "ERROR" $1 | wc -l)
	if [ "$ct" -ne "0" ]; then
		echo "Errors occurred during execution:" >&2
		grep --color "ERROR" $1 >&2
		do_exit 1
	fi
}

#
# Get rid of all the leading junk on the line
#
function trim_headings() {
	do_sed "s/^[^]]*] //" $1 $2
}

#
# Do the actual value scrubbing. Expand as necessary.
#
function trim_body() {
	do_sed "/MaxOverflow/d" $1 $2
	do_sed "/^$/d" $1 $2

	do_sed "s/\(CPU#\)[0-9]\+/\1/g" $1 $2

	# scrub PGD stuff
	do_sed "s/\(pgd=\)[0-9a-f]\+/\1<scrubbed>/g" $1 $2
}

while getopts ":d" opt; do
	case $opt in
	d) MODE=dmesg;;
	esac
done
shift $(expr $OPTIND - 1)

FILE=$1

if [ -z "$FILE" ]; then
	usage
fi

cp $FILE $A
check_file $A

trim_headings $A $B
trim_body $A $B

cat $A
do_exit 0
