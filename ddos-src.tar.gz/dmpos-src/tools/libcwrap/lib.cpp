//
// Wrapper for libc functions
//

#include <assert.h>
#include <dlfcn.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <execinfo.h>

#include "dmp.h"

// pthreads
static int (*real_pthread_mutex_lock)(pthread_mutex_t*) = NULL;
static int (*real_pthread_mutex_trylock)(pthread_mutex_t*) = NULL;
static int (*real_pthread_mutex_unlock)(pthread_mutex_t*) = NULL;

static int (*real_pthread_rwlock_rdlock)(pthread_rwlock_t*) = NULL;
static int (*real_pthread_rwlock_wrlock)(pthread_rwlock_t*) = NULL;
static int (*real_pthread_rwlock_unlock)(pthread_rwlock_t*) = NULL;

static int (*real_pthread_cond_wait)(pthread_cond_t*, pthread_mutex_t*) = NULL;
static int (*real_pthread_cond_broadcast)(pthread_cond_t*) = NULL;
static int (*real_pthread_cond_signal)(pthread_cond_t*) = NULL;

static int (*real_pthread_barrier_wait)(pthread_barrier_t*) = NULL;

//--------------------------------------------------------------------
// Wrappers
//--------------------------------------------------------------------

extern "C" {

int pthread_mutex_unlock(pthread_mutex_t* lock)
{
	int r = real_pthread_mutex_unlock(lock);
	dmp_maybe_endquantum();
	return r;
}

int pthread_rwlock_unlock(pthread_rwlock_t* lock)
{
	int r = real_pthread_rwlock_unlock(lock);
	dmp_maybe_endquantum();
	return r;
}

int pthread_rwlock_unlock(pthread_rwlock_t* lock)
{
	int r = real_pthread_rwlock_unlock(lock);
	dmp_maybe_endquantum();
	return r;
}

int pthread_cond_wait(pthread_cond_t* cond, pthread_mutex_t* lock)
{
	int r = real_pthread_cond_wait(cond, lock);
	dmp_maybe_endquantum();
	return r;
}

int pthread_barrier_wait(pthread_barrier_t* barrier)
{
	int r = real_pthread_barrier_wait(barrier);
	dmp_maybe_endquantum();
	return r;
}

}  // extern "C"

//--------------------------------------------------------------------
// At startup
//--------------------------------------------------------------------

#define LoadSym(sym)                                          \
  do {                                                        \
    real_##sym = (typeof(real_##sym)) dlsym(RTLD_NEXT, #sym); \
    char* msg = dlerror();                                    \
    if ( msg != NULL ) {                                      \
      fprintf(stderr, "dlsym() failed : %s\n", msg);          \
      fflush(stderr);                                         \
    }                                                         \
  } while(0)

static void InitWrapper()
{
	LoadSym(pthread_mutex_unlock);
	LoadSym(pthread_rwlock_unlock);
	//LoadSym(pthread_cond_wait);
	LoadSym(pthread_barrier_wait);
}

// Constructor
namespace {
struct Initializer {
  Initializer() { InitWrapper(); }
};
}

static Initializer Initializer;
