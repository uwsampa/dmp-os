#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sched.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

int run(void *_arg)
{
	char **argv = _arg;

	setreuid(getuid(), getuid());
	setregid(getgid(), getgid());

	if (execvp(argv[0], argv) < 0)
		perror("execvp");

	return -1;
}

int main(int argc, char *argv[])
{
	struct rlimit stack_size;
	char *stack = NULL;
	pid_t pid;
	int ret;

	if (getrlimit(RLIMIT_STACK, &stack_size) != 0) {
		perror("getrlimit");
		abort();
	}

	stack = malloc(stack_size.rlim_cur);
	assert(stack);

	pid = clone(run, stack + stack_size.rlim_cur - 1, CLONE_NEWPID, argv + 1);
	if (pid < 0) {
		perror("clone");
	} else {
		printf("Waiting for task %d\n", pid);
		if (waitpid(pid, &ret, __WCLONE) < 0)
			perror("wait");
		printf("%d Done. (ret %d)\n", pid, WIFEXITED(ret) ? WEXITSTATUS(ret) : -1);
	}

	return 0;
}
