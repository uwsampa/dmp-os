/**
 * dmpshim.cpp --
 *
 *   The DMP shim process. The behavior of this shim (e.g., record, replay,
 *   detfs, etc.) is controlled via command line parameters described below.
 *
 *   NOTE: by the time the shim is invoked, we have already been attached to
 *   the DMP thread, and that thread is stopped.
 */

#include <errno.h>
#include <getopt.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syscall.h>
#include <sys/user.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdint.h>

#include "dmp.h"
#include "basicshim.h"
#include "recplayshim.h"

using namespace DMP;

/******************************************************************************
 * Global Values                                                              *
 ******************************************************************************/

/* 
 * Default number of logical ticks for determinstic file operations that have
 * not been given explicit durations
 */
#define DEFAULT_TIME 50

#define USAGE "\
Usage: %s [opts]                                                          \n\
Options:                                                                  \n\
   -F PATH                  Log shim messages to this file                \n\
                                                                          \n\
   -p PATH[,TIMING], --detpath=PATH[,TIMING]                              \n\
                            Add a determistic path (all files below this  \n\
                            point in the directory hieararchy are treated \n\
                            deterministically as well)                    \n\
                                                                          \n\
   -f FD[,TIMING], --detfd=FD[,TIMING]                                    \n\
                            Treat the given file descriptor               \n\
                            deterministcally, with the given timing       \n\
                                                                          \n\
   -m MANIFEST, --manifest=MANIFEST                                       \n\
                            Set the manifest file. See note below for     \n\
                            more information on format of this file       \n\
                                                                          \n\
   -n MAXDRIFT, --max-drift=MAXDRIFT                                      \n\
                            The largest difference in global time allowed \n\
                            before two DPGs must sync at a barrier        \n\
                                                                          \n\
                                                                          \n\
   --master=MASTER          Designate MASTER as the master node in the    \n\
                            distributed system                            \n\
                                                                          \n\
   --mport=PORT             Port that the master is listening for control \n\
                            channel connections on                        \n\
                                                                          \n\
   --detports=PORTS         Comma-separated list of deteministic ports    \n\
                                                                          \n\
   -r LOGFILE, --record=LOGFILE                                           \n\
                            Create a record shim, and use LOGFILE as the  \n\
                            basename of logs produced. Each thread gets   \n\
                            its own file, with a numeric suffix indicating\n\
                            its creation order.                           \n\
                                                                          \n\
   --replay                 Replay from the given log file                \n\
                                                                          \n\
   --reexec-detnet          Re-execute deterministic network communication\n\
                            rather than relying on contents in log when   \n\
                            recording/replaying.                          \n\
                                                                          \n\
   -s, --task-summary       Print an execution summary at termination     \n\
                                                                          \n\
   -z, --compress           Enable compression of the record logs         \n\
                                                                          \n\
                                                                          \n\
   TIMING format:                                                         \n\
       read[,write[,open[,close[,generic]]]]                              \n\
                                                                          \n\
       Where each value specifies the number of logical                   \n\
       ticks the corresponding operation takes to                         \n\
       complete.                                                          \n\
                                                                          \n\
                                                                          \n\
   MANIFEST format:                                                       \n\
       <host> <ports> <cmd>                                               \n\
"

/*
 * global_options contains the values of various program options. It is
 * initialized in main and updated based on the command line arguments in
 * parseCommandLine
 */
static struct {
	string                   logfile;
	char                    *shim_log_file; /* Used for recording shim messages */
	bool                     compressed;
	bool                     dosummary;
	bool                     replay;
	bool                     reexec_detnet;
	uint64_t                 max_drift;    /* Max drift in global time; 0 to disable */
	string                   manifest;
	string                   master;
	string                   detports;
	uint16_t                 mport;
	map<int, FileTimingInfo> detfds;
	map<string, FileTimingInfo> detpaths;
} global_options;

/**
 * Commandline parsing --
 *
 *   See the definition of USAGE for a complete description of these options
 */
enum option_t {
	OPT_DETPATH = 0x100, OPT_DETFD, OPT_RECORD, OPT_SUMMARY, OPT_COMPRESS,
	OPT_REPLAY, OPT_NODE, OPT_MANIFEST, OPT_MAX_DRIFT, OPT_MASTER,
	OPT_MPORT, OPT_DETPORTS, OPT_REEXEC_NET,
};

struct option options[] = {
	{ "detpath",        required_argument, NULL, OPT_DETPATH    },
	{ "detfd",          required_argument, NULL, OPT_DETFD      },
	{ "record",         required_argument, NULL, OPT_RECORD     },
	{ "task-summary",   no_argument,       NULL, OPT_SUMMARY    },
	{ "compress",       no_argument,       NULL, OPT_COMPRESS   },
	{ "replay",         no_argument,       NULL, OPT_REPLAY     },
	{ "detnode",        required_argument, NULL, OPT_NODE       },
	{ "manifest",       required_argument, NULL, OPT_MANIFEST   },
	{ "max-drift",      required_argument, NULL, OPT_MAX_DRIFT  },
	{ "master",         required_argument, NULL, OPT_MASTER     },
	{ "mport",          required_argument, NULL, OPT_MPORT      },
	{ "detports",       required_argument, NULL, OPT_DETPORTS   },
	{ "reexec-detnet",  no_argument,       NULL, OPT_REEXEC_NET },
	{ NULL,             0,                 NULL, 0              }
};

/******************************************************************************
 * Forward Declarations                                                       *
 ******************************************************************************/
static void usage(const char *prog);
static void parseCommandLine(int argc, char *argv[]);
static int  parseFileTimingInfo(char *opt, char **path, FileTimingInfo *timing);
static int  parseDetPath(char *opt);
static int  parseDetFd(char *opt);
static uint32_t parseDetNode(char *addr);
static void initShim(BasicShim *shim);

/******************************************************************************
 * Main                                                                       *
 ******************************************************************************/
int main(int argc, char *argv[])
{
	BasicShim* shim = NULL;
	RecPlayTab table;

	/* Initialize and parse command line */
	global_options.compressed = false;
	global_options.dosummary  = false;
	global_options.reexec_detnet = false;
	global_options.shim_log_file = NULL;
	global_options.master     = "";
	global_options.detports   = "";
	global_options.mport      = 5000;
	global_options.max_drift  = 0;
	parseCommandLine(argc, argv);

	if (global_options.reexec_detnet && global_options.logfile == "") {
		SHIM_ERR("Specifying --reexec-detnet without a RecPlayShim is non-sensical.\n");
		return 0;
	}

	set_shim_log(global_options.shim_log_file);	

	/* Create the appropriate shim */
	if (!global_options.logfile.empty()) {
		SHIM_LOG("Creating a new %s%s shim\n",
			global_options.manifest == "" ? "" : "distributed ",
			global_options.replay ? "replay" : "record");

		shim = new RecPlayShim(NULL, 0, global_options.logfile,
				       &table, global_options.replay,
				       global_options.compressed,
				       global_options.reexec_detnet);

	} else {
		SHIM_LOG("Creating a new basic shim\n");
		shim = new BasicShim(NULL, 0, global_options.reexec_detnet);
	}

	/* Start the shim */
	SHIM_LOG("Initializing the shim\n");
	initShim(shim);
	SHIM_LOG("Shim initialize @%p\n", shim);
	shim->set_max_drift(global_options.max_drift);
	//shim->set_max_drift(100);

	SHIM_LOG("Entering main loop\n");
	shim->loop();
	delete shim;
	SHIM_LOG("Leaving main loop\n");

	/* Terminate once all threads have died */
	WaitForThreadsToDie(global_options.dosummary);
	SHIM_LOG("All done.\n");
	return 0;
}

/**
 * usage --
 *
 *   Display the program's usage summary and exit.
 *
 *   Returns:
 *       Does not return
 */
static void usage(const char *prog)
{
	fprintf(stderr, USAGE, prog);
	exit(1);
}

/**
 * parseCommandLine --
 *
 *   Parse the command line arguments, and populate the fields of
 *   global_options with the appropriate values.
 *
 *   Parameters:
 *       argc  -- Number of command line arguments
 *       argv  -- Array of NULL-terminated command line options
 *
 *   Modifies:
 *       Updates global_options based on command line options
 *
 *   Returns:
 *       Nothing
 */
static void parseCommandLine(int argc, char *argv[])
{
	int opt;
	
	/* Stops at first unknown arg */
	while ((opt = getopt_long(argc, argv, "p:F:f:sr:zm:n:", options, NULL)) != -1) {
		switch (opt) {
		case 'p': case OPT_DETPATH:
			parseDetPath(optarg);
			break;
		case 'F':
			global_options.shim_log_file = optarg;
			break;
		case 'f': case OPT_DETFD:
			parseDetFd(optarg);
			break;
		case 's': case OPT_SUMMARY:
			global_options.dosummary = true;
			break;
		case 'r': case OPT_RECORD:
			global_options.logfile = string(optarg);
			break;
		case OPT_REPLAY:
			global_options.replay = true;
			break;
		case OPT_REEXEC_NET:
			global_options.reexec_detnet = true;
			break;
		case 'm': case OPT_MANIFEST:
			global_options.manifest = string(optarg);
			break;
		case 'n': case OPT_MAX_DRIFT:
			global_options.max_drift = atol(optarg);
			break;
		case OPT_MASTER:
			global_options.master = string(optarg);
			break;
		case OPT_MPORT:
			global_options.mport = atoi(optarg);
			break;
		case OPT_DETPORTS:
			global_options.detports = string(optarg);
			break;
		case 'z': case OPT_COMPRESS:
			global_options.compressed = true;
			break;
		default:
			fprintf(stderr, "Unrecognized option: %x (%c)", opt, opt);
			usage(argv[0]);
		}
	}

	// Rest of the commandline should be empty.
	if (optind != argc) {
		fprintf(stderr, "Extra stuff at end of command line...\n");
		usage(argv[0]);
	}
}

/**
 * parseFileTimingInfo --
 *  
 *   Parse a TIMING string as defined in the usage message.
 *
 *   Parameters:
 *       opt    -- The option value, as passed on the command line
 *       path   -- (out) Points to the path affected on return
 *       timing -- (out) Populated with timing information on return
 *
 *   Returns:
 *       0 on success, < 0 on failure
 */
static int parseFileTimingInfo(char *opt, char **path, FileTimingInfo *timing)
{
	char *tmp, *rdtime, *wrtime, *optime, *cltime, *gtime;

	if (!opt || !path || !timing)
		return -EINVAL;

	*path  = strtok_r(opt,  ",", &tmp);
	rdtime = strtok_r(NULL, ",", &tmp);
	wrtime = strtok_r(NULL, ",", &tmp);
	optime = strtok_r(NULL, ",", &tmp);
	cltime = strtok_r(NULL, ",", &tmp);
	gtime  = strtok_r(NULL, ",", &tmp);

	if (!path)
		return -EINVAL;

	timing->read    = rdtime ? atoi(rdtime) : DEFAULT_TIME;
	timing->write   = wrtime ? atoi(wrtime) : DEFAULT_TIME;
	timing->open    = optime ? atoi(optime) : DEFAULT_TIME;
	timing->close   = cltime ? atoi(cltime) : DEFAULT_TIME;
	timing->generic = gtime  ? atoi(gtime)  : DEFAULT_TIME;

	return 0;
}

/**
 * parseDetPath --
 *
 *   Returns:
 *       0 on success, < 0 on failure
 */
static int parseDetPath(char *opt)
{
	FileTimingInfo timing;
	char *path, *cpath;

	parseFileTimingInfo(optarg, &path, &timing);

	cpath = realpath(path, NULL);
	assert(cpath);

	global_options.detpaths[cpath] = timing;
	free(cpath);

	return 0;
}

/**
 * parseDetFd --
 *
 *   Returns:
 *       0 on success, < 0 on failure
 */
static int parseDetFd(char *opt)
{
	FileTimingInfo timing;
	char *path;

	parseFileTimingInfo(optarg, &path, &timing);
	int fd = atoi(path);
	if (fd < 0)
		return -EINVAL;

	global_options.detfds[fd] = timing;
	return 0;
}

/**
 * parseDetNode --
 *
 */ /*
static uint32_t parseDetNode(char *addr)
{
	struct addrinfo *res;
	struct sockaddr_in *sin;
	uint32_t address;
	int err;

	if ((err = getaddrinfo(addr, NULL,  NULL, &res)) < 0) {
		fprintf(stderr, "Couldn't resolve %s: %s\n", addr, gai_strerror(err));
		return -1;
	}
	
	sin = (struct sockaddr_in *)res->ai_addr;
	address = sin->sin_addr.s_addr;

	printf("Got: %s -> %s -> %#x\n", addr, inet_ntoa(sin->sin_addr), address);
	global_options.detnodes[address] = true;

	freeaddrinfo(res);
	return address;
} */

/**
 * initShim --
 *
 *   Prepare a shim for use; this includes adding the deterministic file
 *   descriptors specified on the command line, as well as specifing the PID of
 *   the inital DMP task.
 *
 *   Parameters:
 *       shim  -- The shim to initialize
 *
 *   Returns:
 *       None
 */
static void initShim(BasicShim *shim)
{
	char *pid, *tmp, *tok, *ports;

	/* Tell shim which paths are deterministic */
	for (map<string,FileTimingInfo>::const_iterator
	                               iter  = global_options.detpaths.begin();
				       iter != global_options.detpaths.end();
				       iter++)
		shim->add_deterministic_path(iter->first.c_str(), iter->second);

	/* Tell shim which file descriptors are determinstic */ 
	for (map<int,FileTimingInfo>::const_iterator
	                               iter  = global_options.detfds.begin();
	                               iter != global_options.detfds.end();
	                               iter++)
		shim->add_deterministic_fd(iter->first, iter->second);

	/* Read the det ports -- must be called before add_manifest */
	ports = strdup(global_options.detports.c_str());
	for (tok = strtok_r(ports, ",", &tmp); tok != NULL; tok = strtok_r(NULL, ",", &tmp))
		shim->add_det_ports(tok);
	free(ports);

	/* Read the manifest file, if provided */
	if (global_options.manifest != "")
		shim->add_manifest(global_options.manifest);

	else if (global_options.master != "")
		shim->set_master_node(global_options.master, global_options.mport);

	// Get the pid from environ
	if ((pid = getenv("INITIAL_DMP_PID")) != NULL) {
		shim->_dmp_pid = atoi(pid);
		SHIM_LOG("Connecting to DMP task with pid %d\n", shim->_dmp_pid);

	} else {
		SHIM_LOG("warning: no INITIAL_DMP_PID specified\n");
	}
}
