#include <assert.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/utsname.h>
#include <termios.h>


#define TYPE_SYSCALL 0
#define TYPE_SIGNAL  1
#define TYPE_RDTSC   2


#define SIGNBIT       0x00800000
#define TYPE(full)    ((full) & 0xff)
#define SUBTYPE(full) \
	((SIGNBIT & ((full) >> 8)) ? ((full) >> 8) | (0xff << 24) : ((full) >> 8))
/**
 * rechdr --
 *   
 *   Every entry in the record log is preceded by one of these headers. The
 *   reclen field indicates how much additional event specific data follows
 *   this header.
 */
struct rechdr {
	uint64_t quantum;
	uint32_t fulltype;
	uint64_t reclen;
} __attribute__((__packed__));

/**
 * Syscall magic -- 
 *
 *   Define syscall_names to be a number -> string mapping of the system calls.
 *   NSYSCALLS is defined as the number of system calls in the list.
 */
#undef  __SYSCALL
#define __SYSCALL(a, b) [a] = #b,
const char *syscall_names[] = {
	#include <syscall.h>
};
#define NSYSCALLS (sizeof(syscall_names) / sizeof(syscall_names[0]))
#undef __SYSCALL

/**
 * Record display functions --
 *
 *   Define the list of functions responsible for displaying the details of a
 *   record entry when the verbosity is sufficiently high.
 *
 *   Each display function is pass the return value of the system call, along
 *   with a pointer to a buffer containing the rest of the record. nbytes
 *   indicates the lenght of this buffer.
 */
typedef int (*dispfn_t)(long ret, char *buffer, size_t nbytes);
#define DISPLAY(s) static int display_sys_##s(long ret, char *buffer, size_t nbytes)

DISPLAY(read);
DISPLAY(time);
DISPLAY(getpid);
DISPLAY(stat);
DISPLAY(getsockname);
DISPLAY(sysfs);
DISPLAY(getgroups);
DISPLAY(uname);
DISPLAY(poll);
DISPLAY(ioctl);
DISPLAY(recvmsg);

dispfn_t dispfns[NSYSCALLS] = {
	[SYS_read]   = display_sys_read,
	[SYS_readv]  = display_sys_read, /* Intentionally not sys_readv */
	[SYS_time]   = display_sys_time,
	[SYS_getpid] = display_sys_getpid,
	[SYS_fstat]  = display_sys_stat,
	[SYS_lstat]  = display_sys_stat,
	[SYS_stat]   = display_sys_stat,
	[SYS_getsockname] = display_sys_getsockname,
	[SYS_getpeername] = display_sys_getsockname, /* Reused */
	[SYS_sysfs]  = display_sys_sysfs,
	[SYS_getgroups] = display_sys_getgroups,
	[SYS_uname]  = display_sys_uname,
	[SYS_poll]   = display_sys_poll,
	[SYS_ioctl]  = display_sys_ioctl,
	[SYS_recvmsg] = display_sys_recvmsg,
	[SYS_recvfrom] = display_sys_read, /* Reused */
};

static struct count_t {
	int      syscallnr;    /* Position in array may change after sorting;
	                          remember what the original index was */
	int      count;
	uint64_t recsize;
} subtype_counts[NSYSCALLS+1]; /* Add one more slot for RDTSC events */


static const char *syscall_name(int idx);
static const char *event_name(char event_type);
static int readn(int fd, char *buf, int n);
static void readlog(int fd);
	
static uint64_t total_size = 0;
static int verbose = 0;

static void usage(const char *prog)
{
	fprintf(stderr, "Usage: %s <log>\n", prog);
}

static int count_cmp(void *_arg1, void *_arg2)
{
	struct count_t *arg1 = _arg1;
	struct count_t *arg2 = _arg2;
	return arg2->recsize - arg1->recsize;
}

int main(int argc, char *argv[])
{
	const char *filename;
	int logfd, i, curopt;
	struct stat sb;
	
	while ((curopt = getopt(argc, argv, "v")) != -1) {
		switch (curopt) {
		case 'v': verbose++; break;
		}
	}

	if (optind == argc) {
		usage(argv[0]);
		exit(EXIT_FAILURE);
	}

	/* Clear the count */
	memset(subtype_counts, 0, sizeof(subtype_counts));
	for (i = 0; i < NSYSCALLS; i++)
		subtype_counts[i].syscallnr = i;

	for (i = optind; i < argc; i++) {
		filename = argv[i];
		if (verbose >= 1)
			printf("Opening %s...\n", filename);

		logfd = open(filename, O_RDONLY);
		if (logfd < 0) {
			perror("open failed");
			exit(EXIT_FAILURE);
		}

		fstat(logfd, &sb);
		total_size += sb.st_size;

		readlog(logfd);
		close(logfd);
	}

	/* Sort the records in decreasing order */
	qsort(subtype_counts, NSYSCALLS, sizeof(subtype_counts[0]), count_cmp);

	printf("\nLog  summary (from %d files and %lu bytes):\n", i-optind, total_size);
	printf(  "===========================================\n");

	printf("RDTSC instructions: %d calls, %ld bytes, %.2f%%\n\n", subtype_counts[NSYSCALLS].count,
		subtype_counts[NSYSCALLS].recsize, ((float)subtype_counts[NSYSCALLS].recsize * 100.0) / (float)total_size);

	printf("%-20s %-5s %-10s %s\n", "System call", "Count", "Nbytes", "Percent");
	printf("-------------------- ----- ---------- -------\n");
	for (i = 0; i < NSYSCALLS && total_size; i++) {
		if (subtype_counts[i].count != 0) {
			printf("%-20s %-5d %-10ld %.2f%%\n", syscall_name(subtype_counts[i].syscallnr),
				subtype_counts[i].count, subtype_counts[i].recsize,
				((float)subtype_counts[i].recsize * 100.0) / (float)total_size);
		}
	}

	return 0;
}

static void readlog(int fd)
{
	struct rechdr hdr;
	uint64_t ret;
	size_t toseek, nbytes;
	char *buffer;
	int type, subtype;

	/*
	 * N.B. This currently assumes all records are syscall records. Once
	 * signals are added to the mix, this will need to be rewritten.
	 */
	while (1) {
		if (readn(fd, (char *)&hdr, sizeof(hdr)) <= 0)
			break;

		type    = TYPE(hdr.fulltype);
		subtype = SUBTYPE(hdr.fulltype);
		toseek  = hdr.reclen;
		
		if (verbose >= 2) {
			printf("Quantum: %ld, Event: %s, Subtype: %s (%d), Length: %ld ",
				hdr.quantum, event_name(type),
				syscall_name(subtype), subtype, hdr.reclen);
			
			if (type == TYPE_SYSCALL) {
				readn(fd, (char *)&ret, sizeof(ret));
				printf(" (ret: %ld)\n", ret);
				toseek -= sizeof(ret);

			} else if (type == TYPE_RDTSC) {
				readn(fd, (char *)&ret, sizeof(ret));
				printf(" (tsc: %ld)\n", ret);
				toseek -= sizeof(ret);
			}
		}

		if (type == TYPE_SYSCALL) {
			if (subtype < 0 || subtype > sizeof(subtype_counts)/sizeof(subtype_counts[0])) {
				printf("    WARNING: Subtype %d out of bounds?\n", subtype);
				printf("    WARNING: Not accounting for it\n");

			} else {
				subtype_counts[subtype].count++;
				subtype_counts[subtype].recsize += hdr.reclen + sizeof(hdr);
			}

			if (verbose >= 3) {
				/* Slurp any record that we need to */
				nbytes = toseek;
				if (nbytes > 0) {
					buffer = calloc(nbytes, 1);
					assert(buffer);
					toseek -= readn(fd, buffer, nbytes);
				} else {
					buffer = NULL;
					nbytes = 0;
				}

				if (dispfns[subtype] != NULL)
					dispfns[subtype](ret, buffer, nbytes);

				free(buffer);
			}

		} else if (type == TYPE_RDTSC) {
			subtype_counts[NSYSCALLS].count++;
			subtype_counts[NSYSCALLS].recsize += hdr.reclen + sizeof(hdr);
		}

		lseek(fd, toseek, SEEK_CUR);
	}
}

/**
 * syscall_name --
 *  
 *   Given a system call number, return its english name
 *
 *   Parameters:
 *       idx  -- System call to lookup
 *
 *   Returns:
 *       The english name of the system call, or a NULL pointer on error
 */
static const char *syscall_name(int idx)
{
	if (idx < 0 || idx >= NSYSCALLS)
		return NULL;
	else
		return syscall_names[idx];
}

/**
 * event_name --
 *  
 *   Given an event type, return its english name
 *
 *   Parameters:
 *       event_type  -- Event type to look up
 *
 *   Returns:
 *       The english name of the event
 */
static const char *event_name(char event_type)
{
	const char *events[] = {
		"SYSCALL", "SIGNAL", "RDTSC", "<UNKNOWN>"
	};
	const int numevents = sizeof(events) / sizeof(events[0]);

	if (event_type >= numevents)
		event_type = numevents - 1;

	return events[(int)event_type];
}

/**
 * readn --
 *
 *   Read exactly n bytes from an fd
 *
 *   Parameters:
 *       fd   -- Fd to read from
 *       buf  -- Pointer to beginning of buffer
 *       n    -- Number of bytes to read
 *
 *   Returns:
 *       Number of bytes actually read; less than n indicates failure
 */
static int readn(int fd, char *buf, int n)
{
	int left = n, sofar = 0, last = 0;

	while (left > 0) {
		if ((last = read(fd, buf + sofar, left)) < 0) {
			perror("read failed");
			sofar = last;
			break;
		}

		if (last == 0)
			break;

		sofar += last;
		left  -= last;
	};

	return sofar;
}

static void print_buffer(char *buf, int n, int indent, const char *pre)
{
	int pos;
	const int width = 64;

	for (pos = 0; pos < n; pos++) {
		if (pos == 0)
			printf("%*s: ", indent, pre);
		else if (pos % width == 0)
			printf("%*s  ", indent, "");
		else if (pos % (width/2) == 0)
			printf("%*s", 2, "");

		putchar(isgraph(buf[pos]) ? buf[pos] : '.');
		if ((pos + 1) % width == 0)
			putchar('\n');
	}

	if (pos % width != 0)
		printf("\n");
}

/******************************************************************************
 *                          Record Display Functions                          *
 ******************************************************************************/
DISPLAY(read)
{
	print_buffer(buffer, nbytes, 8, "Read");
	return 0;
}

DISPLAY(time)
{
	time_t t = ret;
	printf("    Time: %ld, %s", t, ctime(&t));
	return 0;
}

DISPLAY(getpid)
{
	printf("    Pid: %ld\n", ret);
	return 0;
}

DISPLAY(stat)
{
	struct stat *s = (struct stat *)buffer;

	printf("    atime: %s", ctime(&s->st_atime));
	printf("    mtime: %s", ctime(&s->st_mtime));
	printf("    ctime: %s", ctime(&s->st_ctime));

	return 0;
}

DISPLAY(getsockname)
{
	struct sockaddr *sa;
	struct sockaddr_in *sin;
	char *family;
	socklen_t *addrlen;

	sa  = (struct sockaddr *)buffer;
	sin = (struct sockaddr_in *)sa;
	addrlen = (socklen_t *)(buffer + sizeof(struct sockaddr));

	family = (sa->sa_family == AF_INET ? "AF_INET" :
	         (sa->sa_family == AF_UNIX ? "AF_UNIX" : "Unknown"));

	printf("    Size   : %d\n", *addrlen);
	printf("    Family : %d (%s)\n", sa->sa_family, family);
	if (sa->sa_family == AF_INET) {
		printf("    Port   : %d\n", ntohs(sin->sin_port));
		printf("    Address: %s\n", inet_ntoa(sin->sin_addr));
	}

	return 0;
}

DISPLAY(sysfs)
{
	if (nbytes <= 0)
		return 0;

	char tmpbuf[nbytes+1];

	memcpy(tmpbuf, buffer, nbytes);
	tmpbuf[nbytes] = '\0';

	printf("    FS Name: %s\n", tmpbuf);

	return 0;
}

DISPLAY(getgroups)
{
	int i, ngids = nbytes / sizeof(gid_t);
	gid_t *gids = (gid_t *)buffer;

	if (ngids == 0)
		printf("    No groups returned\n");
	else {
		printf("    Groups: ");
		for (i = 0; i < ngids; i++)
			printf("%d ", gids[i]);
		printf("\n");
	}

	return 0;
}

DISPLAY(uname)
{
	struct utsname *uts;

	if (nbytes > 0) {
		uts = (struct utsname *)buffer;

		printf("    Sysname : %s\n", uts->sysname);
		printf("    Nodename: %s\n", uts->nodename);
		printf("    Release : %s\n", uts->release);
		printf("    Version : %s\n", uts->version);
		printf("    Machine : %s\n", uts->machine);
		//printf("    Domain  : %s\n", uts->domainname);

	} else {
		printf("    No data\n");
	}

	return 0;
}

DISPLAY(poll)
{
	int i;
	short *flags = (short *)buffer;

	int nflags = nbytes / sizeof(short);
	if (nbytes % sizeof(short) != 0)
		printf("    WARNING: Not an aligned size %ld\n", nbytes);

	printf("    Reading %d flags\n", nflags);
	for (i = 0; i < nflags; i++)
		printf("    [%2d] Flags: %d\n", i, flags[i]);

	return 0;
}

DISPLAY(ioctl)
{
	int i;
	long *val = (long *)buffer;
	struct termios *ios = (struct termios *)buffer;

	if (nbytes == 0) {
		printf("    No extra data to display\n");
		return 0;

	} else if (nbytes == sizeof(long)) {
		printf("    Long: %ld\n", *val);

	} else if (nbytes == sizeof(struct termios)) {
		printf("    Contents look like a termios struct:\n");
		printf("    - c_iflag: %08x\n", ios->c_iflag);
		printf("    - c_oflag: %08x\n", ios->c_oflag);
		printf("    - c_cflag: %08x\n", ios->c_cflag);
		printf("    - c_lflag: %08x\n", ios->c_lflag);
		printf("    - c_line:  %02x\n", ios->c_line);
		printf("    - c_cc:    [");
		for (i = 0; i < NCCS; i++)
			printf("%02x ", ios->c_cc[i]);
		printf("]\n");
		printf("    - ispeed:  %u\n", ios->c_ispeed);
		printf("    - ospeed:  %u\n", ios->c_ospeed);
	}

	return 0;
}

DISPLAY(recvmsg)
{
	socklen_t namelen;
	size_t controllen, txtlen;
	char *name, *control, *txt;
	unsigned int pos, flags;

	pos = 0;
	namelen = *((socklen_t *)&buffer[pos]);
	pos += sizeof(namelen);

	name = &buffer[pos];
	pos += namelen;

	controllen = *((socklen_t *)&buffer[pos]);
	pos += sizeof(controllen);

	control = &buffer[pos];
	pos += controllen;

	flags = *((unsigned int *)&buffer[pos]);
	pos += sizeof(unsigned int);

	txt = &buffer[pos];
	txtlen = nbytes - (txt - buffer);

	printf("    Name length: %d\n", namelen);
	print_buffer(name, namelen, 8, "Name");
	printf("    Control length: %d\n", controllen);
	print_buffer(control, controllen, 8, "Ctrl");
	printf("    Message flags: %x\n", flags);
	printf("    Message length: %d\n", txtlen);
	print_buffer(txt, txtlen, 8, "Txt");
	
	return 0;
}
