#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <getopt.h>

#define BUFLEN     1024
#define MAXTHREADS 32

typedef struct {
	int pid;
	FILE *fp;
} fd_t;

typedef enum {
	SHIM, DMESG
} mode_t;

static char *suffix = "msg";
static int nfds = 0;
static fd_t fds[MAXTHREADS];
static mode_t mode = SHIM;

static int get_index(int pid)
{
	int i;
	
	for (i = 0; i < nfds; i++) {
		if (fds[i].pid == pid)
			return i;
	}

	return -1;
}

static void read_file(FILE *msgfile)
{
	char buffer[BUFLEN];
	char nametmp[256];
	int pid, idx, i;
	char *tmp, *tok;

	assert(msgfile);

	while (fgets(buffer, BUFLEN, msgfile) != NULL) {

		if (mode == SHIM) {
			sscanf(buffer, "[%d]", &pid);

		} else {
			tmp = strdup(buffer);
			for (tok = strtok(tmp, " "); tok; tok = strtok(NULL, " ")) {
				if (tok[0] == '@')
					break;
			}

			if (tok && tok[0] == '@') {
				int pos = 0;
				free(tmp);
				tmp = strdup(tok);
				for (tok = strtok(tmp, ":"); tok; tok = strtok(NULL, ":"), pos++) {
					if (pos == 1)
						break;
				}

				if (tok)
					pid = atoi(tok);
				else
					pid = 255;
			} else {
				pid = 255;
			}

			free(tmp);
		}

		idx = get_index(pid);
		if (idx < 0) {
			idx = nfds++;
			assert(idx < MAXTHREADS);

			snprintf(nametmp, sizeof nametmp, "%s.%d", suffix, pid);

			fds[idx].pid = pid;
			fds[idx].fp  = fopen(nametmp, "w");
			assert(fds[idx].fp);
		}

		fprintf(fds[idx].fp, "%s", buffer);
	}

	for (i = 0; i < nfds; i++)
		fclose(fds[i].fp);
}

int main(int argc, char *argv[])
{
	const char *filename;
	FILE *msgfile;
	int curopt;

	while ((curopt = getopt(argc, argv, "d")) != -1) {
		switch (curopt) {
		case 'd': mode = DMESG; break;
		}
	}

	if (optind >= argc) {
		fprintf(stderr, "Usage: %s msgfile\n", argv[0]);
		abort();
	}

	filename = argv[optind];
	if (argc - optind >= 2)
		suffix = argv[optind+1];

	printf("Opening %s\n", filename);
	msgfile = fopen(filename, "r");
	assert(msgfile);

	read_file(msgfile);

	fclose(msgfile);
	return 0;
}
	
