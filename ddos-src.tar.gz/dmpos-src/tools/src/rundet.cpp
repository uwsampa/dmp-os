//
// rundet
//
// A simple wrapper to run a program deterministically.
// We just call fork(), sys_make_deterministic(), and then exec().
//

#include <assert.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <getopt.h>
#include <stdint.h>
#include <errno.h>

#include "dmp.h"
#include "dmpshim.h"

enum option_t {
	OPT_QSIZE = 0x100, OPT_MODE, OPT_MMFREQ,
	OPT_DFLAGS, OPT_DSTART, OPT_DSTOP, OPT_OPTIMS,
	OPT_ADAPTS_MIN, OPT_ADAPTS_MAX, OPT_ADAPTS_MAX_FAULT,
	OPT_ADAPTQ_MIN, OPT_ADAPTQ_MAX, OPT_ADAPTQ_DELTA,
	OPT_ADAPTQ, OPT_ADAPTS,
	OPT_SHIM, OPT_QUIET, OPT_ENDQ_THRESH, OPT_SYSCALL_TICKS,
};

struct option options[] = {
	{ "quantum-size",     required_argument, NULL, OPT_QSIZE            },
	{ "mode",             required_argument, NULL, OPT_MODE             },
	{ "shim",             required_argument, NULL, OPT_SHIM             },
	/* System Options */
	{ "quiet",            no_argument,       NULL, OPT_QUIET            },
	{ "mm-verify-freq",   required_argument, NULL, OPT_MMFREQ           },
	{ "debug-flags",      required_argument, NULL, OPT_DFLAGS           },
	{ "debug-start",      required_argument, NULL, OPT_DSTART           },
	{ "debug-stop",       required_argument, NULL, OPT_DSTOP            },
	{ "optims",           required_argument, NULL, OPT_OPTIMS           },
	{ "adapts",           required_argument, NULL, OPT_ADAPTS           },
	{ "adapts-min",       required_argument, NULL, OPT_ADAPTS_MIN       },
	{ "adapts-max",       required_argument, NULL, OPT_ADAPTS_MAX       },
	{ "adapts-max-fault", required_argument, NULL, OPT_ADAPTS_MAX_FAULT },
	{ "adaptq",           required_argument, NULL, OPT_ADAPTQ           },
	{ "adaptq-min",       required_argument, NULL, OPT_ADAPTQ_MIN       },
	{ "adaptq-max",       required_argument, NULL, OPT_ADAPTQ_MAX       },
	{ "adaptq-delta",     required_argument, NULL, OPT_ADAPTQ_DELTA     },
	{ "endq-thresh",      required_argument, NULL, OPT_ENDQ_THRESH      },
	{ "syscall-ticks",    required_argument, NULL, OPT_SYSCALL_TICKS    },
	{ NULL, 0, NULL, 0 },
};

/*
 * Named optimization configurations, for ease and consistency
 */
struct adaptq_config {
	const char *name;
	uint64_t aqmin;
	uint64_t aqmax;
	uint64_t aqdelta;
};

struct adapts_config {
	const char *name;
	uint64_t asminper;
	uint64_t asmaxper;
	uint64_t asmaxfault;
};

struct adaptq_config adaptq_configs[] = {
	{ "conserv",   10000,  500000,     10000 },
	{ "medium",    50000,  50000000,   10000 },
	{ "aggressive", 500000, 50000000, 10000 },
	{ NULL, 0, 0, 0 } /* Last */
};

struct adapts_config adapts_configs[] = {
	{ "onefault",  100, 100, 1   },
	{ "twofault",  100, 100, 2   },
	{ "dynamic",   10,  90,  100 },
	{ NULL, 0, 0, 0 } /* Last */
};

static void usage(char* argv[], int code)
{
	fprintf(stderr,
		"Usage: %s [-q quantum_size] [-m mode] [-f debug_flags] prog ...\n",
		argv[0]);
	exit(code);
}

static void initialize_options(struct dmpopts *opts)
{
	/* Debug message options */
	opts->debug_flags = "";
	opts->debug_quiet = 0;
	opts->start = -1;
	opts->stop = -1;

	opts->verify_mm_freq = 500;

	/* Optimization options */
	opts->optims = "";
	opts->adapts_min = 10;
	opts->adapts_max = 90;
	opts->adapts_max_fault = 1;
	opts->adaptq_min = 1003;
	opts->adaptq_max = 1000003;
	opts->adaptq_delta = 100;
	opts->default_quantum_size = 500000;
	opts->maybe_endq_thresh = 10000;
	opts->syscall_tick_penalty = 0;
}

static int set_adaptq(struct dmpopts *opts, const char *name)
{
	int i;

	for (i = 0; adaptq_configs[i].name; i++) {
		if (strcmp(name, adaptq_configs[i].name) == 0)
			break;
	}

	if (adaptq_configs[i].name == NULL) {
		printf("adaptq config %s not defined\n", name);
		return -1;
	}

	opts->adaptq_min   = adaptq_configs[i].aqmin;
	opts->adaptq_max   = adaptq_configs[i].aqmax;
	opts->adaptq_delta = adaptq_configs[i].aqdelta;
	return 0;
}

static int set_adapts(struct dmpopts *opts, const char *name)
{
	int i;

	for (i = 0; adapts_configs[i].name; i++) {
		if (strcmp(name, adapts_configs[i].name) == 0)
			break;
	}

	if (adapts_configs[i].name == NULL) {
		printf("adapts config %s not defined\n", name);
		return -1;
	}

	opts->adapts_min       = adapts_configs[i].asminper;
	opts->adapts_max       = adapts_configs[i].asmaxper;
	opts->adapts_max_fault = adapts_configs[i].asmaxfault;
	return 0;

}

static int distq_thread_loop(void)
{
	long done = 0;
	printf("New distq user-thread is alive; registering first barrier\n");
	if (dmp_call_shim1(SHIM_FN_SET_DISTQ_HANDLER, (long)&done) < 0) {
		printf("Trouble creating new distq thread\n");
		exit(1);
	}

	while (!done) {
		printf("Looping...\n");
	}
	
	printf("Leaving?\n");
	return -1;
}

int main(int argc, char* argv[])
{
	int opt;
	const char *mode = "MOT";
	const char *shim_exec = NULL;
	struct dmpopts opts;
	pid_t pid, shim_pid;
	int error = 0;

	initialize_options(&opts);

	// Stop at first unknown arg.
	while ((opt = getopt_long(argc, argv, "q:m:o:f:", options, NULL)) != -1) {
		switch (opt) {
		case 'q':                  /* fallthrough */
		case OPT_QSIZE:            opts.default_quantum_size = atoi(optarg); break;
		case 'm':                  /* fallthrough */
		case OPT_MODE:             mode = optarg; break;
		case 'o':                  /* fallthrough */
		case OPT_OPTIMS:           opts.optims = optarg; break;
		case 'f':                  /* fallthrough */
		case OPT_DFLAGS:           opts.debug_flags = optarg; break;
		case OPT_DSTART:           opts.start = atoi(optarg); break;
		case OPT_DSTOP:            opts.stop = atoi(optarg); break;
		case OPT_MMFREQ:           opts.verify_mm_freq = atoi(optarg); break;
		case OPT_ADAPTS:           error = set_adapts(&opts, optarg); break;
		case OPT_ADAPTS_MIN:       opts.adapts_min = atoi(optarg); break;
		case OPT_ADAPTS_MAX:       opts.adapts_max = atoi(optarg); break;
		case OPT_ADAPTS_MAX_FAULT: opts.adapts_max_fault = atoi(optarg); break;
		case OPT_ADAPTQ:           error = set_adaptq(&opts, optarg); break;
		case OPT_ADAPTQ_MIN:       opts.adaptq_min = atoi(optarg); break;
		case OPT_ADAPTQ_MAX:       opts.adaptq_max = atoi(optarg); break;
		case OPT_ADAPTQ_DELTA:     opts.adaptq_delta = atoi(optarg); break;
		case OPT_ENDQ_THRESH:      opts.maybe_endq_thresh = atoi(optarg); break;
		case OPT_SYSCALL_TICKS:    opts.syscall_tick_penalty = atoi(optarg); break;
		case OPT_SHIM:             shim_exec = optarg; break;
		case OPT_QUIET:            opts.debug_quiet = 1; break;
		default:
			usage(argv, 1);
		}
	}

	if (optind >= argc || error) {
		usage(argv, 2);
	}

	const int shimmed = (shim_exec != NULL);

	char** newargv = (char**)calloc(sizeof(newargv[0]), argc - optind + 1);
	memcpy(newargv, argv+optind, (argc-optind)*sizeof(newargv[0]));

	// Fork the app.
	pid = fork();
	if (pid < 0) {
		perror("app fork failed");
		exit(1);
	}

	if (pid == 0) {

		if (dmp_set_options(&opts) != 0) {
			perror("dmp_set_options failed");
			exit(1);
		}

		if (dmp_make_deterministic(mode, shimmed) != 0) {
			perror("dmp_make_deterministic failed");
			exit(1);
		}

		if (strstr(argv[0], "runddet") != 0) {
			fprintf(stderr, "Creating a distq thread\n");
			pid_t ddpid = fork();

			if (ddpid == 0) {
				fprintf(stderr, "New distq thread created; looping...\n");	
				distq_thread_loop();
				fprintf(stderr, "distq thread is exiting\n");
				exit(1);

			} else if (ddpid > 0) {
				fprintf(stderr, "Parent continuing\n");

			} else {
				fprintf(stderr, "Couldn't create distq thread? %s\n", strerror(errno));
				exit(1);
			}
		}

		execvp(newargv[0], newargv);
		perror("execvp failed");
		exit(1);
	}

	// Fork the shim.
	if (shimmed) {
		shim_pid = fork();
		if (shim_pid < 0) {
			perror("shim fork failed");
			kill(pid, SIGKILL);
			exit(1);

		} else if (shim_pid == 0) {
			if (dmp_shim_attach(pid) != 0) {
				perror("dmp_shim_attach failed");
				kill(pid, SIGKILL);
				exit(1);
			}

			char buf[128];
			snprintf(buf, sizeof buf, "INITIAL_DMP_PID=%d", pid);
			putenv(buf);

			execlp("bash", "bash", "-c", shim_exec, NULL);
			perror("shim exec");
			kill(pid, SIGKILL);
			exit(1);
		}
	}

	if (shimmed) {
		printf("rundet: app{pid=%d qs=%lu mode=%s bin=%s} shim{pid=%d cmd=(%s)}\n",
			pid, opts.default_quantum_size, mode, argv[optind], shim_pid, shim_exec);
	} else {
		printf("rundet: app{pid=%d qs=%lu mode=%s bin=%s} shim{}\n",
			pid, opts.default_quantum_size, mode, argv[optind]);
	}

	// Wait.
	int status;
	waitpid(pid, &status, 0);

	return 0;
}
