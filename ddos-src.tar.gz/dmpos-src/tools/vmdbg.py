#!/usr/bin/env python
import os
import sys
import re

def uniquify(seq):
	# not order preserving
	set = {}
	map(set.__setitem__, seq, [])
	return set.keys()

dirty_dmp = []
dirty_shim = []

targets = []

def usage(prog):
	print "Usage: %s <log>" % prog

def search_address(address):
	for (start, end) in dirty_dmp:
		if address >= start and address < end:
			return 1

	for (start, end) in dirty_shim:
		if address >= start and address < end: 
			return 2

	return 0

def add_range(res):
	res = res.group(1)
	toks = res.split(" ")

	if len(toks) != 4:
		return

	if toks[0] == 'FROM_DMP' and toks[2] == 'TO_SHIM':
		(dstart, dlen) = toks[1].split(":")
		(sstart, slen) = toks[3].split(":")

		send   = (int(sstart, 16) + int(slen) + 4096) & ~0xfff;
		sstart = int(sstart, 16) & ~0xfff

		dirty_shim.append((sstart, send))

	elif toks[0] == 'FROM_SHIM' and toks[2] == 'TO_DMP':
		(sstart, slen) = toks[1].split(":")
		(dstart, dlen) = toks[3].split(":")
		
		dend   = (int(dstart, 16) + int(dlen) + 4096) & ~0xfff;
		dstart = int(dstart, 16) & ~0xfff
		
		dirty_dmp.append((dstart, dend))

def add_target(reres):
	keys = ['stack', 'cpu_pda', 'runqueues']

	res = []
	res.append(reres.group(1))
	res.append(reres.group(2))

	if res[0] in keys:
		targets.append(res[1])

def main(args):
	global targets
	if len(args) < 2:
		usage(args[0])
		sys.exit(1)

	log = args[1]
	print "Using log", log

	fp = open(log, "r")
	lines = fp.readlines()

	for line in lines:
		line = line.strip()
		
		res = re.search(".* VMDBG: (.*)$", line)
		if res:
			add_range(res)
			continue

		#res = re.search(".*VMDBG: ([a-z]+): ([a-z0-9x]+)", line)
		res = re.search(".* VMDBG ([a-z]+): +([a-z0-9x]+).*", line)
		if res:
			add_target(res)
			continue

	targets = uniquify(targets)

	print "Dirty dmp"
	print dirty_dmp
	print "Dirty shim"
	print dirty_shim
	print "Targets"
	print targets

	for target in targets:
		address = int(target, 16)

		res = search_address(address)
		if res == 0:
			#print "Not found."
			pass
		elif res == 1:
			print target, "Found in DMP"
		elif res == 2:
			print target, "Found in shim"



if __name__ == "__main__":
	main(sys.argv)
