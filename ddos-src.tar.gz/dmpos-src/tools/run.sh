#!/bin/bash

for b in $@; do
	if [ ! -d "$b" ]; then mkdir $b; fi
	cd $b

	echo "=== Running $b"
	makeboxgraph.py $b

	echo "=== Making graphs for $b"
	for d in $(find . -maxdepth 1 -type d ); do
		if [ "$d" == "." -o "$d" == ".." ]; then continue; fi
		cd $d
		bargraph.pl ${b}.graph > ${b}.ps
		makepidgraph.py $(ls ${b}_mot_*_n8_*.dat | tail -n 1) > ${b}.pid.graph
		bargraph.pl ${b}.pid.graph > ${b}.pid.ps
		cd ..
	done
	
	echo ""
done
