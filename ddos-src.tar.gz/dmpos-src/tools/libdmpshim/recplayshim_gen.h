#ifndef _RECPLAY_H_
#define _RECPLAY_H_

#include "dmpshim.h"
#include "recplayshim.h"
#include "recplayshim_tab.h"

using namespace DMP;

/* Event types */
#define LOG_SYSCALL 0
#define LOG_SIGNAL  1
#define LOG_RDTSC   2

/* Encoding of RecFnTab */
#define END     0L
#define ARG0    1L
#define ARG1    2L
#define ARG2    3L
#define ARG3    4L
#define ARG4    5L
#define ARG5    6L
#define RET     7L

#define IMMLONG 1L
#define IMMREG  2L
#define PTR     3L

#define TYPE_SYSCALL 0
#define TYPE_SIGNAL  1
#define TYPE_RDTSC   2

#define __TYPE(full)    ((full) & 0xff)
#define __SUBTYPE(full) ((full) >> 8)

#define TYPE(hdr)    (__TYPE((hdr).fulltype))
#define SUBTYPE(hdr) (__SUBTYPE((hdr).fulltype))

#define IS_SYSCALL(hdr) (TYPE(hdr) == TYPE_SYSCALL)

void add_record(RecPlayShim *shim, uint64_t logical_time, char type, uint32_t subtype, uint64_t len);
void replay_str(RecPlayShim *shim, shim_event *event, const long *recstr);
void record_str(RecPlayShim *shim, shim_event *event, const long *recstr);

#define __RECPLAY(fn) void (recplay_##fn)(RecPlayShim *shim, shim_event *event, ShimMode mode, void *arg)

/* File system */
__RECPLAY(stat);
__RECPLAY(statfs);

__RECPLAY(open);
__RECPLAY(close);
__RECPLAY(write);
__RECPLAY(writev);
__RECPLAY(read);
__RECPLAY(readv);
__RECPLAY(pread64);
__RECPLAY(fcntl);
__RECPLAY(sysfs);
__RECPLAY(access);
__RECPLAY(dup2);

__RECPLAY(readlink);

/* Idempotent syscalls */
__RECPLAY(getresuid);
__RECPLAY(getresgid);
__RECPLAY(sched_getparam);
__RECPLAY(sched_rr_get_interval);
__RECPLAY(get_mempolicy);
__RECPLAY(sched_getaffinity);
__RECPLAY(getgroups);
__RECPLAY(uname);

/* Memory management */
__RECPLAY(mmap);

/* Signals */
__RECPLAY(rt_sigaction);
__RECPLAY(rt_sigprocmask);

/* Unclassified */
__RECPLAY(time);
__RECPLAY(gettimeofday);
__RECPLAY(clock_gettime);
__RECPLAY(getrlimit);
__RECPLAY(getcwd);
__RECPLAY(getdents);
__RECPLAY(nanosleep);
__RECPLAY(getrusage);
__RECPLAY(sysinfo);
__RECPLAY(times);
__RECPLAY(ustat);
__RECPLAY(getitimer);
__RECPLAY(ioctl);
__RECPLAY(set_tid_address);
__RECPLAY(futex);
__RECPLAY(wait4);
__RECPLAY(inotify_init);
__RECPLAY(poll);
__RECPLAY(epoll_wait);
__RECPLAY(epoll_create);

/* Generic functions */
__RECPLAY(generic);
__RECPLAY(reexec);
__RECPLAY(abort);

#endif /* _RECPLAY_H_ */
