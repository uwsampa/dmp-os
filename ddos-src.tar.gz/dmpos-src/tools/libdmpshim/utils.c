/**
 * utils --
 *
 *   Misc util functions; whatever seems useful
 */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <errno.h>

#include "utils.h"
#include "lib.h"


FILE *shim_log_file = NULL;
int set_shim_log(const char *filename)
{
	FILE *fp = NULL;

	printf("Got filename: %s\n", filename);
	if (filename != NULL && strlen(filename) > 0) {
		printf("Opening\n");
		fp = fopen(filename, "w");
		if (fp == NULL)
			return -1;
		printf("Success\n");
	}

	if (shim_log_file && shim_log_file != stderr) {
		printf("Closing old file\n");
		fclose(shim_log_file);
	}

	shim_log_file = (fp ? fp : stderr);
	printf("shim_log_file is set\n");
	return 0;
}

static const char* SyscallNames[300] = {
#include <syscall.h>
};

const char* GetSyscallName(const long syscall)
{
	if (syscall >= 300)
		return "?";
	else
		return SyscallNames[syscall] ? : "?";
}

/**
 * writen --
 *
 *   Write exactly n bytes of a buffer to an fd.
 *
 *   Parameters:
 *       fd   -- Fd to write the buffer to
 *       buf  -- Pointer to beginning of buffer
 *       n    -- Number of bytes to write
 *
 *   Returns:
 *       Number of bytes actually written; less than n indicates failure
 */
int writen(int fd, char *buf, int n)
{
	int left = n, sofar = 0, last = 0;

	while (left > 0) {
		if ((last = write(fd, buf + sofar, left)) < 0) {
			sofar = last;
			break;
		}
		
//		SHIM_LOG("   ret:%d  (%d/%d)\n", last, sofar, n);

		if (last == 0)
			break;

		sofar += last;
		left  -= last;
	};

	return sofar;
}

/**
 * readn --
 *
 *   Read exactly n bytes from an fd
 *
 *   Parameters:
 *       fd   -- Fd to read from
 *       buf  -- Pointer to beginning of buffer
 *       n    -- Number of bytes to read
 *
 *   Returns:
 *       Number of bytes actually read; less than n indicates failure
 */
int readn(int fd, char *buf, int n)
{
	int left = n, sofar = 0, last = 0;

	while (left > 0) {
		char *dest = (buf + sofar);
		/* SHIM_LOG("   Reading up to %d bytes of %d total, into buffer %p\n", left, n, dest); */
		
		if ((last = read(fd, dest, left)) < 0) {
			perror("read failed");
			sofar = last;
			break;
		}

		/* SHIM_LOG("   ret:%d  (%d/%d)\n", last, sofar, n); */

		if (last == 0) {
			SHIM_LOG("End-of-file reached\n");
			break;
		}

		sofar += last;
		left  -= last;
	};

	return sofar;
}

/**
 * get_string --
 *
 *   Read a NULL-terminated string from the DMP task. At most nbytes are copied
 *   in to shim_buf. If a NULL-terminator is not found in the first nbytes
 *   bytes, the resulting string will be truncated.
 *
 *   Parameters:
 *       shim_buf  -- (out) The destination buffer
 *       dmp_buf   -- Pointer in DMP tasks's address space of beginning of
 *                    buffer to copy
 *       nbytes    -- The maximum number of bytes to copy
 *       out       -- (out) The number of bytes read
 *
 *   Returns:
 *       TODO (The number of bytes read?)
 */
long get_string(char *shim_buf, const char *dmp_buf, long nbytes, long *out)
{
	long bytes, ret;

	/* Get the string */
	ret = dmp_shim_strncpy_sync(shim_buf, (char *)dmp_buf, nbytes, &bytes);

	/* Make sure its NULL-terminated */
	if (bytes > 0)
		shim_buf[bytes - 1] = '\0';
	else
		shim_buf[0] = '\0';

	if (out)
		*out = bytes;

	return ret;
}


/**
 * create_listening_socket(port) --
 *
 *   Create a socket that listens on the given port, and return the socket
 *   descriptor. If an error occurs, a negative code is returned to the caller.
 *
 *   Parameters:
 *       port  -- Port to listen on
 *
 *   Returns:
 *       A valid socket descriptor (>= 0) on success, or a negative value (< 0)
 *       on error.
 */
int create_listening_socket(const int port)
{
	struct sockaddr_in sin;
	int fd, one = 1;
	int error = 0, ret;

	SHIM_LOG("Creating listening socket on port %d\n", port);
	fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		error = -errno;
		goto out_ret;
	}

	SHIM_LOG("    Setting SO_REUSEADDR...\n");
	ret = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
	if (ret < 0)
		SHIM_WARN("    Setting SO_REUSEADDR failed; trying without it...\n");

	memset(&sin, 0, sizeof sin);
	sin.sin_family      = AF_INET;
	sin.sin_port        = htons(port);
	sin.sin_addr.s_addr = INADDR_ANY;

	SHIM_LOG("    Binding...\n");
	ret = bind(fd, (struct sockaddr *)&sin, sizeof sin);
	if (ret < 0) {
		error = -errno;
		goto out_close;
	}

	SHIM_LOG("    Listening...\n");
	ret = listen(fd, 10);
	if (ret < 0) {
		error = -errno;
		goto out_close;
	}
	
	SHIM_LOG("Success!\n");
	return fd;

 out_close:
 	close(fd);
 out_ret:
 	return error;
}

/**
 * connect_to(host, port) --
 * 
 *   Establish a TCP connection to the given host on the provided port number.
 *   Resolution is performed on host, so hostnames and IP addresses will both
 *   work as expected. A valid socket descriptor is returned on success, or a
 *   negative code if an error occurs.
 *
 *   Parameters:
 *       host  -- Hostname or IP address of target; must be NULL-terminated
 *       port  -- Port to connect to
 *
 *   Returns:
 *       A valid socket descriptor (>= 0) on success, or a negative value (< 0)
 *       on error.
 */
int connect_to(const char *host, const int port)
{
	int error = 0, ret;
	struct addrinfo *addr;
	struct sockaddr_in *ressin;
	uint32_t haddr;

	SHIM_LOG("Connecting to %s:%d\n", host, port);

	SHIM_LOG("    Looking up %s...\n", host);
	ret = getaddrinfo(host, NULL, NULL, &addr);
	if (ret != 0) {
		SHIM_LOG("    Lookup failed!\n");
		error = -ret;
		goto out_ret;
	}

	ressin = (struct sockaddr_in *)addr->ai_addr;
	haddr = ntohl(ressin->sin_addr.s_addr);
 	freeaddrinfo(addr);

	return __connect_to(haddr, port);

 out_ret:
 	return error;
}

int __connect_to(const uint32_t addr, const uint16_t port)
{
	int fd;
	int error = 0, ret;
	struct sockaddr_in sin;
	useconds_t retry_timer = 5000;

	fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		error = -errno;
		goto out_ret;
	}

	memset(&sin, 0, sizeof sin);
	sin.sin_family = AF_INET;
	sin.sin_port   = htons(port);
	sin.sin_addr.s_addr = htonl(addr);

	for (int i = 0; i < 16; i++) {
		SHIM_LOG("    Connecting to %s:%d (attempt %d)\n", inet_ntoa(sin.sin_addr), port, i);
		ret = connect(fd, (struct sockaddr *)&sin, sizeof sin);
		if (ret >= 0)
			break;

		SHIM_LOG("Waiting %dms for retry...\n", retry_timer/1000);
		usleep(retry_timer);
		retry_timer *= 2;
	}

	if (ret < 0) {
		SHIM_LOG("Connection failed!\n");
		error = -errno;
		goto out_ret;
	}

	SHIM_LOG("Success!\n");
	return fd;

 out_ret:
 	return error;
}

/**
 * accept_connection(fd, *addr, *port) --
 *
 *   Accept a new connection from the given file descriptor, and return the
 *   remote ip address and port number, if valid pointers are provided by the
 *   caller.
 *
 *   Parameters:
 *       fd    -- Descriptor to accept a connection from
 *       addr  -- (out) Address of remote node
 *       port  -- (out) Port number of remote node
 *
 *   Returns:
 *       >= 0 on success, or < 0 on failre
 */
int accept_connection(int fd, uint32_t *addr, uint16_t *port)
{
	struct sockaddr sa;
	struct sockaddr_in *sin;
	socklen_t size = sizeof(sa);
	int newfd, error = 0;

	SHIM_LOG("Calling accept() on fd:%d\n", fd);
	newfd = accept(fd, &sa, &size);
	if (newfd < 0) {
		error = -errno;
		goto out_ret;
	}

	if (sa.sa_family != AF_INET) {
		SHIM_LOG("Non-IP connection?\n");
		error = -1;
		goto out_close;
	}

	sin = (struct sockaddr_in *)&sa;

	//SHIM_LOG("    New connection from %s:%d\n", inet_ntoa(sin->sin_addr), ntohs(sin->sin_port));
	if (addr)
		*addr = ntohl(sin->sin_addr.s_addr);
	if (port)
		*port = ntohs(sin->sin_port);

	SHIM_LOG("accept_connection() done\n");
	return newfd;

 out_close:
 	close(newfd);
 out_ret:
 	SHIM_LOG("Bad things are happening...\n");
 	return error;
}

/**
 * remote_exec(host, cmd, quiet) --
 *
 *   Execute the given command on a remote host. If quiet is a non-zero value,
 *   then output from the remote program is supressed. Otherwise, the remote
 *   program's output is echoed locally. This function uses SSH to remotely
 *   spawn the given command.
 *
 *   Parameters:
 *       host   -- Remote host to execute on
 *       cmd    -- Command to execute
 *       quiet  -- Set to non-zero to suppress program output
 *
 *   Returns:
 *       0 on success, < 0 on failure
 */
int remote_exec(const char *host, const char *cmd, const int quiet)
{
	int error = 0, i, status;
	pid_t pid;
	const char *args[6];

	if ((pid = fork()) == 0) {

		if (quiet) {
			for (i = 0; i < 3; i++)
				close(i);
		}

		/* Construct the command line */
		args[0] = "ssh";
		args[1] = "-f";  /* Force ssh to the background */
		args[2] = host;
		args[3] = "--";
		args[4] = cmd;
		args[5] = NULL;

		/* Make magic happen */
		execvp(args[0], (char **)args);
		
	} else if (pid > 0) {
		
		/* Wait for ssh to finish spawning */
		waitpid(pid, &status, 0);

		/* Make sure SSH was able to establish a connection */
		if (status != 0)
			error = -1;	
	
	} else {
		error = -errno;
	}

	return error;
}
