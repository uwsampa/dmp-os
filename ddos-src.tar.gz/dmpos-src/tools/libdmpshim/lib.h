#ifndef _LIB_H_
#define _LIB_H_

#include "dmpshim.h"

long dmp_shim_emulate_syscall(long sysret, struct user_regs_struct *regs);

long dmp_shim_memcpy_sync(void *shim_buf_in, void *dmp_buf_in, long nbytes,
                          enum ShimCtlFlag write_to_dmp, long *bytes_out);

long dmp_shim_strncpy_sync(void *shim_buf_in, void *dmp_buf_in, long nbytes,
			   long *bytes_out);

#endif /* _LIB_H_ */
