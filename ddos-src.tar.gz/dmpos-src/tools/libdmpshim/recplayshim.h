#ifndef _RECPLAYSHIM_H_
#define _RECPLAYSHIM_H_

#ifndef __cplusplus
#error "RecPlay shim requires c++"
#endif

#include "basicshim.h"
#include "recplayshim_tab.h"
#include "zbuf.h"
#include "recplayshim_gen.h"


namespace DMP {

/**
 * RecPlayShim --
 *
 *   Defines a shim that can record and replay nondeterministic events.
 *   Behavior is controlled by the replay flag to the constructor.
 *
 *   Note on file descriptor table:
 *   ------------------------------
 *       Whereas the BasicShim maintains a DMP fd -> Shim fd map for files in
 *       the deterministic file hierarchy (DFH), the Replay shim must also
 *       maintain a similar map for descriptors outside of the DFH.
 *
 *       One reason for this is the need to correcly replay a write. We log the
 *       number of bytes actually written during the recorded execution;
 *       however, the shim needs to perform the write on behalf of the replayed
 *       process in order to ensure the exact same number of bytes are actually
 *       written during replay. Simply returning the value isn't sufficient,
 *       since the effects of the write wouldn't actually occur.
 */
class RecPlayShim : public BasicShim {
  public:
  	/* Constructors and destructors */
	RecPlayShim(RecPlayShim *parent, int clone_flags, const string &logfile,
	           RecPlayTab *table, bool replay, bool compressed, bool reexec_detnet);
	virtual ~RecPlayShim();	

	/* Factory functions */
	virtual RecPlayShim *clone(int clone_flags);

	/* Overridden functions from BasicShim */
	virtual bool trace_syscall_enter(shim_event *event);
	virtual void trace_syscall_leave(shim_event *event);
	virtual void trace_rdtsc(shim_event *event);
	virtual void trace_signal(shim_event *event);

	/* Miscellaneous functions */
	int append_buffer(char *buf, int n);
	int read_buffer(char *buf, int n);
	RecPlayTab *get_table(void);
	int get_nullfd(void);

  protected:
	/* Private utility functions */
	void wait_for_event_time(shim_event *event, rechdr_t *rechdr);

	bool record_syscall_enter(shim_event *event);
	void record_syscall_leave(shim_event *event);
	bool replay_syscall_enter(shim_event *event);
	void replay_syscall_leave(shim_event *event);

	void record_syscall(shim_event *event);
	void replay_syscall(shim_event *event);
	void record_rdtsc(shim_event *event);
	void replay_rdtsc(shim_event *event);

  protected:
	/* Information about the log file */
	int    logfd;        /* For logging of  synchronous events */
	string logbasename;
	char  *logfilename;
	int    siglogfd;     /* For logging signals */

	/* Table for the record functions */
	RecPlayTab *table;

	/* Set if this is replaying */
	bool replay;
	bool consume_log; /* Consume log entry on syscall_leave; for non-replayed system calls */
	
  	/* State for compression stuff, if in use */
  	bool compressed;
	ZBuf zbuf;
};

} /* DMP */

#endif /* _RECPLAYSHIM_H_ */
