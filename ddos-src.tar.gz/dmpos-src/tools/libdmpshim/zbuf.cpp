#include <zlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>

/******************************************************************************
 *                                                                            *
 * NOTE: This hasn't been thoroughly tested. Reading from compressed streams  *
 *   (at least) is broken; writing to compressed streams appears to work. Use *
 *   at your own risk.                                                        *
 *                                                                            *
 ******************************************************************************/

#ifndef ZLIB_STANDALONE
#include "dmpshim.h"
#else
#define SHIM_LOG(str, args ...) printf(str, ##args)
#endif /* ZLIB_STANDALONE */

#include "zbuf.h"

#ifndef MIN
#  define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

/**
 * zbufinit --
 *
 *   Initialize a ZBuf for use.
 *
 *   Parameters:
 *       zbuf  -- The zbuf to initialize
 *       fd    -- File descriptor to attach to
 *       mode  -- ZCOMPRESS or ZDECOMPRESS
 *
 *   Returns:
 *       0 on success, non-0 on error
 */
int zbufinit(ZBuf *zbuf, int fd, int mode)
{
	int ret;

	if (!zbuf)
		return -EINVAL;

	/* Open the output file */
	zbuf->fd = fd;

	/* Input and output buffers are initially empty */
	zbuf->inlen   = 0;
	zbuf->inavail = ZCHUNK;

	zbuf->outlen   = 0;
	zbuf->outavail = ZCHUNK;

	/* Initialize zlib */
	zbuf->strm.zalloc   = Z_NULL;
	zbuf->strm.zfree    = Z_NULL;
	zbuf->strm.opaque   = Z_NULL;
	zbuf->strm.avail_in = 0;
	zbuf->strm.next_in  = Z_NULL;

	/* Initialize the stream for compression or decompression */
	if (mode == ZCOMPRESS) {
		zbuf->mode = ZCOMPRESS;
		if ((ret = deflateInit(&zbuf->strm, Z_DEFAULT_COMPRESSION)) != Z_OK)
			return ret;

	} else {
		zbuf->mode = ZDECOMPRESS;
		if ((ret = inflateInit(&zbuf->strm)) != Z_OK)
			return ret;
	}

	return 0;
}

/**
 * zbufdestroy --
 *
 *   Flush all pending output to disk, and destroy the zlib stream.
 *
 *   Parameters:
 *       zbuf  -- The buffer to destroy
 *
 *   Retruns:
 *       None
 */
void zbufdestroy(ZBuf *zbuf)
{
	if (!zbuf)
		return;
	
	/* Flush all pending input and output */
	zbufflush(zbuf, Z_FINISH);

	/* Destroy the zlib data structures */
	if (zbuf->mode == ZCOMPRESS)
		deflateEnd(&zbuf->strm);
	else
		inflateEnd(&zbuf->strm);
}

/**
 * zbufflush --
 *
 *   Compress all pending input and store the results in an output buffer. Once
 *   ZCHUNK bytes of compressed data have accumulated the data is flushed to
 *   disk. If end is nonzero, the ZBuf is flushed for closing, and can safely
 *   be destroyed.
 *
 *   Parameters:
 *       zbuf  -- The ZBuf to flush
 *       end   -- Whether or not this is the final flush before closing
 *
 *   Returns:
 *       0 on success, non-0 on failure
 */
int zbufflush(ZBuf *zbuf, int end)
{
	z_stream *strm = NULL;
	int ngot, ret;
	int flush = end ? Z_FINISH : Z_NO_FLUSH;

	if (!zbuf || zbuf->mode != ZCOMPRESS)
		return -EINVAL;

	strm = &zbuf->strm;

	SHIM_LOG("  Flushing input buffer %s(have %d/%d bytes)...\n",
		flush ? "for close " : "", zbuf->inlen, zbuf->inavail);

	/* Tell zlib what and how much to compress */
	strm->next_in  = zbuf->inbuf;
	strm->avail_in = zbuf->inlen;

	do {

		/* Append new output to what we already have */
		strm->next_out  = zbuf->outbuf + zbuf->outlen;
		strm->avail_out = zbuf->outavail;

		/* Compress as much input as possible */
		ret = deflate(strm, flush);
		if (ret == Z_STREAM_ERROR)
			return ret;

		ngot = zbuf->outavail - strm->avail_out;
		zbuf->outlen   += ngot;
		zbuf->outavail -= ngot;

		SHIM_LOG("    Got %d bytes of output\n", ngot);

		/* If our output buffer is full, write it to disk */
		if (strm->avail_out == 0 || flush == Z_FINISH) {
			SHIM_LOG("      Flushing output buffer\n");
			ret = write(zbuf->fd, zbuf->outbuf, zbuf->outlen);
			zbuf->outlen = 0;
			zbuf->outavail = ZCHUNK;
		}
	
	} while (strm->avail_out == 0);

	if (flush == Z_FINISH && ret != Z_STREAM_END)
		return Z_STREAM_ERROR;

	/* We wrote all of our input buffer */
	zbuf->inlen = 0;
	zbuf->inavail = ZCHUNK;

	return 0;
}

/**
 * zwriten --
 *
 *   Add n bytes from buf to the zbuf object. All input is buffered until
 *   ZCHUNK bytes have accumulated, at which point the pending input is
 *   compressed and buffered.
 *
 *   Parameters:
 *       zbuf  -- The zbuf to add the data to
 *       buf   -- Pointer to data to add
 *       n     -- Number of bytes to add
 *
 *   Returns:
 *       The number of bytes added to the zstream
 */
int zwriten(ZBuf *zbuf, char *buf, int n)
{
	int left = n, sofar = 0, last;

	if (zbuf->mode != ZCOMPRESS) {
		SHIM_LOG("  ERROR: Attempting to add data to decompression stream\n");
		return -EINVAL;
	}

	SHIM_LOG("  Adding %d bytes to zbuf...\n", n);

	/* While there is still unprocessed data in buf ... */
	while (left > 0) {

		last = MIN(left, zbuf->inavail);
		memcpy(&zbuf->inbuf[zbuf->inlen], buf + sofar, last);

		SHIM_LOG("    Wrote %d / %d\n", last, left);

		sofar += last;
		left  -= last;

		zbuf->inlen   += last;
		zbuf->inavail -= last;

		/* Do we need to flush the zbuf to disk now? */
		if (zbuf->inavail == 0)
			zbufflush(zbuf, 0 /* end */);

	}

	return sofar;
}

/**
 * zbufslurp --
 *
 *   Fill the input buffer as up to ZCHUNK bytes or EOF.
 *
 *   Parameters:
 *       zbuf  -- The zbuf to slurp
 *
 *   Returns:
 *       The number of available input bytes
 */
int zbufslurp(ZBuf *zbuf)
{
	int last;

	if (!zbuf || zbuf->mode != ZDECOMPRESS)
		return -EINVAL;

	SHIM_LOG("  Slurping %d bytes to zbuf...\n", zbuf->inavail);

	while (zbuf->inavail > 0) {
		last = read(zbuf->fd, &zbuf->inbuf[zbuf->inlen], zbuf->inavail);
		if (last <= 0)
			break;

		zbuf->inlen   += last;
		zbuf->inavail -= last;
	}

	return zbuf->inlen;
}

/**
 * zreadn --
 *
 *   Parameters:
 *       zbuf  -- The zstream to read from
 *       buf   -- (out) Where to place the read data
 *       n     -- Number of bytes to read
 *
 *   Returns:
 *       Number of bytes read, or < 0 on error
 */
int zreadn(ZBuf *zbuf, char *buf, int n)
{
	int left = n, sofar = 0, last, done;

	if (zbuf->mode != ZDECOMPRESS) {
		SHIM_LOG("  ERROR: Attempting to read data from compression stream\n");
		return -EINVAL;
	}

	SHIM_LOG("  Reading %d bytes from zbuf...\n", n);

	/* While there is still data left to read ... */
	done = 0;
	while (left > 0 && !done) {

		/* First copy the data we have already decompressed */
		last = MIN(zbuf->outlen, n);
		SHIM_LOG("    %d bytes already decompressed, grabbing %d\n", zbuf->outlen, last);

		memcpy(buf + sofar, zbuf->outbuf, last);

		left  -= last;
		sofar += last;

		/* Remove the data we just read from the output buffer */
		memmove(zbuf->outbuf, zbuf->outbuf + last, zbuf->outlen - last);
		zbuf->outlen -= last;

		/* If we still need more data, decompress more data */
		if (left > 0) {
			SHIM_LOG("    Still need %d more bytes\n", left);

			if (zbuf->strm.avail_in) {
				SHIM_LOG("      Still have %d bytes of input\n", zbuf->strm.avail_in);

			} else {
				SHIM_LOG("      Getting more data from file\n");
				
				if (zbufslurp(zbuf) <= 0)
					done = 1;

				zbuf->strm.avail_in = zbuf->inlen;
				zbuf->strm.next_in  = zbuf->inbuf;
			}

			/* Decompress the available data */
			zbuf->strm.avail_out = zbuf->outavail;
			zbuf->strm.next_out  = zbuf->outbuf + zbuf->outlen;

			inflate(&zbuf->strm, done ? Z_FINISH : Z_NO_FLUSH);
			last = zbuf->outavail - zbuf->strm.avail_out;

			SHIM_LOG("  Decompressed %d more bytes\n", last);

			zbuf->outlen   += last;
			zbuf->outavail -= last;
		}
	}

	return sofar;

}
