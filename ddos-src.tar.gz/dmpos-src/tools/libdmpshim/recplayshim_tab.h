#ifndef _RECPLAYTAB_H_
#define _RECPLAYTAB_H_

#ifndef __cplusplus
#error "record shim requires c++"
#endif

#include "dmpshim.h"

namespace DMP {

class RecPlayShim;
enum ShimMode { SHIM_RECORD, SHIM_REPLAY };

typedef void (*RecPlayFn)(RecPlayShim *, shim_event *, ShimMode mode, void *arg);

class RecPlayTab {
  public:
  	RecPlayTab();
	~RecPlayTab();

	RecPlayFn get_fn(int syscall);
	
  private:
	/* One entry for each system call in asm/unistd.h */
	RecPlayFn Table[295];
	RecPlayFn GenericFn; 
};

} /* DMP */

#endif /* _RECPLAYTAB_H_ */
