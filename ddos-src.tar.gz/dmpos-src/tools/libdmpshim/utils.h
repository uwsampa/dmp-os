#ifndef _UTILS_H_
#define _UTILS_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#undef  __SYSCALL
#define __SYSCALL(nr, name)  [nr] = #name,

int set_shim_log(const char *filename);
const char* GetSyscallName(const long syscall);
int writen(int fd, char *buf, int n);
int readn(int fd, char *buf, int n);
long get_string(char *shim_buf, const char *dmp_buf, long nbytes, long *out);
int create_listening_socket(const int port);
int connect_to(const char *host, const int port);
int __connect_to(const uint32_t haddr, const uint16_t port);
int accept_connection(int fd, uint32_t *addr, uint16_t *port);
int remote_exec(const char *host, const char *cmd, const int quiet);

#ifndef MIN
#	define MIN(x, y) ((x) < (y) ? (x) : (y))
#	define MAX(x, y) ((x) > (y) ? (x) : (y))
#endif

#ifdef __cplusplus
}
#endif

#endif /* _UTILS_H_ */
