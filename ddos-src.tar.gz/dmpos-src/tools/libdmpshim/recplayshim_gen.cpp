/* Includes needed for various struct sizes */
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/vfs.h>
#include <unistd.h>
#include <ustat.h>
#include <poll.h>
#include <signal.h>
#include <sys/utsname.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/futex.h>
#include <sys/epoll.h>

#include "recplayshim_gen.h"
#include "recplayshim_ioctl.h"

static int read_iovec(RecPlayShim *shim, ShimMode mode, struct iovec *dmp_iov, size_t nio, int nbytes);

/**
 *  TODO --
 *
 *    void fn(shim, *event, mode, *rechdr)
 *
 *      (Rechdr is only valid during replay on syscall_enter events)
 */

__RECPLAY(stat)
{
	const long statsz = sizeof(struct stat);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, statsz, END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * time_t time(time_t *t) --
 *
 *   Nondeterministic outputs:
 *       Return value
 *       t, if non-NULL
 */
__RECPLAY(time)
{
	const long timesz = sizeof(time_t);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, timesz, END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * int gettimeofday(struct timeval *tv, struct timezone *tz)
 *
 *   Nondeterministic outputs:
 *       - Return value
 *       - tv, if non-NULL
 *       - tz, if non-NULL
 */
__RECPLAY(gettimeofday)
{
	const long tvsz = sizeof(struct timeval);
	const long tzsz = sizeof(struct timezone);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, tvsz, ARG1, PTR, IMMLONG, tzsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getitimer)
{
	const long itsz = sizeof(struct itimerval);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, itsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * pid_t wait4(pid_t pid, int *status, int options, struct rusage *rusage) --
 *
 *   Nondeterministic outputs:
 *       - status, if non-NULL
 *       - rusage, if non-NULL
 */
__RECPLAY(wait4)
{
	const long usagesz = sizeof(struct rusage);
	const long recstr[] = { RET,
	                        ARG1, PTR, IMMLONG, sizeof(int),
				ARG3, PTR, IMMLONG, usagesz,
				END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * ssize_t read(int fd, void *buf, size_t count)
 *
 *   Nondeterministic outputs:
 *       - Return value (number of bytes read)
 *       - Contents of buf
 */
__RECPLAY(read)
{
	const long ext_recstr[] = { RET, ARG1, PTR, RET, END };
	const long int_recstr[] = { RET, END };
	const int __unused fd = shim_syscall_arg0(&event->regs);
	const void *buf = (void *)shim_syscall_arg1(&event->regs);

	
	SHIM_LOG("read(fd:%d, ...)\n", fd);

	PFileDescriptor pfd = shim->_fdtable->get(fd);
	if (pfd != NULL && pfd->type == FDT_REP_SOCK)
		SHIM_LOG("read() on an internal socket\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, (pfd != NULL && pfd->type == FDT_REP_SOCK ? int_recstr : ext_recstr));
	else
		replay_str(shim, event, (pfd != NULL && pfd->type == FDT_REP_SOCK ? int_recstr : ext_recstr));
}


/**
 *
 */
__RECPLAY(readv)
{
	long syscallnr                = event->regs.orig_rax;
	struct iovec *dmp_iov_base  = (struct iovec *)shim_syscall_arg1(&event->regs);
	struct iovec  shim_iov;
	int dmp_iovcnt              = shim_syscall_arg2(&event->regs);
	char *buffer;
	long i, sofar, ret, reclen, last;
	unsigned long left;
	int __unused fd = shim_syscall_arg0(&event->regs);

	SHIM_LOG("readv(fd:%d, ...)\n", fd);

	PFileDescriptor pfd = shim->_fdtable->get(fd);
	if (pfd != NULL)
		SHIM_LOG("readv() on an internal fd\n");
	
	if (mode == SHIM_RECORD) {
		ret = shim_syscall_return(&event->regs);

		reclen  = sizeof(ret);

		/* We only record the data when we it isn't an internal fd/sock */
		if (ret >= 0 && pfd == NULL)
			reclen += ret;

		/* Append the header to the log */
		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&ret, sizeof(ret));
	
	} else /* SHIM_REPLAY */ {

		/* Read the return value from the log */
		shim->read_buffer((char *)&ret, sizeof(ret));
		SHIM_LOG("Got return value of %ld\n", ret);
	}

	if (ret > 0 && pfd == NULL) {
		left = ret;

		/* Copy or append the contents from or to the log */
		for (i = 0, sofar = 0; i < dmp_iovcnt && left > 0; i++) {

			/* Get the next iovec from the DMP task */
			shim->timed_dmp_shim_memcpy_sync(&shim_iov, dmp_iov_base, sizeof(struct iovec), FROM_DMP, NULL);
			dmp_iov_base++;

			/* Determine number of bytes from this iovec to read */
			last = MIN(left, shim_iov.iov_len);
			if (mode == SHIM_RECORD) {
				SHIM_LOG("Appending %ld bytes of %ld from iov[%ld]; %ld to go\n",
					last, shim_iov.iov_len, i, left);
			}

			/* Copy those bytes */
			buffer = new char[last];

			if (mode == SHIM_RECORD) {
				shim->timed_dmp_shim_memcpy_sync(buffer, shim_iov.iov_base, last, FROM_DMP, NULL);
				shim->append_buffer(buffer, last);

			} else /* SHIM_REPLAY */ {
				shim->read_buffer(buffer, last);
				shim->timed_dmp_shim_memcpy_sync(buffer, shim_iov.iov_base, last, TO_DMP, NULL);
			}

			delete [] buffer;

			sofar += last;
			left  -= last;
		}
	}

	if (mode == SHIM_REPLAY)
		dmp_shim_emulate_syscall(ret, &event->regs);
}


/**
 * ssize_t readlink(const char *path, char *buf, size_t bufsiz) --
 *
 * TODO: BasicShim should perform this operation for files in the DFH.
 */
__RECPLAY(readlink)
{
	const long recstr[] = { RET, ARG1, PTR, RET, END };

	SHIM_WARN("Untested\n");
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 *
 */
__RECPLAY(pread64)
{
	const long recstr[] = { RET, ARG1, PTR, RET, END };

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * size_t write(int fd, const void *buf, size_t count) --
 *
 *   Nondeterministic outputs:
 *       - Return value (number of bytes written)
 */
__RECPLAY(write)
{
	const long dmp_sys = event->regs.orig_rax;
	const long dmp_fd  = shim_syscall_arg0(&event->regs);
	const long dmp_buf = shim_syscall_arg1(&event->regs);
	const long __unused dmp_n   = shim_syscall_arg2(&event->regs);
	long       ret, shim_fd;
	char      *shim_buf = NULL;
	rechdr_t  *rechdr = (rechdr_t *)arg;
	const long recstr[] = { RET, END };

	SHIM_LOG("write(fd:%ld, ...)\n", dmp_fd);

	if (mode == SHIM_RECORD) {
		/* Just record the number of bytes actually written */
		record_str(shim, event, recstr);

	} else { /* SHIM_REPLAY */
		SHIM_LOG("Made it to recplay_write(fd:%ld, buf:%p, n:%ld)\n",
			dmp_fd, (void *)dmp_buf, dmp_n);

		/*
		 * To ensure the correct number of bytes are written, the shim
		 * needs to perform the write on behalf of the DMP task.
		 * First, consume the record.
		 */
		assert(dmp_sys == SUBTYPE(*rechdr));

		/* Get the number of bytes to write */
		shim->read_buffer((char *)&ret, sizeof(ret));
		
		/* Make a copy of the buffer */
		SHIM_LOG("Copying target buffer to shim\n");
		shim_buf = (char *)malloc(ret);
		assert(shim_buf);

		SHIM_LOG("Starting to copy buffer...\n");
		shim->timed_dmp_shim_memcpy_sync((void *)shim_buf, (void *)dmp_buf, ret, FROM_DMP, NULL);
		SHIM_LOG("done.\n");

		/*
		 * TODO: We do not, in general, want to re-execute the write. However,
		 *   in some special cases (such as writing to stdout), re-executing
		 *   the write is useful. We should only perform the write in these
		 *   cases.
		 */

		/* HACK: This assumes that fd 1 and fd 2 are connected to the terminal */
		if ((dmp_fd == 1 || dmp_fd == 2)) {
		
			/* Duplicate the target FD in to the shim */
			shim_fd = dmp_shim_dupfd(dmp_fd, FROM_DMP, 0);
			assert(shim_fd >= 0);
			SHIM_LOG("Duped dmp_fd:%ld -> shim_fd:%ld\n", dmp_fd, shim_fd);

			/* Write the buffer to our fd */
			SHIM_LOG("Writing exactly %ld bytes to %ld\n", ret, shim_fd);
			writen(shim_fd, shim_buf, ret);

			/* Close our copy */
			close(shim_fd);
		}

		/* Free our copy of the buffer */
		free(shim_buf);

		/* Actually emulate the system call */
		dmp_shim_emulate_syscall(ret, &event->regs);
	}
}


/**
 * 
 */
__RECPLAY(writev)
{
	const long recstr[] = { RET, END };
	int __unused fd = shim_syscall_arg0(&event->regs);

	SHIM_LOG("writev(fd:%d, ...)\n", fd);

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);

	} else { /* SHIM_REPLAY */

		/* TODO: Write to stdout/stderr */
		replay_str(shim, event, recstr);
	}
}


/**
 * int open(const char *pathname, int flags) --
 *
 *   N.B.: File descriptors are allocated deterministically, and if no files
 *         are part of the deterministic file hiearchy, simply returning the
 *         same descriptor during replay would be sufficient. However, becase
 *         the deterministic files are actually reoopened when replaying,
 *         a descriptor for the non-det files still needs to be allocated.
 *         This is currently handled by dup a dummy fd in to the DMP task each
 *         time an fd is opened. See the wiki for alternate implementations.
 *
 *   Nondet outputs:
 *       - Return value (fd)
 */
__RECPLAY(open)
{
	const long recstr[] = { RET, END };
	const long flags = shim_syscall_arg1(&event->regs);
	int fd;
	long ret;
	rechdr_t  *rechdr = (rechdr_t *)arg;

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);
	
	} else /* SHIM_REPLAY */ {
		assert(rechdr->reclen == sizeof(ret));
		shim->read_buffer((char *)&ret, sizeof(ret));

		/* In the error case, just replay return value */
		if (ret < 0) {
			SHIM_LOG("Error case during record; just replaying\n");
			dmp_shim_emulate_syscall(ret, &event->regs);
			return;
		}

		/* Otherwise, dupe a null fd */
		fd = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, flags & O_CLOEXEC);
		if (fd < 0) {
			SHIM_ERR("Couldn't dup fd\n");
			abort();
		}

		SHIM_LOG("Duped nullfd to dmp fd %d\n", fd);
		dmp_shim_emulate_syscall(fd, &event->regs);
	}
}

__RECPLAY(inotify_init)
{
	const long recstr[] = { RET, END };
	int fd;
	long ret;

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);
	
	} else /* SHIM_REPLAY */ {
		rechdr_t  *rechdr = (rechdr_t *)arg;
		assert(rechdr->reclen == sizeof(ret));
		shim->read_buffer((char *)&ret, sizeof(ret));

		/* In the error case, just replay return value */
		if (ret < 0) {
			SHIM_LOG("Error case during record; just replaying\n");
			dmp_shim_emulate_syscall(ret, &event->regs);
			return;
		}

		/* Otherwise, dupe a null fd */
		fd = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0);
		if (fd < 0) {
			SHIM_ERR("Couldn't dup fd\n");
			abort();
		}

		SHIM_LOG("Duped nullfd to dmp fd %d\n", fd);
		dmp_shim_emulate_syscall(fd, &event->regs);
	}
}


__RECPLAY(dup2)
{
	const long dmp_newfd = shim_syscall_arg1(&event->regs);
	const long recstr[] = { RET, END };
	long ret, fd;
	rechdr_t *rechdr = (rechdr_t *)arg;

	if (mode == SHIM_RECORD) {
		int __unused oldfd = shim_syscall_arg0(&event->regs);
		SHIM_LOG("dup2(fd:%d, fd:%ld)\n", oldfd, dmp_newfd);

		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		assert(rechdr->reclen == sizeof(ret));
		shim->read_buffer((char *)&ret, sizeof(ret));

		/* In the error case, just replay return value */
		if (ret < 0) {
			SHIM_LOG("Error case during record; just replaying\n");
			dmp_shim_emulate_syscall(ret, &event->regs);
			return;
		}

		/* We only want to dupe the dummy fd if newfd wasn't already open */
		if (!dmp_shim_checkfd(dmp_newfd)) {
			/* Otherwise, dupe a null fd */
			fd = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0 /* always !cloexec */);
			if (fd < 0) {
				SHIM_ERR("Couldn't dup fd\n");
				abort();
			}

			SHIM_LOG("Duped nullfd to dmp fd %ld\n", fd);

		} else {
			fd = dmp_newfd;
			SHIM_LOG("fd %ld already open, not duping the dummy\n", dmp_newfd);
		}

		SHIM_LOG("During record, ret:%ld (fd now:%ld)\n", ret, fd);

		assert(fd == ret);
		dmp_shim_emulate_syscall(fd, &event->regs);
	}
}


/**
 * int close(int fd) --
 *
 */
__RECPLAY(close)
{
	const long recstr[] = { RET, END };
	const long fd = shim_syscall_arg0(&event->regs);
	long ret, thisret;
	PFileDescriptor tmp;

	SHIM_LOG("close(fd:%ld)\n", fd);
		
	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);

		/*
		 * With reexec-net set, the FDT contains an entry for this fd;
		 * remove it if necessary.
		 */
		ret = shim_syscall_return(&event->regs);
		tmp = shim->_fdtable->get(fd);
		if (tmp != NULL && ret == 0) {
			SHIM_LOG(" ... fd:%d is in the FDT with type %d\n", fd, tmp->type);
			SHIM_LOG(" ... removing\n");
			shim->_fdtable->remove(fd);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		/*
		 * We need to re-execute the close for nondet files to reclaim
		 * the fd. So we don't actually do anything until the leave
		 * event below.
		 */
		SHIM_LOG("Allowing close to execute\n");

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		/*
		 * Make sure the close behaved the same during replay as during
		 * record.
		 */
		shim->read_buffer((char *)&ret, sizeof(ret));
		SHIM_LOG("Got leave event for close (ret: %ld)\n", ret);

		thisret = shim_syscall_return(&event->regs);
		if (thisret != ret) {
			SHIM_WARN("Return during record %ld, during replay %ld\n",
				ret, thisret);
			SHIM_WARN("Using replayed value\n");
		}
		
		/*
		 * With reexec-net set, the FDT contains an entry for this fd;
		 * remove it if necessary.
		 */
		tmp = shim->_fdtable->get(fd);
		if (tmp != NULL && thisret == 0) {
			SHIM_LOG(" ... fd:%d is in the FDT with type %d\n", fd, tmp->type);
			SHIM_LOG(" ... removing\n");
			shim->_fdtable->remove(fd);
		}

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}


#define FCNTLSTR(_str) case _str: return #_str; break
static const char *fcntl_string(unsigned long cmd)
{
	switch (cmd) {
	FCNTLSTR(F_DUPFD);
	FCNTLSTR(F_DUPFD_CLOEXEC);
	FCNTLSTR(F_GETFD);
	FCNTLSTR(F_SETFD);
	FCNTLSTR(F_GETFL);
	FCNTLSTR(F_SETFL);
	default:
		return "Unknown";
	};

	return "Unknown";
}
#undef FCNTLSTR

__RECPLAY(fcntl)
{
	const long fd  = shim_syscall_arg0(&event->regs);
	const long cmd = shim_syscall_arg1(&event->regs);
	const long flag = shim_syscall_arg2(&event->regs);
	const long recstr[] = { RET, END };	
	long thisret;

	SHIM_LOG("fcntl(fd:%ld, %s, ...)\n", fd, fcntl_string(cmd));

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		switch (cmd) {
		case F_GETFD:
		case F_GETFL:
			dmp_shim_emulate_syscall(thisret, &event->regs);
			break;

		case F_SETFD:
			/* The CLOEXEC flag of the duped fd needs to be kept up to date */
			SHIM_LOG("Setting CLOEXEC flag for dummy dmp_fd:%ld\n", fd);
			dmp_shim_set_cloexec(fd, flag);
			dmp_shim_emulate_syscall(thisret, &event->regs);
			break;

		default:
			SHIM_WARN("Unsupported fcntl cmd %ld; replay probably doesn't work\n", cmd);
			dmp_shim_emulate_syscall(thisret, &event->regs);
			break;
		}
	}
}


__RECPLAY(access)
{
	char *dmp_path = (char *)shim_syscall_arg0(&event->regs);

	const long recstr[] = { RET, END };
	char shim_path[PATH_MAX];

	/* Make a copy of the path */
	shim->timed_dmp_shim_strncpy_sync(shim_path, dmp_path, sizeof(shim_path), NULL);
	SHIM_LOG("@%ld.%d access(%s)\n", EVTIME(event), shim_path);

	/*
	 * If this is a det path, there is nothing to record/replay; simply
	 * let the call proceed unencumbered
	 */
	if (shim->isdetpath(shim_path, NULL)) {
		SHIM_LOG(" ... path is deterministic; returning\n");
		return;
	}

	/* If it is a non-det path, then record/replay as usual */
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else /* SHIM_REPLAY */
		replay_str(shim, event, recstr);
}


/**
 * int clock_gettime(clockid_t clk_id, struct timespec *tp)
 *
 *   Nondeterministic outputs:
 *       - Return value
 *       - res
 */
__RECPLAY(clock_gettime)
{
	const long tssz     = sizeof(struct timespec);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, tssz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * char *getcwd(char *buf, size_t size)
 *
 *   Nondeterministic outputs:
 *       - Return value
 *       - Contents of buf
 */
__RECPLAY(getcwd)
{
	const long recstr[] = { RET, ARG0, PTR, RET, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getdents)
{
	const long recstr[] = { RET, ARG1, PTR, RET, END };
	const long __unused fd = shim_syscall_arg0(&event->regs);
	
	SHIM_LOG("getdents(fd:%ld, ...)\n", fd);

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getrlimit)
{
	const long rsz = sizeof(struct rlimit);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, rsz, END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * int pipe(int pipefd[2]) --
 *
 *   N.B.: Pipes should be deterministic; don't record/replay
 */
#if 0
__RECPLAY(pipe)
{
	const long intsz = sizeof(int);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, 2 * intsz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}
#endif


__RECPLAY(statfs)
{
	const long statsz = sizeof(struct statfs);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, statsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(sched_getaffinity)
{
	const long recstr[] = { RET, ARG2, PTR, IMMREG, ARG1, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(nanosleep)
{
	const long tssz = sizeof(struct timespec);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, tssz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getrusage)
{
	const long rusz = sizeof(struct rusage);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, rusz, END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(sysinfo)
{
	const long sisz = sizeof(struct sysinfo);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, sisz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(times)
{
	const long tmsz = sizeof(struct tms);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, tmsz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(ustat)
{
	const long ussz = sizeof(struct ustat);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, ussz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(sched_getparam)
{
	const long spsz = sizeof(struct sched_param);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, spsz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(sched_rr_get_interval)
{
	const long tssz = sizeof(struct timespec);
	const long recstr[] = { RET, ARG1, PTR, IMMLONG, tssz, END };
	
	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/*
 * Because poll() is often called in tight loops, there is an optimization
 * below; if the return value of the poll system call is 0, then we don't need
 * to record all of the zeros, we can simply "reconstruct" the zeros during
 * replay. This will save space in the log, and will save time copying values
 * from the task during record.
 */
__RECPLAY(poll)
{
	const long syscallnr = event->regs.orig_rax;
	struct pollfd *dmp_fds = (struct pollfd *)shim_syscall_arg0(&event->regs);
	const nfds_t nfds = shim_syscall_arg1(&event->regs);
	long thisret, reclen;
	unsigned int i;
	struct pollfd shim_fd, *dmp_curfd;
	rechdr_t *rechdr = (rechdr_t *)arg;

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);

		/* Add a record header to the log file */
		reclen  = sizeof(thisret);
		if (thisret > 0) /* See comment above */
			reclen += sizeof(short) * nfds;

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));

		if (thisret == 0) {
			SHIM_LOG("No fds are ready; not recording anything\n");

		} else if (thisret > 0) {
			SHIM_LOG("Writing values for %ld fds...\n", nfds);

			/* Add the returned flags for each fd to the log */
			for (dmp_curfd = dmp_fds, i = 0; i < nfds; i++, dmp_curfd++) {

				/* Read the current fd from the DMP task */
				shim->timed_dmp_shim_memcpy_sync(&shim_fd, dmp_curfd, sizeof(struct pollfd),
						     FROM_DMP, NULL);

				SHIM_LOG("    [%2d] Flags: %d\n", i, shim_fd.revents);

				/* Write the returned flags to the file */
				shim->append_buffer((char *)&shim_fd.revents, sizeof(short));
			}
		} else {
			SHIM_LOG("Negative return value; not recording any FDs\n");
		}

	} else /* SHIM_REPLAY */ {
		SHIM_LOG("Rechdr is %ld bytes = return value + %ld fds; syscall asking for %ld fds\n",
			rechdr->reclen, (rechdr->reclen - sizeof(thisret)) / sizeof(short), nfds);
		assert(rechdr->reclen == sizeof(thisret) + nfds * sizeof(short));
		
		/* Get the return value */
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		if (thisret == 0) {
			SHIM_LOG("No fds were ready, reconstructing zeroes\n");

		} else {
			SHIM_LOG("Reading values for %ld fds...\n", nfds);
		}

		/* Update each field in the fd array */
		for (dmp_curfd = dmp_fds, i = 0; i < nfds; i++, dmp_curfd++) {

			if (thisret > 0)
				shim->read_buffer((char *)&shim_fd.revents, sizeof(short));
			else
				shim_fd.revents = 0;
			
			SHIM_LOG("    [%2d] Flags: %d\n", i, shim_fd.revents);

			shim->timed_dmp_shim_memcpy_sync(&shim_fd.revents, &dmp_curfd->revents,
				sizeof(short), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}


__RECPLAY(epoll_create)
{
	const long recstr[] = { RET, END };
	long ret;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {
		ret = shim_syscall_return(&event->regs);
		SHIM_LOG("epoll_create(...) -> fd:%ld\n", ret);
		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		replay_str(shim, event, recstr);
		ret = event->regs.rcx;
		SHIM_LOG("epoll_create(...) -> fd:%ld\n", ret);
		
		SHIM_LOG("Creating new fd...\n");
		if (ret > 0) {
			int fd = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0);
			if (fd < 0) {
				SHIM_ERR("Couldn't dup fd\n");
				abort();
			}

			SHIM_LOG("Duped nullfd to new dmp fd:%d\n", fd);
		
		} else {
			SHIM_LOG("Error case; no new fd to create\n");
		}
	}
}

__RECPLAY(epoll_wait)
{
	const long syscallnr  = event->regs.orig_rax;
	const int __unused dmp_efd  = shim_syscall_arg0(&event->regs);
	const int dmp_nfds = shim_syscall_arg2(&event->regs);
	struct epoll_event shim_event, *dmp_events = (struct epoll_event *)shim_syscall_arg1(&event->regs);
	long recsz = 0;
	int i; 

	SHIM_WARN("Untested\n");
	SHIM_LOG("epoll_wait(fd:%d, ...\n", dmp_efd);

	if (mode == SHIM_RECORD) {
		const long dmp_ret = shim_syscall_return(&event->regs);
		SHIM_LOG("Events for %d fds (of %d)\n", dmp_ret, dmp_nfds);

		recsz = sizeof dmp_ret;
		if (dmp_nfds > 0)
			recsz += sizeof(struct epoll_event) * dmp_nfds;

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, recsz);
		shim->append_buffer((char *)&recsz, sizeof(recsz));
		for (i = 0; i < dmp_nfds; i++) {
			shim->timed_dmp_shim_memcpy_sync(&shim_event, &dmp_events[i], sizeof(shim_event), FROM_DMP, NULL);
			SHIM_LOG("    [%2d] events %#x\n", i, shim_event.events);
			shim->append_buffer((char *)&shim_event, sizeof(shim_event));
		}

	} else /* SHIM_REPLAY */ {
		rechdr_t *rechdr = (rechdr_t *)arg;
		long shim_ret;

		assert(rechdr->reclen >= sizeof(shim_ret));
		shim->read_buffer((char *)&shim_ret, sizeof(shim_ret));
		SHIM_LOG("Events for %ld fds (of %d)\n", shim_ret, dmp_nfds);

		for (i = 0; i < dmp_nfds; i++) {
			shim->read_buffer((char *)&shim_event, sizeof(shim_event));
			SHIM_LOG("    [%2d] events %#x\n", i, shim_event.events);
			shim->timed_dmp_shim_memcpy_sync(&shim_event, &dmp_events[i], sizeof(shim_event), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(shim_ret, &event->regs);
	}
}


__RECPLAY(get_mempolicy)
{
	const long recstr[] = { RET,
	                        ARG0, PTR, IMMLONG, sizeof(int),
	                        ARG1, PTR, IMMLONG, sizeof(long),
				END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getresuid)
{
	const long uidsz = sizeof(uid_t);
	const long recstr[] = { RET,
	                        ARG0, PTR, IMMLONG, uidsz,
	                        ARG1, PTR, IMMLONG, uidsz,
	                        ARG2, PTR, IMMLONG, uidsz,
	                        END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}

__RECPLAY(getresgid)
{
	const long gidsz = sizeof(gid_t);
	const long recstr[] = { RET,
	                        ARG0, PTR, IMMLONG, gidsz,
	                        ARG1, PTR, IMMLONG, gidsz,
	                        ARG2, PTR, IMMLONG, gidsz,
	                        END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(uname)
{
	const long utssz = sizeof(struct utsname);
	const long recstr[] = { RET, ARG0, PTR, IMMLONG, utssz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}

/**
 * int getgroups(int size, gid_t list[]) --
 *
 *   Return a list of gids that the caller is a member of.
 *
 *   Nondet outputs:
 *       return  -- Number of member or groups
 *       list    -- List of groups
 */
__RECPLAY(getgroups)
{
	const long syscallnr    = event->regs.orig_rax;
	const long ret        = shim_syscall_return(&event->regs);
	long thisret, reclen;
	gid_t *dmp_gids = (gid_t *)shim_syscall_arg1(&event->regs);
	gid_t *shim_gids;
	int gidsz, ngids;
	rechdr_t *rechdr = (rechdr_t *)arg;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {
		gidsz = ret * sizeof(gid_t);

		/* Compute the record size */
		reclen = sizeof(ret);
		if (ret > 0)
			reclen += sizeof(gid_t) * ret;

		/* Add a header to the log */
		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&ret, sizeof(ret));

		/* Add any supplementary groups */
		if (ret > 0) {
			SHIM_LOG("Retrieving %ld supplementary group ids\n", ret);
			shim_gids = new gid_t[ret];
			shim->timed_dmp_shim_memcpy_sync(shim_gids, dmp_gids, gidsz, FROM_DMP, NULL);
			shim->append_buffer((char *)shim_gids, gidsz);
			delete [] shim_gids;
		}

	} else /* SHIM_REPLAY */ {
		
		/* Get the number of groups we need to read */
		gidsz = rechdr->reclen - sizeof(thisret);
		ngids = gidsz / sizeof(gid_t);
		assert(gidsz % sizeof(gid_t) == 0);

		/* Get the return value from the log */
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		/* Get the gids, if there are any to get */
		if (ngids > 0) {
			SHIM_LOG("Reading %d supplementary group ids from log\n", ngids);
			shim_gids = new gid_t[ngids];
			shim->read_buffer((char *)shim_gids, gidsz);
			shim->timed_dmp_shim_memcpy_sync(shim_gids, dmp_gids, gidsz, TO_DMP, NULL);
			delete [] shim_gids;

		} else {
			SHIM_LOG("No gids to read\n");
		}

		/* Do it. */
		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}


/**
 * void *mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off)
 */
__RECPLAY(mmap)
{
	const long syscallnr  = event->regs.orig_rax;
	const void *__unused dmpaddr = (void *)shim_syscall_arg0(&event->regs);
	const long __unused dmplen   = shim_syscall_arg1(&event->regs);
	const long __unused dmpprot  = shim_syscall_arg2(&event->regs);
	const long dmpflags = shim_syscall_arg3(&event->regs);
	const long dmpfd    = shim_syscall_arg4(&event->regs);
	const long __unused dmpoff   = shim_syscall_arg5(&event->regs);
	long logret, thisret;

	SHIM_LOG("mmap(addr:%p, len:%ld, prot:%lx, flags:%lx, fd:%ld, off:%ld)\n",
	         dmpaddr, dmplen, dmpprot, dmpflags, dmpfd, dmpoff);

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);

		shared_ptr<FileDescriptor> fp = shim->_fdtable->get(dmpfd);
		if (!(dmpflags & MAP_ANONYMOUS) && fp == NULL)
			SHIM_WARN("Mapping a nondeterministic file is unsupported; continuing anyway\n");

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, sizeof(thisret));
		shim->append_buffer((char *)&thisret, sizeof(thisret));

	} else /* SHIM_REPLAY */ {
		if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
			SHIM_LOG("Entering mmap; re-executing...\n");

			shared_ptr<FileDescriptor> fp = shim->_fdtable->get(dmpfd);
			if (!(dmpflags & MAP_ANONYMOUS) && fp == NULL)
				SHIM_WARN("Mapping a nondeterministic file is unsupported; continuing anyway\n");

		} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
			thisret = shim_syscall_return(&event->regs);
			shim->read_buffer((char *)&logret, sizeof(logret));

			if (thisret != logret) {
				SHIM_WARN("mmap return differs from log: now %lx, log %lx\n", thisret, logret);
				SHIM_WARN("continuing anyway\n");
			}

		} else {
			SHIM_ERR("Unexepected event type %d\n", event->event_type);
			abort();
		}
	}
}


__RECPLAY(sysfs)
{
	const long syscallnr = event->regs.orig_rax;
	const long option  = shim_syscall_arg0(&event->regs);
	char      *dmp_buf = (char *)shim_syscall_arg2(&event->regs);
	char       shim_buf[256];
	long       shim_len, reclen, ret;
	rechdr_t  *rechdr = (rechdr_t *)arg;

	const long recstr[] = { RET, END };

	/* See sysfs(2) for description of this nonsense */

	if (option == 2 ) {
		if (mode == SHIM_RECORD) {
			ret = shim_syscall_return(&event->regs);

			shim->timed_dmp_shim_strncpy_sync(shim_buf, dmp_buf, 256, &shim_len);
			if (shim_buf[shim_len-1] != '\0') {
				SHIM_ERR("Overflow detected\n");
				abort();
			}

			SHIM_LOG("   Got: '%s'\n", shim_buf);

			reclen = sizeof(ret) + shim_len - 1;

			add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
			shim->append_buffer((char *)&ret, sizeof(ret));
			shim->append_buffer(shim_buf, shim_len-1);

		} else /* SHIM_REPLAY */ {

			shim_len = rechdr->reclen - sizeof(ret);
			if (shim_len+1 >= 256) {
				SHIM_ERR("Overflow during replay\n");
				abort();
			}

			shim->read_buffer((char *)&ret, sizeof(ret));
			shim->read_buffer(shim_buf, shim_len);
			shim_buf[shim_len] = '\0';

			SHIM_LOG("    Got: '%s'\n", shim_buf);
			
			shim->timed_dmp_shim_memcpy_sync(shim_buf, dmp_buf, shim_len+1, TO_DMP, NULL);
			dmp_shim_emulate_syscall(ret, &event->regs);
		}

	} else {
		if (mode == SHIM_RECORD)
			record_str(shim, event, recstr);
		else
			replay_str(shim, event, recstr);
	}
}


/**
 * rt_sigaction --
 *
 *   Modifies which user-space function is called for signal delivery. Needs to
 *   be reexecuted during replay to ensure the same function is called.
 *
 *   TODO:
 *       Not entirely clear whether the old sigaction is deterministic or not.
 *       Record for now, and check during replay.
 */
__RECPLAY(rt_sigaction)
{
	const long sasz = sizeof(struct sigaction);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, sasz, END };
	struct sigaction *dmp_sigact = (struct sigaction *)shim_syscall_arg2(&event->regs);
	struct sigaction  shim_sigact, log_sigact;
	long thisret, logret;

	if (mode == SHIM_RECORD) {
		/* During record, log the event */
		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
			SHIM_LOG("Re-executing system call...\n");

		} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
			/* Get the return values */
			thisret = shim_syscall_return(&event->regs);
			shim->read_buffer((char *)&logret, sizeof(logret));

			SHIM_LOG("   Return now:%ld, log:%ld\n", thisret, logret);

			if (dmp_sigact != NULL) {
				shim->timed_dmp_shim_memcpy_sync(&shim_sigact, dmp_sigact, sasz, FROM_DMP, NULL);
				shim->read_buffer((char *)&log_sigact, sizeof(log_sigact));

				/* Display a warning if this execution divereged from record */
				if (thisret != logret)
					SHIM_WARN("Return values differ: now %ld, log %ld\n", thisret, logret);

				/* Just make sure nothing has changed... */
				if (shim_sigact.sa_handler   != log_sigact.sa_handler   ||
				    shim_sigact.sa_sigaction != log_sigact.sa_sigaction ||
				    /* shim_sigact.sa_mask   != log_sigact.sa_mask      || */
				    shim_sigact.sa_flags     != log_sigact.sa_flags     ||
				    shim_sigact.sa_restorer  != log_sigact.sa_restorer   )
					SHIM_WARN("Returned sigact differs from log; continuing\n");

			} else {
				SHIM_LOG("    NULL oldsigact parameter; ignoring...\n");
			}

		} else {
			SHIM_ERR("Unexpected event type %d\n", event->event_type);
			abort();
		}
	}
}


/**
 * rt_sigprocmask --
 *
 *   Because rt_sigprocmask modifies which signals can be delivered to the task,
 *   it needs to be reexecuted during replay to ensure that the same set of 
 *   signals can be delivered as during record. (This really only matters for
 *   signals sent between DPG tasks, since their kill() syscalls will be
 *   reexecuted; signals sent by non-DPG tasks during record will be injected
 *   during replay.)
 *
 *   TODO:
 *       Not entirely clear whether or not oldset is deterministic. Record it
 *       for now, and check it during replay.
 */
__RECPLAY(rt_sigprocmask)
{
	sigset_t *dmp_set = (sigset_t *)shim_syscall_arg2(&event->regs);
	long thisret, logret;
	sigset_t shim_set, log_set;

	const long sssz = sizeof(sigset_t);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, sssz, END };

	if (mode == SHIM_RECORD) {
		/* During record, log the event */
		record_str(shim, event, recstr);

	} else {
		if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
			SHIM_LOG("Re-executing system call...\n");

		} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
			/* Get the return values */
			thisret = shim_syscall_return(&event->regs);
			shim->read_buffer((char *)&logret, sizeof(logret));

			if (dmp_set != NULL) {

				shim->timed_dmp_shim_memcpy_sync(&shim_set, dmp_set, sssz, FROM_DMP, NULL);
				shim->read_buffer((char *)&log_set, sizeof(log_set));

				/* Display a warning if this execution divereged from record */
				if (thisret != logret)
					SHIM_WARN("Return values differ: now %ld, log %ld\n", thisret, logret);

				/* TODO: Find a way to compare these values */
				#if 0
				if ((long)shim_set != (long)log_set) {
					SHIM_WARN("Returned sigsets differ: now %lx, log %lx\n", 
						(long)shim_set, (long)log_set);
				}
				#endif

			} else {
				SHIM_LOG("    NULL oldset parameter; ignoring\n");
			}

		} else {
			SHIM_ERR("Unexpected event type %d\n", event->event_type);
			abort();
		}
	}
}


#define IOCTLSTR(_str) case _str: return #_str; break
static const char *ioctl_string(unsigned long cmd)
{
	switch (cmd) {
	IOCTLSTR(SIOCGIFCONF);
	IOCTLSTR(SIOCGIFFLAGS);
	IOCTLSTR(SIOCGIFINDEX);
	IOCTLSTR(SIOCGIFADDR);
	IOCTLSTR(SIOCGIFNETMASK);
	IOCTLSTR(TCGETS);
	IOCTLSTR(TCSETS);
	IOCTLSTR(TIOCGPGRP);
	IOCTLSTR(TIOCGPTN);
	IOCTLSTR(TIOCSPTLCK);
	IOCTLSTR(TIOCINQ);
	IOCTLSTR(TIOCOUTQ);
	IOCTLSTR(TIOCGWINSZ);
	default:
		return "Unknown";
	};

	return "Unknown";
}
#undef IOCTLSTR

/**
 * ioctl(fd, cmd, ...) --
 *
 *   The effect of ioctl depends not only on the value of cmd, but also on what
 *   type of descriptor fd is.
 *
 *   TODO: This is currently *way* incomplete; every ioctl will need to be 
 *     handled individually before record/replay to be complete. However,
 *     the ones that are handled here are the ones used by the test benchmarks.
 */
__RECPLAY(ioctl)
{
	int __unused fd  = shim_syscall_arg0(&event->regs);
	unsigned long cmd = shim_syscall_arg1(&event->regs);
	int handled = 0;

	const long recstr[] = { RET, END };

	SHIM_LOG("ioctl(fd:%d, %s, ...)\n", fd, ioctl_string(cmd));

	switch (cmd) {
	/* Socket ioctls */
	case SIOCGIFCONF:    recplay_ioctl_siocgifconf(shim, event, mode, arg); break;
	case SIOCGIFFLAGS:   recplay_ioctl_siocgifflags(shim, event, mode, arg); break;
	case SIOCGIFINDEX:   recplay_ioctl_siocgifindex(shim, event, mode, arg); break;
	case SIOCGIFADDR:    recplay_ioctl_siocgifaddr(shim, event, mode, arg); break;
	case SIOCGIFNETMASK: recplay_ioctl_siocgifnetmask(shim, event, mode, arg); break;

	/* Terminal ioctls */
	case TCGETS:         recplay_ioctl_tcgets(shim, event, mode, arg); break;
	case TIOCGPGRP:      recplay_ioctl_tiocgpgrp(shim, event, mode, arg); break;
	case TIOCGPTN:       recplay_ioctl_tiocgptn(shim, event, mode, arg); break;
	case TIOCINQ:        recplay_ioctl_tiocinq(shim, event, mode, arg); break;
	case TIOCOUTQ:       recplay_ioctl_tiocoutq(shim, event, mode, arg); break;
	case TIOCGWINSZ:     recplay_ioctl_tiocgwinsz(shim, event, mode, arg); break;
		
	/* Everything else */
	case TCSETS:         /* Fallthrough */ /* TODO: recplay_ioctl_tcsets(shim, event, mode, arg); break; */
	case TIOCSPTLCK:     handled = 1; /* Fallthrough */
	default:
		if (!handled)
			SHIM_WARN("Unhandled ioctl 0x%lx. ", cmd);

		SHIM_LOG("Using generic ioctl recstr\n");
		if (mode == SHIM_RECORD)
			record_str(shim, event, recstr);
		else
			replay_str(shim, event, recstr);
		break;
	}
}


/**
 * TODO: This is not implemented correctly.
 */
__RECPLAY(set_tid_address)
{
	long ret, thisret;
	const long recstr[] = { RET, END };
	rechdr_t *rechdr = (rechdr_t *)arg;

	SHIM_WARN("Incomplete\n");

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
			assert(rechdr->reclen == sizeof(ret));
			SHIM_LOG("Allowing set_tid_address to reexecute\n");

		} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
			shim->read_buffer((char *)&ret, sizeof(ret));

			thisret = shim_syscall_return(&event->regs);
			SHIM_LOG("  During record, return was %ld, during replay, return was %ld\n",
			         ret, thisret);
			SHIM_LOG("  Using the value recorded\n");

			event->regs.rax = ret;
			dmp_shim_setregs(&event->regs);

		} else {
			SHIM_ERR("Unexpected event type: %d\n", event->event_type);
		}
	}
}

#define FUTEXSTR(_str) case _str: return #_str; break
const char *futex_str(int op)
{
	op = op & ~FUTEX_PRIVATE_FLAG;

	switch (op) {
	FUTEXSTR(FUTEX_WAIT);
	FUTEXSTR(FUTEX_WAKE);
	FUTEXSTR(FUTEX_FD);
	FUTEXSTR(FUTEX_REQUEUE);
	FUTEXSTR(FUTEX_CMP_REQUEUE);
	FUTEXSTR(FUTEX_WAKE_OP);
	FUTEXSTR(FUTEX_LOCK_PI);
	FUTEXSTR(FUTEX_UNLOCK_PI);
	FUTEXSTR(FUTEX_TRYLOCK_PI);
	default:
		return "Unknown";
		break;
	};
}
#undef FUTEXSTR

__RECPLAY(futex)
{
	const long __unused dmpptr    = shim_syscall_arg0(&event->regs);
	long dmpop           = shim_syscall_arg1(&event->regs);
	long dmp_val2p       = shim_syscall_arg4(&event->regs);
	const long __unused dmpval    = shim_syscall_arg1(&event->regs);
	const long __unused priv      = dmpop & FUTEX_PRIVATE_FLAG;
	const long recstr[] = { RET, ARG4, PTR, IMMLONG, sizeof(uint32_t), END };
	uint32_t shim_val2;

	dmpop = dmpop & ~FUTEX_PRIVATE_FLAG;

	SHIM_LOG("futex(0x%p, %s%s (0x%x), %ld, ...)\n", (void*)dmpptr, futex_str(dmpop),
	         priv ? "(P)" : "", (unsigned int)dmpop, dmpval);

	if (dmpop == FUTEX_WAKE_OP) {
		shim->timed_dmp_shim_memcpy_sync(&shim_val2, (void *)dmp_val2p, sizeof(shim_val2), FROM_DMP, NULL);
		SHIM_LOG("    Val before: %d\n", shim_val2);
	}

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
	
	if (dmpop == FUTEX_WAKE_OP) {
		shim->timed_dmp_shim_memcpy_sync(&shim_val2, (void *)dmp_val2p, sizeof(shim_val2), FROM_DMP, NULL);
		SHIM_LOG("    Val after : %d\n", shim_val2);
	}
}


/******************************************************************************
 *         Generic recplay functions used by many different syscalls          *
 ******************************************************************************/
/**
 * recplay_generic --
 *
 *   Generic record/replay function used for system calls that only return
 *   non-deterministic values, and have no additional program-visible
 *   side-effects.
 */
__RECPLAY(generic)
{
	const long recstr[] = { RET, END };

	SHIM_LOG("%s with generic function\n",
		mode == SHIM_RECORD ? "Recording" : "Replaying");
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


/**
 * recplay_reexec --
 *
 *   Generic record/replay function used for system calls that should
 *   be reexecuted during replay. This will also display a message if 
 *   the return value has diverged from what is in the log.
 */
__RECPLAY(reexec)
{
	const long syscallnr  = event->regs.orig_rax;
	long thisret, logret;

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);
		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, sizeof(thisret));
		shim->append_buffer((char *)&thisret, sizeof(thisret));

	} else /* SHIM_REPLAY */ {
		if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
			SHIM_LOG("Entering reexec; re-executing...\n");

		} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
			SHIM_LOG("Returned from re-execution...\n");

			thisret = shim_syscall_return(&event->regs);
			shim->read_buffer((char *)&logret, sizeof(logret));

			if (thisret != logret)
				SHIM_WARN("reexec return differs: now %ld, log %ld\n", thisret, logret);

		} else {
			SHIM_ERR("Unexpected event type %d\n", event->event_type);
			abort();
		}
	}
}


/**
 * recplay_abort --
 *
 *   Prints a message and aborts record/replay. This is used by syscalls
 *   such as fork and clone that the Recplay shim should never see.
 */
__RECPLAY(abort)
{
	SHIM_ERR("Recplay saw a system call it shouldn't ever see!\n");
	abort();
}


/******************************************************************************
 *                      General Record Helper Functions                       *
 ******************************************************************************/
/**
 * add_record --
 *
 *   Add an entry header to the log file. Every entry must have a header. The
 *   len field indicates how much additional data is stored after the header,
 *   and depends on what is being recorded for this event.
 *
 *   Parameters:
 *       shim          -- The recording shim
 *       logical_time  -- Logical time the event happened
 *       type          -- The type of the event (SYSCALL, SIGNAL, etc.)
 *       subtype       -- The event subtype (syscall number, or signal number)
 *       len           -- How many bytes for event-specific record
 *
 *   Returns:
 *       None
 */
void add_record(RecPlayShim *shim, uint64_t logical_time, char type, uint32_t subtype, uint64_t len)
{
	uint32_t fulltype = type | (subtype << 8);

	SHIM_LOG("Adding record: @%ld.%d, type:%d, subtype:%d, reclen:%ld\n",
		__EVTIME(logical_time), type, subtype, len);

	/* TODO: Don't need to record the syscall number; its deterministic */
	shim->append_buffer((char *)&logical_time, sizeof(logical_time));
	shim->append_buffer((char *)&fulltype,     sizeof(fulltype));
	shim->append_buffer((char *)&len,          sizeof(len));
}


/******************************************************************************
 *                       Record String Helper Functions                       *
 ******************************************************************************/
/**
 * get_reg --
 *
 *   Get the contents of a specific register in the given event
 *
 *   Parameters:
 *       event  -- The event to query
 *       reg    -- The register to extract
 *
 *   Returns:
 *       The value of the requested register
 */
static long get_reg(shim_event *event, long reg)
{
	switch (reg) {
	case ARG0: return shim_syscall_arg0(&event->regs); break;
	case ARG1: return shim_syscall_arg1(&event->regs); break;
	case ARG2: return shim_syscall_arg2(&event->regs); break;
	case ARG3: return shim_syscall_arg3(&event->regs); break;
	case ARG4: return shim_syscall_arg4(&event->regs); break;
	case ARG5: return shim_syscall_arg5(&event->regs); break;
	case RET:  return event->regs.rax; break;
	default:
		return -1;
		break;
	}
}


/**
 * compute_arg_len --
 *
 *   Compute the length of the next token in the recstring
 *
 *   Parameters:
 *       recstr  -- The record string that contains the tokens
 *       event   -- The event being recorded
 *       i       -- (in)  The current token position in the string
 *                  (out) Where we finished processing
 *
 *   Returns:
 *       The number of bytes for this token
 */
static long compute_arg_len(const long *recstr, shim_event *event, int *i)
{
	long target = recstr[(*i)++];
	long type, subtype;
	long reclen = 0;
	void *dmp_ptr;

	if (target == RET) {
		reclen = sizeof(long);

	} else {
		type = recstr[(*i)++];

		switch (type) {
		case IMMREG:
			reclen = sizeof(long);
			break;
		case IMMLONG:
			reclen = recstr[(*i)++];
			break; 
		case PTR:
			subtype = recstr[(*i)++];
			switch (subtype) {
			case RET:     reclen = get_reg(event, RET); break;
			case IMMREG:  reclen = get_reg(event, recstr[(*i)++]); break;
			case IMMLONG: reclen = recstr[(*i)++]; break;
			};

			dmp_ptr = (void *)get_reg(event, target);
			if (dmp_ptr == NULL)
				reclen = 0;

			break;
		}
	}

	return reclen;
}


/**
 * record_arg --
 *
 *   Record a single target from the given recstr.
 *
 *   Parameters:
 *       shim    -- Record shim
 *       recstr  -- Recstr to record, starting at the given idx
 *       event   -- Corresponding shim event
 *       ret     -- (in)  Used as a lenght, if PTR len is given as RET
 *               -- (out) Updated to return value, if target is RET
 *       idx     -- (in)  Index to the target to record
 *               -- (out) Updated to the index of the next target
 *
 *   Returns:
 *       None
 */
static void record_arg(RecPlayShim *shim, const long *recstr, shim_event *event, int *idx)
{
	long target = recstr[(*idx)++], type, lensrc, ret, reg;
	long len;
	void *dmp_ptr;
	char *buffer;

	if (target == RET) {
		ret = shim_syscall_return(&event->regs);
		shim->append_buffer((char *)&ret, sizeof(ret));
	
	} else {
		type = recstr[(*idx)++];
		if (type != PTR) {
			SHIM_ERR("Recording a non-pointer target?\n");
			abort();
		}

		lensrc = recstr[(*idx)++];
		SHIM_LOG("    Reading length as %ld\n", lensrc);
		
		switch (lensrc) {
		case RET:
			len = shim_syscall_return(&event->regs);
			SHIM_LOG("    Using return value of %ld as length\n", len);
			break;
		case IMMLONG:
			len = recstr[(*idx)++];
			break;
		case IMMREG:
			reg = recstr[(*idx)++];
			len = get_reg(event, reg);
			SHIM_LOG("Using length %ld from reg %ld\n", len, reg);
			break;
		default:
			SHIM_ERR("Unknown length type %ld\n", lensrc);
			abort();
		};

		dmp_ptr = (void *)get_reg(event, target);
		SHIM_LOG("    Appending %ld byte sfrom dmp address 0x%p\n", len, dmp_ptr);

		if (dmp_ptr == NULL) {
			SHIM_LOG("NULL target; skipping\n");

		} else if (len <= 0) {
			SHIM_LOG("No bytes to copy; skipping\n");

		} else {
			buffer = new char[len];
			if (!buffer) {
				SHIM_ERR("No memory\n");
				abort();
			}
	
			SHIM_LOG("Starting to copy %ld to %p from DMP\n", len, dmp_ptr);
			shim->timed_dmp_shim_memcpy_sync(buffer, dmp_ptr, len, FROM_DMP, NULL);
			SHIM_LOG("done\n");

			shim->append_buffer(buffer, len);

			delete [] buffer;
		}
	}
}


/**
 * record_str --
 *
 *   Record the effects of the given recstr, based on the values in the event
 *   and the contents of the shim's log.
 *
 *   Parameters:
 *       shim    -- Record shim
 *       event   -- The corresponding shim event
 *       recstr  -- The record string to record
 *
 *   Returns:
 *       None
 */
void record_str(RecPlayShim *shim, shim_event *event, const long *recstr)
{
	long reclen = 0, thislen;
	int i = 0;

	while (recstr[i] != END) {
		thislen = compute_arg_len(recstr, event, &i);
		SHIM_LOG("    Arg len: %ld\n", thislen);
		if (thislen > 0)
			reclen += thislen;
	}

	SHIM_LOG("    Rec len: %ld\n", reclen);
	add_record(shim, event->logical_time, LOG_SYSCALL,
	           event->regs.orig_rax, reclen);

	i = 0;
	while (recstr[i] != END)
		record_arg(shim, recstr, event, &i);
}

/**
 * replay_arg --
 *
 *   Replay a single target from the given recstr.
 *
 *   Parameters:
 *       shim    -- Replay shim
 *       recstr  -- Recstr to replay, starting at the given idx
 *       event   -- Corresponding shim event
 *       ret     -- (in)  Used as a lenght, if PTR len is given as RET
 *               -- (out) Updated to return value, if target is RET
 *       idx     -- (in)  Index to the target to record
 *               -- (out) Updated to the index of the next target
 *
 *   Returns:
 *       None
 */
static void replay_arg(RecPlayShim *shim, const long *recstr, shim_event *event, uint64_t *ret, int *idx)
{
	long target = recstr[(*idx)++], type, lensrc, reg;
	long len;
	void *dmp_ptr;
	char *buffer;

	if (target == RET) {
		shim->read_buffer((char *)ret, sizeof(*ret));
		SHIM_LOG("    Set return value to %ld\n", *ret);

	} else {
		type = recstr[(*idx)++];

		if (type != PTR) {
			SHIM_ERR("Why did you record a non-pointer value?\n");
			abort();
		}

		lensrc = recstr[(*idx)++];
		SHIM_LOG("    Reading length as %ld\n", lensrc);
		switch (lensrc) {
		case RET:
			SHIM_LOG("    Using return value of %ld as length (MUST BE SET ALREADY!)\n", *ret);
			len = *ret;
			break;
		case IMMLONG:
			len = recstr[(*idx)++];
			break;
		case IMMREG:
			reg = recstr[(*idx)++];
			SHIM_LOG("    Using length from reg %ld\n", reg);
			len = get_reg(event, reg);
			break;
		default:
			SHIM_ERR("    Unimplemented length type for replay: %ld\n", lensrc);
			abort();
			break;
		};

		dmp_ptr = (void *)get_reg(event, target);
		SHIM_LOG("    Copying %ld bytes to dmp address 0x%p\n", len, dmp_ptr);

		if (dmp_ptr == NULL) {
			SHIM_LOG("Target address is NULL; skipping\n");

		} else if (len < 0) {
			SHIM_LOG("Weird length %ld; skipping...\n", len);

		} else if (len > 0) {
			/*
			 * Allocate a local buffer to hold the result
			 */
			buffer = new char[len];
			if (!buffer) {
				SHIM_ERR("No memory\n");
				abort();
			}

			/* 
			 * Slurp the log, advancing the current position (can't lseek
			 * without the fd, which is a private member of the shim)
			 */
			shim->read_buffer(buffer, len);

			/*
			 * Copy the buffer over to the dmp task
			 */
			SHIM_LOG("Starting to copy %ld to %p in DMP task...\n", len, dmp_ptr);
			shim->timed_dmp_shim_memcpy_sync(buffer, dmp_ptr, len, TO_DMP, NULL);
			SHIM_LOG("done\n");

			/*
			 * Get rid of our copy
			 */
			delete [] buffer;
		}
	}
}


/**
 * replay_str --
 *
 *   Replay the effects of the given recstr, based on the values in the event
 *   and the contents of the shim's log.
 *
 *   Parameters:
 *       shim    -- Replay shim
 *       event   -- The corresponding shim event
 *       recstr  -- The record string to interpret
 *
 *   Returns:
 *       None
 */
void replay_str(RecPlayShim *shim, shim_event *event, const long *recstr)
{
	uint64_t ret = -1;
	int i = 0;

	/* Replay any side effects in recstr */
	while (recstr[i] != END)
		replay_arg(shim, recstr, event, &ret, &i);

	dmp_shim_emulate_syscall(ret, &event->regs);
}


/******************************************************************************
 *                           Other helper functions                           *
 ******************************************************************************/
static int read_iovec(RecPlayShim *shim, ShimMode mode, struct iovec *dmp_iov,
	size_t nio, int nbytes)
{
	int sofar, last;
	unsigned int i, left;
	struct iovec shim_iov;
	struct iovec *dmp_curiov = dmp_iov;
	char *buffer;

	/* Don't do anything if we don't have data to read/write */
	if (shim == NULL || dmp_iov == NULL || nbytes <= 0 || nio <= 0)
		return 0;

	sofar = 0;
	left  = nbytes;

	/* Copy or append the contents from or to the log */
	for (i = 0; i < nio && left > 0; i++) {

		/* Get the next iovec from the DMP task */
		shim->timed_dmp_shim_memcpy_sync(&shim_iov, dmp_curiov, sizeof(struct iovec), FROM_DMP, NULL);
		dmp_curiov++;

		/* Determine number of bytes from this iovec to read */
		last = MIN(left, shim_iov.iov_len);

		if (mode == SHIM_RECORD) {
			SHIM_LOG("Appending %d bytes of %ld from iov[%d]; %d to go\n",
				last, shim_iov.iov_len, i, left);

		} else /* SHIM_REPLAY */ {
			SHIM_LOG("Reading %d bytes of %ld from iov[%d]; %d to go\n",
				last, shim_iov.iov_len, i, left);
		}

		/* Copy those bytes */
		buffer = new char[last];

		if (mode == SHIM_RECORD) {
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_iov.iov_base, last, FROM_DMP, NULL);
			shim->append_buffer(buffer, last);

		} else /* SHIM_REPLAY */ {
			shim->read_buffer(buffer, last);
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_iov.iov_base, last, TO_DMP, NULL);
		}

		delete [] buffer;

		sofar += last;
		left  -= last;
	}

	return sofar;
}
