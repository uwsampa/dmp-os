/*
 * User-land wrappers for DMP-shim syscalls
 */

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "dmpshim.h"

/*
 * Syscalls
 */

long dmp_shim_attach(pid_t pid)
{
	return syscall(SYS_dmp_shim_attach, pid);
}

long dmp_shim_trace(struct shim_event *event)
{
	if (!event) {
		errno = EINVAL;
		return -errno;
	}

	return syscall(SYS_dmp_shim_trace, event);
}

long dmp_shim_set_barrier(enum ShimBarrierType type, enum ShimBarrierWhence whence, uint64_t logical_time)
{
	return syscall(SYS_dmp_shim_set_barrier, 0, type, whence, logical_time);
}

long __dmp_shim_set_barrier(pid_t pid, enum ShimBarrierType type, enum ShimBarrierWhence whence, uint64_t logical_time)
{
	return syscall(SYS_dmp_shim_set_barrier, pid, type, whence, logical_time);
}

long dmp_shim_sleep(int sleep_for_wake)
{
	return syscall(SYS_dmp_shim_sleep, sleep_for_wake);
}

long dmp_shim_wake(void)
{
	return syscall(SYS_dmp_shim_wake);
}

long dmp_shim_ctl(enum ShimCtl func, long arg1, long arg2, long arg3, long arg4, long arg5)
{
	return syscall(SYS_dmp_shim_ctl, func, arg1, arg2, arg3, arg4, arg5);
}

/*
 * Ctl shorthands
 */

long dmp_shim_memcpy(void *shim_buf, void *dmp_buf, long nbytes, enum ShimCtlFlag write_to_dmp, long *bytes_out)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_MEMCPY,
			    (long)shim_buf, (long)dmp_buf, nbytes, write_to_dmp, (long)bytes_out);
}

long dmp_shim_strncpy(void *shim_buf, void *dmp_buf, long nbytes, long *bytes_out)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_STRNCPY,
			    (long)shim_buf, (long)dmp_buf, nbytes, (long)bytes_out, 0);
}

long dmp_shim_setregs(struct user_regs_struct *regs)
{
	if (!regs) {
		errno = EINVAL;
		return -errno;
	}

	return dmp_shim_ctl(DMP_SHIM_CTL_SETREGS, (long)regs, 0, 0, 0, 0);
}

long dmp_shim_dupfd(unsigned int dmp_fd, enum ShimCtlFlag dup_to_dmp, int cloexec)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_DUPFD, dmp_fd, dup_to_dmp, cloexec, 0, 0);
}

long dmp_shim_dupfd2(unsigned int dmp_fd, unsigned int dmp_fd_2)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_DUPFD2, dmp_fd, dmp_fd_2, 0, 0, 0);
}

long dmp_shim_closefd(unsigned int dmp_fd)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_CLOSEFD, dmp_fd, 0, 0, 0, 0);
}

long dmp_shim_checkfd(unsigned int dmp_fd)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_CHECKFD, dmp_fd, 0, 0, 0, 0);
}

long dmp_shim_set_cloexec(unsigned int dmp_fd, int val)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_SET_CLOEXEC, dmp_fd, val, 0, 0, 0);
}

long dmp_shim_set_nomot(unsigned int shim_fd, enum ShimMotFlag flag)
{
	int val;

	val = (flag == NOMOT);

	return dmp_shim_ctl(DMP_SHIM_CTL_SET_NOMOT, shim_fd, val, 0, 0, 0);
}

long dmp_shim_get_logical_time(void)
{
	return dmp_shim_ctl(DMP_SHIM_CTL_GET_LOGICAL_TIME, 0, 0, 0, 0, 0);
}
