/*
 * User-land library for DMP-shims
 */

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "dmpshim.h"

/*
 * This should only be called while the thread we are shimming is blocked on
 * a SYSCALL event, before the SYSCALL occurs. This function only copies the
 * modified registers back to the shimmed thread; it does not continue its
 * execution.  Another call to sys_dmp_shim_trace is required.
 *   ret  :: return value of the syscall
 *   regs :: registers at the start of the syscall
 */
long dmp_shim_emulate_syscall(long sysret, struct user_regs_struct *regs)
{
	if (!regs) {
		errno = EINVAL;
		return -errno;
	}

	unsigned long old_rax = regs->rax;
	unsigned long old_rcx = regs->rcx;

	/*
	 * Encode the emulation request in rcx and rax.
	 * See comments in entry_64.S about the selection of these registers.
	 */
	regs->rax = -1;
	regs->rcx = sysret;

	SHIM_LOG("rax:%ld (return)rcx:%ld orig_rax:%ld rip:%lx\n",
		 regs->rax, regs->rcx, regs->orig_rax, regs->rip);

	long ret = dmp_shim_setregs(regs);
	if (ret < 0) {
		SHIM_PERROR("dmp_shim_setregs for dmp_shim_emulate_syscall");
		regs->rax = old_rax;
		regs->rcx = old_rcx;
	}

	return ret;
}

long dmp_shim_memcpy_sync(void *shim_buf_in, void *dmp_buf_in, long nbytes,
			  enum ShimCtlFlag write_to_dmp, long *bytes_out)
{
	char *shim_buf = (char*)shim_buf_in;
	char *dmp_buf  = (char*)dmp_buf_in;
	long ret, last;
	long sofar = 0;

	if (bytes_out)
		*bytes_out = 0;

	SHIM_LOG("dmpbuf %p\n", dmp_buf);

	do {
		ret = dmp_shim_memcpy(shim_buf, dmp_buf, nbytes - sofar, write_to_dmp, &last);
		sofar += last;
		shim_buf += last;
		dmp_buf  += last;

		SHIM_LOG("sofar: %ld of %ld last: %ld ret: %ld/%d\n", sofar, nbytes, last, ret, errno);

		if (ret < 0) {
			if (errno == EAGAIN) {
				/*
				 * Incomplete write due to MOT violation -- wait for
				 * next serial mode before retrying
				 */
				struct shim_event event;
				SHIM_LOG("EAGAIN: Waiting for next serial mode\n");
				if (dmp_shim_set_barrier(SHIM_BARRIER_IO, SHIM_BARRIER_NEXT_SERIAL, 0) < 0)
					SHIM_PERROR("shim_set_barrier");
				if (dmp_shim_sleep(DMP_SLEEP_NORMAL) < 0)
					SHIM_PERROR("shim_sleep");
				if (dmp_shim_trace(&event) < 0)
					SHIM_PERROR("shim_trace");
				if (event.event_type != DMP_SHIM_BARRIER) {
					SHIM_LOG("unexpected event %d\n", event.event_type);
				}
				continue;
			}

			/* Everything else is an error */
			SHIM_LOG("error: %d\n", errno);
			break;
		}

	} while (sofar != nbytes);

	if (bytes_out)
		*bytes_out = sofar;

	return ret;
}

long dmp_shim_strncpy_sync(void *shim_buf_in, void *dmp_buf_in, long nbytes, long *bytes_out)
{
	char *shim_buf = (char*)shim_buf_in;
	char *dmp_buf  = (char*)dmp_buf_in;
	long ret = 0, last = -1;
	long sofar = 0;

	if (bytes_out)
		*bytes_out = 0;

	SHIM_LOG("dmpbuf %p\n", dmp_buf);

	do {
		ret = dmp_shim_strncpy(shim_buf, dmp_buf, nbytes - sofar, &last);
		sofar += last;
		shim_buf += last;
		dmp_buf  += last;

		SHIM_LOG("sofar: %ld of %ld last: %ld ret: %ld/%d\n", sofar, nbytes, last, ret, errno);

		if (ret < 0) {
			if (errno == EAGAIN) {
				/*
				 * Incomplete write due to MOT violation -- wait for
				 * next serial mode before retrying
				 */
				struct shim_event event;
				SHIM_LOG("EAGAIN: Waiting for next serial mode\n");
				if (dmp_shim_set_barrier(SHIM_BARRIER_IO, SHIM_BARRIER_NEXT_SERIAL, 0) < 0)
					SHIM_PERROR("shim_set_barrier");
				if (dmp_shim_sleep(DMP_SLEEP_NORMAL) < 0)
					SHIM_PERROR("shim_sleep");
				if (dmp_shim_trace(&event) < 0)
					SHIM_PERROR("shim_trace");
				if (event.event_type != DMP_SHIM_BARRIER) {
					SHIM_LOG("unexpected event %d\n", event.event_type);
				}
				continue;
			}

			/* Everything else is an error */
			SHIM_LOG("error: %d\n", errno);
			break;
		}

	} while (ret != 0);

	if (bytes_out)
		*bytes_out = sofar;

	return ret;
}
