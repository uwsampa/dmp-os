/*
 * A library of useful shim functions
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/times.h>
#include <utime.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syscall.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <linux/netdevice.h>

#include "dmp.h"
#include "basicshim.h"

static uint32_t uniquekey;

pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;

namespace DMP {

/**
 * Timer stuff
 */
/**
 * timeval_diff(s, e, res) --
 *
 *   Compute the difference in two timeval structs, storing the result in the
 *   provided timeval struct.
 *
 *   Parameters:
 *     s    -- Starting time
 *     e    -- Ending time
 *     res  -- Where to store the resulting difference
 *
 *   Returns:
 *     0 on success, -1 on failure.
 */
int timeval_diff(struct timeval *s, struct timeval *e, struct timeval *res)
{
	if (res == NULL)
		return -1;
 
	res->tv_usec = e->tv_usec - s->tv_usec;
	res->tv_sec  = e->tv_sec - s->tv_sec;
 
	if (s->tv_usec > e->tv_usec)
	{
		res->tv_usec += 1000000;
		res->tv_sec--;
	}
 
	return 0;
}
 
/**
 * timeval_diff_ms(s, e) --
 *
 *   Compute the difference in two timeval structs, returning the result as the
 *   number of milliseconds elapsed between the two values.
 *
 *   Parameters:
 *     s  -- Starting time
 *     e  -- Ending time
 * 
 *   Returns:
 *     The difference in ms between the two times in ms
 */
int timeval_diff_ms(struct timeval *s, struct timeval *e)
{
	struct timeval tmp;
	timeval_diff(s, e, &tmp);
	return 1000 * tmp.tv_sec + (tmp.tv_usec / 1000);
}

TimerStat::TimerStat(const char *msg)
	: _timer(0), _msg(msg), _running(false)
{ }

TimerStat::~TimerStat()
{
	if (_running)
		stop();

	SHIM_WARN("   %s: %.3f s\n", _msg.c_str(), _timer*1.0/1000.0);
}

uint64_t TimerStat::get_ms()
{
	return _timer;
}

void TimerStat::reset()
{
	set(0);
	_running = false;
}

void TimerStat::set(uint64_t ms)
{
	if (_running) {
		SHIM_WARN("Setting a running timer\n");
	}

	_timer = ms;
}

void TimerStat::start()
{
	if (_running) {
		SHIM_WARN("Timer already started!\n");
	}

	_running = true;
	gettimeofday(&_start, NULL);
}

void TimerStat::stop()
{
	struct timeval _temp;

	if (_running) {
		gettimeofday(&_temp, NULL);
		_timer += timeval_diff_ms(&_start, &_temp);
		_running = false;
	} else {
		SHIM_WARN("Stopping a stopped timer?\n");
	}
}

HistogramStat::HistogramStat(const char *msg)
	: _msg(msg)
{ }

HistogramStat::~HistogramStat(void)
{
	print();
}

void HistogramStat::print(void)
{
	map<int, int>::iterator i;
	char buffer[128];
	string drifts = "{";

	SHIM_WARN("%s:\n", _msg.c_str());
	for (i = _buckets.begin(); i != _buckets.end(); ++i) {
		snprintf(buffer, sizeof buffer, "%d : %d, ", i->first, i->second);
		drifts += buffer;
	}
	drifts += "}";

	SHIM_WARN("%s\n", drifts.c_str());
}

int HistogramStat::add(int key)
{
	_buckets[key] = _buckets[key]++;
	return _buckets[key];
}

long BasicShim::timed_dmp_shim_memcpy_sync(void *shim_buf, void *dmp_buf, long nbytes,
	enum ShimCtlFlag write_to_dmp, long *bytes_out)
{
	long ret;
	memcpyTime.start();
	ret = dmp_shim_memcpy_sync(shim_buf, dmp_buf, nbytes, write_to_dmp, bytes_out);
	memcpyTime.stop();
	return ret;
}

long BasicShim::timed_dmp_shim_strncpy_sync(void *shim_buf, void *dmp_buf, long nbytes,
	long *bytes_out)
{
	long ret;
	memcpyTime.start();
	ret = dmp_shim_strncpy_sync(shim_buf, dmp_buf, nbytes, bytes_out);
	memcpyTime.stop();
	return ret;
}

//-------------------------------------------------------------------------
// Local stuff
//-------------------------------------------------------------------------

boost::filesystem::path join_paths(const boost::filesystem::path &root, const char* sub)
{
	if (sub[0] == '/') {
		return boost::filesystem::path(sub);
	} else {
		return root / sub;
	}
}

static uint32_t nprocesses;
static uint32_t nthreads;
uint32_t nrunning;

static pthread_mutex_t nrunning_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  nrunning_cond = PTHREAD_COND_INITIALIZER;

uint32_t GetProcesses()
{
	return nprocesses;
}

uint32_t GetThreads()
{
	return nthreads;
}

uint32_t GetRunning()
{
	return nrunning;
}

static inline void AddProcess()
{
	__sync_fetch_and_add(&nprocesses, 1);
}

static inline void AddThread()
{
	__sync_fetch_and_add(&nthreads, 1);
}

static inline void UpdateNRunning(int diff)
{
	pthread_mutex_lock(&nrunning_lock);
	nrunning += diff;
	pthread_cond_signal(&nrunning_cond);
	pthread_mutex_unlock(&nrunning_lock);
}

inline void FillLocalIP(PDNode node)
{
	int s;
	struct ifconf ifconf;
	struct ifreq ifr[50];
	int ifs;
	int i;

	const uint32_t LOCAL1 = 0x0;
	const uint32_t LOCAL2 = 0x7f000001;
	const uint32_t LOCAL3 = 0x7f000101;

	if (!node || (node->address != LOCAL1 && node->address != LOCAL2 && node->address != LOCAL3))
		return;

	s = socket(AF_INET, SOCK_STREAM, 0); 
	if (s < 0) {
		perror("socket");
		return;
	}

	ifconf.ifc_buf = (char *) ifr;
	ifconf.ifc_len = sizeof ifr;

	if (ioctl(s, SIOCGIFCONF, &ifconf) == -1) {
		close(s);
		perror("ioctl");
		return;
	}

	ifs = ifconf.ifc_len / sizeof(ifr[0]);
	SHIM_LOG("Found interfaces = %d:\n", ifs);
	for (i = 0; i < ifs; i++) {
		struct sockaddr_in *s_in = (struct sockaddr_in *) &ifr[i].ifr_addr;

		if (s_in->sin_addr.s_addr != LOCAL1 &&
		    s_in->sin_addr.s_addr != LOCAL2 &&
		    s_in->sin_addr.s_addr != LOCAL3) {
			SHIM_LOG("Setting address to: %x\n", ntohl(s_in->sin_addr.s_addr));
			node->address = ntohl(s_in->sin_addr.s_addr);
		}
	}

	close(s);
}

void WaitForThreadsToDie(bool printsummary)
{
	pthread_mutex_lock(&nrunning_lock);
	while (nrunning != 0) {
		SHIM_LOG("waiting for %d more threads to die\n", nrunning);
		pthread_cond_wait(&nrunning_cond, &nrunning_lock);
	}
	pthread_mutex_unlock(&nrunning_lock);

	if (printsummary) {
		printf("DMP spawned %d threads\n", nthreads);
		printf("DMP spawned %d processes\n", nprocesses);
	}
}

/**
 * Constant -> string helper functions
 */
const char *event_type_tostring(uint32_t type, char *buf, int maxsize)
{
	int idx;
	const char *events[] = {
		"SYSCALL_ENTER", "SYSCALL_LEAVE", "BARRIER", "SHIM_CALL",
		"SHIM_EXIT", "VFORK_WAIT", "RDTSC", "SIGNAL", "<UNKNOWN>"
	};
	
	
	idx = MIN(sizeof(events) / sizeof(events[0])-1, type);

	snprintf(buf, maxsize, "%s", events[idx]);

	return buf;
}

void append_type(const char *newstr, char *buf, int maxsize, int *cursize)
{
	if (buf[0] != '\0') {
		strncat(buf, " | ", maxsize - *cursize);
		*cursize -= 3;
	}

	strncat(buf, newstr, maxsize - *cursize);
	*cursize -= strlen(newstr);

	if (*cursize == maxsize)
		buf[maxsize-1] = '\0';
}

const char *barrier_type_tostring(uint32_t barrier_type, char *buf, int n)
{
	int sofar = 0;

	if (buf == NULL || n < 1)
		return "<INVALID>";

	buf[0] = '\0';

	if (barrier_type & SHIM_BARRIER_IO)
		append_type("IO", buf, n, &sofar);
	if (barrier_type & SHIM_BARRIER_SYSCALL)
		append_type("SYSCALL", buf, n, &sofar);
	if (barrier_type & SHIM_BARRIER_DISTQ)
		append_type("DISTQ", buf, n, &sofar);

	return buf;
}


//-----------------------------------------------------------------------------
// Socket communication
//-----------------------------------------------------------------------------
//    Sockets that communicate with deterministic network nodes are tracked
//    in the _fdtable. To enforce deterministic network communication, the 
//    arrival of network data must occur deterministically. To do this, the
//    shim buffers all data sent to a DNN and forwards it to the remote shim.
//    The remote shim in turn buffers this data until the next "network
//    quantum"; when this next quantum arrives, the shim makes the buffered 
//    data available to the program. All receive operations performed on a
//    socket can only read data once it has been released from the shim; until
//    being released, the buffered data is inaccesible to the program.
//-----------------------------------------------------------------------------


/**
 * get_next_shim_event(event) --
 *
 *   Convience function to return the next shim event. This function will
 *   determine whether or not the event received is a distributed quantum
 *   barrier, and perform the correct action. Further, if the event is *only* a
 *   distributed quantum barrier (i.e., not a distq barrier piggy-backed on
 *   another event), it will discard the event and wait for the next one.
 */
int BasicShim::get_next_shim_event(shim_event *event)
{
	int ret = 0;
	char __unused buf1[1024], __unused buf2[1024];

	/*
	 * Make sure we're given a valid shim_event to fill in
	 */
	if (!event)
		return -1;

	/*
	 * Grab the next shim event from the kernel; if the next event is a
	 * global distributed quantum, we call the appropriate handler. We
	 * repeatedly get shim events until the first "real" one arrives (i.e.,
	 * the first event that isn't a dedicated distq barrier)
	 */
	while (1) {
		//SHIM_LOG("Waiting for the next shim event\n");
		waitForEventTime.start();
		ret = dmp_shim_trace(event);
		waitForEventTime.stop();
		if (ret < 0) {
			SHIM_PERROR("dmp_shim_trace");
			abort();
		}

		//SHIM_LOG("Received event: @%ld.%d (%ld) type:%d (%s)\n", EVTIME(event), event->logical_time, event->event_type, event_type_tostring(event->event_type, buf1, sizeof(buf1)));
		//if (event->event_type == DMP_SHIM_BARRIER)
			//SHIM_LOG("    barrier_type:%d (%s)\n", event->barrier_type, barrier_type_tostring(event->barrier_type, buf2, sizeof(buf2)));

		/*
		 * If this is a non-barrier event, return it right away to the caller.
		 */
		if (event->event_type != DMP_SHIM_BARRIER) {
			//SHIM_LOG("    This isn't a barrier; returning immediately\n");
			break;

		/*
		 * Otherwise, this is a barrier event. If it is a distq
		 * barrier, call the distq barrier handler.
		 */
		} else if (event->barrier_type & SHIM_BARRIER_FLAG_DISTQ) {
			SHIM_LOG("    Received a distributed quantum barrier!\n");
			handle_distq_barrier(event);
			
			if (event->barrier_type != SHIM_BARRIER_FLAG_DISTQ)
				SHIM_WARN("   Why did we get a shared barrier? This shouldn't exist anymore.\n");

		} else {
			SHIM_LOG("    Non-distq barrier received; returning\n");
			break;
		}
	}

	return ret;
}

//-------------------------------------------------------------------------
// VirtualSocket
//-------------------------------------------------------------------------
VirtualSocket::VirtualSocket()
	: refctr(1)
{
	pthread_mutex_init(&__lock, NULL);
	sock_sndbuf = 8192;
	sock_rcvbuf = 8192;
	sock_keepalive = 0;
	tcp_nodelay    = 0;
	sock_reuseaddr = 0;
}

VirtualSocket::~VirtualSocket()
{
	pthread_mutex_destroy(&__lock);
}

/**
 * Returns TRUE if there is data ready to be read, or an incoming connection
 * request to this virtual socket.
 *
 * N.B. this->lock() must be called FIRST!
 */
bool VirtualSocket::pending_read()
{
	bool result = false;

	if (this->data.avail(current_distq) != 0) {
		SHIM_LOG("Data is ready to be read\n");
		result = true;
	}
 
	if ((this->state & VS_LISTENING) && this->incoming_connections.size() != 0) {
		SHIM_LOG("There is an incoming connection request\n");
		result = true;
	}

	return result;
}


VSockMap::VSockMap()
	: map<uint16_t, PVSock>()
{
	pthread_mutex_init(&__lock, NULL);
	nextPort = 1024;
}

VSockMap::~VSockMap()
{
	pthread_mutex_destroy(&__lock);
}

uint16_t VSockMap::getNewPort()
{
	uint16_t port;

	do {
		port = nextPort++;
		SHIM_LOG("  Trying vport %d\n", port);
	} while(this->find(port) != this->end());

	SHIM_LOG("  Returning vport %d\n", port);
	return port;
}



/******************************************************************************/
/* BitSet                                                                     */
/******************************************************************************/
BitSet::BitSet()
	: bitset<MAXDDPGS>()
{
	SHIM_LOG("Creating bitset\n");
	SHIM_LOG("New bitset: %lx\n", this->to_ulong());
	pthread_mutex_init(&__lock, NULL);
}

BitSet::~BitSet()
{
	pthread_mutex_destroy(&__lock);
}

void BitSet::lock(void)
{
	pthread_mutex_lock(&__lock);
}

void BitSet::unlock(void)
{
	pthread_mutex_unlock(&__lock);
}

void BitSet::set()
{
	SHIM_LOG("Setting all bits in %p\n", this);
	bitset<MAXDDPGS>::set();
	SHIM_LOG("   Result: %ld\n", to_ulong());
}

void BitSet::set(size_t pos)
{
	SHIM_LOG("Setting bit %ld in %p\n", pos, this);
	bitset<MAXDDPGS>::set(pos);
	SHIM_LOG("   Result: %ld\n", to_ulong());
}

void BitSet::reset()
{
	SHIM_LOG("Resetting all bits in %p\n", this);
	bitset<MAXDDPGS>::reset();
	SHIM_LOG("   Result: %ld\n", to_ulong());
}

void BitSet::reset(size_t pos)
{
	SHIM_LOG("Resetting bit %ld in %p\n", pos, this);
	bitset<MAXDDPGS>::reset(pos);
	SHIM_LOG("   Result: %ld\n", to_ulong());
}

void BitSet::safe_set(size_t pos)
{
	lock();
	this->set(pos);
	unlock();
}

void BitSet::safe_set()
{	
	lock();
	this->set();
	unlock();
}

void BitSet::safe_reset(size_t pos)
{
	lock();
	this->reset(pos);
	unlock();
}

void BitSet::safe_reset()
{
	lock();
	this->reset();
	unlock();
}

//-------------------------------------------------------------------------
// SlottedBuffer 
//-------------------------------------------------------------------------
SlottedBuffer::SlottedBuffer()
{
	pthread_mutex_init(&lock, NULL);
}

SlottedBuffer::~SlottedBuffer()
{
	pthread_mutex_destroy(&lock);
}

void SlottedBuffer::debug_msg()
{
	const int context = 5;
	int cnt;

	list<PSlottedMessage>::const_iterator iter;

	cnt = 0;
	if (true) {
		SHIM_LOG("Pending messages for buffer %p:\n", this);
		pthread_mutex_lock(&lock);
		for (iter = messages.begin(); iter != messages.end(); iter++) {
			if (cnt < context || cnt >= messages.size() - context) {
				SHIM_LOG("  [%ld] @%ld: %ld bytes\n",
						cnt, (*iter)->arrival_time,
						(*iter)->data.size());

			} else if (cnt == context) {
				SHIM_LOG("  ...........\n");
			}

			cnt++;
		}
		pthread_mutex_unlock(&lock);
	}
}

/**
 * avail(now) --
 *  
 *   Get the number of bytes that are currently available for reading by the
 *   application.
 *
 *   Parameters:
 *       now  -- Current global quantum
 *
 *   Returns:
 *       The number of available bytes for this quantum
 */
uint64_t SlottedBuffer::avail(uint64_t now)
{
	uint64_t ret = 0;
	list<PSlottedMessage>::const_iterator pos;

	debug_msg();

	/*
	 * Iterate over all pending messages, and accumulate the lengths
	 * from messages that were available no later than the beginning of
	 * quantum now. 
	 */
	pthread_mutex_lock(&lock);
	for (pos = messages.begin(); pos != messages.end(); pos++) {
		if ((*pos)->arrival_time >= now)
			break;

		ret += (*pos)->data.size();
	}
	pthread_mutex_unlock(&lock);

	return ret;
}

/**
 * append(now, buf, n) --
 *
 *   Add n bytes of data from buf to the slotted buffer. This data will
 *   be available for consumption at time now+1. 
 *
 *   Parameters:
 *       now  -- Current global quantum
 *       buf  -- Pointer to beginning of data to append
 *       n    -- Number of bytes to copy from buf
 *
 *   Returns:
 *       Number of bytes appended, or < 0 on failure.
 */
uint64_t SlottedBuffer::append(uint64_t now, char *buf, uint64_t n)
{
	uint64_t i;
	char *curpos;
	
	if (buf == NULL)
		return -EINVAL;
	
	PSlottedMessage message = PSlottedMessage(new SlottedMessage);
	message->arrival_time = now;
		
	/*
	 * TODO: This is really quite bad; we'll see about it in the future...
	 */
	for (i = 0, curpos = buf; i < n; i++, curpos++)
		message->data.push_back(*curpos);
	
	pthread_mutex_lock(&lock);
	messages.push_back(message);
	pthread_mutex_unlock(&lock);

	debug_msg();

	return i;
}

/**
 * get(now, buf, n) --
 *
 *   Read up to n bytes from the SlottedBuffer. If not enough data is
 *   currently available to satisfy the request, as many bytes are copied as
 *   are available.
 *
 *   Parameters:
 *       now  -- Current global quantum
 *       buf  -- Where to store the resulting data
 *       n    -- Number of bytes to read
 *
 *   Returns:
 *       Number of bytes copied if successful, or < 0 if error 
 */
uint64_t SlottedBuffer::get(uint64_t now, char *buf, uint64_t n)
{
	uint64_t sofar = 0, toget, i;
	char *curpos;
	PSlottedMessage message;
	list<PSlottedMessage>::iterator iter;

	debug_msg();

	pthread_mutex_lock(&lock);
	for (iter = messages.begin(); n > 0 && iter != messages.end(); /* Updated in body */) {
		message = (*iter);
	
		/* We can only consume data from earlier quanta */
		if (message->arrival_time >= now) {
			SHIM_LOG("Earliest message is in the future (now: %ld, message: %ld)\n",
				now, message->arrival_time);
			break;
		}

		/* Again, brain-dead copy, but I don't posess STL foo */
		toget = MIN(n, message->data.size());
		
		SHIM_LOG("Getting %ld bytes from message of length %ld\n", 
			toget, message->data.size());

		/* Leverage contiguousness of vectors for bulk copy */
		memcpy(buf+sofar, &message->data[0], toget);
		message->data.erase(message->data.begin(), message->data.begin()+toget);

		n     -= toget;
		sofar += toget;

		/* If we completely consumed this message, remove it from the list */
		if (message->data.size() == 0)
			iter = messages.erase(iter);
		else
			iter++;
	}
	pthread_mutex_unlock(&lock);

	SHIM_LOG("   Retrieved %ld bytes\n", sofar);
	return sofar;
}

//-------------------------------------------------------------------------
// FileDescriptor
//-------------------------------------------------------------------------

FileDescriptor::FileDescriptor()
	: type(FDT_FILE), shadowfd(-1), filesize(0), filepos(0), close_on_exec(0)
{
	timing.read  = -1;
	timing.write = -1;
	timing.open  = -1;
	timing.close = -1;
}

FileDescriptor::~FileDescriptor()
{
	if (shadowfd >= 0)
		close(shadowfd);
}

//-------------------------------------------------------------------------
// FileDescriptorTable
//-------------------------------------------------------------------------

FileDescriptorTable::FileDescriptorTable()
	: map<int,shared_ptr<FileDescriptor> >()
{}

shared_ptr<FileDescriptorTable> FileDescriptorTable::clone()
{
	shared_ptr<FileDescriptorTable> clone(new FileDescriptorTable);
	for (const_iterator i = begin(); i != end(); ++i)
		clone->add(i->first, i->second);
	return clone;
}

shared_ptr<FileDescriptor> FileDescriptorTable::get(int fd)
{
	PFileDescriptor pfd;

	iterator i = this->find(fd);
	if (i != this->end())
		pfd = i->second;
	else
		pfd = shared_ptr<FileDescriptor>();
	
	SHIM_LOG("_fdtable:%p fd:%d, _fdtable->get(%d):%p\n",
		this, fd, fd, pfd.get());

	return pfd;
}

void FileDescriptorTable::remove(int fd)
{
	iterator i = this->find(fd);
	if (i != this->end())
		this->erase(i);
}

void FileDescriptorTable::clean_cloexec(void)
{
	SHIM_LOG("Cleaning close on exec descriptors from table...\n");
	for (iterator i = this->begin(); i != this->end(); i++) {
		if (i->second->close_on_exec) {
			SHIM_LOG("dmp_fd:%d (shim_fd:%d) set for FD_CLOEXEC\n", i->first, i->second->shadowfd);
			close(i->second->shadowfd);
			this->erase(i);
		}
	}
	SHIM_LOG("Done.\n");
}

//-------------------------------------------------------------------------
// BasicShim
//-------------------------------------------------------------------------

BasicShim::BasicShim(BasicShim* parent, int clone_flags, bool reexec_detnet)
	: _dmp_pid(0), _unique_id(__sync_fetch_and_add(&uniquekey, 1)),
	  _done_flag(false), event_count(0),
	  master_node_id(0), num_dpgs(1), distq_size(0), control_sock(-1),
	  reexec_detnet(reexec_detnet), max_drift(0), totalTime("Total time alive"),
	  memcpyTime("Memcpy time"), waitForDistqTime("Waiting for distq barrier"),
	  socketIOTime("Socket IO"), waitForPeersTime("Waiting for peers to catch up"),
	  waitForEventTime("Waiting for shim events"), waitForConnectTime("Waiting for connect resp"),
	  waitForDataTime("Waiting for data to arrive"), acceptWaitTime("Waiting in accept"),
	  pollWaitTime("Waiting in poll"), selectWaitTime("Waiting in select"),
	  floodEndqTime("Flooding ENDQ messages"), distqDelta("GLT Drift")
{
	/* Count running threads */
	UpdateNRunning(1);

	SHIM_LOG("Creating a new shim (parent:%p, clone_flags:%x, id:%d\n",
		parent, clone_flags, _unique_id);

	totalTime.start();

	/*
	 * Create the dummy fd; used with determinsitc sockets (and also by the
	 * replay shim)
	 */
	nullfd = open("/dev/null", O_RDWR);
	if (nullfd < 0) {
		SHIM_ERR("Couldn't open null fd\n");
		abort();
	}

	// If no parent, then initialize from scratch.
	if (parent == NULL) {
		_fdtable.reset(new FileDescriptorTable);
		_ndfdtable.reset(new FileDescriptorTable);

		char dir[PATH_MAX];
		if (getcwd(dir, sizeof dir)) {
			_cwd.reset(new boost::filesystem::path(dir));
		} else {
			SHIM_PERROR("getcwd");
			_cwd.reset(new boost::filesystem::path("/"));
		}

		/* 
		 * Create a temporary master node entry
		 */
		node_id = 0;
		DetNodes = PDNodeMap(new DNodeMap);
		PDNode me(new DNode);
		me->nodeid = 0;
		me->address = 0;
		me->ctrlfd = -1;
		me->exiting = false;
		me->control_port = DMP_CONTROL_PORT;
		me->ports.clear();
		me->manager = 0;
		FillLocalIP(me);
		(*DetNodes)[0] = me;

		/*
		 * Create new state for the VSock map and WaitFor set
		 */
		VSocks  = PVSockMap(new VSockMap);
		WaitFor = PBitSet(new BitSet);
		assert(VSocks);
		assert(WaitFor);

		SHIM_LOG("_fdtable:%p, _ndfdtable:%p, DetNodes:%p, VSocks:%p, WaitFor:%p\n",
			_fdtable.get(), _ndfdtable.get(), DetNodes.get(),
			VSocks.get(), WaitFor.get());
		return;
	}

	/* Reuse or clone the file descriptor table? */
	if (clone_flags & CLONE_FILES) {
		SHIM_LOG("CLONE_FILES is set\n");
		_fdtable      = parent->_fdtable;
		_ndfdtable    = parent->_ndfdtable;
	} else {
		SHIM_LOG("CLONE_FILES is not set\n");
		_fdtable     = parent->_fdtable->clone();
		_ndfdtable   = parent->_ndfdtable->clone();
	}

	/*
	 * Reuse or clone the filesystem info?
	 * NOTE: no reference counting on _cwd because I'm lazy.
	 */
	if (clone_flags & CLONE_FS)
		_cwd = parent->_cwd;
	else
		_cwd.reset(new boost::filesystem::path(*parent->_cwd));

	/*
	 * Grab information about the DDPG from the parent node
	 */
	node_id        = parent->node_id;
	master_node_id = parent->master_node_id;
	num_dpgs       = parent->num_dpgs;
	distq_size     = parent->distq_size;
	max_drift      = parent->max_drift;
	DetNodes       = parent->DetNodes;
	VSocks         = parent->VSocks;
	WaitFor        = parent->WaitFor;

	SHIM_LOG("_fdtable:%p, _ndfdtable:%p, DetNodes:%p, VSocks:%p WaitFor:%p\n",
		_fdtable.get(), _ndfdtable.get(), DetNodes.get(), VSocks.get(),
		WaitFor.get());

	/*
	 * Propogate the determnistic paths to the child, so they have the same
	 * idea of what is included in the DFH
	 */
	for (FileTimingMap::const_iterator i  = parent->FsTimings.begin(); i != parent->FsTimings.end(); i++)
		add_deterministic_path(i->first.c_str(), i->second);
}

BasicShim::~BasicShim()
{
	SHIM_LOG("Destroying basic shim (node: %d)\n", node_id);
}

BasicShim* BasicShim::clone(int clone_flags)
{
	return new BasicShim(this, clone_flags, reexec_detnet);
}

void BasicShim::set_max_drift(uint64_t md)
{
	SHIM_LOG("Setting max drift to %ld\n", md);
	max_drift = md;
}

void BasicShim::loop()
{
	shim_event event;
	user_regs_struct *const __unused regs = &event.regs;

	while (!_done_flag) {
		int r = get_next_shim_event(&event);
		if (r != 0) {
			SHIM_PERROR("dmp_shim_trace");
			continue;
		}

		SHIM_LOG("@%ld.%d (event #%ld, qticks:%ld) ", EVTIME(&event), event_count, event.qticks);

		switch (event.event_type) {
		case DMP_SHIM_SYSCALL_ENTER:
			event_count++;
			SHIM_LOG_CONT("sysenter rax:%ld orig_rax:%ld (%s)\n", regs->rax, regs->orig_rax, GetSyscallName(regs->orig_rax));
			trace_syscall_enter(&event);
			break;

		case DMP_SHIM_SYSCALL_LEAVE:
			SHIM_LOG_CONT("sysleave rax:%ld orig_rax:%ld (%s)\n", regs->rax, regs->orig_rax, GetSyscallName(regs->orig_rax));
			trace_syscall_leave(&event);
			break;

		case DMP_SHIM_CALL:
			SHIM_LOG_CONT("call func:%ld\n", shim_syscall_arg0(regs));
			trace_shimcall(&event);
			break;

		case DMP_SHIM_BARRIER:
			SHIM_LOG_CONT("barrier\n");
			trace_barrier(&event);
			break;

		case DMP_SHIM_EXIT:
			SHIM_LOG_CONT("exit event received\n");
			trace_exit(&event);
			break;

		case DMP_SHIM_RDTSC:
			SHIM_LOG_CONT("rdtsc\n");
			trace_rdtsc(&event);
			break;

		case DMP_SHIM_SIGNAL:
			SHIM_LOG_CONT("signal\n");
			trace_signal(&event);
			break;

		default:
			SHIM_LOG_CONT("unknown event type: %d\n", event.event_type);
			break;
		}
	}

	// Count running threads.
	UpdateNRunning(-1);
}

static void show_syscall_path(BasicShim *shim, const char *name, shim_event *event)
{
	char buf[1024];
	char *dmp_path = (char *)shim_syscall_arg0(&event->regs);

	shim->timed_dmp_shim_strncpy_sync(buf, dmp_path, sizeof buf, NULL);
	SHIM_LOG("%s(%s, ...)\n", name, buf);
}

static void show_pipe(BasicShim *shim, shim_event *event, int pos)
{
	int __unused shim_pipe[2];
	int __unused *dmp_pipe = 
		(pos == 0 ? (int *)shim_syscall_arg0(&event->regs) :
		 pos == 1 ? (int *)shim_syscall_arg1(&event->regs) :
		 pos == 2 ? (int *)shim_syscall_arg2(&event->regs) :
		 pos == 3 ? (int *)shim_syscall_arg3(&event->regs) : NULL);

	if (dmp_pipe) {
		shim->timed_dmp_shim_memcpy_sync(shim_pipe, dmp_pipe, sizeof(int) * 2, FROM_DMP, NULL);
		SHIM_LOG("pipe(%p) ==> [fd:%d, fd:%d]\n", dmp_pipe, shim_pipe[0], shim_pipe[1]);
	}
}

bool BasicShim::trace_syscall_enter(shim_event* event)
{
	const long syscallnr = event->regs.orig_rax;
	bool handled = false;

	switch (syscallnr) {
	// Forking
	case SYS_fork:
		follow_fork(syscallnr, 0);
		handled = true;
		break;
	case SYS_clone:
		follow_fork(syscallnr, shim_syscall_arg0(&event->regs));
		handled = true;
		break;
	case SYS_vfork:
		follow_fork(syscallnr, CLONE_VFORK | CLONE_VM);
		handled = true;
		break;

	// Fileops
	case SYS_open:   handled = do_fs_open(event);   break;
	case SYS_creat:  handled = do_fs_creat(event);  break;
	case SYS_close:  handled = do_fs_close(event);  break;
	case SYS_read:   handled = do_fs_read(event);   break;
	case SYS_write:  handled = do_fs_write(event);  break;
	case SYS_lseek:  handled = do_fs_lseek(event);  break;
	case SYS_dup:    handled = do_fs_dup(event);    break;
	case SYS_dup2:   handled = do_fs_dup2(event);   break;
	case SYS_utime:  handled = do_fs_utime(event);  break;
	case SYS_utimes: handled = do_fs_utimes(event); break;
	case SYS_fcntl:  handled = do_fs_fcntl(event);  break;
	case SYS_readv:  handled = do_fs_readv(event);  break;
	case SYS_writev: handled = do_fs_writev(event); break;
	case SYS_fsync:      /* Fallthrough */
	case SYS_fdatasync:  /* Fallthrough */
	case SYS_ftruncate:  /* Fallthrough */
	case SYS_fchmod:     /* Fallthrough */
		handled = do_fs_generic(syscallnr, event);
		break;
	case SYS_unlink:     /* Fallthrough */
	case SYS_rmdir:      /* Fallthrough */
	case SYS_access:     /* Fallthrough */
	case SYS_chmod:      /* Fallthrough */
		handled = do_fs_generic_path(syscallnr, event);
		break;

	// Sockets
	case SYS_socket:   handled = do_sock_socket(event);   break;
	case SYS_bind:     handled = do_sock_bind(event);     break;
	case SYS_listen:   handled = do_sock_listen(event);   break;
	case SYS_accept:   handled = do_sock_accept(event);   break;
	case SYS_connect:  handled = do_sock_connect(event);  break;
	case SYS_select:   handled = do_sock_select(event);   break;
	case SYS_getpeername: handled = do_sock_getpeername(event); break;
	case SYS_getsockname: handled = do_sock_getsockname(event); break;
	case SYS_setsockopt:  handled = do_sock_setsockopt(event); break;
	case SYS_getsockopt:  handled = do_sock_getsockopt(event); break;
	case SYS_poll:     handled = do_sock_poll(event);     break;

	case SYS_sendto:   handled = do_sock_sendto(event);   break;
	case SYS_recvfrom: handled = do_sock_recvfrom(event); break;
	case SYS_sendmsg:  handled = do_sock_sendmsg(event);  break;
	//case SYS_recvmsg:  handled = do_sock_recvmsg(event);  break;

	case SYS_execve: do_fs_execve(event); break;
	}

	return handled;
}

bool BasicShim::do_fs_execve(shim_event *event)
{
	char pathname[PATH_MAX];
	unsigned long arg0 = shim_syscall_arg0(&event->regs);

	if (timed_dmp_shim_strncpy_sync((void*)pathname, (void*)arg0, sizeof pathname, NULL) != 0)
		SHIM_PERROR("dmp_shim_strcpy");
	else
		SHIM_LOG("@%ld.%d: execve(%s, ...)\n", EVTIME(event), pathname);

	_fdtable->clean_cloexec();
	_ndfdtable->clean_cloexec();

	return false;
}


void BasicShim::trace_syscall_leave(shim_event* event)
{
	const long syscallnr = event->regs.orig_rax;

	switch (syscallnr) {
	// Fileops
	case SYS_pipe:       show_pipe(this, event, 0); break;
	case SYS_socketpair: show_pipe(this, event, 3); break;
	case SYS_chdir:
		do_fs_chdir(event);
		break;

	// Sockets
	//case SYS_accept: do_sock_accept(event); break;
	}
}

void BasicShim::trace_shimcall(shim_event* event)
{
	long shimfn = shim_syscall_arg0(&event->regs);

	SHIM_LOG("@%ld.%d: shim_call(%ld, ...)\n", EVTIME(event), shimfn);

	switch (shimfn) {
	case SHIM_FN_SET_DISTQ_HANDLER:
		BasicShim::set_distq_handler(event);
		break;

	default:
		SHIM_WARN("Unknown shim fn %ld\n", shimfn);
		break;
	}
}

void BasicShim::trace_barrier(shim_event* event)
{
	// nop
	if (event->barrier_type == SHIM_BARRIER_DISTQ)
		handle_distq_barrier(event);

	SHIM_WARN("Barrier received; wasn't expecting one\n");
}

void BasicShim::trace_signal(shim_event* event)
{
	// nop
}

void BasicShim::trace_rdtsc(shim_event *event)
{
	// nop
}

void BasicShim::trace_exit(shim_event* event)
{
	_done_flag = true;

	/* If this DPG is part of a DDPG */
	if (this->distq_size > 0)
		do_sock_exit(event);
}

bool BasicShim::add_deterministic_fd(int dmp_fd, const FileTimingInfo& timing)
{
	long ret;

	// Dup the fd into the shim.
	ret = dmp_shim_dupfd(dmp_fd, FROM_DMP, 0);
	if (ret < 0) {
		SHIM_PERROR("dmp_shim_dupfd");
		return false;
	}

	shared_ptr<FileDescriptor> fd(new FileDescriptor);

	fd->timing = timing;
	fd->shadowfd = ret;

	// Get the filesize.
	// We assume the filesize is a constant.
	struct stat stat;
	if (fstat(fd->shadowfd, &stat) != 0) {
		/* Could be a pipe, or socket, or ...; Do nothing? */
		fd->filesize = -1;
		fd->filepos  =  0;
	} else {
		fd->filesize = stat.st_size;

		// Get the current file position.
		ret = lseek(fd->shadowfd, 0, SEEK_CUR);
		if (ret < 0) {
			//SHIM_PERROR("lseek");
			fd->filepos = 0;
		} else {
			fd->filepos = ret;
		}
	}

	// Now shadow the fd.
	SHIM_LOG("Adding dmp_fd[%d] -> shim_fd[%d] mapping\n", dmp_fd, fd->shadowfd);
	_fdtable->add(dmp_fd, fd);

	return true;
}

static void* shim_pthread(void *_shim)
{
	BasicShim *shim = reinterpret_cast<BasicShim*>(_shim);
	shim->attach_after_fork();
	delete shim;
	return NULL;
}

void BasicShim::follow_fork(long syscallnr, long clone_flags)
{
	shim_event event;
	pthread_t th;

	SHIM_LOG("syscall=%ld clone_flags=%lx\n", syscallnr, clone_flags);

	if (syscallnr == SYS_fork || syscallnr == SYS_vfork || !(clone_flags & CLONE_VM))
		AddProcess();
	else
		AddThread();

	// Wait for the system call to return.
	//dmp_shim_trace(&event);
	get_next_shim_event(&event);

	// vfork is special: the parent task blocks and waits for the
	// child to call exec or exit *before* returning from vfork.
	// Thus, the parent triggers a special event saying "I'm about
	// to wait for the child".  At this point we learn the child's
	// pid and can fork a shim to attach to the child.  ugly ugly.
	if (syscallnr == SYS_vfork) {
		if (event.event_type != DMP_SHIM_VFORK_WAIT) {
			SHIM_LOG("bad event type (vfork wait): %d\n", event.event_type);
			return;
		}
	}
	// The sane normal case of fork() or clone().
	else {
		if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
			SHIM_LOG("bad event type: %d\n", event.event_type);
			return;
		}
	}

	const int rax = shim_syscall_return(&event.regs);
	if (rax < 0) {
		SHIM_LOG("fork call failed err=%d\n", rax);
		return;
	}

	SHIM_LOG("forked dmp thread pid=%d\n", rax);

	// Spawn a new shim thread.
	BasicShim* shim = clone(clone_flags);
	shim->_dmp_pid = rax;

	if (pthread_create(&th, NULL, shim_pthread, reinterpret_cast<void*>(shim)) != 0)
		SHIM_PERROR("pthread_create");

	// vfork is special: now wait for vfork to exit.
	if (syscallnr == SYS_vfork) {
		//dmp_shim_trace(&event);
		get_next_shim_event(&event);
		if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
			SHIM_LOG("bad event type (vfork leave): %d\n", event.event_type);
			return;
		}
		SHIM_LOG("vfork returned for dmp thread pid=%d\n", rax);
	}
}

void BasicShim::attach_after_fork()
{
	shim_event event;

	SHIM_LOG("new shim created\n");

	// Attach to the deterministic thread
	long ret = dmp_shim_attach(_dmp_pid);
	if (ret < 0) {
		SHIM_PERROR("dmp_shim_attach");
		return;
	}

	SHIM_LOG("shim attached to pid=%d\n", _dmp_pid);

	// Wait for the system call to return in the dmp thread.
	dmp_shim_trace(&event);
	//get_next_shim_event(&event);
	if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
		SHIM_LOG("bad event type: %d\n", event.event_type);
		return;
	}

	SHIM_LOG("pid=%d returned from fork\n", _dmp_pid);
	loop();
	SHIM_LOG("Leaving attach_after_fork()\n");
}

}  // namespace DMP
