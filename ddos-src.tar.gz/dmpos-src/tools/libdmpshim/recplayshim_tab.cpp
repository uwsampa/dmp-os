#include <cstring>

/* Includes necessary to define the various structs in the recstr's */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/vfs.h>
#include <sys/socket.h>

#include "dmpshim.h"
#include "recplayshim_tab.h"
#include "recplayshim_gen.h"
#include "recplayshim_net.h"

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(ar) (sizeof(ar) / sizeof(ar[0]))
#endif

#define SPECIAL(s) Table[SYS_##s] = recplay_##s
#define REUSE(s,t) Table[SYS_##s] = Table[SYS_##t];
#define GENERIC(s) Table[SYS_##s] = recplay_generic;
#define REEXEC(s)  Table[SYS_##s] = recplay_reexec;
#define ABORT(s)   Table[SYS_##s] = recplay_abort;

namespace DMP {

RecPlayTab::RecPlayTab()
{
	/*
	 * Setup the bindings for recording system calls. The memset will zero
	 * the table, meaning all system calls not explicitly defined will use
	 * the GenericFn on record/replay.
	 */
	memset(Table, 0, sizeof(Table));

	SPECIAL(read);
	SPECIAL(write);
	SPECIAL(open);
	SPECIAL(close);
	SPECIAL(stat);
	REUSE(fstat, stat);
	REUSE(lstat, stat);
	SPECIAL(poll);

	GENERIC(lseek);
	SPECIAL(mmap);
	REEXEC(mprotect);
	REEXEC(munmap);
	REEXEC(brk);
	SPECIAL(rt_sigaction);
	SPECIAL(rt_sigprocmask); 
	/* rt_sigreturn */

	/**
	 * ioctl --
	 *     TODO: This syscall is especially hairy. Device specific effects.
	 *     Each ioctl request needs to be dealt with on a case-by-case
	 *     basis.
	 *
	 * pipe --
	 *     N.B. Allocates 2 fds for unidirectional communication; can be
	 *     shared only by children tasks of the creator; allocation of fds
	 *     should be deterministic if reexecuted.
	 *
	 *     TODO: assume this for now.
	 */
	SPECIAL(ioctl);
	SPECIAL(pread64);
	GENERIC(pwrite64);
	SPECIAL(readv);
	SPECIAL(writev);
	SPECIAL(access);
	REEXEC(pipe);
	SPECIAL(select);

	GENERIC(sched_yield);
	REEXEC(mremap);
	REEXEC(msync);
	/* mincore */
	REEXEC(madvise);
	/* shmget */
	/* shmat */
	/* shmctl */

	/**
	 * dup --
	 *
	 *   RecplayShim only sees events for non-deterministic file
	 *   descriptors; det fds are handled by BasicShim. Thus, dup only
	 *   need to be replayed, but RecplayShim must first allocate a dummy
	 *   fd; see recplay_open for more info.
	 *
	 * dup2 --
	 *   
	 *   TODO: If newfd is already open, we don't want to allocate a new
	 *   descriptor.
	 */
	REUSE(dup,  open);
	SPECIAL(dup2);
	GENERIC(pause);
	SPECIAL(nanosleep);
	SPECIAL(getitimer);
	REEXEC(alarm);
	/* setitimer */
	REEXEC(getpid);  /* Assuming rundet clones with CLONE_NEWPID, pids are deterministic */

	/* sendfile64 */
	SPECIAL(socket);
	SPECIAL(connect);
	SPECIAL(accept);
	SPECIAL(sendto);
	SPECIAL(recvfrom);
	GENERIC(sendmsg);
	SPECIAL(recvmsg);

	/**
	 * TODO: 
	 *   setsockopt -- Haven't checked this at all.
	 */
	GENERIC(shutdown);
	SPECIAL(bind);
	SPECIAL(listen);
	SPECIAL(getsockname);
	REUSE(getpeername, getsockname);
	SPECIAL(socketpair);
	SPECIAL(setsockopt);
	SPECIAL(getsockopt);

	/**
	 * clone, fork, vfork --
	 *
	 *   These should always be handled by BasicShim. If the RecplayShim
	 *   sees one of these system calls, something has gone wrong.
	 */
	ABORT(clone);
	ABORT(fork);
	ABORT(vfork);
	/* execve */
	/* exit */
	SPECIAL(wait4);
	/* kill */
	SPECIAL(uname);

	/* semget */
	/* semop */
	/* semctl */
	/* shmdt */
	/* msgget */
	/* msgsnd */
	/* msgrcv */
	/* msgctl */

	SPECIAL(fcntl);
	/* flock */
	GENERIC(fsync);
	GENERIC(fdatasync);
	/* truncate */
	GENERIC(ftruncate);
	SPECIAL(getdents);
	SPECIAL(getcwd);

	/* chdir */
	/* fchdir */
	/* rename */
	/* mkdir */
	/* rmdir */
	REUSE(creat, open);
	/* link */
	/* unlink */

	/* symlink */
	SPECIAL(readlink);
	GENERIC(chmod);
	GENERIC(fchmod);
	/* GENERIC(chown); */
	/* REUSE(fchown, chown); */
	/* REUSE(lchown, chown); */
	GENERIC(umask);

	SPECIAL(gettimeofday);
	SPECIAL(getrlimit);
	SPECIAL(getrusage);
	SPECIAL(sysinfo);
	SPECIAL(times);
	/* ptrace */
	GENERIC(getuid);
	/* syslog */

	/**
	 * set*id --
	 *
	 *   TODO: Because the (u|g|pg|fs|r)id affects what files the process
	 *   can open/read/write, etc., these must be reexecuted in order to
	 *   guarantee deterministic access to files in the DFH.
	 *
	 *   XXX N.B. This assumes that these ids are determinsistic, which may not
	 *   always be the case.
	 */
	GENERIC(getgid);
	REEXEC(setuid);
	REEXEC(setgid);
	GENERIC(geteuid);
	GENERIC(getegid);
	/* setpgid */
	REEXEC(getppid); /* Set getpid */
	GENERIC(getpgrp);

	/* setsid */
	REEXEC(setreuid);
	REEXEC(setregid);
	SPECIAL(getgroups);
	/* setgroups */
	REEXEC(setresuid);
	SPECIAL(getresuid);
	REEXEC(setresgid);

	SPECIAL(getresgid);
	GENERIC(getpgid);
	REEXEC(setfsuid);
	REEXEC(setfsgid);
	REEXEC(getsid); /* Set getpid */
	/* capget */
	/* capset */

	GENERIC(rt_sigpending); 
	/* rt_sigtimedwait */
	/* rt_sigqueueinfo */
	/* rt_sigsuspend */
	/* signalstack */
	GENERIC(utime);
	/* mknod */

	GENERIC(personality);
	SPECIAL(ustat);
	SPECIAL(statfs);
	REUSE(fstatfs, statfs);
	SPECIAL(sysfs);
	GENERIC(getpriority);
	GENERIC(setpriority);

	GENERIC(sched_setparam);
	SPECIAL(sched_getparam);
	GENERIC(sched_setscheduler);
	GENERIC(sched_getscheduler);
	GENERIC(sched_get_priority_max);
	GENERIC(sched_get_priority_min);
	SPECIAL(sched_rr_get_interval);

	REEXEC(mlock);
	REEXEC(munlock);
	REEXEC(mlockall);
	REEXEC(munlockall);
	/* vhangup */
	/* modify_ldt */
	/* pivot_root */

	/**
	 * arch_ptrcl --
	 *   Allows programs to set/get GS/FS segment registers. FS is used by
	 *   pthreads to point to TLS. Needs to be reexecuted.
	 *
	 *   TODO: What is in %gs?
	 */
	/* sysctl */
	/* prctl */
	REEXEC(arch_prctl);
	/* adjtimex */
	/* setrlimit */
	/* chroot */
	/* sync */

	GENERIC(acct);
	GENERIC(settimeofday);
	/* mount */
	/* umount */
	/* swapon */
	/* swapoff */
	/* reboot */

	/* sethostname */
	/* setdomainname */
	/* iopl */
	/* ioperm */
	/* init_module */
	/* delete_module */
	/* quotactl */

	/* nfsservctl */
	GENERIC(gettid);
	/* readahead */
	/* setxattr */
	/* lsetxattr */
	/* fsetxattr */
	/* SPECIAL(getxattr); */

	/* REUSE(lgetxattr, getxattr); */
	/* REUSE(fgetxattr, getxattr); */
	/* SPECIAL(listxattr); */
	/* REUSE(llistxattr, listxattr); */
	/* REUSE(flistxattr, listxattr); */
	/* removexattr */
	/* lremovexattr */

	/**
	 * futex --
	 *   TODO: This hasn't been considered too carefully
	 */
	/* fremovexattr */
	/* tkill */
	SPECIAL(time);
	SPECIAL(futex);
	GENERIC(sched_setaffinity);
	SPECIAL(sched_getaffinity);
	/* io_setup */

	/* io_destroy */
	/* io_getevents */
	/* io_submit */
	/* io_cancel */
	/* lookup_dcookie */
	SPECIAL(epoll_create);
	/* remap_file_pages */

	/**
	 * set_tid_address --
	 *   TODO: Sets a pointer to write pid on clone. We don't have a good
	 *   answer for this yet. pids retruned in this manner are currently
	 *   nondeterministic. (We could fault on target page and record on
	 *   access?)
	 */
	REUSE(getdents64, getdents);
	SPECIAL(set_tid_address);
	/* restart_syscall */
	/* semtimedop */
	GENERIC(fadvise64);
	/* timer_create */
	/* timer_settime */

	/* timer_gettime */
	/* timer_getoverrun */
	/* timer_delete */
	/* clock_settime */
	SPECIAL(clock_gettime);
	REUSE(clock_getres, clock_gettime);
	/* clock_nanosleep */

	/* exit_group */
	SPECIAL(epoll_wait);
	GENERIC(epoll_ctl);
	/* tgkill */
	GENERIC(utimes);
	/* mbind */
	GENERIC(set_mempolicy);

	SPECIAL(get_mempolicy);
	/* mq_open */
	/* mq_unlink */
	/* mq_timedsend */
	/* mq_timedreceive */
	/* mq_notify */
	/* mq_getsetattr */

	/* kexec_load */
	/* waitid */
	/* add_key */
	/* request_key */
	/* keyctl */
	/* ioprio_set */
	/* sys_ioprio_get */

	/*
	 * inotify_add_watch --
	 *   TODO: It's unclear whether or not the returned descriptor is a
	 *   file descriptor (in the fdtable) or just a unique integer.
	 */
	SPECIAL(inotify_init);
	REUSE(inotify_add_watch, inotify_init);
	GENERIC(inotify_rm_watch);
	/* migrate_pages */
	/* openat */
	/* mkdirat */
	/* mknodat */
	
	/* fchownat */
	/* futimesat */
	/* newsfstatat */
	/* unlinkat */
	/* renameat */
	/* linkat */
	/* symlinkat */

	/*
	 * set_robust_list --
	 *   TODO: This sets a pointer to a list of futexes currently held by 
	 *   the task for the kernel to clean up should the task crash while
	 *   holding a lock.
	 */
	/* readlinkat */
	/* fchmodat */
	/* faccessat */
	/* pselect6 */
	/* ppoll */
	/* unshare */
	REEXEC(set_robust_list);
	
	/* get_robust_list */
	/* splice */
	/* tee */
	/* sync_file_range */
	/* vmsplice */
	/* move_pages */
	/* utimesat */
	
	/* epoll_pwait */
	/* signalfd */
	/* timerfd */
	/* eventfd */
	GENERIC(fallocate);
	
	GenericFn = recplay_generic;
}

RecPlayTab::~RecPlayTab()
{ }

RecPlayFn RecPlayTab::get_fn(int syscallnr)
{
	RecPlayFn fn;

	if ((unsigned long)syscallnr >= ARRAY_SIZE(Table)) {
		SHIM_LOG("syscall %d outside of range 0-%ld\n", syscallnr, ARRAY_SIZE(Table)-1);
		return GenericFn;
	}

	fn = Table[syscallnr];
	if (!fn)
		fn = GenericFn;

	return fn;
}

} /* DMP */
