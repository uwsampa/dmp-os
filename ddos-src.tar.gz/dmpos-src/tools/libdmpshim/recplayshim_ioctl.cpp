#include <sys/ioctl.h>
#include <net/if.h>
#include <termios.h>

#include "recplayshim_gen.h"

/******************************************************************************
 *                              Socket ioctl()'s                              *
 ******************************************************************************/
/**
 * ioctl(fd, SIOCGIFCONF, struct ifconf *ifc) --
 *
 */
__RECPLAY(ioctl_siocgifconf)
{
	const long syscallnr = event->regs.orig_rax;
	long thisret, reclen;
	struct ifconf *dmp_ifc = (struct ifconf *)shim_syscall_arg2(&event->regs);
	struct ifconf shim_ifc;
	rechdr_t *rechdr = NULL;
	char *tempbuf = NULL;

	SHIM_WARN("Untested\n");
		
	if (dmp_ifc)
		shim->timed_dmp_shim_memcpy_sync(&shim_ifc, dmp_ifc, sizeof(shim_ifc), FROM_DMP, NULL);

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);
		reclen = sizeof(thisret);

		if (dmp_ifc) {
			SHIM_LOG("Recording %d bytes of ifconf\n", shim_ifc.ifc_len);
			reclen += shim_ifc.ifc_len;
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));

		if (dmp_ifc && shim_ifc.ifc_len) {
			tempbuf = new char[shim_ifc.ifc_len];
			assert(tempbuf);

			shim->timed_dmp_shim_memcpy_sync(tempbuf, shim_ifc.ifc_req, shim_ifc.ifc_len, FROM_DMP, NULL);
			shim->append_buffer(tempbuf, shim_ifc.ifc_len);
			
			delete [] tempbuf;
		}

	} else /* SHIM_REPLAY */ {

		rechdr = (rechdr_t *)arg;

		shim_ifc.ifc_len = rechdr->reclen - sizeof(thisret);
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		SHIM_LOG("Got return value of %ld\n", thisret);

		SHIM_LOG("Setting length to %d\n", shim_ifc.ifc_len);
		shim->timed_dmp_shim_memcpy_sync(&shim_ifc.ifc_len, (((char *)dmp_ifc) + __builtin_offsetof(struct ifconf, ifc_len)),
		                     sizeof(shim_ifc.ifc_len), TO_DMP, NULL);

		if (shim_ifc.ifc_len) {
			tempbuf = new char[shim_ifc.ifc_len];
			assert(tempbuf);
		
			SHIM_LOG("Reading %d bytes of interfaces\n", shim_ifc.ifc_len);
			shim->read_buffer(tempbuf, shim_ifc.ifc_len);
			shim->timed_dmp_shim_memcpy_sync(tempbuf, (char *)shim_ifc.ifc_req, shim_ifc.ifc_len, TO_DMP, NULL);

			delete [] tempbuf;
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}

__RECPLAY(ioctl_siocgifflags)
{
	const long syscallnr = event->regs.orig_rax;
	struct ifreq *dmp_ifr = (struct ifreq *)shim_syscall_arg2(&event->regs);
	struct ifreq shim_ifr;
	long thisret, reclen;
	rechdr_t *rechdr = NULL;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {

		thisret = shim_syscall_return(&event->regs);
		reclen = sizeof(thisret);

		if (dmp_ifr) {
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr, (char *)dmp_ifr, sizeof(shim_ifr), FROM_DMP, NULL);
			reclen += sizeof(shim_ifr.ifr_flags);
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr)
			shim->append_buffer((char *)&shim_ifr.ifr_flags, sizeof(shim_ifr.ifr_flags));

	} else /* SHIM_REPLAY */ {
		rechdr = (rechdr_t *)arg;
		assert(rechdr->reclen >= sizeof(thisret));

		shim->read_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr) {
			assert(rechdr->reclen >= sizeof(thisret) + sizeof(shim_ifr.ifr_flags));
			shim->read_buffer((char *)&shim_ifr.ifr_flags, sizeof(shim_ifr.ifr_flags));
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr.ifr_flags, &dmp_ifr->ifr_flags,
			                     sizeof(shim_ifr.ifr_flags), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}

__RECPLAY(ioctl_siocgifindex)
{
	const long syscallnr = event->regs.orig_rax;
	struct ifreq *dmp_ifr = (struct ifreq *)shim_syscall_arg2(&event->regs);
	struct ifreq shim_ifr;
	long thisret, reclen;
	rechdr_t *rechdr = NULL;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {

		thisret = shim_syscall_return(&event->regs);
		reclen = sizeof(thisret);

		if (dmp_ifr) {
			shim->timed_dmp_shim_memcpy_sync(&shim_ifr, dmp_ifr, sizeof(shim_ifr), FROM_DMP, NULL);
			reclen += sizeof(shim_ifr.ifr_ifindex);
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr)
			shim->append_buffer((char *)&shim_ifr.ifr_ifindex, sizeof(shim_ifr.ifr_ifindex));

	} else /* SHIM_REPLAY */ {
		rechdr = (rechdr_t *)arg;
		assert(rechdr->reclen >= sizeof(thisret));

		shim->read_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr) {
			assert(rechdr->reclen >= sizeof(thisret) + sizeof(shim_ifr.ifr_ifindex));
			shim->read_buffer((char *)&shim_ifr.ifr_ifindex, sizeof(shim_ifr.ifr_ifindex));
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr.ifr_ifindex, &dmp_ifr->ifr_ifindex, sizeof(shim_ifr.ifr_ifindex), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}

__RECPLAY(ioctl_siocgifaddr)
{

	const long syscallnr = event->regs.orig_rax;
	struct ifreq *dmp_ifr = (struct ifreq *)shim_syscall_arg2(&event->regs);
	struct ifreq shim_ifr;
	long thisret, reclen;
	rechdr_t *rechdr = NULL;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {

		thisret = shim_syscall_return(&event->regs);
		reclen = sizeof(thisret);

		if (dmp_ifr) {
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr, (char *)dmp_ifr, sizeof(shim_ifr), FROM_DMP, NULL);
			reclen += sizeof(shim_ifr.ifr_addr);
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr)
			shim->append_buffer((char *)&shim_ifr.ifr_addr, sizeof(shim_ifr.ifr_addr));

	} else /* SHIM_REPLAY */ {
		rechdr = (rechdr_t *)arg;
		assert(rechdr->reclen >= sizeof(thisret));

		shim->read_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr) {
			assert(rechdr->reclen >= sizeof(thisret) + sizeof(shim_ifr.ifr_addr));
			shim->read_buffer((char *)&shim_ifr.ifr_addr, sizeof(shim_ifr.ifr_addr));
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr.ifr_addr, &dmp_ifr->ifr_addr,
			                     sizeof(shim_ifr.ifr_addr), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}

__RECPLAY(ioctl_siocgifnetmask)
{

	const long syscallnr = event->regs.orig_rax;
	struct ifreq *dmp_ifr = (struct ifreq *)shim_syscall_arg2(&event->regs);
	struct ifreq shim_ifr;
	long thisret, reclen;
	rechdr_t *rechdr = NULL;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {

		thisret = shim_syscall_return(&event->regs);
		reclen = sizeof(thisret);

		if (dmp_ifr) {
			shim->timed_dmp_shim_memcpy_sync(&shim_ifr, dmp_ifr, sizeof(shim_ifr), FROM_DMP, NULL);
			reclen += sizeof(shim_ifr.ifr_netmask);
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr)
			shim->append_buffer((char *)&shim_ifr.ifr_netmask, sizeof(shim_ifr.ifr_netmask));

	} else /* SHIM_REPLAY */ {
		rechdr = (rechdr_t *)arg;
		assert(rechdr->reclen >= sizeof(thisret));

		shim->read_buffer((char *)&thisret, sizeof(thisret));
		if (dmp_ifr) {
			assert(rechdr->reclen >= sizeof(thisret) + sizeof(shim_ifr.ifr_netmask));
			shim->read_buffer((char *)&shim_ifr.ifr_netmask, sizeof(shim_ifr.ifr_netmask));
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_ifr.ifr_netmask, &dmp_ifr->ifr_netmask,
			                     sizeof(shim_ifr.ifr_netmask), TO_DMP, NULL);
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}


/******************************************************************************
 *                            Terminal ioctls()'s                             *
 ******************************************************************************/
/**
 * ioctl(fd, TCGETS, struct termios *ios) --
 *
 *   Returns 0 on success, -EFAULT on error. Copies the termios control
 *   structure to the given location.
 */
__RECPLAY(ioctl_tcgets)
{
	const long tiosz = sizeof(struct termios);
	const long recstr[] = { RET, END }; // TODO: TEMPORARY! ARG2, PTR, IMMLONG, tiosz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}

/**
 * ioctl(fd, TCSETS, struct termios *ios) --
 *   
 *   Returns 0 on success, -EFAULT on error. Sets the attributes given in
 *   termios for the given fd. 
 */
__RECPLAY(ioctl_tcsets)
{
	SHIM_ERR("Not implemented\n");
	abort();
}


/**
 * ioctl(fd, TIOCGPGRP, pid_t *pgrp) --
 *
 *   Returns 0 on success, -ENOTTY on error. Copies the tty's pgrp to the given
 *   location. 
 */
__RECPLAY(ioctl_tiocgpgrp)
{
	const long pidsz = sizeof(pid_t);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, pidsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}

/**
 * ioctl(fd, TIOCGPTN, unsigned int *ptn) --
 *
 *   Returns 0 on success, -EFAULT on error. Copies the tty's number in to the
 *   given location.
 */
__RECPLAY(ioctl_tiocgptn)
{
	const long intsz = sizeof(unsigned int);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, intsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else 
		replay_str(shim, event, recstr);
}


/**
 * ioctl(fd, TIOCINQ, int *bytes) --
 *
 *   Returns 0 on success, -EFAULT on error. Copies the number of bytes in the
 *   input queue to the given location.
 */
__RECPLAY(ioctl_tiocinq)
{
	const long intsz = sizeof(int);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, intsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else 
		replay_str(shim, event, recstr);
}

/**
 * ioctl(fd, TIOCOUTQ, int *bytes) --
 *
 *   Returns 0 on success, -EFAULT on error. Copies the number of bytes in the
 *   output queue to the given location.
 */
__RECPLAY(ioctl_tiocoutq)
{
	const long intsz = sizeof(int);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, intsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else 
		replay_str(shim, event, recstr);
}

/**
 * ioctl(fd, TIOCGWINSZ, struct winsize *out) --
 *
 *  Returns 0 on success, -EFAULT on error. Files out the size of the terminal
 *  in the out struct.
 */
__RECPLAY(ioctl_tiocgwinsz)
{
	const long winsz = sizeof(struct winsize);
	const long recstr[] = { RET, ARG2, PTR, IMMLONG, winsz, END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else 
		replay_str(shim, event, recstr);
}
