/*
 * A library of useful shim functions
 */

#ifndef __LIBDMPSHIM_BASICSHIM_H__
#define __LIBDMPSHIM_BASICSHIM_H__

#ifndef __cplusplus
#error "basic shim requires c++"
#endif

#include <errno.h>
#include <pthread.h>
#include <syscall.h>
#include <sys/user.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <poll.h>

#include "utils.h"
#include "dmpshim.h"

#include <boost/filesystem/path.hpp>
#include <boost/shared_ptr.hpp>
#include <algorithm>
#include <memory>
#include <map>
#include <set>
#include <bitset>
#include <string>
#include <vector>
#include <list>

/**
 * basicshim TODOs --
 *
 *   The following functions need to be properly implemented in BasicShim for 
 *   deterministic file paths and file descriptors:
 *
 *    - utimes
 *    - readv, writev
 *    - truncate
 *    - flock
 *    - fcntl
 *    - ... and many more ...
 */

using std::auto_ptr;
using std::map;
using std::set;
using std::string;
using std::vector;
using std::list;
using std::bitset;
using boost::shared_ptr;

#ifndef MAX_BUF
#define MAX_BUF		(16<<20)  // for read/write buffers
#endif

#ifndef PATH_MAX
#define PATH_MAX	4096      // matches PATH_MAX in the kernel
#endif

#define DMP_CONTROL_PORT 5000  // Port shims listen on for incoming control channel connections

namespace DMP {

/* Blocks until all threads die */
void WaitForThreadsToDie(bool printsummary);

class TimerStat {
 public:
	TimerStat(const char *msg);
	~TimerStat();

	uint64_t get_ms();
	void reset();
	void set(uint64_t ms);

	void start();
	void stop();

 private:
 	struct timeval _start;
	uint64_t _timer;
	string _msg;
	bool _running;
};

class HistogramStat {
 public:
	HistogramStat(const char *msg);
	~HistogramStat(void);

	void print();
	int  add(int key);

 private:
	map <int, int> _buckets;
	string _msg;
};

/*
 * Deterministic fs ops
 * Must initialize these before spawning any threads.
 */

// Number of logical time ticks to use for each operation
//   < 0 :: blocking unbounded (nondeterministic)
//     0 :: nonblocking
//   > 0 :: blocking bounded
struct FileTimingInfo {
	int read;
	int write;
	int open;
	int close;
	int generic;
};
typedef map<string, FileTimingInfo> FileTimingMap;

extern uint64_t current_distq;

/**
 * BitSet, PBitSet --
 *
 *   Bit sets used to keep track of which remote DPGs a DPG needs to wait 
 *   for before entering the next global quantum. See use of WaitFor in
 *   BasicShim
 */
#define MAXDDPGS 32 /* This is a silly limit; make sure its big enough */
class BitSet : public bitset<MAXDDPGS> {
 public:
	BitSet();
	~BitSet();

	void lock();
	void unlock();

	void set(size_t pos);
	void set(void);
	void reset(size_t pos);
	void reset(void);
	void safe_set(size_t pos);
	void safe_set(void);
	void safe_reset(size_t pos);
	void safe_reset(void);

 private:
	pthread_mutex_t __lock;
};
typedef shared_ptr<BitSet> PBitSet;

/**
 * IncomingConn, IncomingConnList --
 *
 *   An IncomingConn is information about a incoming connection request on a
 *   listening socket that has not been accepted yet. The IncomingConnList
 *   is a simple list data structure to hold many incoming connection
 *   requests
 */
struct IncomingConn {
	uint64_t connection_time;
	uint32_t peerid;
	uint16_t remote_port;
};
typedef shared_ptr<IncomingConn> PIncomingConn;
typedef list<PIncomingConn> IncomingConnList;

/**
 * SlottedBuffer --
 *
 *   Contains pending data for a socket. The SlottedBuffer is implemented as
 *   a list of messages; each message is an arbitrary length of data sent in the
 *   same global quantum. Each message is tagged with the logical arrival time.
 */
struct SlottedMessage {
	uint64_t arrival_time;
	vector<unsigned char> data;
};
typedef shared_ptr<SlottedMessage> PSlottedMessage;

class SlottedBuffer {
 public:
	SlottedBuffer();
	~SlottedBuffer();

	void debug_msg();

	uint64_t avail(uint64_t now);
	uint64_t append(uint64_t now, char *bytes, uint64_t n);
	uint64_t get(uint64_t now, char *bytes, uint64_t n);

 private:
	pthread_mutex_t lock;
	list<PSlottedMessage> messages;
};
typedef shared_ptr<SlottedBuffer> PSlottedBuffer;

/**
 * PendingConn --
 *
 *   Contains the result of a connection request to a remote port.
 */
struct PendingConn {
	PendingConn() {
		conn_result = -1;
	}

	int conn_result;
};
typedef shared_ptr<PendingConn> PPendingConn;



/**
 * VS_* --
 *   
 *   Various bits used in the state flag of the VirtualSocket defined below.
 */
#define VS_CLOSED      0      /* Socket closed */
#define VS_BOUND      (1<<0)  /* Socket is bound to a det port */
#define VS_LISTENING  (1<<1)  /* listen() has been called on this socket */
#define VS_CONNECTING (1<<2)  /* A connection request has been made */
#define VS_CONNECTED  (1<<3)  /* Socket has established a connection */
#define VS_NONBLOCK   (1<<4)  /* O_NONBLOC has been set on socket */

/**
 * VirtualSocket --
 *
 *   Contains the state needed to implement a deterministic socket connection
 *   between two DPGs in a distributed DPG.
 */
struct VirtualSocket {
 public:
 	VirtualSocket();
	~VirtualSocket();

 	void lock()      { pthread_mutex_lock(&__lock); }
	void unlock()    { pthread_mutex_unlock(&__lock); }

	uint32_t upctr()     { return ++refctr; }
	uint32_t downctr()   { return 1; /* return --refctr; */ } /* Disable reclaiming for now */

	bool pending_read();                      /* Used for select and poll family */

	uint8_t  state;                           /* Bit-mask of VS_* above */
	uint16_t remote_port;

	SlottedBuffer    data;                    /* Data on this socket */
	IncomingConnList incoming_connections;    /* Incoming connections on this socket */
	PendingConn      pending_connect_req;     /* Our pending connection request if
	                                           * the state is VS_CONNECTING. */

	/* Various values that are set from setsockopt, but do not effect the behavior of the socket */
	int  sock_sndbuf;
	int  sock_rcvbuf;
	char sock_keepalive;
	char tcp_nodelay;
	char sock_reuseaddr;

 private:
 	pthread_mutex_t __lock;
	uint32_t        refctr;                   /* Number of fd's pointing to this
	                                           * VirtualSocket; VirtualSockets should
						   * only be destroyed when refctr = 0.
						   * This is currently initialized to 1 and
						   * never decremented; leaks memory but
						   * I'm lazy. */
};
typedef shared_ptr<VirtualSocket> PVSock;

/**
 * VSockMap --
 *
 *   This data structure is used for looking up the VirtualSocket for a given
 *   virtual port number. 
 */
class VSockMap : public map<uint16_t, PVSock> {
  public:
	VSockMap();
	~VSockMap();

	void set(uint16_t port, PVSock vsock) { 
		//SHIM_LOG("VSockMap@0x%p.set(%d, %p)\n", this, port, vsock.get());
		(*this)[port] = vsock;
	}

	PVSock get(uint16_t port) {
		VSockMap::const_iterator i = this->find(port);
		//SHIM_LOG("VSockMap@0x%p.get(%d) = %p\n", this, port, (i == this->end() ? NULL : i->second.get()));

		if (i == this->end())
			return PVSock();
		else
			return i->second;
	}

	void lock()   { pthread_mutex_lock(&this->__lock);   }
	void unlock() { pthread_mutex_unlock(&this->__lock); }

	/* Make sure to lock! */
	uint16_t getNewPort();

 private:
 	uint16_t nextPort;
	pthread_mutex_t __lock;
};
typedef shared_ptr<VSockMap> PVSockMap;

/**
 * DNode -- 
 *
 *  The DNode struct contains information about remote DPGs
 */
typedef set<uint16_t> PortSet;
struct DNode {
	DNode() {
		SHIM_LOG("Creating new DNode\n");
		pthread_mutex_init(&ctrlfd_lock, NULL);
		pthread_mutex_init(&quantum_lock, NULL);
		pthread_cond_init(&quantum_cv, NULL);
		manager = 0;
		last_known_quantum = 0;
	}

	~DNode() {
		SHIM_LOG("Destroying DNode for %d\n", nodeid);
	}

	uint32_t nodeid;  /* Remote dpg's node id (unique) */
	uint32_t address; /* May not be unique if multiple dpgs are running on a single host */
	bool     exiting; /* Set by master when this node reports it is exiting */
	PortSet  ports;   /* Which listening ports are deterministic on this dpg */
	uint16_t control_port; /* Port this node is listening on for new control connections */

	pthread_mutex_t ctrlfd_lock;
	int      ctrlfd;  /* Control fd used for communicating with this dpg */
	int      ctrlfd2; /* This is the fd used for communicating with self */

	pthread_t manager; /* Handle to the manager thread the processes the control connection */

	/* These variables track the quantum of the remote DPG */
	pthread_mutex_t quantum_lock;
	pthread_cond_t  quantum_cv;
	uint64_t        last_known_quantum;
};
typedef shared_ptr<DNode> PDNode;
class DNodeMap : public map<uint32_t, PDNode> {
  public:
	DNodeMap() : map<uint32_t, PDNode>() { pthread_mutex_init(&__lock, NULL); }
	~DNodeMap()                          { pthread_mutex_destroy(&__lock); }

	void set(uint32_t id, PDNode node)   { (*this)[id] = node; }
	PDNode get(uint32_t id)              { return (*this)[id]; }

	void lock()   { pthread_mutex_lock(&this->__lock);   }
	void unlock() { pthread_mutex_unlock(&this->__lock); }

 private:
	pthread_mutex_t __lock;
};
typedef shared_ptr<DNodeMap> PDNodeMap;

boost::filesystem::path join_paths(const boost::filesystem::path &root, const char* sub);
bool add_deterministic_file_path(const char* path, const FileTimingInfo& timing);
bool check_for_deterministic_file_path(const boost::filesystem::path &cwd,
				       const char* path, FileTimingInfo* timing);

void *ControlManagerFn(void *_args);

/*
 * Fd tables
 *  
 *   - FDT_FILE,  this entry contains a shadow fd for deterministic file operations
 *   - FDT_SOCKET, this entry contains a virtual socket for determinisic socket
 *                 communication
 *   - FDT_REP_SOCK, this entry indicates the corresponding application fd is a
 *                   determinstic socket during replay
 */
enum FDType { FDT_FILE, FDT_SOCKET, FDT_REP_SOCK };
struct FileDescriptor
{
	FileDescriptor();
	~FileDescriptor();
	
	FDType type;             // Type of descriptor
	FileTimingInfo timing;   // how much logical time to spend for each fs op
	int shadowfd;            // shadow file descriptor

	union {
		struct {
			long filesize;           // total file size in bytes
			long filepos;            // position in the file
			char close_on_exec;      // set if descriptor should be removed on exec
						 // (allows the shim to mimic the FD_CLOEXEC flag)
		};
		struct {
			uint32_t addr;           // remote address for accepted connections
			uint16_t port;           // port this fd is listening on
			int      family;

			int      peerid;         // id of the peer we're connected to
			//uint32_t remote_port;   // cookie to use when sending data to a remote node

			/* Other */
			bool     nonblocking;    // true if the socket is nonblocking
		};
	};
};
typedef shared_ptr<FileDescriptor> PFileDescriptor;

class FileDescriptorTable : public map<int, PFileDescriptor>
{
 public:
	FileDescriptorTable();
	shared_ptr<FileDescriptorTable> clone();

	void add(int fd, PFileDescriptor f)	{ (*this)[fd] = f; }
	void clear()				{ (*this).clear(); }
	PFileDescriptor get(int fd);
	void remove(int fd);

	void clean_cloexec(void);

 private:
	FileDescriptorTable(const FileDescriptorTable& clone);
	bool operator=(FileDescriptorTable&);
	friend class shared_ptr<FileDescriptorTable>;
};
typedef shared_ptr<FileDescriptorTable> PFDTable;

/*
 * An extensible base-class for a basic DMP shim thread
 */

class BasicShim {
        /**********************************************************************
         *                     Common interface and state                     *
         **********************************************************************/
 public:
	pid_t _dmp_pid;              /* info about the dmp task being shimmed */
	const uint32_t _unique_id;   /* a unique, deterministic sort key      */
 	bool _done_flag;             /* Set when the shim should exit         */
	uint64_t event_count;        /* Gives each shim event a unique id     */

	/* Misc fields */
	int nullfd; /* dummy fd for replaying file descriptors and dummy sockets */

 public:
	BasicShim(BasicShim* parent, int clone_flags, bool reexec_detnet);
	virtual ~BasicShim();

	virtual BasicShim* clone(int clone_flags);
	
	virtual void loop();
	virtual int get_next_shim_event(shim_event *event);

	virtual bool trace_syscall_enter(shim_event* event);
	virtual void trace_syscall_leave(shim_event* event);
	virtual void trace_shimcall(shim_event* event);
	virtual void trace_barrier(shim_event* event);
	virtual void trace_signal(shim_event *event);
	virtual void trace_rdtsc(shim_event *event);
	virtual void trace_exit(shim_event* event);
	virtual void follow_fork(long syscall, long clone_flags);
	virtual void attach_after_fork();

	struct UniqueSort { /* for sorting by _unique_id */
		bool operator()(BasicShim* a, BasicShim* b) {
			return a->_unique_id < b->_unique_id;
		}
	};


        /**********************************************************************
         *           Interface and state for deterministic file ops           *
         **********************************************************************/
 public:
	shared_ptr<boost::filesystem::path> _cwd;
	PFDTable _fdtable;
	PFDTable _ndfdtable;
	vector<char> _tmp_buffer;

 protected:
	FileTimingMap FsTimings;
 
 protected:
 	/* Helper function for open and creat */
	bool __do_fs_open(shim_event *event, unsigned long path, int flags, int mode);

	/* utils */
	void start_io_op(int timing);
	void finish_io_op(int timing);

 public:
	/* called on sysenter: return true iff the event was emulated */
	virtual bool do_fs_open(shim_event* event);
	virtual bool do_fs_creat(shim_event *event);
	virtual bool do_fs_close(shim_event* event);
	virtual bool do_fs_read(shim_event* event);
	virtual bool do_fs_readv(shim_event *event);
	virtual bool do_fs_write(shim_event* event);
	virtual bool do_fs_writev(shim_event *event);
	virtual bool do_fs_lseek(shim_event* event);
	virtual bool do_fs_dup(shim_event* event);
	virtual bool do_fs_dup2(shim_event* event);
	virtual bool do_fs_utime(shim_event *event);
	virtual bool do_fs_utimes(shim_event *event);
	virtual bool do_fs_fcntl(shim_event *event);
	virtual bool do_fs_execve(shim_event *event);
	virtual bool do_fs_generic(int syscall, shim_event *event);
	virtual bool do_fs_generic_path(int syscall, shim_event *event);

	/* called on sysleave */
	virtual void do_fs_chdir(shim_event* event);

	/* utils */
	bool add_deterministic_fd(int dmp_fd, const FileTimingInfo& timing);
	bool add_deterministic_path(const char *path, const FileTimingInfo &timing);

	bool isdetfd(int dmp_fd, FileTimingInfo *timing);
	bool isdetpath(const string &path, FileTimingInfo *timing);
	bool isdetpath(const boost::filesystem::path &cwd, const char *path, FileTimingInfo *timing);


        /**********************************************************************
         *     Interface and state for deterministic distributed systems      *
         **********************************************************************/
 protected:
	uint32_t node_id;       /* Our unique id in the distributed system */
	int master_node_id;     /* Unique ID of the current master (always 0 for now) */
	int num_dpgs;           /* The number of DPGS (including this one) in the DDPG */

	uint64_t max_drift;     /* Maximum drift in notion of global time; if 
	                         * DPGs drift more, they are forced to sync at the
				 * next global barrier. 0 disables this. */

	uint64_t distq_size;    /* Number of local rounds per distributed
	                         * quantum */

	int control_sock;	/* Listening socket for incoming control
				 * channel; used by master. Remote nodes use it
				 * to communicate with the master */
	bool reexec_detnet;     /* Set to true to re-execute deterministic network
	                         * communication freely, rather than waiting for barriers.
				 * This option only makes sense when using deterministic
				 * nodes in a record/replay scenario. */

	long *distq_data;       /* Pointer to value in DPG to set when the
				 * second to last thread has exited; used by
				 * the distq-handling thread to know when to
	                         * exit. */

	/*--------------------------------------------------------------------*
	 * The following structures are shared by all threads in a process    *
	 *--------------------------------------------------------------------*/
	PDNodeMap DetNodes;  /* Contains control channel and state for other
			      * nodes in the dist sys; indexed by node id.
			      * (Can't be indexed by address since multiple DPGs
			      * may be running on a single host) */

	PVSockMap VSocks;    /* Contains a map from virtual port number to
			      * state of the corresponding virtual socket
			      * connection */

	PBitSet   WaitFor;   /* Each DPG in a DDPG has a bit; that bit is set
			      * when this DPG must wait for that DDPG to enter
			      * the next global quantum. Cleared at beginning
			      * of each distributed quantum. */
	/*--------------------------------------------------------------------*
	 * End of shared structures                                           *
	 *--------------------------------------------------------------------*/

	 /*********************************************************************
	  * Statistics for this shim                                          *
	  *   Make these public so the various recplay functions can start    *
	  *   and stop them as well.                                          *
	  *                                                                   *
	  *   timed_* functions are wrappers that accumulate time             *
	  *   automatically                                                   *
	  *********************************************************************/
 public:
	TimerStat totalTime;//("Total time alive");
	TimerStat memcpyTime;//("Memcpy time");
	TimerStat waitForDistqTime;//("Waiting for distq barrier");
	TimerStat socketIOTime; /* cc_send_data and reading from slotted buffers */
	TimerStat waitForPeersTime;
	TimerStat waitForEventTime;
	TimerStat waitForConnectTime;
	TimerStat waitForDataTime; /* wait_for_distq_barrier on blocking sockets */
	TimerStat acceptWaitTime;
	TimerStat pollWaitTime;
	TimerStat selectWaitTime;
	TimerStat floodEndqTime;
	HistogramStat distqDelta;

	long timed_dmp_shim_memcpy_sync(void *shim_buf, void *dmp_buf, long nbytes,
		enum ShimCtlFlag write_to_dmp, long *bytes_out);

	long timed_dmp_shim_strncpy_sync(void *shim_buf, void *dmp_buf, long nbytes,
		long *bytes_out);
	

 protected:
	bool handle_distq_barrier(shim_event *event);
	void set_distq_handler(shim_event *event);
	
	int accept_control_connection(int nodeid);
	bool start_remote_shim(int nodeid, const char *host, const char *cmd);
	bool establish_control_channels(void);

	void wait_for_global_barrier(uint32_t status);
	void wait_for_ddpg_exit(void);
	bool wait_for_distq_barrier(void);

 public:
 	friend void *ControlManagerFn(void *);

	void set_max_drift(uint64_t max_drift);
	bool add_manifest(string filename);
	bool set_master_node(string master, uint16_t port);
	bool add_det_port(uint16_t port);
	bool add_det_ports(const char *ports);
	bool add_det_port_range(const char *range);

	bool isdetport(uint16_t port);
	PDNode isdetaddr(uint32_t addr, uint16_t port);
	bool add_deterministic_node(uint32_t addr);
	bool step_slotted_buffers(void);
	int  add_nondet_shadow_fd(int dmpfd);
	int  __get_set_size(int maxfd);

	virtual bool do_sock_socket(shim_event *event);
	virtual bool do_sock_bind(shim_event *event);
	virtual bool do_sock_listen(shim_event *event);
	virtual bool do_sock_accept(shim_event *event);
	virtual bool do_sock_connect(shim_event *event);
	virtual bool do_sock_exit(shim_event *event);
	virtual bool do_sock_select(shim_event *event);
	virtual bool do_sock_getpeername(shim_event *event);
	virtual bool do_sock_getsockname(shim_event *event);
	virtual bool do_sock_setsockopt(shim_event *event);
	virtual bool do_sock_getsockopt(shim_event *event);

	virtual bool do_sock_sendto(shim_event *event);
	virtual bool do_sock_recvfrom(shim_event *event);
	virtual bool do_sock_sendmsg(shim_event *event);
	virtual bool do_sock_recvmsg(shim_event *event);
	virtual bool do_sock_poll(shim_event *event);

	virtual bool do_sock_fcntl(shim_event *event);

	virtual bool __do_sock_readv(shim_event *event, PFileDescriptor pfd);
	virtual bool __do_sock_writev(shim_event *event, PFileDescriptor pfd);
	virtual bool __do_sock_dup(shim_event *event, int dmpoldfd, int dmpnewfd, PFileDescriptor pfd);
	virtual bool __do_sock_close(shim_event *event, int dmpfd, PFileDescriptor pfd);
	virtual bool __do_sock_sendto(shim_event *event, PFileDescriptor pfile,
	                              int dmpfd, char *dmpbuf, long nbytes);
	virtual bool __do_sock_recvfrom(shim_event *event, PFileDescriptor pfile,
	                                int dmpfd, char *dmpbuf, long nbytes);
	virtual int  __do_sock_det_select(shim_event *event, int nfds, fd_set *dmp_rdp,
	                                  fd_set *dmp_wrp, fd_set *dmp_exp);
	virtual int  __do_sock_nondet_select(shim_event *event, int nfds,
	                                     fd_set *dmp_rdp, fd_set *dmp_wrp,
	                                     fd_set *dmp_exp);
	virtual bool __do_sock_single_poll(struct pollfd *pollfd);
	virtual int  __do_sock_det_poll(shim_event *event, int detcnt, struct pollfd *detfds);
	virtual int  __do_sock_nondet_poll(shim_event *event, int nondetcnt, struct pollfd *nondetfds);
};

void FillLocalIP(PDNode node);

} // namespace DMP

#endif
