/**
 * basicshim_detfs.cpp --
 *
 *   This file implements the various functions necesasry for implementing
 *   deterministic file services in the shim.
 *
 *   Note:
 *       These functions always return -errno on error
 *
 *   TODO:
 *       - readv, writev
 *       - readlink
 *       - stat/fstat/access
 */
#include <string>
#include <cstring>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <utime.h>
#include <limits.h>
#include <stdlib.h>

#include "dmp.h"
#include "basicshim.h"

namespace DMP {

bool BasicShim::add_deterministic_path(const char* path, const FileTimingInfo& timing)
{
	char *real_path = realpath(path, NULL);	

	SHIM_LOG("Adding %s to DFH\n", path);

	if (real_path == NULL) {
		SHIM_PERROR("realpath failed");
		return false;
	}

	FsTimings[real_path] = timing;
	free(real_path);

	return true;
}

bool BasicShim::isdetfd(int fd, FileTimingInfo *timing)
{
	shared_ptr<FileDescriptor> res;

	res = _fdtable->get(fd);
	if (res && timing)
		*timing = res->timing;

	return res != NULL;
}

bool BasicShim::isdetpath(const string &path, FileTimingInfo *timing)
{
	bool found = false;
	char *cpath = NULL;
	map<string, FileTimingInfo>::iterator i;

	char *working = strdup(path.c_str()), *pos;
	assert(working);
	while (!cpath) {
		SHIM_LOG("Checking %s\n", working);
		cpath = realpath(working, NULL);
		if (cpath) {
			SHIM_LOG("%s canonicalizes to %s\n", path.c_str(), cpath);

		} else {
			SHIM_LOG("Couldn't canonicalize: %s\n", strerror(errno));
			pos = strrchr(working, '/');
			if (pos)
				*pos = '\0';
			else
				break;
		}
	}
	free(working);

	if (cpath == NULL) {
		SHIM_WARN("Couldn't find %s\n", path.c_str());
		return false;
	}

	SHIM_LOG("    Checking for %s in DFH\n", cpath);
	for (i = FsTimings.begin(); i != FsTimings.end(); ++i) {
		SHIM_LOG("    Checking path against %s... ", i->first.c_str());
		if (strncmp(i->first.c_str(), cpath, i->first.length()) == 0) {
			if (timing)
				*timing = i->second;
			found = true;
			SHIM_LOG_CONT("found.\n");
			break;
		}
		SHIM_LOG_CONT("nope.\n");
	}

	free(cpath);
	return found;
}

bool BasicShim::isdetpath(const boost::filesystem::path &cwd, const char *path,
	FileTimingInfo *timing)
{
	string full = join_paths(cwd, path).normalize().string();
	return isdetpath(full, timing);
}


void BasicShim::start_io_op(int timing)
{
	SHIM_LOG("timing=%d\n", timing);

	// Nonblocking
	if (timing == 0)
		return;
	// Blocking unbounded
	else if (timing < 0) {
		if (dmp_shim_sleep(DMP_SLEEP_NORMAL) != 0)
			SHIM_PERROR("dmp_shim_sleep");
	// Blocking bounded
	} else {
		if (dmp_shim_set_barrier(SHIM_BARRIER_IO, SHIM_BARRIER_OFFSET_PARALLEL, timing) < 0)
			SHIM_PERROR("dmp_shim_set_barrier");
		if (dmp_shim_sleep(DMP_SLEEP_NORMAL) != 0)
			SHIM_PERROR("dmp_shim_sleep");
	}
}

void BasicShim::finish_io_op(int timing)
{
	SHIM_LOG("timing=%d\n", timing);

	// Nonblocking
	if (timing == 0)
		return;

	// Blocking unbounded: set a barrier for right now
	// Blocking bounded: we set a barrier in start_io_op()
	if (timing < 0) {
		if (dmp_shim_set_barrier(SHIM_BARRIER_IO, SHIM_BARRIER_NEXT_SERIAL, 0) < 0) {
			SHIM_PERROR("dmp_shim_set_barrier");
			return;
		}
	}

	shim_event event;

	SHIM_LOG("waiting for barrier...\n");
	//if (dmp_shim_trace(&event) < 0)
	if (get_next_shim_event(&event) < 0)
		SHIM_PERROR("dmp_shim_trace");

	SHIM_LOG("@%ld.%d: event received\n", EVTIME(&event));
	if (event.event_type != DMP_SHIM_BARRIER)
		SHIM_LOG("expected a barrier event, got: %d\n", event.event_type);
}

bool BasicShim::__do_fs_open(shim_event *event, unsigned long _path, int _flags, int _mode)
{
	char shim_pathname[PATH_MAX];
	const unsigned long dmp_path = _path;
	const int dmp_flags          = _flags;
	const int dmp_mode           = _mode;
	long ret;

	// Check if this file should be treated deterministically.
	if (timed_dmp_shim_strncpy_sync((void*)shim_pathname, (void*)dmp_path, sizeof shim_pathname, NULL) != 0) {
		SHIM_PERROR("dmp_shim_strcpy");
		return false;
	}

	if (strnlen(shim_pathname, PATH_MAX) >= PATH_MAX-1) {
		fprintf(stderr, "PATH_MAX too big? %ld\n", (long)PATH_MAX);
	}

	// N.B.: need to normalize the path to the CWD.
	const string fullpath = join_paths(*_cwd, shim_pathname).normalize().string();

	SHIM_LOG("@%ld.%d: open(%s, %#x, %#o) ...\n", EVTIME(event), fullpath.c_str(), dmp_flags, dmp_mode);

	shared_ptr<FileDescriptor> fd(new FileDescriptor);
	fd->type = FDT_FILE;

	if (!isdetpath(fullpath, &fd->timing)) {
		SHIM_LOG(" ... (nondeterminstic path)\n");
		return false;
	}

	if (dmp_flags & O_NONBLOCK) {
		SHIM_LOG("Requested nonblocking I/O; ignoring\n");
		return false;
	}

	// Now execute the open.
	start_io_op(fd->timing.open);
	fd->shadowfd = open(fullpath.c_str(), dmp_flags, dmp_mode);

	// Failure here is a failure for the user.
	if (fd->shadowfd < 0) {
		ret = -errno;
		if (errno != ENOENT)
			SHIM_PERROR("open");
		goto out;
	}

	// Get the filesize.
	// We assume the filesize is a deterministic input.
	struct stat stat;
	if (fstat(fd->shadowfd, &stat) != 0) {
		ret = -errno;
		SHIM_PERROR("fstat");
		goto out;
	}

	fd->filesize = stat.st_size;
	fd->filepos = 0;

	// Now shadow the new file descriptor.
	ret = dmp_shim_dupfd(fd->shadowfd, TO_DMP, dmp_flags & O_CLOEXEC);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd");
		goto out;
	}

	SHIM_LOG("Adding dmp_fd:%ld -> shim_fd:%d mapping\n", ret, fd->shadowfd);
	_fdtable->add(ret, fd);

out:
	finish_io_op(fd->timing.open);
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_creat(shim_event *event)
{
	unsigned long dmp_path  = shim_syscall_arg0(&event->regs);
	int dmp_flags           = O_CREAT | O_WRONLY | O_TRUNC; /* See creat(2) */
	int dmp_mode            = (int)shim_syscall_arg1(&event->regs);

	return __do_fs_open(event, dmp_path, dmp_flags, dmp_mode);
}

bool BasicShim::do_fs_open(shim_event* event)
{
	unsigned long dmp_path =      shim_syscall_arg0(&event->regs);
	int dmp_flags          = (int)shim_syscall_arg1(&event->regs);
	int dmp_mode           = (int)shim_syscall_arg2(&event->regs);

	return __do_fs_open(event, dmp_path, dmp_flags, dmp_mode);
}

bool BasicShim::do_fs_close(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	long ret;

	// Are we shadowing this fd?
	PFileDescriptor fd = _fdtable->get(userfd);
	if (fd == NULL || fd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);

		// Do we have a copy of this nondet fd?
		fd = _ndfdtable->get(userfd);
		if (fd != NULL) {
			SHIM_LOG("Closing shims copy:%d of dmpfd:%d\n", fd->shadowfd, userfd);
			_ndfdtable->remove(userfd);
		}

		return false;
	}

	SHIM_LOG("@%ld.%d: close(%d)\n", EVTIME(event), userfd);
	ret = 0;

	// Remove file from the dmp task before closing it (ugly: kernel code assumes this order).
	if (dmp_shim_closefd(userfd) < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_closefd");
		goto out;
	}

	_fdtable->remove(userfd);
	
	/**
	 * Deterministic sockets in the shim do not have a shadow fd; the DMP
	 * task has a file descriptor in its table, but the shim intercepts and
	 * routes all traffic to/from this socket to the determinisitc overlay
	 * created by the pair-wise control connections between dpgs.
	 */
	if (fd->type == FDT_SOCKET) {
		SHIM_LOG("This is a deterministic socket; removing slotted buffers\n");
		__do_sock_close(event, userfd, fd);
		dmp_shim_emulate_syscall(0, &event->regs);
		return true;
	}

	// Close the file in the shim if this is the last reference.
	// NB: if shimming multiple procs there can be >1 references.
	start_io_op(fd->timing.close);

	if (fd.unique()) {
		// Ignore failures here: we already closed in the dmptask.
		if (close(fd->shadowfd) < 0)
			SHIM_PERROR("close");
		fd->shadowfd = -1;
	}

	finish_io_op(fd->timing.close);

out:
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_readv(shim_event *event)
{
	const int     userfd           = shim_syscall_arg0(&event->regs);
	unsigned long __unused uservec = shim_syscall_arg1(&event->regs);
	int           __unused usercnt = shim_syscall_arg2(&event->regs);
	
	SHIM_LOG("@%ld.%d: readv(fd:%d, iov:%p, cnt:%d) ...\n", EVTIME(event), userfd, uservec, usercnt);

	/*
	 * Are we shadowing this fd?
	 */
	PFileDescriptor pfd = _fdtable->get(userfd);
	if (pfd == NULL || pfd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	/*
	 * If the file descriptor is actually a determinstic socket, redirect
	 * to the socket stuff
	 */
	if (pfd->type == FDT_SOCKET) {
		SHIM_LOG("This is a socket; doing socket stuff instead\n");
		return __do_sock_readv(event, pfd);
	}

	SHIM_WARN("readv() not supported for deterministic files yet\n");
	return false;
}

bool BasicShim::do_fs_read(shim_event* event)
{
	const int     userfd    = shim_syscall_arg0(&event->regs);
	unsigned long userbuf   = shim_syscall_arg1(&event->regs);
	unsigned long userbufsz = shim_syscall_arg2(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: read(fd:%d, sz:%ld) ...\n", EVTIME(event), userfd, userbufsz);

	// Are we shadowing this fd?
	PFileDescriptor fd = _fdtable->get(userfd);
	if (fd == NULL || fd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	// Cap the maximum buffer size.
	if (userbufsz > MAX_BUF) {
		userbufsz = MAX_BUF;
		SHIM_LOG(" ... capping buffer to sz:%ld\n", userbufsz);
	}

	/*
	 * If the file descriptor is actually a determinstic socket, redirect
	 * to the socket stuff
	 */
	if (fd->type == FDT_SOCKET) {
		SHIM_LOG("This is a socket; doing socket stuff instead\n");
		return __do_sock_recvfrom(event, fd, userfd, (char *)userbuf, userbufsz);
	}

	SHIM_LOG(" ... filepos %ld / %ld\n", fd->filepos, fd->filesize);
	start_io_op(fd->timing.read);

	// Read the file.
	_tmp_buffer.resize(userbufsz);
	char* buf = &_tmp_buffer[0];
	char* bufptr = buf;
	size_t bytes = 0;

	while (bytes < userbufsz) {
		SHIM_LOG("... read %ld bytes sofar (of %ld)\n", bytes, userbufsz);
		ret = read(fd->shadowfd, bufptr, userbufsz - bytes);
		if (ret == 0) {
			// End Of File
			SHIM_LOG("... end-of-file\n");
			break;
		}
		if (ret < 0) {
			// Ignore transient errors
			if (errno == EINTR)
				continue;
			// TODO: should seek back to where we started
			ret = -errno;
			SHIM_LOG(" ... (ret: %ld)\n", ret);
			finish_io_op(fd->timing.read);
			dmp_shim_emulate_syscall(ret, &event->regs);
			return true;
		}

		bufptr += ret;
		bytes += ret;
		fd->filepos += ret;
	}

	ret = 0;

	// Copy the result.
	finish_io_op(fd->timing.read);
	if (timed_dmp_shim_memcpy_sync((void*)buf, (void*)userbuf, bytes, TO_DMP, (long*)&bytes) < 0)
		ret = -errno;


	// Ignore access errors if >0 bytes were written.
	if (bytes > 0)
		ret = bytes;
	
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_writev(shim_event *event)
{
	const int     userfd           = shim_syscall_arg0(&event->regs);
	unsigned long __unused uservec = shim_syscall_arg1(&event->regs);
	int           __unused usercnt = shim_syscall_arg2(&event->regs);
	
	SHIM_LOG("@%ld.%d: writev(fd:%d, iov:%p, cnt:%d) ...\n", EVTIME(event), userfd, uservec, usercnt);

	/*
	 * Are we shadowing this fd?
	 */
	PFileDescriptor pfd = _fdtable->get(userfd);
	if (pfd == NULL || pfd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	/*
	 * If the file descriptor is actually a determinstic socket, redirect
	 * to the socket stuff
	 */
	if (pfd->type == FDT_SOCKET) {
		SHIM_LOG("This is a socket; doing socket stuff instead\n");
		return __do_sock_writev(event, pfd);
	}

	SHIM_WARN("writev() not supported for deterministic files yet\n");
	return false;
}

bool BasicShim::do_fs_write(shim_event* event)
{
	const int     userfd    = shim_syscall_arg0(&event->regs);
	unsigned long userbuf   = shim_syscall_arg1(&event->regs);
	unsigned long userbufsz = shim_syscall_arg2(&event->regs);
	long ret, res;
	char *temp;

	SHIM_LOG("@%ld.%d: write(fd:%d, sz:%ld) ...\n", EVTIME(event), userfd, userbufsz);

	/* Hack to see error messages in shim log */
	if (1) {
		int tmpsize = (userbufsz > 256 ? 256 : userbufsz);
		temp = (char *)(malloc(tmpsize+1));
		if (temp) {
			timed_dmp_shim_memcpy_sync((void *)temp, (void *)userbuf, tmpsize, FROM_DMP, NULL);

			temp[tmpsize] = '\0';
			SHIM_LOG(" ... msg: %s\n", temp);
			free(temp);
		} else {
			SHIM_LOG(" ... couldn't allocate space for message\n");
		}
	}

	// Are we shadowing this fd?
	PFileDescriptor fd = _fdtable->get(userfd);
	if (fd == NULL || fd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	// Cap the maximum buffer size.
	if (userbufsz > MAX_BUF) {
		userbufsz = MAX_BUF;
		SHIM_LOG(" ... capping buffer to sz:%ld\n", userbufsz);
	}

	/*
	 * If the file descriptor is actually a determinstic socket, redirect
	 * to the socket stuff
	 */
	if (fd->type == FDT_SOCKET) {
		SHIM_LOG("This is a socket; doing socket stuff instead\n");
		return __do_sock_sendto(event, fd, userfd, (char *)userbuf, userbufsz);
	}

	// Copy the buffer.
	_tmp_buffer.resize(userbufsz);
	char* buf = &_tmp_buffer[0];

	res = timed_dmp_shim_memcpy_sync((void*)buf, (void*)userbuf, userbufsz, FROM_DMP, NULL);
	if (res < 0) {
		ret = -errno;
		dmp_shim_emulate_syscall(ret, &event->regs);
		return true;
	}

	start_io_op(fd->timing.write);

	// Write the file.
	char* bufptr = buf;
	size_t bytes = 0;

	while (bytes < userbufsz) {
		ret = write(fd->shadowfd, bufptr, userbufsz - bytes);
		if (ret < 0) {
			if (errno == EINTR)
				continue;
			ret = -errno;
			goto out;
		}

		bufptr += ret;
		bytes += ret;
		fd->filepos += ret;
	}

	ret = bytes;

out:
	if (fd->filepos > fd->filesize)
		fd->filesize = fd->filepos;

	SHIM_LOG(" ... (ret: %ld)\n", ret);

	finish_io_op(fd->timing.write);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_lseek(shim_event* event)
{
	const int timing = 0;
	const int userfd = shim_syscall_arg0(&event->regs);
	const off_t offset = shim_syscall_arg1(&event->regs);
	const int whence = shim_syscall_arg2(&event->regs);
	long ret;

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL)
		return false;

	SHIM_LOG("@%ld.%d: lseek(%d, %ld, %d)n", EVTIME(event), userfd, offset, whence);

	// Seek the file.
	// N.B.: since the shadowfd is a dup of the userfd, this will apply to both.
	start_io_op(timing);

	ret = lseek(fd->shadowfd, offset, whence);
	if (ret >= 0) {
		switch (whence) {
		case SEEK_SET:
			fd->filepos = offset;
			break;
		case SEEK_CUR:
			fd->filepos += offset;
			break;
		case SEEK_END:
			fd->filepos = fd->filesize - offset;
			break;
		}
	} else {
		ret = -errno;
	}

	finish_io_op(timing);
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_dup(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: dup(%d)\n", EVTIME(event), userfd);

	// Are we shadowing this fd?
	PFileDescriptor fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	// Dup in the dmptask.
	ret = dmp_shim_dupfd(userfd, DUP_IN_DMP, 0);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd");
		goto out;
	}

	if (_fdtable->get(ret) != NULL)
		SHIM_ERR("already have fd:%ld?\n", ret);

	SHIM_LOG("Adding dmp_fd:%ld -> shim_fd:%d mapping\n", ret, fd->shadowfd);
	_fdtable->add(ret, fd);
	
	/* Hook for dup'ing deterministic sockets */
	if (fd->type == FDT_SOCKET) {
		SHIM_LOG("dup() called on a deterministic socket; call do_sock_dup()\n");
		__do_sock_dup(event, userfd, ret, fd);
	}


out:
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_dup2(shim_event* event)
{
	const int userfdfrom = shim_syscall_arg0(&event->regs);
	const int userfdto   = shim_syscall_arg1(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: dup2(%d, %d)\n", EVTIME(event), userfdfrom, userfdto);

	// Are we shadowing either fd?
	shared_ptr<FileDescriptor> fdfrom = _fdtable->get(userfdfrom);
	shared_ptr<FileDescriptor> fdto   = _fdtable->get(userfdto);

	if (fdfrom == NULL && fdto == NULL) {
		SHIM_LOG(" ... fd:%d fd:%d are not shadowed\n", userfdfrom, userfdto);
		return false;
	}

	// Same fds: always succeed.
	if (userfdfrom == userfdto) {
		ret = userfdto;
		goto out;
	}

	if (fdfrom == fdto) {
		ret = userfdto;
		goto out;
	}

	// Dup in dmptask.
	ret = dmp_shim_dupfd2(userfdfrom, userfdto);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd2");
		goto out;
	}

	if (ret != userfdto) {
		fprintf(stderr, "ERROR: unexpected value from dmp_shim_dupfd2: %ld != %d\n", ret, userfdto);
	}

	// Dup in shimtask, if shadowed.
	if (fdto != NULL) {
		SHIM_LOG("Removing dmp_fd:%d -> shim_fd:%d mapping\n", userfdto, fdto->shadowfd);
		_fdtable->remove(userfdto);
	}
	if (fdfrom != NULL) {
		SHIM_LOG("Adding dmp_fd:%d -> shim_fd:%d mapping\n", userfdto, fdfrom->shadowfd);
		_fdtable->add(userfdto, fdfrom);
	}
	
	/* Hook for dup'ing deterministic sockets */
	if (fdfrom->type == FDT_SOCKET) {
		SHIM_LOG("dup2() called on a deterministic socket; call do_sock_dup()\n");
		__do_sock_dup(event, userfdfrom, userfdto, fdto);
	}

	// Close target in the shimtask, if shadowed.
	if (fdto != NULL && fdto.unique()) {
		start_io_op(fdto->timing.close);

		// Ignore failures here: we already dup'd in the dmptask.
		if (close(fdto->shadowfd) < 0)
			SHIM_PERROR("close");
		fdto->shadowfd = -1;

		finish_io_op(fdto->timing.close);
	}

out:
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_fcntl(shim_event *event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	const long cmd   = shim_syscall_arg1(&event->regs);
	const long arg   = shim_syscall_arg2(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: fcntl(%d, %ld, ...)\n", EVTIME(event), userfd, cmd);

	/* Are we shadowing this fd? */
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL || fd->type == FDT_REP_SOCK) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	if (fd->type == FDT_SOCKET) {
		SHIM_LOG(" ... fd:%d is a determinsitic socket\n", userfd);
		return do_sock_fcntl(event);
	}

	/*
	 * F_SETFD modifies the fdtable of a task, not just the struct file the
	 * fd points to. Thus, F_SETFD needs to be handled specially by the shim.
	 */
	start_io_op(fd->timing.generic);
	if (cmd == F_SETFD) {
		SHIM_LOG("Setting FD_CLOEXEC for fd %d to %ld\n", userfd, arg & FD_CLOEXEC);
		ret = dmp_shim_set_cloexec(userfd, arg & FD_CLOEXEC);
		SHIM_LOG("Setting close-on-exec for shim fd %d to %d\n", fd->shadowfd, !!(arg & FD_CLOEXEC));
		fd->close_on_exec = !!(arg & FD_CLOEXEC);

	/*
	 * TODO: Verify this. For other commands, the struct file is modified.
	 * Thus performing the * operation using the shim's descriptor should
	 * be sufficient.
	 */
	} else {
		ret = fcntl(fd->shadowfd, cmd, arg);
	}
	finish_io_op(fd->timing.generic);

	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}


/**
 * do_fs_generic --
 *
 *   All FS functions to deterministic FDs that do not require special handling
 *   should use this function. The main reason is that it returns true if the
 *   target fd is in the DFH and false otherwise. For record shims, this value
 *   is used to determine whether or not to reexecute or replay the system call.
 *
 *   N.B. The target fd is assumed to be the first argument to the syscall.
 *
 *   Parameters:
 *       syscallnr  -- The system call being executed
 *       event    -- Corresponding event
 *
 *   Returns:
 *       TRUE  if the target fd is a determinsitic fd
 *       FALSE otherwise
 */
bool BasicShim::do_fs_generic(int syscallnr, shim_event *event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	const long arg1  = shim_syscall_arg1(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: generic fd fs syscall%d(%d)\n", EVTIME(event), syscallnr, userfd);

	/* Are we shadowing this fd? */
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	/*
	 * Because the shim and dmp tasks share a struct file * in the kernel,
	 * the effect of the dmp calling the system call on its fd and the
	 * shim calling the system call with the shadow fd is the same.
	 *
	 * TODO: On first glance, this appears to be true; this should be 
	 *   validated more thoroughly. In the worst case, seperate
	 *   dmp_shim_ctl codes would be added to jump in to the kernel to do
	 *   the right thing.
	 */
	start_io_op(fd->timing.generic);
	switch(syscallnr) {
		case SYS_fsync:     ret = fsync(fd->shadowfd);           break;
		case SYS_fdatasync: ret = fdatasync(fd->shadowfd);       break;
		case SYS_ftruncate: ret = ftruncate(fd->shadowfd, arg1); break;
		case SYS_fchmod:    ret = fchmod(fd->shadowfd, arg1);    break;
		default:
			ret = -EINVAL;
			SHIM_ERR("Unsupported generic fs operation\n");
			abort();
	}
	finish_io_op(fd->timing.generic);

	SHIM_LOG(" ... (ret: %ld/%d)\n", ret, errno);
	if (ret == -1)
		ret = -errno;
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_generic_path(int syscallnr, shim_event *event)
{
	char tmp[4096];
	char *path = (char *)shim_syscall_arg0(&event->regs);
	int arg1   = shim_syscall_arg1(&event->regs);
	long ret;
	FileTimingInfo timing;
	
	SHIM_LOG("@%ld.%d: generic path fs syscall%d\n", EVTIME(event), syscallnr);

	timed_dmp_shim_strncpy_sync(tmp, path, 4096, NULL);
	SHIM_LOG("Got path: %s\n", tmp);

	/* Are we shadowing this fd? */
	if (!isdetpath(tmp, &timing)) {
		SHIM_LOG(" ... path:%s is not deterministic\n", tmp);
		return false;
	}

	/*
	 * Because the shim and dmp tasks share a struct file * in the kernel,
	 * the effect of the dmp calling the system call on its fd and the
	 * shim calling the system call with the shadow fd is the same.
	 *
	 * TODO: On first glance, this appears to be true; this should be 
	 *   validated more thoroughly. In the worst case, seperate
	 *   dmp_shim_ctl codes would be added to jump in to the kernel to do
	 *   the right thing.
	 */
	start_io_op(timing.generic);
	switch(syscallnr) {
		case SYS_access:    ret = access(tmp, arg1);   break;
		case SYS_unlink:    ret = unlink(tmp);         break;
		case SYS_rmdir:     ret = rmdir(tmp);          break;
		case SYS_chmod:     ret = chmod(tmp, arg1);    break;
		default:
			ret = -EINVAL;
			SHIM_ERR("Unsupported generic fs operation\n");
			abort();
	}
	finish_io_op(timing.generic);

	SHIM_LOG(" ... (ret: %ld/%d)\n", ret, errno);
	if (ret == -1)
		ret = -errno;
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_utime(shim_event *event)
{
	char           *dmp_path =           (char *)shim_syscall_arg0(&event->regs);
	struct utimbuf *dmp_buf  = (struct utimbuf *)shim_syscall_arg1(&event->regs);
	
	char shim_path[PATH_MAX];
	FileTimingInfo timing;
	struct utimbuf shim_buf;
	long ret;

	/* Get the target path */
	timed_dmp_shim_strncpy_sync(shim_path, dmp_path, PATH_MAX, NULL);
	SHIM_LOG("@%ld.%d: utime(%s)\n", EVTIME(event), shim_path);

	/* Is this path deterministic? */
	if (!isdetpath(shim_path, &timing)) {
		SHIM_LOG(" ... path:%s is not deterministic\n", shim_path);
		return false;
	}

	/* Get a local copy of the utimbuf */
	timed_dmp_shim_memcpy_sync(&shim_buf, dmp_buf, sizeof(shim_buf), FROM_DMP, NULL);

	/* Perform the syscall */
	start_io_op(timing.generic);
	ret = utime(shim_path, &shim_buf);
	finish_io_op(timing.generic);

	/* Give the result back to the DMP task */
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_utimes(shim_event *event)
{
	char           *dmp_path =           (char *)shim_syscall_arg0(&event->regs);
	struct timeval *dmp_buf  = (struct timeval *)shim_syscall_arg1(&event->regs);
	
	char shim_path[PATH_MAX];
	FileTimingInfo timing;
	struct timeval shim_buf[2];
	long ret;

	/* Get the target path */
	timed_dmp_shim_strncpy_sync(shim_path, dmp_path, PATH_MAX, NULL);
	SHIM_LOG("@%ld.%d: utimes(%s)\n", EVTIME(event), shim_path);

	/* Is this path deterministic? */
	if (!isdetpath(shim_path, &timing)) {
		SHIM_LOG(" ... path:%s is not deterministic\n", shim_path);
		return false;
	}

	/* Get a local copy of the utimbuf */
	timed_dmp_shim_memcpy_sync(&shim_buf, dmp_buf, sizeof(shim_buf), FROM_DMP, NULL);

	/* Perform the syscall */
	start_io_op(timing.generic);
	ret = utimes(shim_path, shim_buf);
	finish_io_op(timing.generic);

	/* Give the result back to the DMP task */
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}
	
void BasicShim::do_fs_chdir(shim_event* event)
{
	char pathname[PATH_MAX];
	unsigned long arg0 = shim_syscall_arg0(&event->regs);
	unsigned long ret = shim_syscall_return(&event->regs);

	if (timed_dmp_shim_strncpy_sync((void*)pathname, (void*)arg0, sizeof pathname, NULL) != 0) {
		SHIM_PERROR("dmp_shim_strcpy");
		return;
	}

	if (strnlen(pathname, PATH_MAX) >= PATH_MAX-1) {
		fprintf(stderr, "PATH_MAX too big? %ld\n", (long)PATH_MAX);
	}

	SHIM_LOG("@%ld.%d: chdir(%s) (ret:%ld)\n", EVTIME(event), pathname, ret);

	// Update if the syscall succeeded.
	if (ret == 0) {
		*_cwd = join_paths(*_cwd, pathname);
	}
}


} /* namespace DMP */
