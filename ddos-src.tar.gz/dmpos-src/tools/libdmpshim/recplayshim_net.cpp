#include <string.h>
#include <stdio.h>
#include <errno.h>

#include "dmpshim.h"
#include "recplayshim_gen.h"
#include "recplayshim_net.h"

#if 0 /* Template */
/**
 * __RECPLAY(fn) --> void recplay_fn(RecPlayShim *shim, shim_event *event, ShimMode mode, void *arg) 
 */
	if (mode == SHIM_RECORD) {

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
#endif

/**
 * GENERAL WARNING:
 *
 *   Some of the network functions *that we reexecute during replay* are
 *   blocking. When we reexecute these functions during replay for distributed
 *   systems, we must make sure that if the call happened in a single logical
 *   time during record, the same happens during replay (i.e., if the function
 *   didn't block during record, it can't block during replay).  Thus, we must
 *   emulate these blocking functions in the shim to enforce this behavior.
 */

/******************************************************************************
 *                               Misc. helpers                                *
 ******************************************************************************/
static void mark_fd_as_det(RecPlayShim *shim, int fd)
{
	PFileDescriptor tmp = shim->_fdtable->get(fd);
	if (tmp != NULL)
		SHIM_WARN("Overwriting FDT entry for fd:%d type:%d\n", fd, tmp->type);

	tmp = PFileDescriptor(new FileDescriptor);
	tmp->type = FDT_REP_SOCK;
	tmp->shadowfd = -1;
	shim->_fdtable->add(fd, tmp);
}

/******************************************************************************
 *                             Socket management                              *
 ******************************************************************************/
/**
 * int socket(int domain, int type, int proto) --
 *
 *   Create a new socket for communication. We create the underlying kernel socket
 *   in both record and replay modes, since we do not know yet whether or not the 
 *   socket will be used to connect to a deterministic host. If it does, we need
 *   the socket even in replay.
 *
 *   During record:
 *       This is called once sys_socket() returns. The socket fd is in rax.
 *
 *   During replay:
 *       Need to hook after sys_socket() returns. Make sure the fd is the same.
 */
__RECPLAY(socket)
{
	const long recstr[] = { RET, END };
	int fd;
	long ret;

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		SHIM_LOG("socket() called; allowing to reexecute\n");

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		shim->read_buffer((char *)&ret, sizeof(ret));
		fd = shim_syscall_return(&event->regs);

		if (fd != ret)
			SHIM_WARN("socket() result mismatch (now:%d, log:%ld)\n", fd, ret);

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}

/**
 * int socketpair(int d, int type, int proto, int sp_out[2]) --
 *
 *   Create a connected pair of sockets. TODO: This doesn't mark the fds as
 *   det yet, but it should.
 *
 *   Record:
 *       Record the return value (fds should be deterministic); because these
 *       sockets are connected and can only be used within this DPG, they are
 *       always deterministic.
 *
 *   Replay:
 *       Reexecute the call if it was successful during record and mark the
 *       resulting fds as determinsitic.
 */
__RECPLAY(socketpair)
{
	const long recstr[] = { RET, END };
	int fds[2];
	long ret;
	int *dmp_fds = (int *)shim_syscall_arg3(&event->regs);
	rechdr_t *rechdr = (rechdr_t *)arg;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {
		record_str(shim, event, recstr);
	
	} else /* SHIM_REPLAY */ {
		assert(rechdr->reclen == sizeof(ret));
		shim->read_buffer((char *)&ret, sizeof(ret));

		/* In the error case, just replay return value */
		if (ret < 0) {
			SHIM_LOG("Error case during record; just replaying\n");
			dmp_shim_emulate_syscall(ret, &event->regs);
			return;
		}

		/* Otherwise, dupe a null fd */
		fds[0] = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0 /* TODO */);
		fds[1] = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0 /* TODO */);
		if (fds[0] < 0 || fds[1] < 0) {
			SHIM_ERR("Couldn't dup fds\n");
			abort();
		}

		SHIM_LOG("Duped nullfd to dmp fds %d and %d\n", fds[0], fds[1]);

		SHIM_LOG("Copying fds to dmp task\n");
		shim->timed_dmp_shim_memcpy_sync(fds, dmp_fds, sizeof(fds), TO_DMP, NULL);

		dmp_shim_emulate_syscall(ret, &event->regs);
	}
}

/**
 * int bind(int fd, struct sockaddr *addr, socklen_t len) --
 *
 *   Binds a socket to an address.
 *
 *   Record:
 *       If addr is a non-det address, then record the result of the bind.
 *       If addr is a det address, record the result of the bind and add
 *           the given fd to the fd table (so we can identify it as a
 *           deterministic fd in the future, type FDT_REP_SOCK)
 *
 *   Replay:
 *       If addr is a non-det address, emulate the call using the log
 *       If addr is a det address, re-execute the bind call and ensure
 *           the result matches what is in the log; add an FDT_REP_SOCK
 *           entry to the fd table
 */
__RECPLAY(bind)
{
	const long recstr[] = { RET, END };

	int dmpfd                = shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpaddr = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	socklen_t dmplen         = (socklen_t)shim_syscall_arg2(&event->regs);
	struct sockaddr_in shim_sin;
	uint16_t shim_port = 0;
	long ret, thisret;

	if (mode == SHIM_RECORD) {
		/* Check to see if we're binding to a deterministic port */
		if (dmpaddr && dmplen == sizeof shim_sin) {
			shim->timed_dmp_shim_memcpy_sync(&shim_sin, dmpaddr, dmplen, FROM_DMP, NULL);
			shim_port = ntohs(shim_sin.sin_port);
			if (shim_sin.sin_family == AF_INET && shim->isdetport(shim_port)) {
				/* Binding to a deterministic port; mark the given FD as determinsitic */
				SHIM_LOG("Binding to a deterministic port... marking fd:%d as det\n", dmpfd);
				mark_fd_as_det(shim, dmpfd);
			}
		}

		record_str(shim, event, recstr);

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		/*
		 * We need to re-execute the bind for det sockets, but not for
		 * non-det sockets.
		 */

		/* Check to see if we're binding to a deterministic port */
		if (dmpaddr && dmplen == sizeof shim_sin) {
			shim->timed_dmp_shim_memcpy_sync(&shim_sin, dmpaddr, dmplen, FROM_DMP, NULL);
			shim_port = ntohs(shim_sin.sin_port);
			if (shim_sin.sin_family == AF_INET && shim->isdetport(shim_port)) {
				SHIM_LOG("Binding to a deterministic port... allowing to re-execute\n");
				mark_fd_as_det(shim, dmpfd);
			} else {
				SHIM_LOG("Non-IP address or non-det port; replaying\n");
				shim->read_buffer((char *)&ret, sizeof (ret));
				dmp_shim_emulate_syscall(ret, &event->regs);
			}

		} else {
			SHIM_LOG("No address given; replaying\n");
			shim->read_buffer((char *)&ret, sizeof (ret));
			dmp_shim_emulate_syscall(ret, &event->regs);
		}
	
	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		shim->read_buffer((char *)&ret, sizeof (ret));
		thisret = shim_syscall_return(&event->regs);
		SHIM_LOG("Got log:%ld reg:%ld\n", ret, thisret);

		if (thisret != ret) {
			SHIM_WARN("Return during record %ld, during replay %ld\n",
				ret, thisret);
			SHIM_WARN("Using replay value\n");
		}
	
	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}

/**
 * int listen(int fd, int backlog) --
 *
 *   Begin listening on the given socket
 *
 *   Record:
 *       If fd is nondet, begin listening on the socket and record the result
 *           in the log
 *       If fd is det, begin listening on the socket record the result in the
 *           log
 *
 *   Replay:
 *       If fd is nondet, simply replay the result from the log (don't need to
 *           reexecute the call because we will replay all of the connections
 *           on this socket as well)
 *       If fd is det, we need to reexecute the listen call, and make sure we
 *           got the same result as during replay. Det connections will be
 *           reexecuted on this socket.
 */
__RECPLAY(listen)
{
	const long recstr[] = { RET, END };
	long dmpfd = shim_syscall_arg0(&event->regs);
	long thisret, ret;
	PFileDescriptor pfd = shim->_fdtable->get(dmpfd);

	SHIM_LOG("listen(fd:%d, ...)\n", (int)dmpfd);

	if (mode == SHIM_RECORD) {
		ret = shim_syscall_return(&event->regs);
		SHIM_LOG(" ... recording ret %ld\n", ret);
		record_str(shim, event, recstr);

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		if (pfd) {
			if (pfd->type != FDT_REP_SOCK)
				SHIM_WARN("Calling listen on non rep sock: %d\n", pfd->type);

			SHIM_LOG("This is a deterministic socket; allowing listen to continue\n");

		} else {
			shim->read_buffer((char *)&ret, sizeof ret);
			SHIM_LOG("This is not a deterministic socket; replaying res:%d from log\n", ret);
			dmp_shim_emulate_syscall(ret, &event->regs);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		shim->read_buffer((char *)&ret, sizeof ret);
		thisret = shim_syscall_return(&event->regs);
		SHIM_LOG("Read result %ld from log (thisret:%ld)\n", ret, thisret);

		if (thisret != ret)
			SHIM_WARN("Return values differ!\n");

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}


__RECPLAY(getsockname)
{
	const long sasz = sizeof(struct sockaddr);
	const long slsz = sizeof(socklen_t);

	const long recstr[] = { RET,
	                        ARG1, PTR, IMMLONG, sasz,
	                        ARG2, PTR, IMMLONG, slsz,
	                        END };
	
	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}


__RECPLAY(getsockopt)
{
	long thisret;
	const long slsz = sizeof(socklen_t);
	socklen_t *dmp_optlen = (socklen_t *)shim_syscall_arg4(&event->regs);
	socklen_t shim_len;
	rechdr_t *rechdr = NULL;

	SHIM_WARN("Untested\n");

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);
		if (thisret < 0) {
			SHIM_LOG("Error case during record; recording return value only");
			const long recstr[] = { RET, END };

			record_str(shim, event, recstr);
			return;
		}

		/*
		 * The length of the returned option is pointed to by optlen. We need
		 * to first read that value before we can record the syscall.
		 */
		shim->timed_dmp_shim_memcpy_sync(&shim_len, dmp_optlen, slsz, FROM_DMP, NULL);

		const long recstr[] = { RET,
					ARG3, PTR, IMMLONG, shim_len,
					ARG4, PTR, IMMLONG, slsz,
					END };

		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		rechdr = (rechdr_t *)arg;

		assert(rechdr->reclen >= sizeof(thisret));
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		if (rechdr->reclen > sizeof(thisret)) {
			void *dmp_optval = (void *)shim_syscall_arg3(&event->regs);
			shim_len = rechdr->reclen - sizeof(thisret);
			char buffer[shim_len];

			shim->read_buffer(buffer, shim_len);
			shim->timed_dmp_shim_memcpy_sync(buffer, dmp_optval, shim_len, TO_DMP, NULL);
			shim->timed_dmp_shim_memcpy_sync((char *)&shim_len, dmp_optlen, sizeof(shim_len), TO_DMP, NULL);

		} else {
			SHIM_LOG("Error case during record; replaying just the return value\n");
		}

		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}


/**
 * int setsockopt(int s, int level, int optname, void *optval,
 *                socklen_t optlen) --
 *
 *   Set options on a socket.
 *
 *   TODO: This hasn't been checked carefully. For non-det sockets, the return
 *       value is recorded and replayed. For det sockets, the function is
 *       reexecuted. No other checking is performed.
 */
__RECPLAY(setsockopt)
{
	const long recst[] = { RET, END };
	int dmpfd = shim_syscall_arg0(&event->regs);
	long logret, thisret;

	PFileDescriptor pfd = shim->_fdtable->get(dmpfd);

	if (mode == SHIM_RECORD) {
		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			SHIM_LOG("det sock\n");
		} else {
			SHIM_LOG("non-det sock\n");
		}

		record_str(shim, event, recst);

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			SHIM_LOG("det sock: reexecuting\n");
		} else {
			SHIM_LOG("non-det sock: replaying...\n");
			shim->read_buffer((char *)&logret, sizeof logret);
			dmp_shim_emulate_syscall(logret, &event->regs);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			shim->read_buffer((char *)&logret, sizeof logret);
			thisret = shim_syscall_return(&event->regs);
			if (thisret != logret) 
				SHIM_WARN("Return values differ: this:%ld log:%ld\n", thisret, logret);
			else
				SHIM_LOG(" ... ret %ld\n", thisret);
		} else {
			SHIM_WARN("non-det sock: shouldn't have gotten here\n");
		}

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}


/******************************************************************************
 *                            Socket communication                            *
 ******************************************************************************/
/**
 * int select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
 *            struct timeval *timeout) --
 *
 *   Select sockets ready for reading, writing, or that have pending
 *   exceptions. select simply queries the status of sockets; there are no
 *   side-effects.
 *
 *   Record:
 *       Record the contents of the output sets.
 *
 *   Replay:
 *   	Replay the contents of the output sets.
 */
__RECPLAY(select)
{
	const long fdsetsz  = sizeof(fd_set);
	const long tvsz     = sizeof(struct timeval);
	const long recstr[] =  { RET,
	                         ARG1, PTR, IMMLONG, fdsetsz,
	                         ARG2, PTR, IMMLONG, fdsetsz,
	                         ARG3, PTR, IMMLONG, fdsetsz,
	                         ARG4, PTR, IMMLONG, tvsz,
				 END };

	if (mode == SHIM_RECORD)
		record_str(shim, event, recstr);
	else
		replay_str(shim, event, recstr);
}

/**
 * ssize_t sendto(int fd, const void *buf, size_t len, int flags, struct
 *                sockaddr *to, socklen_t tolen) --
 *
 *   Send a message on a socket.
 *
 *   N.B. We *must* emulate this call in the shim. See the GENERAL WARNING at
 *        the top of this page for an explanation.
 *
 *   Record:
 *       If fd is non-det, log the result
 *       If fd is det, log the result
 *
 *   Replay:
 *       If fd is non-det, replay the result
 *       If fd is det, re-execute the send, ensuring the same number of bytes
 *           are sent as during the record phase
 */
__RECPLAY(sendto)
{
	int dmpfd              = (int)shim_syscall_arg0(&event->regs);
	void *dmpbuf           = (void *)shim_syscall_arg1(&event->regs);
	size_t dmplen          = (size_t)shim_syscall_arg2(&event->regs);
	int dmpflags           = (int)shim_syscall_arg3(&event->regs);
	struct sockaddr *dmpsa = (struct sockaddr *)shim_syscall_arg4(&event->regs);
	socklen_t dmpsalen     = (socklen_t)shim_syscall_arg5(&event->regs);

	const long recstr[] = { RET, END };
	int tmpfd;
	long ret, thisret, logret, nbytes;
	PFileDescriptor pfd;

	if (dmpsa != NULL && dmpsalen != sizeof(struct sockaddr_in))
		SHIM_WARN("Only TCP/IP connections are supported.\n");

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);
		SHIM_LOG("send(%d, ...) returned %d\n", dmpfd, thisret);
		record_str(shim, event, recstr);

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {
		pfd = shim->_fdtable->get(dmpfd);
		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			SHIM_LOG("This is a deterministic socket\n");
			SHIM_LOG("Emulating the send on behalf of caller.\n");

			SHIM_LOG("Resizing temporary buffer to %d bytes\n", dmplen);
			shim->_tmp_buffer.resize(dmplen);

			SHIM_LOG("Copying buffer from dmp task\n");
			shim->timed_dmp_shim_memcpy_sync(&shim->_tmp_buffer[0], dmpbuf, dmplen, FROM_DMP, &nbytes);
			SHIM_LOG(" ... grabbed %ld bytes\n", nbytes);

			SHIM_LOG("Dup'ing the fd to the shim\n");
			tmpfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
			SHIM_LOG(" ... got new fd %d\n", tmpfd);

			if (tmpfd >= 0) {
				SHIM_LOG("Sending the %d bytes\n", dmplen);
				nbytes = writen(tmpfd, &shim->_tmp_buffer[0], dmplen);
				SHIM_LOG(" ... sent %ld\n", nbytes);

			} else {
				SHIM_ERR("Couldn't dup fd; data not being sent\n");
			}

			/* TODO: Maybe we should save this for the future... */
			SHIM_LOG("Closing shim's dup\n");
			close(tmpfd);

			shim->read_buffer((char *)&logret, sizeof logret);
			if (logret != nbytes)
				SHIM_WARN("Ret mismatch this:%ld log:%ld\n", nbytes, logret);

			SHIM_LOG("Emulating result\n");
			dmp_shim_emulate_syscall(nbytes, &event->regs);

		} else {
			SHIM_LOG("Non-det socket, replaying result\n");
			replay_str(shim, event, recstr);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		SHIM_WARN("Why did we get a leave event on replay?\n");

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}

/**
 * ssize_t recvfrom(int fd, void *buf, size_t len, int flags,
 *                  struct sockaddr *from, socklen_t *fromlen) --
 *
 *   Receive some data from a socket.
 *
 *   N.B. We *must* emulate this call in the shim. See the GENERAL WARNING at
 *        the top of this page for an explanation.
 *
 *   Record:
 *       If fd is non-det record return value and contents of message
 *       If fd is det,    record return value only
 *
 *   Replay:
 *       If fd is non-det, replay return value and conents of message
 *       If fd is det,     reexecute the recv
 */
__RECPLAY(recvfrom)
{
	int dmpfd = (int)shim_syscall_arg0(&event->regs);
	void *dmpbuf = (void *)shim_syscall_arg1(&event->regs);
	
	int shimfd;
	long thisret, logret, nbytes;
	PFileDescriptor pfd = shim->_fdtable->get(dmpfd);

	const long sasz = sizeof(struct sockaddr);
	const long slsz = sizeof(socklen_t);
	const long recstr_det[] = { RET, END };
	const long recstr_nondet[] = { RET,
	                               ARG1, PTR, RET,
	                               ARG4, PTR, IMMLONG, sasz,
	                               ARG5, PTR, IMMLONG, slsz,
	                               END };
	
	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);
		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			SHIM_LOG("Receiving on a det socket; record return value %d only\n", thisret);
			record_str(shim, event, recstr_det);

		} else {
			SHIM_LOG("Non-det socket; recording return %d and data\n", thisret);
			record_str(shim, event, recstr_nondet);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_ENTER) {

		if (pfd != NULL && pfd->type == FDT_REP_SOCK) {
			SHIM_LOG("Recive on a det socket; emulating the call\n");

			SHIM_LOG("Reading nbytes from log\n");
			shim->read_buffer((char *)&logret, sizeof logret);

			if (logret < 0) {
				SHIM_LOG("Error-case during record, not doing anything else\n");
				dmp_shim_emulate_syscall(logret, &event->regs);
				return;
			}

			SHIM_LOG("Allocating space for recv...\n");
			shim->_tmp_buffer.resize(logret);

			SHIM_LOG("Dup'ing the dmpfd:%d\n", dmpfd);
			shimfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
	
			SHIM_LOG("Receiving %ld bytes of data...\n", logret);
			readn(shimfd, &shim->_tmp_buffer[0], logret);

			SHIM_LOG("First 10 bytes of data...\n");
			for (int i = 0; i < 10; i++) {
				char c = (i < shim->_tmp_buffer.size() ? shim->_tmp_buffer[i] : '$');
				SHIM_LOG_CONT("%c (%x) ", c, c);
			}

			SHIM_LOG("Copying data back to dmp thread...\n");
			shim->timed_dmp_shim_memcpy_sync(&shim->_tmp_buffer[0], dmpbuf, logret, TO_DMP, &nbytes);
			SHIM_LOG(" ... wrote %ld bytes.\n", nbytes);

			if (nbytes != logret)
				SHIM_WARN("Return value mismatch; this:%ld log:%ld\n", nbytes, logret);

			dmp_shim_emulate_syscall(nbytes, &event->regs);

			SHIM_LOG("Closing shim's dup'ed fd\n");
			close(shimfd);

		} else {
			SHIM_LOG("Receive on a non-det socket; replaying ret and contents\n");
			replay_str(shim, event, recstr_nondet);
		}

	} else if (event->event_type == DMP_SHIM_SYSCALL_LEAVE) {
		SHIM_WARN("Leave event on det recv replay?\n");

	} else {
		SHIM_ERR("Weird: mode %d, event %d\n", mode, event->event_type);
		abort();
	}
}


/**
 * recvmsg(int sockfd, struct msghdr *msg, int flags) --
 *
 *   TODO: Reduce from HACK^2 to HACK. For instance, factor out the iov stuff and
 *     share it with readmsg.
 */
__RECPLAY(recvmsg)
{
	const long     syscallnr  = event->regs.orig_rax;
	struct msghdr *dmp_msghdr = (struct msghdr *)shim_syscall_arg1(&event->regs);
	
	long thisret, reclen = sizeof(thisret);
	struct msghdr shim_msghdr;
	char buffer[4096];
	char *tmpbuf;

	unsigned int i;
	size_t sofar, left, last;

	struct iovec *dmp_curiov, shim_curiov;
	rechdr_t *rechdr = (rechdr_t *)arg;

	SHIM_WARN("Not updated for det sockets\n");

	if (dmp_msghdr) {
		SHIM_LOG("Non-NULL msghdr provided; reading in to local shim msghdr\n");
		shim->timed_dmp_shim_memcpy_sync(&shim_msghdr, dmp_msghdr, sizeof(shim_msghdr), FROM_DMP, NULL);
	}

	if (mode == SHIM_RECORD) {
		thisret = shim_syscall_return(&event->regs);

		if (thisret > 0) {
			reclen += thisret;

			/* Get a copy of the msghdr struct from the DMP task */
			if (dmp_msghdr) {
				reclen += sizeof(shim_msghdr.msg_namelen) + shim_msghdr.msg_namelen;
				reclen += sizeof(shim_msghdr.msg_controllen) + shim_msghdr.msg_controllen;
				reclen += sizeof(shim_msghdr.msg_flags);
			}
		}

		add_record(shim, event->logical_time, LOG_SYSCALL, syscallnr, reclen);
		shim->append_buffer((char *)&thisret, sizeof(thisret));

		if (dmp_msghdr) {
			SHIM_LOG("Getting name from dmp msghdr...\n");
			shim->append_buffer((char *)&shim_msghdr.msg_namelen, sizeof(shim_msghdr.msg_namelen));
			assert(shim_msghdr.msg_namelen < sizeof(buffer));
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_msghdr.msg_name, shim_msghdr.msg_namelen, FROM_DMP, NULL);
			shim->append_buffer(buffer, shim_msghdr.msg_namelen);

			SHIM_LOG("Getting control from dmp msghdr...\n");
			shim->append_buffer((char *)&shim_msghdr.msg_controllen, sizeof(shim_msghdr.msg_controllen));
			assert(shim_msghdr.msg_controllen < sizeof(buffer));
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_msghdr.msg_control, shim_msghdr.msg_controllen, FROM_DMP, NULL);
			shim->append_buffer(buffer, shim_msghdr.msg_controllen);

			SHIM_LOG("Getting flags from dmp msghdr...\n");
			shim->append_buffer((char *)&shim_msghdr.msg_flags, sizeof(shim_msghdr.msg_flags));
		}

	} else /* SHIM_REPLAY */ {
		assert(rechdr->reclen >= sizeof(thisret));
		shim->read_buffer((char *)&thisret, sizeof(thisret));

		SHIM_LOG("Got recorded return value of %ld\n", thisret);

		if (thisret > 0 && dmp_msghdr) {
			SHIM_LOG("Reading namelen...\n");
			shim->read_buffer((char *)&shim_msghdr.msg_namelen, sizeof(shim_msghdr.msg_namelen));
			SHIM_LOG(" ... got %d\n", shim_msghdr.msg_namelen);
			assert(shim_msghdr.msg_namelen < sizeof(buffer));
			SHIM_LOG("Reading name...\n");
			shim->read_buffer(buffer, shim_msghdr.msg_namelen);
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_msghdr.msg_name, shim_msghdr.msg_namelen, TO_DMP, NULL);
			SHIM_LOG(" ... done.\n");

			SHIM_LOG("Reading controllen...\n");
			shim->read_buffer((char *)&shim_msghdr.msg_controllen, sizeof(shim_msghdr.msg_controllen));
			SHIM_LOG(" ... got %ld\n", shim_msghdr.msg_controllen);
			assert(shim_msghdr.msg_controllen < sizeof(buffer));
			SHIM_LOG("Reading control...\n");
			shim->read_buffer(buffer, shim_msghdr.msg_controllen);
			shim->timed_dmp_shim_memcpy_sync(buffer, shim_msghdr.msg_control, shim_msghdr.msg_controllen, TO_DMP, NULL);
			SHIM_LOG(" ... done.\n");

			SHIM_LOG("Reading msg flags...\n");
			shim->read_buffer((char *)&shim_msghdr.msg_flags, sizeof(shim_msghdr.msg_flags));
			shim->timed_dmp_shim_memcpy_sync(&shim_msghdr.msg_flags, &dmp_msghdr->msg_flags, sizeof(shim_msghdr.msg_flags), TO_DMP, NULL);
			SHIM_LOG(" ... done\n");
		}
	}

	if (thisret > 0) {
		left = thisret;

		dmp_curiov = shim_msghdr.msg_iov;

		/* Copy or append the contents from or to the log */
		for (i = 0, sofar = 0; i < shim_msghdr.msg_iovlen && left > 0; i++) {

			/* Get the next iovec from the DMP task */
			shim->timed_dmp_shim_memcpy_sync(&shim_curiov, dmp_curiov, sizeof(struct iovec), FROM_DMP, NULL);
			dmp_curiov++;

			/* Determine number of bytes from this iovec to read */
			last = MIN(left, shim_curiov.iov_len);
			if (mode == SHIM_RECORD) {
				SHIM_LOG("Appending %ld bytes of %ld from iov[%d]; %ld to go\n",
					last, shim_curiov.iov_len, i, left);
			}

			/* Copy those bytes */
			if (last < sizeof(buffer))
				tmpbuf = buffer;
			else
				tmpbuf = new char[last];

			if (mode == SHIM_RECORD) {
				shim->timed_dmp_shim_memcpy_sync(tmpbuf, shim_curiov.iov_base, last, FROM_DMP, NULL);
				shim->append_buffer(buffer, last);

			} else /* SHIM_REPLAY */ {
				shim->read_buffer(tmpbuf, last);
				shim->timed_dmp_shim_memcpy_sync(tmpbuf, shim_curiov.iov_base, last, TO_DMP, NULL);
			}

			if (last >= sizeof(buffer))
				delete [] tmpbuf;

			sofar += last;
			left  -= last;
		}
	}

	if (mode == SHIM_REPLAY)
		dmp_shim_emulate_syscall(thisret, &event->regs);
}

/******************************************************************************
 *                           Connection management                            *
 ******************************************************************************/
/**
 * int accept(int fd, struct sockaddr *addr, socklen_t *sz) --
 *
 *   Accept a connection on a socket.
 *
 *   TODO: If the caller doesn't pass in a sockaddr, the address isn't written
 *         to the log. In det replay, this means we cannot check to make sure
 *         the same address connected. We should fix this, so it always records
 *         the address of the remote.
 *
 *   N.B. We *must* emulate this call in the shim. See the GENERAL WARNING at
 *        the top of this page for an explanation.
 *
 *   Record:
 *       Execute the accept and record the result in the log; the result
 *           includes the return value as well as the contents of the addr struct
 *           and sz on return.
 *
 *   Replay:
 *       For non-det sockets, replay the result and contents of addr and sz
 *            from the log.
 *       For det sockets, need to reexecute the accept.
 *            TODO: Must ensure we see the same accept order as record.
 */
__RECPLAY(accept)
{
	int              dmpfd = (int)shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpsa = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	socklen_t       *dmpsz = (socklen_t *)shim_syscall_arg2(&event->regs);
	const long sasz = sizeof(struct sockaddr);
	const long slsz = sizeof(socklen_t);
	long ret, thisret;

	PFileDescriptor pfd = shim->_fdtable->get(dmpfd);
	struct sockaddr logsa, thissa;
	struct sockaddr_in *logsin, *thissin;
	socklen_t loglen, thislen;

	int shimfd, shimnewfd;
	struct sockaddr_in shimsin;
	socklen_t shimlen;

	const long recstr[] = { RET,
	                        ARG1, PTR, IMMLONG, sasz,
	                        ARG2, PTR, IMMLONG, slsz,
	                        END };

	SHIM_LOG("accept(%d, ...)\n", dmpfd);

	if (mode == SHIM_RECORD) {
		SHIM_LOG("Recording results to log\n");
		record_str(shim, event, recstr);

		thisret = shim_syscall_return(&event->regs);
		if (pfd && pfd->type == FDT_REP_SOCK && thisret >= 0) {
			SHIM_LOG("New connection on a deterministic socket; adding %ld to fd table\n", thisret);
			mark_fd_as_det(shim, thisret);
		}

	} else /* REPLAY */ {
		if (!pfd) {
			SHIM_LOG("Non-det socket; replaying\n");
			
			/* Log the data returned by the system call */
			SHIM_LOG("Replaying arguments...\n");
			replay_str(shim, event, recstr);
			ret = event->regs.rcx;

			/* If a new fd was created, dup it into the dmp task */
			SHIM_LOG("Creating new fd...\n");
			if (ret > 0) {
				int fd = dmp_shim_dupfd(shim->get_nullfd(), TO_DMP, 0);
				if (fd < 0) {
					SHIM_ERR("Couldn't dup fd\n");
					abort();
				}

				SHIM_LOG("Duped nullfd to dmp fd %d\n", fd);
			} else {
				SHIM_LOG("Error case; no new fd to create\n");
			}

		} else {
			SHIM_LOG("This is a det socket; emulating the call\n");

			if (pfd->type != FDT_REP_SOCK)
				SHIM_WARN("accept() on non-rep-sock?\n");

			SHIM_LOG("Reading return from log...\n");
			shim->read_buffer((char *)&ret, sizeof ret);
			SHIM_LOG(" ... got %ld\n", ret);
			
			/*
			 * TODO: Enforce some ordering on the accepts...
			 */

			if (dmpsa) {
				SHIM_LOG("Reading address from log...\n");
				shim->read_buffer((char *)&logsa,  sasz);
				logsin = (struct sockaddr_in *)&logsa;
				SHIM_LOG("Getting address from DMP task...\n");
				shim->timed_dmp_shim_memcpy_sync(&thissa, dmpsa, sasz, FROM_DMP, NULL);
				thissin = (struct sockaddr_in *)&thissa;
			}

			if (dmpsz) {
				SHIM_LOG("Reading len from log...\n");
				shim->read_buffer((char *)&loglen, slsz);
				SHIM_LOG("Getting len from DMP task...\n");
				shim->timed_dmp_shim_memcpy_sync(&thislen, dmpsz, slsz, FROM_DMP, NULL);
			}

			if (ret < 0) {
				SHIM_LOG("Error-case during record... nothing to do\n");
				dmp_shim_emulate_syscall(ret, &event->regs);
				return;
			}

			/*
			 * The accept() call succeeded in the record phase. Need to execute
			 * the accept on behalf of the caller now.
			 */
			shimfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
			if (shimfd < 0) {
				SHIM_ERR("Couldn't dup fd for accept!\n");
				dmp_shim_emulate_syscall(-EFAULT, &event->regs);
				return;
			}

			SHIM_LOG("Waiting for a connection on new fd:%d\n", shimfd);
			shimlen = sizeof shimsin;
			shimnewfd = accept(shimfd, (struct sockaddr *)&shimsin, &shimlen);
			if (shimnewfd >= 0) {
				SHIM_LOG("Duping new fd:%d to dmp task\n", shimnewfd);
				thisret = dmp_shim_dupfd(shimnewfd, TO_DMP, 0);
			}
			
			if (thisret != ret)
				SHIM_WARN("Return code mismatch this:%ld log:%ld\n", thisret, ret);

			/* TODO: Keep this socket around? */
			close(shimfd);

			/*
			 * The return value, if successful, is a new socket. This new
			 * fd needs to be marked as a determinsitic socket.
			 */
			SHIM_LOG("New connection on a determinsitic socket; adding %ld to fd table\n", shimnewfd);
			mark_fd_as_det(shim, thisret);
			dmp_shim_emulate_syscall(thisret, &event->regs);
		}
	}
}

/**
 * int connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen) --
 *
 *   Connect to the given address.
 *
 *   N.B. We *must* emulate this call in the shim. See the GENERAL WARNING at
 *        the top of this page for an explanation.
 *
 *   Record:
 *       Record the result for both det and non-det sockets. If the addr is a det
 *           addr, we need to mark the fd as a det fd.
 *
 *   Replay:
 *       If the given address is non-det, replay the result from the log.
 *       If the given address is det, re-execute the connection and mark the fd
 *           as a det fd.
 */
__RECPLAY(connect)
{
	int              dmpfd  = shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpsa  = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	socklen_t        dmplen = shim_syscall_arg2(&event->regs);

	int shimfd;
	struct sockaddr shimsa;
	struct sockaddr_in *shimsin;

	uint32_t addr;
	uint16_t port;
	long nbytes, logret, thisret;
	int cnt;

	const long recstr[] = { RET, END };
		
	SHIM_LOG("Getting copy of sockaddr...\n");
	shim->timed_dmp_shim_memcpy_sync(&shimsa, dmpsa, sizeof shimsa, FROM_DMP, &nbytes);
	shimsin = (struct sockaddr_in *)&shimsa;
	SHIM_LOG(" ... got %d bytes\n", nbytes);

	addr = ntohl(shimsin->sin_addr.s_addr);
	port = ntohs(shimsin->sin_port);

	if (mode == SHIM_RECORD) {
		long thisret = shim_syscall_return(&event->regs);
		SHIM_LOG("connect(...) -> %ld\n", thisret);

		if (shimsin->sin_family == AF_INET && shim->isdetaddr(addr, port) != NULL) {
			SHIM_LOG("Connected to a det addr. Marking fd:%d as det\n", dmpfd);
			mark_fd_as_det(shim, dmpfd);
			PFileDescriptor pfd = shim->_fdtable->get(dmpfd);
			SHIM_LOG("shim:%p, shim->_fdtable:%p dmpfd:%d shim->_fdtable->get(%d):%p\n",
				shim, shim->_fdtable.get(), dmpfd, dmpfd, pfd.get())
			if (pfd == NULL) {
				SHIM_WARN("Why didn't it work?\n");
			} else {
				SHIM_LOG("Its there!\n");
			}
		}

		record_str(shim, event, recstr);

	} else /* SHIM_REPLAY */ {
		addr = ntohl(shimsin->sin_addr.s_addr);
		port = ntohs(shimsin->sin_port);

		shim->read_buffer((char *)&logret, sizeof logret);

		/*
		 * Handle some corner cases
		 */
		if (logret < 0) {
			SHIM_LOG("Error case during record... replaying from log\n");
			dmp_shim_emulate_syscall(logret, &event->regs);
			return;

		} else if (shimsin->sin_family != AF_INET) {
			SHIM_WARN("Non-IP address not supported; replaying\n");
			dmp_shim_emulate_syscall(logret, &event->regs);
			return;

		} else if (shim->isdetaddr(addr, port) == NULL) {
			SHIM_LOG("Non-det address... replaying\n");
			dmp_shim_emulate_syscall(logret, &event->regs);
			return;
		}

		/*
		 * Handle the det case
		 */
		SHIM_LOG("%x:%d is a det address; emulating the connect\n", addr, port);
		
		SHIM_LOG("Marking fd:%d as det\n", dmpfd);
		mark_fd_as_det(shim, dmpfd);

		SHIM_LOG("Duping dmpfd:%d to shim task\n", dmpfd);
		shimfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);

		int retry_ms = 1 * 1000;
		for (cnt = 0; cnt < 16; cnt++) {
			SHIM_LOG("Calling connect (attempt %d/16)...\n", cnt+1);
			thisret = connect(shimfd, &shimsa, dmplen);

			if (thisret < 0) {
				SHIM_LOG(" ... Error: %s\n", strerror(errno));
				SHIM_LOG(" ... Sleeping %dms for retry\n", retry_ms/1000);
				usleep(retry_ms);

				if (retry_ms < 1000 * 1000)
					retry_ms *= 2;
			} else {
				break;
			}
		}

		/* TODO: Keep fd around? */
		close(shimfd);
		
		if (thisret != logret)
			SHIM_WARN("Return mismatch: this:%ld log:%ld\n", thisret, logret);

		SHIM_LOG("Returning %ld to the caller\n", thisret);
		dmp_shim_emulate_syscall(thisret, &event->regs);
	}
}
