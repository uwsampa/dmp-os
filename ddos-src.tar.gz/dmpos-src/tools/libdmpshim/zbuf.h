#ifndef _ZBUF_H_
#define _ZBUF_H_

/******************************************************************************
 *                                                                            *
 * NOTE: This hasn't been thoroughly tested. Reading from compressed streams  *
 *   (at least) is broken; writing to compressed streams appears to work. Use *
 *   at your own risk.                                                        *
 *                                                                            *
 ******************************************************************************/

#include <zlib.h>

#define ZCHUNK     (256 * 1024) /* 256KB, per zlib recommendation */

#define ZCOMPRESS   0
#define ZDECOMPRESS 1

typedef struct {
	int fd;
	int mode;

	unsigned char inbuf[ZCHUNK];
	int inlen;
	int inavail;

	unsigned char outbuf[ZCHUNK];
	int outlen;
	int outavail;

	z_stream strm;
} ZBuf;

int  zbufinit(ZBuf *zbuf, int fd, int mode);
void zbufdestroy(ZBuf *zbuf);

int zwriten(ZBuf *zbuf, char *buf, int n);
int zreadn(ZBuf *zbuf, char *buf, int n);
int zbufflush(ZBuf *zbuf, int flush);

#endif /* _ZBUF_H_ */
