/**
 * basicshim_detnet.cpp --
 *
 *   This file implements the various functions neccessary for implementing
 *   deterministic network services in the shim.
 */
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <linux/netdevice.h>
#include <poll.h>

#include "dmp.h"
#include "basicshim.h"

/**
 * These values define status codes passed from peer nodes to the master node
 * at the end of distributed quanta
 */
#define DISTQ_OK         0 /* Normal:  I have more work to do */
#define DISTQ_EXITING    1 /* Exiting: I'm requesting permission to leave the DDPG */
#define DISTQ_MAX_STATUS 2 /* keep last */

/**
 * The control connections between the DPGs are message-oriented; these values
 * define the types of messages that can be passed.
 */
#define CMT_ENDQ     1 /* Indicates the end of a distributed quantum */
#define CMT_CONNREQ  2 /* Connection request to deterministic socket */
#define CMT_CONNRESP 3 /* Indicates a connection request was accepted */
#define CMT_DATA     4 /* Data passed along a determistic socket */
#define CMT_EXITACK  5 /* Acking an exit request */
#define CMT_FDCLOSE    6 /* Sent when a node closes a deterministic socket */

struct ControlMsg {
	uint32_t msgtype;  /* See the CMT_* values */
	union {
		struct {
			/* For CMT_ENDQ */
			uint64_t distq_num;
			uint32_t status;
		} endq;
		struct {
			/* For CMT_CONNREQ */
			uint16_t to_port;
			uint16_t from_port;
		} connreq;
		struct {
			/* For CMT_CONNRESP */
			uint8_t  result;    /* Boolean success value */
			uint16_t from_port; /* Connector's port */
			uint16_t to_port;   /* Acceptor's port */
		} connresp;
		struct {
			/* For CMT_DATA */
			uint16_t to_port;
			uint64_t nbytes;
			/* Following this field is the actual data */
		} data;
		struct {
			/* For CMT_FDCLOSE */
			uint16_t port;
		} fdclose;
	};
};

namespace DMP {

/*
 * This counter is the number of active dmp threads in box; defined in
 * basicshim.cpp
 */
extern uint32_t nrunning; 

/*
 * Keeps track of what distributed quantum we're in.  This is only updated by
 * the last thread to reach the global barrier in handle_distq_barrier or the
 * last thread to exit (and thereby kill) the DPG. Ergo, no locking.
 */
uint64_t current_distq = 0;

static uint32_t        distq_waiting_count = 0;
static pthread_mutex_t distq_lock         = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  distq_waiting_cond = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  distq_ready_cond   = PTHREAD_COND_INITIALIZER;

/**
 * uint32_to_ip(addr) --
 *
 *   Given a 32-bit integer representing an ip address in host-byte order,
 *   return a NULL-terminated string containing the IP address in dotted
 *   decimal notation.
 *
 *   Note:
 *       The pointer returned is to statically allocated data; not thread-safe
 *       in general.
 *
 *   Parameters:
 *       addr  -- 32-bit integer representing ip address in host-byte order
 *
 *   Returns:
 *       Pointer to NULL-terminated string containing ip address in dotted
 *       decimal notation
 */
static char *uint32_to_ip(uint32_t addr)
{
	static char straddr[32];

	snprintf(straddr, sizeof straddr, "%d.%d.%d.%d", (addr >> 24) & 0xff, (addr >> 16) &
		0xff, (addr >> 8) & 0xff, addr & 0xff);

	return &straddr[0];
}

static char *status_to_str(int status, char *buf, int sz)
{
	/* Make sure these are orderd the same as the DISTQ_ constants above */
	static char *strings[DISTQ_MAX_STATUS] = {
		(char *)"OK", (char *)"EXITING",
	};

	static int numstrs = sizeof(strings) / sizeof(strings[0]);

	if (status < 0 || status >= numstrs)
		snprintf(buf, sz, "<UNKNOWN>");
	else	
		snprintf(buf, sz, "%s", strings[status]);
	
	return buf;
}

static int dreadn(int fd, char *buf, int n)
{
	int ret;

	ret = readn(fd, buf, n);
	if (ret != n) {
		SHIM_ERR("Short read: got %d, expected %d\n", ret, n);
		SHIM_ERR("   Reason: %s\n", strerror(errno));
		abort();
	}

	return ret;
}

#define POLLSTR(events, buffer, len, left, str) \
	do { \
		if ((events) & (str)) { \
			strncat((buffer), #str " ", (left)); \
			(left) = (len) - strlen(buffer); \
		} \
	} while(0)

static char *polltostr(short events, char *buffer, int len)
{
	int left = len;

	if (!buffer || len <= 0)
		return (char *)"<INVAL>";

	buffer[0] = '\0';

	POLLSTR(events, buffer, len, left, POLLIN);
	POLLSTR(events, buffer, len, left, POLLPRI);
	POLLSTR(events, buffer, len, left, POLLOUT);
	POLLSTR(events, buffer, len, left, POLLRDHUP);
	POLLSTR(events, buffer, len, left, POLLERR);
	POLLSTR(events, buffer, len, left, POLLHUP);
	POLLSTR(events, buffer, len, left, POLLNVAL);

	return buffer;
}


/**
 * compare_incoming(lhs, rhs) --
 *
 *   Give a total ordering to IncomingConns.
 */
static bool compare_incoming(const PIncomingConn &lhs, const PIncomingConn &rhs)
{
	return lhs->connection_time < rhs->connection_time ||
	       lhs->peerid          < rhs->peerid          ||
	       lhs->remote_port     < rhs->remote_port;
}


/******************************************************************************/
/*                      Control Channel Helper Functions                      */
/******************************************************************************/
/**
 * cc_send_data(peer, port, nbytes, data) --
 *   
 *   Send nbytes of data beginning at data to the given DDPG peer and port.
 */
static int cc_send_data(PDNode peer, int port, int nbytes, char *data)
{
	uint32_t cc_cmd   = CMT_DATA;
	uint16_t cc_port  = port;
	uint64_t cc_bytes = nbytes;

	SHIM_LOG("Sending %ld bytes of data to peer:%d, port:%d\n", cc_bytes, peer->nodeid, cc_port);
	pthread_mutex_lock(&peer->ctrlfd_lock);
	writen(peer->ctrlfd, (char *)&cc_cmd,   sizeof cc_cmd);
	writen(peer->ctrlfd, (char *)&cc_port,  sizeof cc_port);
	writen(peer->ctrlfd, (char *)&cc_bytes, sizeof cc_bytes);
	writen(peer->ctrlfd, data, cc_bytes);
	pthread_mutex_unlock(&peer->ctrlfd_lock);
	SHIM_LOG("Done.\n");

	return cc_bytes;
}

/**
 * cc_send_connreq(peer, toport, fromport) --
 *
 *   Send a CONNREQ message to port toport on peer, from fromport on the local
 *   host.
 */
static int cc_send_connreq(PDNode peer, uint16_t toport, uint16_t fromport)
{
	uint32_t cmd = CMT_CONNREQ;

	SHIM_LOG("Sending request to connect to port %d on node %d from port " \
			"%d\n", toport, peer->nodeid, fromport);

	pthread_mutex_lock(&peer->ctrlfd_lock);
	writen(peer->ctrlfd, (char *)&cmd,      sizeof cmd);
	writen(peer->ctrlfd, (char *)&toport,   sizeof toport);
	writen(peer->ctrlfd, (char *)&fromport, sizeof fromport);
	pthread_mutex_unlock(&peer->ctrlfd_lock);	

	return 0;
}

/**
 * cc_send_connresp(peer, result, remote_port, local_port) --
 *
 *   Send a CONNRESP message to the given node with the provided result value
 */ 
static int cc_send_connresp(PDNode peer, uint8_t cc_result,
	uint16_t cc_remote_port, uint16_t cc_local_port)
{
	uint32_t cc_cmd = CMT_CONNRESP;

	SHIM_LOG("Sending peer:%d:%d connresp:%d from local port:%d\n", peer->nodeid,
		cc_remote_port, cc_result, cc_local_port);

	pthread_mutex_lock(&peer->ctrlfd_lock);
	writen(peer->ctrlfd, (char *)&cc_cmd,         sizeof cc_cmd);
	writen(peer->ctrlfd, (char *)&cc_result,      sizeof cc_result);
	writen(peer->ctrlfd, (char *)&cc_remote_port, sizeof cc_remote_port);
	writen(peer->ctrlfd, (char *)&cc_local_port,  sizeof cc_local_port);
	pthread_mutex_unlock(&peer->ctrlfd_lock);

	return 0;
}

/**
 * cc_send_endq(peer, distq, status) --
 *
 *   Send and ENDQ message for quantum distq to the provided peer.
 */
static int cc_send_endq(PDNode peer, uint64_t distq, uint32_t status)
{
	uint32_t cmd = CMT_ENDQ;

	SHIM_LOG("Node sending: (ENDQ (%d), %ld, %d) to node %d\n",
			cmd, distq, status, peer->nodeid);

	pthread_mutex_lock(&peer->ctrlfd_lock);
	writen(peer->ctrlfd, (char *)&cmd,    sizeof cmd);
	writen(peer->ctrlfd, (char *)&distq,  sizeof distq);
	writen(peer->ctrlfd, (char *)&status, sizeof status);
	pthread_mutex_unlock(&peer->ctrlfd_lock);

	return 0;
}

/**
 * cc_send_fdclose(peer, remote_port) --
 *
 *   Send a FDCLOSE message to the remote peer to let them know the we have
 *   closed the connection to the socket attached to the given virtual port.
 */
static int cc_send_fdclose(PDNode peer, uint16_t remote_port)
{
	uint32_t cmd = CMT_FDCLOSE;

	SHIM_LOG("Node sending: (FDCLOSE (%d), %d) to node %d\n",
		cmd, remote_port, peer->nodeid);

	pthread_mutex_lock(&peer->ctrlfd_lock);
	writen(peer->ctrlfd, (char *)&cmd,         sizeof cmd);
	writen(peer->ctrlfd, (char *)&remote_port, sizeof remote_port);
	pthread_mutex_unlock(&peer->ctrlfd_lock);

	return 0;
}

/**
 * ControlManagerFn --
 * 
 *   Each DPG spans a new ControlManager thread for each of their control
 *   channels. This function should receive data from its control channel,
 *   parse it, and "do the right thing" with respect to the shim's state. For
 *   example, if a new CMT_DATA message comes in, this function should receive
 *   the data, and place it in the appropriate pending queue for the shim to
 *   later read from in do_sock_recv.
 *
 *   This function is a friend of the BasicShim class, and can thus touch its
 *   privates... yeah, they're pretty close.
 */
struct ControlManagerArgs {
	BasicShim *shim;    /* Shim this thread belongs to */
	int        peerid;  /* Nodeid of the peer node */
	int        ctrlfd;  /* The control fd this thread should listen to */
};

void *ControlManagerFn(void *_args)
{
	/* Unpack our arguments */
	ControlManagerArgs *args = (ControlManagerArgs *)_args;
	BasicShim *shim = args->shim;
	uint32_t peerid = args->peerid;
	int ctrlfd      = args->ctrlfd;
	bool done = false;
	ControlMsg msg;
	char __unused buf[32];
	char *tempdata;
	PDNode peer = shim->DetNodes->get(peerid);
	PVSockMap vsockmap = shim->VSocks;
	PVSock vsock;
	int peerfd = -1;

	if (peerid == shim->node_id) {
		SHIM_LOG("Control manager for myself!\n");
		peerfd = peer->ctrlfd2;
	} else {
		SHIM_LOG("Control manager for somebody else\n");
		peerfd = peer->ctrlfd;
	}

	/* We've got the args now; don't need the container */
	delete args;

	SHIM_LOG("New ControlManager thread created for node:%d, peer:%d, fd:%d\n", shim->node_id, peerid, ctrlfd);
	while (!done) {

		//SHIM_LOG("Waiting for a new message...\n");
		int ret = readn(ctrlfd, (char *)&msg.msgtype, sizeof msg.msgtype);
		if (ret == 0) {
			SHIM_LOG("Node %d closed their control connection\n", peer->nodeid);
			if (!peer->exiting)
				SHIM_ERR("Killing manager when node isn't exiting?\n");

			done = true;
			continue;

		} else if (ret < 0) {
			SHIM_WARN("Bad read; aborting\n");
			break;
		}

		switch(msg.msgtype) {
		case CMT_ENDQ:
			/* Read the message */
			
			dreadn(ctrlfd, (char *)(&msg.endq.distq_num), sizeof(msg.endq.distq_num));
			dreadn(ctrlfd, (char *)(&msg.endq.status), sizeof(msg.endq.status));
			
			SHIM_LOG("ENDQ for node %d, %s @%lu\n", peerid,
				status_to_str(msg.endq.status, buf, sizeof buf),
				msg.endq.distq_num);

			if (msg.endq.status == DISTQ_EXITING) {
				SHIM_LOG("Remote node %d is exiting; setting done (@0x%p)\n",
				         peerid,  &peer->exiting);
				peer->exiting = true;
			}

			/* Need to update the last_known_quantum */
			pthread_mutex_lock(&peer->quantum_lock);
			peer->last_known_quantum = msg.endq.distq_num;
			pthread_cond_broadcast(&peer->quantum_cv);
			pthread_mutex_unlock(&peer->quantum_lock);
			break;

		case CMT_CONNREQ:
			SHIM_LOG("CMT_CONNREQ from %d\n", peerid);

			SHIM_LOG("Getting rest of message\n");
			dreadn(ctrlfd, (char *)&msg.connreq.to_port,   sizeof msg.connreq.to_port);
			dreadn(ctrlfd, (char *)&msg.connreq.from_port, sizeof msg.connreq.from_port);

			/* Add a new entry to the IncomingConns list */
			SHIM_LOG("Connection request to port %d from node %d:%d\n",
				msg.connreq.to_port, peerid, msg.connreq.from_port);

			vsockmap->lock();
			vsock = vsockmap->get(msg.connreq.to_port);
			vsockmap->unlock();

			if (vsock == NULL || (vsock->state & VS_LISTENING) == 0) {
				SHIM_LOG("There is not a listening vsock at port %d\n", msg.connreq.to_port);

				uint8_t resp = 0;
				uint32_t cmd = CMT_CONNRESP;
				uint16_t ac  = msg.connreq.to_port;

				pthread_mutex_lock(&peer->ctrlfd_lock);
				writen(peer->ctrlfd, (char *)&cmd, sizeof cmd);
				writen(peer->ctrlfd, (char *)&resp, sizeof resp);
				writen(peer->ctrlfd, (char *)&msg.connreq.from_port, sizeof msg.connreq.from_port);
				writen(peer->ctrlfd, (char *)&ac, sizeof ac); /* Not used */
				pthread_mutex_unlock(&peer->ctrlfd_lock);

			} else {
				SHIM_LOG("Vsock found for port %d\n", msg.connreq.to_port);
				
				SHIM_LOG("Creating new connection at time GLT %ld\n", peer->last_known_quantum);
				PIncomingConn newconn(new IncomingConn);
				newconn->connection_time = peer->last_known_quantum;
				newconn->peerid = peerid;
				newconn->remote_port = msg.connreq.from_port;

				/*
				 * Put the new incoming request in its place in the queue. We
				 * maintain sorted order to help accept determine if it needs
				 * to wait for a distq barrier.
				 */
				SHIM_LOG("Appending to incoming queue\n");
				vsock->lock();
				vsock->incoming_connections.push_back(newconn);
				vsock->incoming_connections.sort(compare_incoming);

				SHIM_LOG("Current list of incoming connections:\n");
				IncomingConnList::iterator i;
				int cnt;
				for (cnt = 0, i = vsock->incoming_connections.begin(); i != vsock->incoming_connections.end(); i++, cnt++) {
					PIncomingConn conn = *i;
					SHIM_LOG("   [%d] @%ld from %d:%d\n", cnt, conn->connection_time, conn->peerid, conn->remote_port);
				}

				vsock->unlock();

				SHIM_LOG("Done\n");
			}
			break;

		case CMT_CONNRESP:
			SHIM_LOG("CMT_CONNRESP from %d\n", peerid);

			/* Get the entire response message from the remote node */
			SHIM_LOG("Getting rest of response\n");
			dreadn(ctrlfd, (char *)&msg.connresp.result,    sizeof msg.connresp.result);
			dreadn(ctrlfd, (char *)&msg.connresp.from_port, sizeof msg.connresp.from_port);
			dreadn(ctrlfd, (char *)&msg.connresp.to_port,   sizeof msg.connresp.to_port);
			SHIM_LOG(" ... done (CMT_CONNRESP, result:%d, fp:%d, tp:%d).\n",
				msg.connresp.result, msg.connresp.from_port, msg.connresp.to_port);

			/* Look up the pending connection */
			vsockmap->lock();
			vsock = vsockmap->get(msg.connresp.from_port);
			vsockmap->unlock();

			if (vsock == NULL) {
				SHIM_WARN("Received a CONNRESP for an unknown connection!\n");
				break;
			}

			/* Update the result */
			vsock->lock();

			vsock->pending_connect_req.conn_result = msg.connresp.result;
			vsock->remote_port                     = msg.connresp.to_port;

			if (msg.connresp.result) {
				SHIM_LOG("Connection accepted\n");
				vsock->state = VS_CONNECTED;

			} else {
				SHIM_LOG("Connection refused\n");
				vsock->state = VS_CLOSED;
				SHIM_LOG("   Removing port %d from vsockmap\n", msg.connresp.from_port);
				vsockmap->lock();
				vsockmap->erase(vsockmap->find(msg.connresp.from_port));
				vsockmap->unlock();
			}

			vsock->unlock();

			break;

		case CMT_DATA:
			SHIM_LOG("CMT_DATA from %d\n", peerid);

			/* Get the entire data message from the remote node */
			SHIM_LOG("Getting rest of data\n");
			dreadn(ctrlfd, (char *)&msg.data.to_port, sizeof msg.data.to_port);
			dreadn(ctrlfd, (char *)&msg.data.nbytes,  sizeof msg.data.nbytes);

			SHIM_LOG("Waiting for %ld bytes to arrive on vport:%d\n", msg.data.nbytes, msg.data.to_port);
			tempdata = (char *)malloc(msg.data.nbytes);
			if (tempdata == NULL) {
				SHIM_ERR("Can't allocate temporary buffer for data!\n");
				abort();
			}
			dreadn(ctrlfd, tempdata, msg.data.nbytes);

			/* Look up the control socket */
			SHIM_LOG("Looking up slotted buffer for dmpfd %d\n", msg.data.to_port);
			vsockmap->lock();
			vsock = vsockmap->get(msg.data.to_port);
			vsockmap->unlock();
			if (vsock == NULL) {
				SHIM_WARN("Received data for unknown socket %d\n", msg.data.to_port);
				free(tempdata);
				break;
			}

			SHIM_LOG("Adding data to file descriptor for GLT %ld\n", peer->last_known_quantum);
			vsock->lock();
			if (vsock->data.append(peer->last_known_quantum, tempdata, msg.data.nbytes) < 0)
				SHIM_WARN("Couldn't add data!\n");
			vsock->unlock();

			free(tempdata);
			break;

		case CMT_FDCLOSE:
			SHIM_LOG("CMT_FDCLOSE from %d\n", peerid);
			
			/* Get the entire data message from the remote node */
			SHIM_LOG("Getting rest of data\n");
			dreadn(ctrlfd, (char *)&msg.fdclose.port, sizeof msg.fdclose.port);

			SHIM_LOG("Remote connection closed on port %d\n", msg.fdclose.port);
			vsockmap->lock();
			vsock = vsockmap->get(msg.fdclose.port);
			vsockmap->unlock();
			if (vsock == NULL) {
				SHIM_WARN("Connection closed on non-existant socket (port:%d)\n",
					msg.fdclose.port);
				break;
			}

			/**
			 * TODO: Before we mark this connection as closed, we need to make sure *all* references
			 * to this socket are closed. For instance, if a process opens a connection and forks, closing
			 * the socket in one of the resulting processes, we can't mark the socket as closed until the
			 * second process closes it as well. Reference counting should fix this, but I'm too lazy.
			 * 
			 * For now, just pretend like it never closes...
			 */
			#if 0
			vsock->lock();
			vsock->state = VS_CLOSED;
			vsock->unlock();
			#endif
			break;

		default:
			SHIM_ERR("Unrecognized shim control message type: %d\n", msg.msgtype);
			abort();
		};
	}

	SHIM_LOG("Manager for node %d exiting\n", peer->nodeid);
	return NULL;
}

/**
 * isdetport(port) --
 *
 *   Returns TRUE iff the given port is listed as a deterministic port for this
 *   shim.
 */
bool BasicShim::isdetport(uint16_t port)
{
	bool res = false;
	PDNode me = (*DetNodes)[node_id];

	SHIM_LOG("Checking if %d is a deterministic port...\n", port);
	SHIM_LOG("My node id: %d\n", node_id);

	res = (me->ports.find(port) != me->ports.end());
	SHIM_LOG("Port %d %sfound in portset\n", port, res ? "" : "not ");
	return res;
}

/**
 * isdetaddr(addr, port) --
 *
 *   Returns a pointer to the DNode representing the given address and port,
 *   if they are deterministic. Otherwise, returns NULL.
 *
 *   Parameters:
 *       address -- Address of remote host, in host-byte order
 *       port    -- Port of remote host, in host-byte order
 *
 *   Returns:
 *       NULL if not deterinistic; otherwise, returns the iterator to
 *       the node that is listening on that port
 */
PDNode BasicShim::isdetaddr(uint32_t address, uint16_t port)
{
	DNodeMap::const_iterator node_i;
	PortSet::const_iterator  port_i;
	PDNode me = DetNodes->get(node_id);

	const uint32_t LOCAL1 = 0x0;
	const uint32_t LOCAL2 = 0x7f000001;
	const uint32_t LOCAL3 = 0x7f000101;

	SHIM_LOG("Searching for %s:%d in the DetNodes list\n", uint32_to_ip(address), port);
	SHIM_LOG("  LOCAL1: %s\n", uint32_to_ip(LOCAL1));
	SHIM_LOG("  LOCAL2: %s\n", uint32_to_ip(LOCAL2));
	SHIM_LOG("  LOCAL3: %s\n", uint32_to_ip(LOCAL3));
	SHIM_LOG("      ME: %s\n", me ? uint32_to_ip(me->address) : "<no me>");

	/*
	 * Iterate over all det nodes; there may be more than one remote dpg
	 * with the same address.
	 */
	for (node_i = DetNodes->begin(); node_i != DetNodes->end(); ++node_i) {
		SHIM_LOG("Checking node %d, address %s\n", node_i->second->nodeid, uint32_to_ip(node_i->second->address));
		if (node_i->second->address == address ||
		   (me && node_i->second->address == me->address &&
		   	(address == LOCAL1 || address == LOCAL2 || address == LOCAL3))) {

			/*
			 * See if this port is included in the deterministic port list
			 */
			port_i = node_i->second->ports.find(port);
			if (port_i != node_i->second->ports.end())
				break;
		}
	}

	if (node_i != DetNodes->end())
		return node_i->second;
	else
		return PDNode();
}

/**
 * do_sock_socket(event) --
 *
 *   At socket creation, we do not yet know whether or not the socket is going
 *   to be used for a deterministic or non-deterministic network connection.
 *   There is nothing we can do at this point; we simply allow the socket
 *   creation to be passed through to the OS.
 */
bool BasicShim::do_sock_socket(shim_event *event)
{
	int __unused dmpdomain   = shim_syscall_arg0(&event->regs);
	int __unused dmptype     = shim_syscall_arg1(&event->regs);
	int __unused dmpprotocol = shim_syscall_arg2(&event->regs);

	SHIM_LOG("@%ld.%d: socket(...) ...\n", EVTIME(event));
	SHIM_LOG("    Socket family: %d (%s)\n", dmpdomain, (dmpdomain == AF_UNIX    ? "AF_UNIX" :
	                                                     dmpdomain == AF_INET    ? "AF_INET" :
							     dmpdomain == AF_INET6   ? "AF_INET6" :
							     dmpdomain == AF_IPX     ? "AF_IPX" : 
							     dmpdomain == AF_NETLINK ? "AF_NETLINK" :
							     dmpdomain == AF_X25     ? "AF_X25" :
							     "UNKNOWN"));

	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	return false;
}

/**
 * do_sock_bind(event) --
 *
 *   The bind syscall ties a socket to a specific port. Because we virtualize
 *   deterministic ports, binds to these ports are not passed to the OS.
 *   Also, we add fds bound to determistic ports to the shim's fd table.
 */
bool BasicShim::do_sock_bind(shim_event *event) 
{
	const int        dmpfd = (int)shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpsa = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	const socklen_t  dmpsz = (socklen_t)shim_syscall_arg2(&event->regs);

	uint16_t port;
	struct sockaddr_in shimsin;
	long ret;
	int shimfd;
	PortSet::const_iterator idx;

	PDNode me = DetNodes->get(node_id);
	assert(me != NULL);

	SHIM_LOG("@%ld.%d: bind(fd:%d, ...) ...\n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/* Get a copy of the sockaddr */
	if (dmpsz > sizeof shimsin) {
		SHIM_LOG("Address size bigger than _in; ignoring\n");
		return false;
	}

	SHIM_LOG("Copying %d/%ld bytes of the address structure...\n", dmpsz, sizeof shimsin);
	timed_dmp_shim_memcpy_sync(&shimsin, dmpsa, dmpsz, FROM_DMP, NULL);

	/* Make sure its what we expect it to be */
	if (shimsin.sin_family != AF_INET) {
		SHIM_LOG("Non-IP address; ignoring\n");
		return false;
	}

	/* See if the socket is being bound to a determinstic port */
	port = ntohs(shimsin.sin_port);
	SHIM_LOG("Looking up port %d in my portset...\n", port);
	idx = me->ports.find(port);
	if (idx == me->ports.end()) {
		SHIM_LOG("  ... port %d not found; ignoring\n", port);
		return false;
	}
	SHIM_LOG("  ... port %d found!\n", port);

	/* Have the shim bind the port on behalf of the caller */
	SHIM_LOG("Duping the DMP socket to the shim...\n");
	shimfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
	SHIM_LOG("   ... got fd:%d\n", shimfd);
	assert(shimfd >= 0);
 
 	ret = bind(shimfd, (struct sockaddr *)&shimsin, sizeof shimsin);
	if (ret < 0) {
		SHIM_LOG("Couldn't bind the socket: %s\n", strerror(errno));
		dmp_shim_emulate_syscall(-errno, &event->regs);
		return true;
	}
		
	SHIM_LOG("Successfully bound the socket!\n");

	/* Create an entry in the fdtable */
	PFileDescriptor newfd(new FileDescriptor);
	newfd->shadowfd = -1;
	newfd->type = FDT_SOCKET;
	newfd->port = port;

	/* Create a new entry in the VSockMap */
	SHIM_LOG("Creating a new Vsock\n");
	PVSock vsock(new VirtualSocket);
	vsock->state = VS_BOUND;

	if (VSocks->find(port) != VSocks->end()) {
		SHIM_ERR("Another vsock already bound to port %d?\n", port);
		SHIM_ERR("Continuing anyway!\n");
	}

	SHIM_LOG("Adding new vsock to VSocks\n");
	VSocks->lock();
	VSocks->set(port, vsock);
	VSocks->unlock();

	SHIM_LOG("Add new fd:%d to the fdtable\n", dmpfd);
	_fdtable->add(dmpfd, newfd);

	/* Emulate and return */
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

/**
 * do_sock_listen(event) --
 *
 *   Because deterministic network connections are performed on top of a
 *   network overlay, we simply need to mark the given fd as "listening" in the
 *   file descriptor table; if the fd is non-deterministic, we pass it to the
 *   OS.
 */
bool BasicShim::do_sock_listen(shim_event *event)
{
	int             dmpfd = shim_syscall_arg0(&event->regs);
	PFileDescriptor filep = _fdtable->get(dmpfd);
	PVSock vsock;

	SHIM_LOG("@%ld.%d: listen(%d, ...) ...\n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}
	
	/* See if we care about this fd */
	if (filep == NULL) {
		SHIM_LOG("This is not a deterministic file descriptor\n");
		return false;

	} else if (filep->type != FDT_SOCKET) {
		SHIM_LOG("Calling listen on a non-socket?\n");
		dmp_shim_emulate_syscall(-ENOTSOCK, &event->regs);
		return true;
	}

	VSocks->lock();
	vsock = VSocks->get(filep->port);
	VSocks->unlock();
	if (!vsock) {
		SHIM_ERR("Couldn't find a vsock at the given port!\n");
		return false;
	}

	/* We now know this is a socket */
	SHIM_LOG("Marking dmpfd:%d as listening\n", dmpfd);
	vsock->lock();
	if (vsock->state & VS_LISTENING)
		SHIM_LOG("dmpfd:%d is already listening?\n", dmpfd);

	vsock->state |= VS_LISTENING;
	vsock->unlock();

	/* Emulate and return */
	dmp_shim_emulate_syscall(0, &event->regs);

	return true;
}

/**
 * do_sock_accept(event) --
 *
 *   Accept a connection from a listening deterministic socket. Care must be
 *   taken to ensure the accepted connection is deterministically chosen.
 *
 *   The incoming connection list is sorted each time an accept request is
 *   made.
 */
bool BasicShim::do_sock_accept(shim_event *event)
{
	int dmpfd                = shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpaddr = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	socklen_t *dmplen        = (socklen_t *)shim_syscall_arg2(&event->regs);
	PVSock vsock, newSock;

	PFileDescriptor filep = _fdtable->get(dmpfd);
	PFileDescriptor newfd;
	PIncomingConn newconn;
	PVSock newsock;
	PDNode peer;
	int newdmpfd;

	SHIM_LOG("@%ld.%d: accept(%d, ...) ...\n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/*
	 * Perform some sanity checks; this socket must be a deterministic fd of
	 * type FDT_SOCKET
	 */
	{
		/* Some sanity checks */
		if (filep == NULL) {
			SHIM_LOG("dmpfd:%d is non-det; ignoring\n", dmpfd);
			return false;
		}

		if (filep->type != FDT_SOCKET) {
			SHIM_LOG("Calling accept on non-socket\n");
			dmp_shim_emulate_syscall(-ENOTSOCK, &event->regs);
			return true;
		}
	}

	/* Make sure the request is sensible */
	VSocks->lock();
	vsock = VSocks->get(filep->port);
	VSocks->unlock();
	if (!vsock || (vsock->state & VS_LISTENING) == 0) {
		SHIM_LOG("Calling accept on a non-listening socket!\n");
		dmp_shim_emulate_syscall(-EINVAL, &event->regs);
		return true;
	}

	/*
	 * Check to see if we need to wait for the next distq barrier. If we already
	 * have a pending request that came in at a time earlier than our current
	 * logical time, we do not need to wait. The list is maintained in sorted 
	 * order in ControlManagerFn.
	 */
	{
		/* Wait for global barrier if we don't have an earlier connection request */

		uint32_t pending_conns;
		uint64_t first_time;
		bool     done = false;

		WaitFor->safe_set(); /* This is a promiscuous operation; need to wait for everyone */
		acceptWaitTime.start();
		wait_for_distq_barrier();
		acceptWaitTime.stop();

		vsock->lock();
		while (!done) {

			/* Look at the first incoming request */
			pending_conns =  vsock->incoming_connections.size();
			first_time    = (pending_conns ? vsock->incoming_connections.front()->connection_time : -1);

			/* 
			 * To make sure all DPGs that are going to make a connection request
			 * this quantum have had a chance to make that request, calling accept
			 * is an implicit distributed barrier
			 */
			if (first_time == -1 || first_time >= current_distq-1) {
				if (first_time == -1) {
					SHIM_LOG("No incoming connection requests; waiting...\n");
				} else {
					SHIM_LOG("First connection request is in the future (at GLT %ld, now GLT %ld)\n", first_time, current_distq);
				}

				vsock->unlock();
				WaitFor->safe_set(); /* This is a promiscuous operation; need to wait for everyone */
				acceptWaitTime.start();
				wait_for_distq_barrier();
				acceptWaitTime.stop();

				SHIM_LOG("End of distq reached; continuing...\n");
				vsock->lock();

				if (filep->nonblocking) {
					SHIM_LOG("This is a non-blocking fd; returning\n");
					done = true;
				}
		
				continue;
			}

			SHIM_LOG("First connection request is at time GLT %ld (current distq GLT %ld)\n", first_time, current_distq);
			done = true;
		}

		if (first_time == -1 || first_time >= current_distq) {
			SHIM_LOG("Not returning any connections (first_time GLT %ld)\n", first_time);
			newconn = PIncomingConn();

		} else {
			SHIM_LOG("Found one. Snagging the first in the list...\n");
			newconn = vsock->incoming_connections.front();
			vsock->incoming_connections.pop_front();
		}

		vsock->unlock();
	}

#if 0
	/*
	 * Wait for an incoming connection request, looping if necessary. Only one
	 * attempt is made if the socket is nonblocking. newconn is set to point
	 * to the new connection, or NULL if the socket is nonblocking and no
	 * connections were available.
	 */
	{
		/* Grab the first available connection, waiting if necessary. */
		bool done = false;
		while (!done) {
			SHIM_LOG("Checking for incoming connections...\n");
			vsock->lock();
			while (vsock->incoming_connections.size() == 0) {
				vsock->unlock();
				SHIM_LOG("  ... None. Waiting\n");
			
				if (filep->nonblocking) {
					SHIM_LOG("This is a non-blocking fd; returning\n");
					done = true;
					break;
				}
		
				WaitFor->safe_set(); /* This is a promiscuous operation; need to wait for everyone */
				wait_for_distq_barrier();
				SHIM_LOG("  ...  Trying again...\n");
				vsock->lock();
			}

			if (vsock->incoming_connections.size() > 0) {
				SHIM_LOG("Found one. Snagging the first in the list...\n");
				newconn = vsock->incoming_connections.front();
				vsock->incoming_connections.pop_front();

			} else {
				newconn = PIncomingConn();
			}
			
			vsock->unlock();
		}
	}
#endif

	if (newconn == NULL) {
		SHIM_LOG("No connection available\n");
		dmp_shim_emulate_syscall(-EAGAIN, &event->regs);
		return true;
	}

	SHIM_LOG("Got: connection from node %d:%d, to port %d, at time %ld\n",
			newconn->peerid, newconn->remote_port, filep->port,
			newconn->connection_time);

	/*
	 * Dupe this new fd in to the caller's file descriptor table
	 */
	{
		newdmpfd = dmp_shim_dupfd(nullfd, TO_DMP, 0);
		if (newdmpfd < 0) {
			SHIM_LOG("Couldn't dup the dummy!\n");
			abort();
		}

		SHIM_LOG("Dummy fd duped to dmpfd:%d\n", newdmpfd);
	}

	/*
	 * Add this new fd to the file descriptor table
	 */
	{
		newsock.reset(new VirtualSocket);
		assert(newsock != NULL);
		newsock->state = VS_CONNECTED;
		
		newfd.reset(new FileDescriptor);
		assert(newfd != NULL);
		newfd->type = FDT_SOCKET;
		newfd->timing.open = 25;
		newfd->timing.close = 25;
		newfd->timing.read = 25;
		newfd->timing.write = 25;
		newfd->timing.generic = 25;
		newfd->peerid = newconn->peerid;
		newsock->remote_port = newconn->remote_port;
		
		assert(DetNodes != NULL);
		peer = DetNodes->get(newfd->peerid);
		if (peer == NULL) {
			SHIM_WARN("Invalid peer?\n");
			return false;
		}
		
		newfd->family = AF_INET;
		newfd->addr = peer->address;
		VSocks->lock();
		newfd->port = VSocks->getNewPort();
		if (VSocks->get(newfd->port) != NULL)
			SHIM_ERR("Overwriting old vsock for port %d!\n", newfd->port);
		VSocks->set(newfd->port, newsock);
		VSocks->unlock();
		
		_fdtable->add(newdmpfd, newfd);
	}
	
	/*
	 * Let the remote node know that its the lucky winner this round
	 */
	SHIM_LOG("Letting the remote node know it's a winner...\n");
	cc_send_connresp(peer, 1, newconn->remote_port, newfd->port);

	/*
	 * If the caller requested the address of the new connection be returned, 
	 * we need to manufacture a structure and copy it back to the caller's
	 * address space.
	 */
	{
		/* Create and copy the new connections address back to the caller */
		struct sockaddr_in accepted_addr;
		socklen_t len = sizeof accepted_addr;

		if (dmpaddr) {
			memset(&accepted_addr, 0, sizeof accepted_addr);
			accepted_addr.sin_family      = AF_INET;     /* This is the only family supported so far */
			accepted_addr.sin_port        = htons(newsock->remote_port);
			accepted_addr.sin_addr.s_addr = htonl(newfd->addr);

			timed_dmp_shim_memcpy_sync((void *)&accepted_addr, (void *)dmpaddr, sizeof accepted_addr, TO_DMP, NULL);
		}

		if (dmplen)
			timed_dmp_shim_memcpy_sync((void *)&len, (void *)dmplen, sizeof len, TO_DMP, NULL);
	}

	dmp_shim_emulate_syscall(newdmpfd, &event->regs);
	return true;

}

bool BasicShim::do_sock_connect(shim_event *event)
{
	const long       dmpfd = shim_syscall_arg0(&event->regs);
	struct sockaddr *dmpsa = (struct sockaddr *)shim_syscall_arg1(&event->regs);
	const socklen_t  dmpsz = shim_syscall_arg2(&event->regs);
	struct sockaddr_in shimsin;
	uint32_t addr;
	uint16_t port, newport;
	PDNode peer;
	PFileDescriptor filp;
	PVSock vsock;
	PendingConn pconn;

	SHIM_LOG("@%ld.%d: connect(%ld, ...) ...\n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}
	
	/* Get the address */
	if (dmpsa == NULL) {
		SHIM_LOG("address not valid (%p, len:%d (sin: %ld))\n", dmpsa, dmpsz, sizeof shimsin);
		return false;
	}
	
	/*
	 * This is a valid socket; continue with the connection
	 */
	SHIM_LOG("Grabbing the sockaddr from the det thread\n");
	timed_dmp_shim_memcpy_sync(&shimsin, dmpsa, sizeof shimsin.sin_family, FROM_DMP, NULL);
	SHIM_LOG(" ... family: %d (%s)\n", shimsin.sin_family,
		(shimsin.sin_family == AF_UNIX  ? "AF_UNIX"  :
		 shimsin.sin_family == AF_LOCAL ? "AF_LOCAL" :
		 shimsin.sin_family == AF_INET  ? "AF_INET"  :
		 shimsin.sin_family == AF_INET6 ? "AF_INET6"  : "UNKNOWN"));

	if (dmpsz < sizeof shimsin) {
		SHIM_LOG("address not valid (%p, len:%d (sin: %ld))\n", dmpsa, dmpsz, sizeof shimsin);
		return false;
	}

	/*
	 * If this socket is already connected, return an error to the user
	 */
	filp = _fdtable->get(dmpfd);
	if (filp) {
		int ret = -EINVAL;

		if (filp->port != 0) {
			VSocks->lock();
			vsock = VSocks->get(filp->port);
			VSocks->unlock();

		} else {
			vsock = PVSock();
		}

		if (filp->type != FDT_SOCKET) {
			SHIM_LOG("Connect on non-socket\n");
			ret = -ENOTSOCK;

		} else if (vsock && (vsock->state & VS_CONNECTED) != 0) {
			SHIM_LOG("Already connected!\n");
			ret = -EISCONN;

		} else if (vsock && (vsock->state & VS_CONNECTING) != 0) {
			SHIM_LOG("Still connecting...\n");
			ret = -EINPROGRESS;

		} else {
			SHIM_ERR("Have an FD entry when I shouldn't ...\n");
		}

		dmp_shim_emulate_syscall(ret, &event->regs);
		return true;
	}
	
	SHIM_LOG("Grabbing the sockaddr from the det thread\n");
	timed_dmp_shim_memcpy_sync(&shimsin, dmpsa, sizeof shimsin, FROM_DMP, NULL);

	/* Make sure we know what to do with this request */
	if (shimsin.sin_family != AF_INET) {
		SHIM_LOG("Non-IP address; ignoring\n");
		return false;
	}

	/* Look up the remote dpg we're connecting to */
	SHIM_LOG("Looking up the remote node...\n");
	addr = ntohl(shimsin.sin_addr.s_addr);
	port = ntohs(shimsin.sin_port);
	peer = isdetaddr(addr, port);
	if (peer == NULL) {
		SHIM_LOG("Didn't find a matching DPG; connection is non-det\n");
		return false;
	}

	SHIM_LOG("%s:%d will be handled by node %d\n", uint32_to_ip(addr), port, peer->nodeid);

	/* Add a new entry to PendingConns */
	SHIM_LOG("vsock: %p, filp: %p\n", vsock.get(), filp.get());
	SHIM_LOG("Creating a new pending conn request at fd:%d\n", dmpfd);
	vsock.reset(new VirtualSocket);
	SHIM_LOG("vsock: %p, filp: %p\n", vsock.get(), filp.get());

	SHIM_LOG("   vsock created at %p\n", vsock.get());
	vsock->state = VS_CONNECTING;
	SHIM_LOG("   vsock state: %d\n", vsock->state);
	VSocks->lock();
	newport = VSocks->getNewPort();
	VSocks->set(newport, vsock);
	VSocks->unlock();
	SHIM_LOG(" ... assigned port %d\n", newport);

	/* Create a new deterministic FileDescriptor for this socket */
	SHIM_LOG("Constructing a new FileDescriptor for the socket\n");
	filp = PFileDescriptor(new FileDescriptor);
	filp->type        = FDT_SOCKET;
	filp->peerid      = peer->nodeid;
	filp->port        = newport;
	SHIM_LOG("   My port %ld\n", filp->port);

	/* There should be a better way to set these values */
	filp->timing.read    = 25;
	filp->timing.write   = 25;
	filp->timing.open    = 25;
	filp->timing.close   = 25;
	filp->timing.generic = 25;

	/* Check to see if we should set our nonblocking flag */
	SHIM_LOG("Checking NONBLOCKING flag...\n");
	int tmpfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
	SHIM_LOG("Dup'ed dmpfd:%d --> shimfd:%d\n", dmpfd, tmpfd);
	if (fcntl(tmpfd, F_GETFL) & O_NONBLOCK) {
		SHIM_LOG("NONBLOCKING is set\n");
		filp->nonblocking = true;
	} else {
		SHIM_LOG("NONBLOCKING is not set\n");
		filp->nonblocking = false;
	}
	close(tmpfd);

	SHIM_LOG("  ... adding dmpfd:%ld to the fdtable\n", dmpfd);
	_fdtable->add(dmpfd, filp);

	/*
	 * We need to wait for a determinstic point before continuing
	 */
	SHIM_LOG("Waiting for the remote node to synchronize (me: GLT %ld, them: GLT %ld)\n", peer->last_known_quantum);
	waitForConnectTime.start();
	WaitFor->safe_set(peer->nodeid);
	wait_for_distq_barrier();
	waitForConnectTime.stop();

	/* Send a control message to the remote DPG */
	cc_send_connreq(peer, port, newport);

	/*
	 * If the file descriptor is non blocking, return to the caller right away.
	 */
	if (filp->nonblocking) {
		SHIM_LOG("fd is nonblocking; returning %d\n", -EINPROGRESS);
		dmp_shim_emulate_syscall(-EINPROGRESS, &event->regs);
		return true;
	}

	/* Wait for a response; should be replaced by a condvar */
	SHIM_LOG("Waiting for response to connect request\n");
	waitForConnectTime.start();
	vsock->lock();
	while (vsock->pending_connect_req.conn_result < 0) {
		vsock->unlock();
		SHIM_LOG(" ... nothing yet; waiting for peer %d\n", peer->nodeid);
		WaitFor->safe_set(peer->nodeid);
		wait_for_distq_barrier();
		SHIM_LOG(" ... trying again\n");
		vsock->lock();
	}
	waitForConnectTime.stop();
	SHIM_LOG("Got connect response of: %d, remote_port:%d\n",
		vsock->pending_connect_req.conn_result,
		vsock->remote_port);

	/* See if we were successful or not */
	if (vsock->pending_connect_req.conn_result == 0) {
		SHIM_LOG("Request denied\n");
		_fdtable->remove(dmpfd);
		dmp_shim_emulate_syscall(-ECONNREFUSED, &event->regs);

	} else {
		SHIM_LOG("   My port %ld, their port %d\n", filp->port, vsock->remote_port);
		SHIM_LOG("Returning success\n");
		dmp_shim_emulate_syscall(0, &event->regs);
	}

	vsock->pending_connect_req = PendingConn();
	vsock->unlock();

	return true;
}

bool BasicShim::do_sock_exit(shim_event *event)
{
	SHIM_LOG("Exiting the DPG\n");

	/* Clean up, if we're the last thread to exit */
	if (nrunning == 1) {
		SHIM_LOG("We're the last! Letting the world known...\n");
		current_distq++; /* End our current distq */
		wait_for_ddpg_exit();
		SHIM_LOG("Done.\n");
	}

	return true;
}

/**
 * __do_sock_single_poll --
 *
 *   Compute the result of a poll for a single deterministic fd
 */
bool BasicShim::__do_sock_single_poll(struct pollfd *poll_fd)
{
	PFileDescriptor pfd;
	PVSock vsock;

	if (!poll_fd) {
		SHIM_ERR("Null pollfd?\n");
		return false;
	}

	pfd = _fdtable->get(poll_fd->fd);
	if (pfd == NULL) {
		SHIM_LOG("Non-det fd %d?\n", poll_fd->fd);
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(pfd->port);
	VSocks->unlock();

	if (!vsock) {
		SHIM_LOG("No virtual socket for fd:%d, port:%d?\n", poll_fd->fd, pfd->port);
		return false;
	}

	/*
	 * We only understand POLLIN and POLLOUT for now
	 */
	if ((poll_fd->events & ~(POLLIN | POLLOUT)) != 0)
		SHIM_WARN("We only support POLLIN and POLLOUT on detfds. Events:%d\n", poll_fd->events);

	poll_fd->revents = 0;
	vsock->lock();
	if ((poll_fd->events & POLLIN) && vsock->pending_read())
		poll_fd->revents |= POLLIN;

	if ((poll_fd->events & POLLOUT) && (vsock->state & VS_CONNECTED))
		poll_fd->revents |= POLLOUT;

	vsock->unlock();
	return true;
}

int BasicShim::__do_sock_det_poll(shim_event *event, int detcnt, struct pollfd *detfds)
{
	int i;
	int ready = 0;
	char buffer[64];

	for (i = 0; i < detcnt; i++) {
		__do_sock_single_poll(&detfds[i]);
		if (detfds[i].revents != 0) {
			SHIM_LOG(" ... det-fd:%d is ready (%d: %s)\n", detfds[i].fd, detfds[i].revents, polltostr(detfds[i].revents, buffer, sizeof buffer));
			ready++;
		}
	}

	return ready;
}

int BasicShim::__do_sock_nondet_poll(shim_event *event, int nondetcnt, struct pollfd *nondetfds)
{
	int i;
	PFileDescriptor pfd;
	char buffer[64];

	int *originalfds = (int *)malloc(sizeof(int) * nondetcnt);
	assert(originalfds);

	SHIM_LOG("Performing nondet poll\n");

	/*
	 * Make sure we have nondet shadow of this fd 
	 */
	for (i = 0; i < nondetcnt; i++) {
		pfd = _ndfdtable->get(nondetfds[i].fd);
		if (!pfd) {
			add_nondet_shadow_fd(nondetfds[i].fd);
			pfd = _ndfdtable->get(nondetfds[i].fd);
		}

		if (!pfd) {
			SHIM_WARN("Couldn't shadow non-det fd:%d\n", i);
			continue;
		}

		originalfds[i]  = nondetfds[i].fd;
		nondetfds[i].fd = pfd->shadowfd;
	}

	/*
	 * Perform the underlying poll
	 */
	int ret = poll(nondetfds, nondetcnt, 0 /* poll only */);
	SHIM_LOG(" ... ret:%d\n", ret);

	/*
	 * Map the shadow fds back to dmp fds
	 */
	for (i = 0; i < nondetcnt; i++) {
		nondetfds[i].fd = originalfds[i];
		if (nondetfds[i].revents != 0) {
			SHIM_LOG(" ... nondet-fd:%d is ready (%d: %s)\n",
				nondetfds[i].fd, nondetfds[i].revents,
				polltostr(nondetfds[i].revents, buffer, sizeof buffer));
		}
	}

	return ret;
}


bool BasicShim::do_sock_poll(shim_event *event)
{
	unsigned long dmppollfds = shim_syscall_arg0(&event->regs);
	nfds_t        dmpnfds    = shim_syscall_arg1(&event->regs);
	int  __unused dmptime    = shim_syscall_arg2(&event->regs);
	char buffer1[64];
	char buffer2[64];

	long fdsize;
	struct pollfd *shimfds, *nondetfds, *detfds;
	int nondetcnt, detcnt;
	int nondetready, detready;
	int ready = 0;
	uint32_t i;
	int di, ni;
	bool ret = false;
	bool done = false;
	int numToWaitFor = 0;
	PDNode peer;
	DNodeMap::iterator cur;

	BitSet MyPeers;
	PVSock vsock;

	SHIM_LOG("@%ld.%d: poll(%p, %d, %d) (fdtable: %p) ...\n", EVTIME(event), dmppollfds, dmpnfds, dmptime, _fdtable.get());
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	fdsize = sizeof(struct pollfd) * dmpnfds;
	shimfds   = (struct pollfd *)malloc(fdsize);
	nondetfds = (struct pollfd *)malloc(fdsize);
	detfds    = (struct pollfd *)malloc(fdsize);
	assert(shimfds);
	assert(nondetfds);
	assert(detfds);

	timed_dmp_shim_memcpy_sync(shimfds, (void *)dmppollfds, fdsize, FROM_DMP, NULL);

	/*
	 * If we don't have any det fds, just let the OS take care of the poll
	 *
	 * BUG: There is a race with the below short-circuit. Because a socket
	 *   is marked as deterministic when it is bound, if one thread begins to
	 *   poll on the socket before a second thread binds it to a
	 *   deterministic port, then it will incorrectly by routed through the
	 *   kernel instead of the det fd stuff.
	 */
	#if 0
	if (detcnt == 0) {
		ret = false;
		goto out_ret;
	}
	#endif 

	/*
	 * Arbitrarily map any length of physical time to a single ddpg tick
	 */
	done = (dmptime >= 0 ? true : false);

	do {
		/* 
		 * Split the pollfds in to det and nondet sets; this needs to
		 * be done on each iteration. If a non-det socket is bound to a
		 * det port after poll is called, it needs to look in the
		 * appropriate place for data.
		 */
		nondetcnt = detcnt = 0;
		for (i = 0; i < dmpnfds; i++) {
			int fd = shimfds[i].fd;
			PFileDescriptor pfd = _fdtable->get(fd);
			SHIM_LOG("Checking (fd:%d, events:%s (%d), revents:%s (%d))\n",
				shimfds[i].fd, polltostr(shimfds[i].events,
				buffer1, sizeof buffer1), shimfds[i].events,
				polltostr(shimfds[i].revents, buffer2, sizeof buffer2),
				shimfds[i].revents);

			if (pfd != NULL) {
				SHIM_LOG("Adding fd:%d, port:%d to det poll set\n", fd, pfd->port);
				detfds[detcnt++] = shimfds[i];
			
				if (pfd->type == FDT_SOCKET) {
					VSocks->lock();
					vsock = VSocks->get(pfd->port);
					VSocks->unlock();

					/*
					 * Reading from a listening socket is a promiscuous operation
					 * and thus needs to wait for all peers to reach the same
					 * logical time before continuing.
					 *
					 * Reading from a non-listening socket needs to wait for the
					 * remote node if and only if the remote node is currently
					 * executing "in the past" and we don't already have data
					 * available. In other words, we can safely not wait if one
					 * of the following conditions is met:
					 *   
					 *     1) Node is executing in an earlier GLT, but has
					 *        already sent data we can consume
					 *
					 *     2) Node is executing in the future
					 */
					if ((shimfds[i].events & POLLIN) && (vsock->state == VS_LISTENING)) {
						MyPeers.set(); 
					} else {
						PDNode peer = DetNodes->get(pfd->peerid);

						if (peer->last_known_quantum <= current_distq && !vsock->pending_read()) {
							MyPeers.set(pfd->peerid);
							numToWaitFor++;
						} else {
							SHIM_LOG("Don't need to wait for %d\n", pfd->peerid);
						}
					}
				}

			} else {
				SHIM_LOG("Adding fd:%d to nondet poll set\n", fd);
				nondetfds[nondetcnt++] = shimfds[i];
			}
		}

		SHIM_LOG("Of %d fds, %d were det, and %d were nondet, numToWaitFor %d\n", dmpnfds, detcnt, nondetcnt, numToWaitFor);
		SHIM_LOG("MyPeers = %08lx\n", MyPeers.to_ulong());

		if (numToWaitFor > 0 || nondetcnt > 0) {
			WaitFor->lock();
			(*WaitFor) |= MyPeers;
			WaitFor->unlock();
			pollWaitTime.start();
			wait_for_distq_barrier();
			pollWaitTime.stop();
		}
		
		SHIM_LOG("Checking det fds\n");
		detready    = __do_sock_det_poll(event, detcnt, detfds);
		SHIM_LOG("Checking nondetfds\n");
		nondetready = __do_sock_nondet_poll(event, nondetcnt, nondetfds);

		ready = detready + nondetready;
		SHIM_LOG("Total of %d sockets ready for stuff\n", ready);

		if (ready > 0) {
			done = true;
			SHIM_LOG("Returning %d fds\n", ready);
		}

	} while (!done);

	/*
	 * Merge the results from the two sets
	 */
	di = ni = 0;
	for (i = 0; i < dmpnfds; i++) {
		if (di < detcnt && detfds[di].fd == shimfds[i].fd)
			shimfds[i].revents = detfds[di++].revents;
		else if (ni < nondetcnt && nondetfds[ni].fd == shimfds[i].fd)
			shimfds[i].revents = nondetfds[ni++].revents;
		else
			SHIM_WARN("fd:%d is neither det nor nondet?\n", i);
	}

	/*
	 * Copy the result back to the caller
	 */
	SHIM_LOG("Copying %d ready fds\n", ready);
	timed_dmp_shim_memcpy_sync(shimfds, (void *)dmppollfds, fdsize, TO_DMP, NULL);
	dmp_shim_emulate_syscall(ready, &event->regs);
	ret = true;

 out_ret:
 	free(shimfds);
	free(nondetfds);
	free(detfds);
	return ret;
}

/**
 * ssize_t readv(int fd, const struct iovec *iov, int iovcnt) -- 
 *
 *   Read data from the given file descriptor, filling the buffers in *iov
 *   one at a time.
 */
bool BasicShim::__do_sock_readv(shim_event *event, PFileDescriptor pfd)
{
	const int     __unused userfd    = shim_syscall_arg0(&event->regs);
	unsigned long __unused uservec   = shim_syscall_arg1(&event->regs);
	int           __unused usercnt   = shim_syscall_arg2(&event->regs);

	struct iovec *shimiovec = NULL;
	bool done = pfd->nonblocking;
	PVSock vsock;
	long ret = 0;

	/* Grab the virtual socket on this port */
	VSocks->lock();
	vsock = VSocks->get(pfd->port);
	VSocks->unlock();

	if (vsock == NULL) {
		SHIM_ERR("readv on a socket without a VSock?\n");
		return false;
	}

	/* Fast path for non-blockers */
	vsock->lock();
	if (pfd->nonblocking && vsock->data.avail(current_distq) == 0) {
		vsock->unlock();
		SHIM_LOG("Nonblocking read on empty buffer\n");
		dmp_shim_emulate_syscall(-EAGAIN, &event->regs);
		return true;
	}
	vsock->unlock();

	/* Wait for some amount of data to arrive */
	SHIM_LOG("Waiting for data to be available\n");
	waitForDataTime.start();
	vsock->lock();
	do {
		if (vsock->data.avail(current_distq) > 0) 
			break;
		else {
			vsock->unlock();
			SHIM_LOG("Waiting for peer %d...\n", pfd->peerid);
			WaitFor->safe_set(pfd->peerid);
			wait_for_distq_barrier();
			vsock->lock();
		}
	} while (1);
	vsock->unlock();
	waitForDataTime.stop();

	/*
	 * Read a copy of the iovec array to the shim's address space and
	 * allocate local buffers to accumulate the data read.
	 */
	int current_iov = 0;
	int vecsize = sizeof(struct iovec) * usercnt;
	char **arrays;

	SHIM_LOG("Allocating iovec\n");
	shimiovec = (struct iovec *)malloc(vecsize);
	if (shimiovec == NULL) {
		SHIM_ERR("Couldn't allocate room for iovec\n");
		return false;
	}
	
	SHIM_LOG("Copying iovec array from user space\n");
	timed_dmp_shim_memcpy_sync(shimiovec, (void *)uservec, vecsize, FROM_DMP, NULL);

	SHIM_LOG("Allocating %d iovec buffers\n", usercnt);
	arrays = (char **)malloc(sizeof(char *) * usercnt);
	assert(arrays != NULL);
	for (current_iov = 0; current_iov < usercnt; current_iov++) {
		arrays[current_iov] = (char *)malloc(shimiovec[current_iov].iov_len);
		assert(arrays[current_iov] != NULL);
	}

	/*
	 * To ensure the readv is performed "atomically" as required by POSIX,
	 * we don't first accumulate all of the data in the shim, and then
	 * "batch" copy those buffers back to the DMP thread. Copying each
	 * buffer to the DMP as we read it could result in a MOT violation,
	 * giving other threads a chance to consume data from the socket.
	 */

	int last;
	vsock->lock();
	for (current_iov = 0; current_iov < usercnt; current_iov++) {
		SHIM_LOG("Filling up to %d bytes in iov:%d\n", shimiovec[current_iov].iov_len, current_iov);
		socketIOTime.start();
		last = vsock->data.get(current_distq, arrays[current_iov], shimiovec[current_iov].iov_len);
		socketIOTime.stop();
		SHIM_LOG(" ... got %d bytes\n", last);

		ret += last;

		/* We've consumed as much as we can */	
		if (ret > 0 && last < shimiovec[current_iov].iov_len) {
			SHIM_LOG("Partial fill, done\n");
			break;
		}
	}
	vsock->unlock();

	/*
	 * Now we need to copy all the data back to the DMP thread; the first
	 * current_iov - 1 buffers are completely full, the last buffer
	 * (current_iov) only has *last* bytes.
	 */
	int i;
	for (i = 0; i <= current_iov && i < usercnt; i++) {
		int nbytes = 0;

		/* This is a full fill */
		if (i < current_iov)
			nbytes = shimiovec[i].iov_len;
		else
			nbytes = last;

		SHIM_LOG("Writing %d bytes from iov:%d to DMP %p\n", nbytes, i, shimiovec[i].iov_base);
		timed_dmp_shim_memcpy_sync(arrays[i], shimiovec[i].iov_base, nbytes, TO_DMP, NULL);
	}

	for (i = 0; i < usercnt; i++)
		free(arrays[i]);

	free(shimiovec);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::__do_sock_writev(shim_event *event, PFileDescriptor pfd)
{
	const int     __unused userfd    = shim_syscall_arg0(&event->regs);
	unsigned long __unused uservec   = shim_syscall_arg1(&event->regs);
	int           __unused usercnt   = shim_syscall_arg2(&event->regs);

	struct iovec *shimiovec = NULL;
	long ret = 0;
	int current_iov = 0;
	int vecsize = sizeof(struct iovec) * usercnt;
	char *buf = NULL;
	int lastwrite = 0;
	PDNode peer = DetNodes->get(pfd->peerid);
	PVSock vsock;
	assert(peer);

	/*
	 * Read a copy of the iovec array to the shim's address space and
	 * allocate local buffers to accumulate the data read.
	 */
	SHIM_LOG("Allocating iovec\n");
	shimiovec = (struct iovec *)malloc(vecsize);
	if (shimiovec == NULL) {
		SHIM_ERR("Couldn't allocate room for iovec\n");
		return false;
	}
	
	SHIM_LOG("Copying iovec array from user space\n");
	timed_dmp_shim_memcpy_sync(shimiovec, (void *)uservec, vecsize, FROM_DMP, NULL);

	VSocks->lock();
	vsock = VSocks->get(pfd->port);
	VSocks->unlock();

	vsock->lock();
	for (current_iov = 0; current_iov < usercnt; current_iov++) {
		SHIM_LOG("Reading %d bytes from iov:%d\n", shimiovec[current_iov].iov_len, current_iov);

		/* Allocate some space for this message */
		buf = (char *)malloc(shimiovec[current_iov].iov_len);
		assert(buf);

		/* Grab this iovec locally */
		timed_dmp_shim_memcpy_sync(buf, shimiovec[current_iov].iov_base, shimiovec[current_iov].iov_len, FROM_DMP, NULL);

		/* Send this iovec to the peer */
		socketIOTime.start();
		lastwrite = cc_send_data(peer, vsock->remote_port, shimiovec[current_iov].iov_len, buf);
		socketIOTime.stop();

		free(buf);
		ret += lastwrite;
	}
	vsock->unlock();

	free(shimiovec);
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

/**
 * __do_sock_dup --
 *
 *   Arguments are assumed to be valid. The new fd has already been added
 *   to the fdtable.
 */
bool BasicShim::__do_sock_dup(shim_event *event, int dmpoldfd, int dmpnewfd, PFileDescriptor __foo)
{
	PVSock vsockold, vsocknew;
	PFileDescriptor pfdold, pfdnew;

	SHIM_LOG("Dup'ing det socket fd:%d to %d\n", dmpoldfd, dmpnewfd);
	SHIM_LOG("(I think everything should work... just verifying the stuff)\n");

	pfdnew = _fdtable->get(dmpnewfd);
	pfdold = _fdtable->get(dmpoldfd);
	if (!pfdold) {
		SHIM_WARN("Couldn't get PFD for old file descriptor\n");
		return false;
	}
	if (!pfdnew) {
		SHIM_WARN("Couldn't get PFD for new file descriptor\n");
		return false;
	}

	SHIM_LOG("  Looking up the vsock for old port %d\n", pfdold->port);
	VSocks->lock();
	vsockold = VSocks->get(pfdold->port);
	VSocks->unlock();
	SHIM_LOG("    ... got %p\n", vsockold.get());

	SHIM_LOG("  Looking up the vsock for new port %d\n", pfdnew->port);
	VSocks->lock();
	vsocknew = VSocks->get(pfdnew->port);
	VSocks->unlock();
	SHIM_LOG("    ... got %p\n", vsocknew.get());

	return true;
}

/**
 * __do_sock_close --
 *
 *   Called when closing a detex socket; the fd has already been removed from the 
 *   shim's fd table; we just need to clean up the receive buffers and send an
 *   FDCLOSE message.
 *
 *   Parameters:
 *       event  --
 *       dmpfd  -- DMP file descriptor we're closing
 *       pfile  -- PFileDescriptor corresponding to the given dmpfd
 */
bool BasicShim::__do_sock_close(shim_event *event, int dmpfd, PFileDescriptor pfile)
{
	VSockMap::iterator vsock_iter;
	PVSock vsock;
	PDNode peer;

	VSocks->lock();
	vsock_iter = VSocks->find(pfile->port);
	if (vsock_iter == VSocks->end()) {
		VSocks->unlock();
		SHIM_ERR("Couldn't find receive buffer for dmpfd:%d port:%d\n", dmpfd, pfile->port);
		SHIM_LOG("Nothing to do?\n");
		return true;
	}

	vsock = VSocks->get(vsock_iter->first);
	if (vsock->state == VS_CONNECTED) {
		SHIM_LOG("This socket is connected\n");
		
		peer = DetNodes->get(pfile->peerid);
		if (peer == NULL) {
			SHIM_WARN("Can't find peer node!\n");
			return false;
		}
	
		cc_send_fdclose(peer, vsock->remote_port);
	}

	vsock->lock();
	if (vsock->downctr() == 0) {
		SHIM_LOG("Removing Vsock for vport %d\n", pfile->port);
		VSocks->erase(vsock_iter);
	}
	vsock->unlock();
	VSocks->unlock();

	return true;
}


/**
 * __do_sock_sendto --
 *
 *   Workhorse for sending data across deterministic connections; used by both
 *   do_sock_sendto and do_fs_write when the given fd is a socket. Parameters
 *   are assumed to be correct.
 *
 *   Parameters:
 *       dmpfd  -- DMP file descriptor to write to
 *       dmpbuf -- Pointer to data in the DMP thread to send
 *       nbytes -- Number of bytes to send
 */
bool BasicShim::__do_sock_sendto(shim_event *event, PFileDescriptor pfile, int dmpfd, char *dmpbuf, long nbytes)
{
	char *buf = NULL;
	PDNode peer;
	PVSock vsock;

	/* 
	 * The provided fd looks to be a deterministic socket. Grab the
	 * provided buffer from the dmp program into our local buffer
	 */
	_tmp_buffer.resize(nbytes);
	buf = &_tmp_buffer[0];

	SHIM_LOG("Copying %ld bytes from DMP task...\n", nbytes);
	if (timed_dmp_shim_memcpy_sync((void*)buf, (void*)dmpbuf, nbytes, FROM_DMP, NULL) < 0) {
		SHIM_WARN("Bad things happened while writing socket; what do we do now?\n");
		dmp_shim_emulate_syscall(-errno, &event->regs);
		return true;
	}

	/* Queue this data for delivery in the next quantum */
	SHIM_LOG("Looking up peer for nodeid %d\n", pfile->peerid);
	peer = DetNodes->get(pfile->peerid);
	if (peer == NULL) {
		SHIM_WARN("Cant find peer node!\n");
		free(buf);
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(pfile->port);
	VSocks->unlock();

	/* Send the data */
	socketIOTime.start();
	cc_send_data(peer, vsock->remote_port, nbytes, buf);
	socketIOTime.stop();
	
	/* Emulate the syscall for the caller */
	dmp_shim_emulate_syscall(nbytes, &event->regs);
	return true;
}

/**
 * do_sock_sendto(event) --
 *
 *   Outstanding TODOs:
 *    - Unconnected (e.g., UDP) sockets
 */
bool BasicShim::do_sock_sendto(shim_event *event)
{
	int    dmpfd  = shim_syscall_arg0(&event->regs);
	char  *dmpbuf = (char *)shim_syscall_arg1(&event->regs);
	size_t dmpsz  = shim_syscall_arg2(&event->regs);
	PFileDescriptor pfile = _fdtable->get(dmpfd);
	PDNode peer;
	PVSock vsock;

	SHIM_LOG("@%ld.%d: send(%d, %p, %ld, ...) ...\n", EVTIME(event), dmpfd, dmpbuf, dmpsz);
	if (reexec_detnet) {
		SHIM_WARN("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/* Make sure we got a valid fd */
	SHIM_LOG("Checking the validity of the file descriptor...\n");
	if (!pfile) {
		SHIM_LOG("fd:%d not in a tracked socket\n", dmpfd);
		return false;
	
	} else if (pfile->type != FDT_SOCKET) {
		SHIM_WARN("fd:%d is deterministic, but not a socket\n", dmpfd);
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	
	} 

	VSocks->lock();
	vsock = VSocks->get(pfile->port);
	VSocks->unlock();
	
	if ((vsock->state & VS_CONNECTED) == false) {
		SHIM_WARN("Sending data on unconnected socket?\n");
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	}
	SHIM_LOG("Looks good!\n");
	
	return __do_sock_sendto(event, pfile, dmpfd, dmpbuf, dmpsz);
}

/**
 * __do_sock_recvfrom --
 *
 *   Workhorse for reading data from deterministic connections; used by both
 *   do_sock_recvfrom and do_fs_read when the given fd is a socket. Parameters
 *   are assumed to be correct.
 *
 *   Parameters:
 *       dmpfd  -- DMP file descriptor to read from
 *       dmpbuf -- Pointer to buffer in DMP thread to store data
 *       nbytes -- Number of bytes to read
 */
bool BasicShim::__do_sock_recvfrom(shim_event *event, PFileDescriptor pfile, int dmpfd, char *dmpbuf, long nbytes)
{
	int ret = 0;
	char *buf = NULL;
	PSlottedBuffer buffer;
	PVSock vsock;
	bool done = pfile->nonblocking;
	PDNode peer;

	VSocks->lock();
	vsock = VSocks->get(pfile->port);
	VSocks->unlock();

	peer = DetNodes->get(pfile->peerid);

	/* Get the data */
	_tmp_buffer.resize(nbytes);
	buf = &_tmp_buffer[0];

	waitForDataTime.start();
	vsock->lock();
	do {
		socketIOTime.start();
		ret = vsock->data.get(current_distq, buf, nbytes);
		socketIOTime.stop();
		SHIM_LOG("Got %d bytes from the socket\n", ret);
		if (ret > 0)
			done = true;

		if (!done) {
			vsock->unlock();
			SHIM_LOG("Waiting for peer %d\n", pfile->peerid);
			WaitFor->safe_set(pfile->peerid);
			wait_for_distq_barrier();
			vsock->lock();
		}
	} while (!done);
	vsock->unlock();
	waitForDataTime.stop();

	/* Give it to the dmp task */
	if (ret > 0) {
		SHIM_LOG("Copying %lu bytes to DMP task\n", ret);
		timed_dmp_shim_memcpy_sync(buf, dmpbuf, ret, TO_DMP, NULL);

	} else if (ret == 0) {
		SHIM_LOG("Non-blocking; empty read (%d); setting EAGAIN\n", ret);
		ret = -EAGAIN;

	} else {
		SHIM_LOG("Got error %d\n", ret);
	}
	
	/* Emulate the syscall for the caller */
	dmp_shim_emulate_syscall(ret, &event->regs);
	
	return true;
}

bool BasicShim::do_sock_recvfrom(shim_event *event)
{
	int      dmpfd  = shim_syscall_arg0(&event->regs);
	char    *dmpbuf = (char *)shim_syscall_arg1(&event->regs);
	uint64_t dmpsz  = (uint64_t)shim_syscall_arg2(&event->regs);
	PFileDescriptor pfile = _fdtable->get(dmpfd);
	PVSock vsock;

	SHIM_LOG("@%ld.%d: recv(%d, %p, %lu, ...) ...\n", EVTIME(event), dmpfd, dmpbuf, dmpsz);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/* Make sure we got a valid fd */
	SHIM_LOG("Checking the validity of the file descriptor...\n");
	if (!pfile) {
		SHIM_LOG("fd:%d not in a tracked socket\n", dmpfd);
		return false;
	
	} else if (pfile->type != FDT_SOCKET) {
		SHIM_LOG("fd:%d is deterministic, but not a socket\n", dmpfd);
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(pfile->port);
	VSocks->unlock();
	
	if ((vsock->state & VS_CONNECTED) == false) {
		SHIM_LOG("Reading data from unconnected socket?\n");
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	}
	SHIM_LOG("Looks good!\n");

	return __do_sock_recvfrom(event, pfile, dmpfd, dmpbuf, dmpsz);
}

bool BasicShim::do_sock_sendmsg(shim_event *event)
{
	int dmpfd                = shim_syscall_arg0(&event->regs);
	struct msghdr *dmpmsghdr = (struct msghdr *)shim_syscall_arg1(&event->regs);
	int  __unused dmpflags   = shim_syscall_arg2(&event->regs);

	struct msghdr shimmsghdr;
	struct iovec  shimcuriov, *dmpcuriov;
	int           i, res = 0;
	vector<char>  buffer;
	char          *buffer2;

	uint32_t cmd;
	uint16_t remote_port;
	uint64_t bytes;

	PDNode peer;
	PFileDescriptor pfile = _fdtable->get(dmpfd);
	PVSock vsock;

	SHIM_LOG("@%ld.%d: sendmsg(%d, %p, %lu) ...\n", EVTIME(event), dmpfd, dmpmsghdr, dmpflags);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/* Make sure we got a valid fd */
	SHIM_LOG("Checking the validity of the file descriptor...\n");
	if (!pfile) {
		SHIM_LOG("fd:%d not in a tracked socket\n", dmpfd);
		return false;
	
	} else if (pfile->type != FDT_SOCKET) {
		SHIM_LOG("fd:%d is deterministic, but not a socket\n", dmpfd);
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(pfile->port);
	VSocks->unlock();
	
	if ((vsock->state & VS_CONNECTED) == false) {
		SHIM_LOG("Reading data from unconnected socket?\n");
		SHIM_WARN("  Don't know what to do; passing through...\n");
		return false;
	}
	SHIM_LOG("Looks good!\n");

	if (!dmpmsghdr) {
		SHIM_LOG(" ... dmpmsghdr is null; ignoring\n");
		dmp_shim_emulate_syscall(-EINVAL, &event->regs);
		return true;
	}

	/* Grab the msghdr struct from the dmp task */
	timed_dmp_shim_memcpy_sync(&shimmsghdr, dmpmsghdr, sizeof(struct msghdr), FROM_DMP, NULL);
	dmpcuriov = shimmsghdr.msg_iov;

	/* Grab the peer for this descriptor */
	peer = (*DetNodes)[pfile->peerid];

	SHIM_LOG("Processing %d iovec structures...\n", shimmsghdr.msg_iovlen);
	cmd         = CMT_DATA;
	remote_port = vsock->remote_port;

	for (i = 0; i < shimmsghdr.msg_iovlen; ++i) {

		SHIM_LOG("Reading %d/%d ...\n", i+1, shimmsghdr.msg_iovlen);
		timed_dmp_shim_memcpy_sync(&shimcuriov, dmpcuriov, sizeof(struct iovec), FROM_DMP, NULL);
		dmpcuriov++;

		int blen = shimcuriov.iov_len + 1;
		SHIM_LOG("Allocating %d bytes for buffer...\n", blen);
		buffer2 = (char *)malloc(blen);
		assert(buffer2 != NULL);

		/*
		buffer.resize(shimcuriov.iov_len+1);
		timed_dmp_shim_memcpy_sync(&buffer[0], shimcuriov.iov_base, shimcuriov.iov_len, FROM_DMP, NULL);
		res += shimcuriov.iov_len;

		buffer[shimcuriov.iov_len] = '\0';
		SHIM_LOG("Got: '%s'\n", &buffer[0]);
		*/

		long out = 0;
		timed_dmp_shim_memcpy_sync(buffer2, shimcuriov.iov_base, shimcuriov.iov_len, FROM_DMP, &out);
		SHIM_LOG("Got %ld byte sfrom the dmp task iov\n", out);
		res += out;

		/* 
		 * TODO: These should be accumulated and sent as a batch, rather than
		 *    sending each iovec individually.
		 */
		bytes = shimcuriov.iov_len;
		SHIM_LOG("Sending %ld bytes from iovec %d\n", bytes, i);
		pthread_mutex_lock(&peer->ctrlfd_lock);
		writen(peer->ctrlfd, (char *)&cmd,         sizeof cmd);
		writen(peer->ctrlfd, (char *)&remote_port, sizeof remote_port);
		writen(peer->ctrlfd, (char *)&bytes,       sizeof bytes);
		writen(peer->ctrlfd, buffer2, out);
		pthread_mutex_unlock(&peer->ctrlfd_lock);
		SHIM_LOG("iovec %d done\n", i+1);

		free(buffer2);
	}
	SHIM_LOG("All done (sent %ld bytes total).\n", res);

	dmp_shim_emulate_syscall(res, &event->regs);
	return true;
}

bool BasicShim::do_sock_recvmsg(shim_event *event)
{
	SHIM_WARN("recvmsg is not implemented\n");
	return false;
}

static void print_fdset(int maxfd, const char *label, fd_set *setp) 
{
	int i;
	fd_set set;

	SHIM_LOG("    %s (max %d): [", label, maxfd);
	if (!setp) {
		SHIM_LOG_CONT("]\n");
	} else {
		set = *setp;
		for (i = 0; i < maxfd; i++) {
			if (FD_ISSET(i, &set))
				SHIM_LOG_CONT("%d ", i);
		}
	}
	SHIM_LOG_CONT("]\n");
}

/**
 * int BasicShim::__do_sock_det_select(event, nfds, det_rdp, det_wrp, det_exp) --
 *
 *   Implement select() for deterministic sockets.
 *
 *   Returns:
 *       The number of fds in the result
 */
int BasicShim::__do_sock_det_select(shim_event *event, int nfds, fd_set *det_rdp, fd_set *det_wrp, fd_set *det_exp)
{
	int i, res = 0;
	fd_set det_rd, det_wr, det_ex; /* These sets hold in the input sets */
	fd_set res_rd, res_wr, res_ex; /* These sets hold the results */
	PFileDescriptor pfd;
	PSlottedBuffer buf;
	bool found = false;
	PVSock vsock;

	FD_ZERO(&res_rd);
	FD_ZERO(&res_wr);
	FD_ZERO(&res_ex);
	FD_ZERO(&det_rd); if (det_rdp) det_rd = *det_rdp;
	FD_ZERO(&det_wr); if (det_wrp) det_wr = *det_wrp;
	FD_ZERO(&det_ex); if (det_exp) det_ex = *det_exp;

	print_fdset(nfds, "det read  set", &det_rd);
	print_fdset(nfds, "det write set", &det_wr);
	print_fdset(nfds, "det ex    set", &det_ex);

	for (i = 0; i < nfds; i++) {

		pfd = _fdtable->get(i);
		if (!pfd || pfd->type != FDT_SOCKET)
			continue;

		VSocks->lock();
		vsock = VSocks->get(pfd->port);
		VSocks->unlock();

		if (!vsock) {
			SHIM_WARN("No vsock found for fd:%d, port:%d\n", i, pfd->port);
			continue;
		}

		/*
		 * Check for incoming data or incoming connections
		 */
		if (FD_ISSET(i, &det_rd)) {
			SHIM_LOG("    Checking for read availability on fd:%d (port:%d, state:%d)...\n", i, pfd->port, vsock->state);
			found = false;
			
			/* See if this socket has pending data */
			vsock->lock();
			found = vsock->pending_read();
			vsock->unlock();
			
			if (found) {
				SHIM_LOG("   Adding fd:%d to read set\n", i);
				res++;
				FD_SET(i, &res_rd);
			}
		}

		/*
		 * Connected det sockets are always writable; connecting det
		 * sockets are not writable until the connection completes.
		 */
		if (FD_ISSET(i, &det_wr)) {
			SHIM_LOG("    Checking for write availability on fd:%d (port:%d, state:%d)...\n", i, pfd->port, vsock->state);
			vsock->lock();
			if (vsock->state & VS_CONNECTED) {
				SHIM_LOG("        Ready to write!\n");
				res++;
				FD_SET(i, &res_wr);
			} else if (vsock->state & VS_CONNECTING) {
				SHIM_LOG("        fd:%d is still connecting, not ready\n", i);
			} else {
				SHIM_LOG("        fd:%d is in weird state, not ready\n", i);
			}
			vsock->unlock();
		}

		/*
		 * Ignore the freaky folks...
		 */
		if (FD_ISSET(i, &det_ex))
			SHIM_WARN("Ignoring fd:%d in the exception set\n", i);
	}

	SHIM_LOG("Det select returning %d:\n", res); 
	if (det_rdp) {
		*det_rdp = res_rd;
		print_fdset(nfds, "det_rd", det_rdp);
	}
	if (det_wrp) {
		*det_wrp = res_wr;
		print_fdset(nfds, "det_wr", det_wrp);
	}
	if (det_exp) {
		*det_exp = res_ex;
		print_fdset(nfds, "det_ex", det_exp);
	}

	return res;
}

int BasicShim::add_nondet_shadow_fd(int dmpfd)
{
	int newfd;
	PFileDescriptor pfd(new FileDescriptor);

	SHIM_LOG("Creating a new shadow for nondet fd:%d\n", dmpfd);
	newfd = dmp_shim_dupfd(dmpfd, FROM_DMP, 0);
	pfd->shadowfd = newfd;
	SHIM_LOG("   ... dmpfd:%d -- dup'ed to --> shimfd:%d\n", dmpfd, newfd);

	_ndfdtable->add(dmpfd, pfd);
	return newfd;
}

int BasicShim::__do_sock_nondet_select(shim_event *event, int nfds, fd_set *dmp_rdp, fd_set *dmp_wrp, fd_set *dmp_exp)
{
	int i, res = 0;
	fd_set dmp_rd, dmp_wr, dmp_ex; /* These sets hold in the input sets */
	fd_set res_rd, res_wr, res_ex; /* These sets hold the results */
	PFileDescriptor pfd;
	int maxfd = -1;
	struct timeval zero = { 0, 0 };

	FD_ZERO(&res_rd);
	FD_ZERO(&res_wr);
	FD_ZERO(&res_ex);
	FD_ZERO(&dmp_rd); if (dmp_rdp) dmp_rd = *dmp_rdp;
	FD_ZERO(&dmp_wr); if (dmp_wrp) dmp_wr = *dmp_wrp;
	FD_ZERO(&dmp_ex); if (dmp_exp) dmp_ex = *dmp_exp;

	for (i = 0; i < nfds; i++) {

		/*
		 * Make sure we have a non-det shadow of this fd
		 */
		if (FD_ISSET(i, &dmp_rd) || FD_ISSET(i, &dmp_wr) || FD_ISSET(i, &dmp_ex)) {
			SHIM_LOG("Checking nondet select on fd:%d\n", i);

			pfd = _ndfdtable->get(i);
			if (pfd == NULL) {
				add_nondet_shadow_fd(i);
				pfd = _ndfdtable->get(i);
			}

			if (pfd == NULL) {
				SHIM_WARN("Couldn't shadow non-det fd %d?\n", i);
				continue;
			}
		}

		/*
		 * Translate the read set
		 */
		if (FD_ISSET(i, &dmp_rd)) {
			SHIM_LOG("    Adding shimfd:%d, dmpfd:%d to read\n", pfd->shadowfd, i);
			FD_SET(pfd->shadowfd, &res_rd);
			res++;
			maxfd = (pfd->shadowfd > maxfd ? pfd->shadowfd : maxfd);
		}

		/*
		 * Translate the write set
		 */
		if (FD_ISSET(i, &dmp_wr)) {
			SHIM_LOG("    Adding shimfd:%d, dmpfd:%d to write\n", pfd->shadowfd, i);
			FD_SET(pfd->shadowfd, &res_wr);
			res++;
			maxfd = (pfd->shadowfd > maxfd ? pfd->shadowfd : maxfd);
		}

		/*
		 * Translate the exception set
		 */
		if (FD_ISSET(i, &dmp_ex)) {
			SHIM_LOG("    Adding shimfd:%d, dmpfd:%d to except\n", pfd->shadowfd, i);
			FD_SET(pfd->shadowfd, &res_ex);
			res++;
			maxfd = (pfd->shadowfd > maxfd ? pfd->shadowfd : maxfd);
		}
	}

	/*
	 * Do the select on the nondet fds 
	 */
	if (maxfd >= 0) {
		SHIM_LOG("Calling select on the nondet fds...\n");
		res = select(maxfd + 1, &res_rd, &res_wr, &res_ex, &zero);
		SHIM_LOG("   ... ret:%d\n", res);
	}

	/*
	 * Map the fds back to fds in the dmp's fd table
	 */
	FD_ZERO(&dmp_rd);
	FD_ZERO(&dmp_wr);
	FD_ZERO(&dmp_ex);

	if (res > 0) {
		FileDescriptorTable::iterator iter;

		for (iter = _ndfdtable->begin(); iter != _ndfdtable->end(); ++iter) {
			if (FD_ISSET(iter->second->shadowfd, &res_rd)) {
				SHIM_LOG("    Setting shimfd:%d, dmpfd:%d in read\n", iter->second->shadowfd, iter->first);
				FD_SET(iter->first, &dmp_rd);
			}
			if (FD_ISSET(iter->second->shadowfd, &res_wr)) {
				SHIM_LOG("    Setting shimfd:%d, dmpfd:%d in write\n", iter->second->shadowfd, iter->first);
				FD_SET(iter->first, &dmp_wr);
			}
			if (FD_ISSET(iter->second->shadowfd, &res_ex)) {
				SHIM_LOG("    Setting shimfd:%d, dmpfd:%d in except\n", iter->second->shadowfd, iter->first);
				FD_SET(iter->first, &dmp_ex);
			}
		}

	}

	/*
	 * Give the results back to the caller
	 */
	if (dmp_rdp) {
		*dmp_rdp = dmp_rd;
		print_fdset(nfds, "nondet_rd", dmp_rdp);
	}
	if (dmp_wrp) {
		*dmp_wrp = dmp_wr;
		print_fdset(nfds, "nondet_wr", dmp_wrp);
	}
	if (dmp_exp) {
		*dmp_exp = dmp_ex;
		print_fdset(nfds, "nondet_ex", dmp_exp);
	}

	return res;
}

/**
 * __get_set_size(maxfd) -- 
 *
 *   Returns the number of bytes of an fd_set required to represent maxfd file
 *   descriptors.
 *
 *   Params:
 *       maxfd  -- Number of fds in the set
 *
 *   Returns:
 *       Number of bytes used of the fd_set
 */
int BasicShim::__get_set_size(int maxfd)
{
	return (maxfd + 7) / 8;
}

/**
 * int select(int nfds, fd_set *read, fd_set *write, fd_set *except, struct
 *            timeval *tv) --
 *
 *   Return the file descriptors that are ready to read, write, or have pending
 *   exceptions.
 *
 *   N.B. select() is an implicit distq barrier; we must wait until the end
 *     of the current distq (and before the next distq) to make the underlying
 *     call to select, to make sure all data that will arrive this quantum
 *     has arrived.
 *
 *   N.B. select() has two phases. Because the socket sets passed by the caller
 *     can have an arbitrary mix of non-det sockets, det sockets, non-sockets, 
 *     etc., we have to take care that the "right thing" happens.
 *
 *     This means we must mask all of the det-sockets from the sets (since
 *     the kernel does not know about them) and pass the others to
 *
 *
 *   TODO: What do we do with the timeout value? One option would be to
 *      arbitrarily map physical time to logical time. Another would be to
 *      do our best to respect the physical time. Whatever we do, it should
 *      have the same semantics as sleep() in the end.
 */
bool BasicShim::do_sock_select(shim_event *event)
{
	int             dmpnfds = shim_syscall_arg0(&event->regs);
	fd_set  *dmprdp  = (fd_set *)shim_syscall_arg1(&event->regs);
	fd_set  *dmpwrp  = (fd_set *)shim_syscall_arg2(&event->regs);
	fd_set  *dmpexp  = (fd_set *)shim_syscall_arg3(&event->regs);
	struct timeval *dmptv = (struct timeval *)shim_syscall_arg4(&event->regs);
	bool have_detfds = false, have_nondetfds = false;

	fd_set dmprd,     dmpwr,     dmpex;              /* Holds the fdset as passed in from the dmp task */
	fd_set detrd,     detwr,     detex;              /* Holds the fds that are determinstic */
	fd_set detrd_res, detwr_res, detex_res;          /* Contains the result of selecting on the det fds */
	fd_set nondetrd,  nondetwr,  nondetex;           /* Holds the fds that are nondeterministic */
	fd_set nondetrd_res, nondetwr_res, nondetex_res; /* Contains the result of selecting on the nondet fds */
	fd_set resrd,     reswr,     resex;              /* Contains the bit-wise OR of det*_res and nondet*_res */
	int res;

	BitSet MyPeers;
	PVSock vsock;

	/*
	 * Only copy and write as many words as necessary to check the descriptors.
	 *   -- Some applications (i.e., libevent) REQUIRE this behavior for correctness
	 */
	int set_size = __get_set_size(dmpnfds-1);

	/* Right now, we map *all* physical timeouts to the end of the distq barrier */
	bool done = (dmptv != NULL);

	SHIM_LOG("@%ld.%d: select(nfds:%d, %p, %p, %p, %p) ...\n", EVTIME(event),
	         dmpnfds, dmprdp, dmpwrp, dmpexp, dmptv);

	SHIM_LOG("    rdset: %p\n", dmprdp);
	SHIM_LOG("    wrset: %p\n", dmpwrp);
	SHIM_LOG("    exset: %p\n", dmpexp);

	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	/*
	 * Read the socket sets from the DMP task
	 */
	FD_ZERO(&dmprd);
	if (dmprdp) {
		//SHIM_LOG("Grabbing read set...\n");
		timed_dmp_shim_memcpy_sync(&dmprd, dmprdp, set_size, FROM_DMP, NULL);
		print_fdset(dmpnfds, "read", &dmprd);
	}

	FD_ZERO(&dmpwr);
	if (dmpwrp) {
		//SHIM_LOG("Grabbing write set...\n");
		timed_dmp_shim_memcpy_sync(&dmpwr, dmpwrp, set_size, FROM_DMP, NULL);
		print_fdset(dmpnfds, "write", &dmpwr);
	}

	FD_ZERO(&dmpex);
	if (dmpexp) {
		//SHIM_LOG("Grabbing exception set...\n");
		timed_dmp_shim_memcpy_sync(&dmpex, dmpexp, set_size, FROM_DMP, NULL);
		print_fdset(dmpnfds, "except", &dmpex);
	}
		
		
	print_fdset(dmpnfds, "read", &dmprd);
	print_fdset(dmpnfds, "write", &dmpwr);
	print_fdset(dmpnfds, "except", &dmpex);

	/*
	 * Split the socket sets in to a det set and a non-det set
	 */
	FD_ZERO(&detrd);    FD_ZERO(&detwr);    FD_ZERO(&detex);
	FD_ZERO(&nondetrd); FD_ZERO(&nondetwr); FD_ZERO(&nondetex);
	for (int i = 0; i < dmpnfds; i++) {
		PFileDescriptor pfd = _fdtable->get(i);

		if (pfd != NULL) {
			VSocks->lock();
			vsock = VSocks->get(pfd->port);
			VSocks->unlock();
		}

		if (FD_ISSET(i, &dmprd)) {
			if (pfd == NULL) {
				//SHIM_LOG("  Adding %d to nondet rd...\n", i);	
				FD_SET(i, &nondetrd);
				have_nondetfds = true;
			} else {
				//SHIM_LOG("  Adding %d to det rd...\n", i);
				FD_SET(i, &detrd);
				have_detfds = true;

				/*
				 * If we're waiting for connections, we need
				 * to wait for all of the nodes to catch up.
				 */
				if (vsock != NULL && vsock->state == VS_LISTENING)
					MyPeers.set();
				else
					MyPeers.set(pfd->peerid);
			}
		}

		if (FD_ISSET(i, &dmpwr)) {
			if (pfd == NULL) {
				//SHIM_LOG("  Adding %d to nondet wr...\n", i);	
				FD_SET(i, &nondetwr);
				have_nondetfds = true;
			} else {
				//SHIM_LOG("  Adding %d to det wr...\n", i);
				FD_SET(i, &detwr);
				have_detfds = true;
				MyPeers.set(pfd->peerid);
			}
		}
	
		if (FD_ISSET(i, &dmpex)) {
			if (pfd == NULL) {
				//SHIM_LOG("  Adding %d to nondet ex...\n", i);	
				FD_SET(i, &nondetex);
				have_nondetfds = true;
			} else {
				//SHIM_LOG("  Adding %d to det ex...\n", i);
				FD_SET(i, &detex);
				have_detfds = true;
				MyPeers.set(pfd->peerid);
			}
		}
	}

	/* 
	 * If we have at least one deterministic file descriptor in any of the
	 * fd_sets, we need to wait for global barriers in order to compute the
	 * result of select.
	 *
	 * If we only have non-det fds, then we do not need to wait for global
	 * barriers. We can simply forward the request to the OS.
	 */
	/* See BUG message in do_sock_poll */
	if (!have_detfds)
		return false;

	done = false;

	do {
		/*
		 * Wait for the end of this distributed barrier; see note above
		 */
		//SHIM_LOG("Waiting for the end of this distributed barrier\n");
		WaitFor->lock();
		(*WaitFor) |= MyPeers;
		WaitFor->unlock();
		selectWaitTime.start();
		wait_for_distq_barrier();
		selectWaitTime.stop();
		//SHIM_LOG("Continuing...\n");

		//SHIM_LOG("Doing deterministic select\n");
		detrd_res = detrd; detwr_res = detwr; detex_res = detex;
		int ndet  = __do_sock_det_select(event, dmpnfds, &detrd_res, &detwr_res, &detex_res);
		//SHIM_LOG("   ... ret:%d\n", ndet);
		//SHIM_LOG("Doing nondeterministic select\n");
		nondetrd_res = nondetrd; nondetwr_res = nondetwr; nondetex_res = nondetex;
		int nnondet = __do_sock_nondet_select(event, dmpnfds, &nondetrd_res, &nondetwr_res, &nondetex_res);
		//SHIM_LOG("   ... ret:%d\n", nnondet);
		res = ndet + nnondet;
		SHIM_LOG("Total of %d sockets ready for stuff...\n", res);

		if (res > 0) {
			done = true;
			SHIM_LOG("Returning %d fds\n", res);
		}

	} while (!done);

	/*
	 * Combine the results of the det and nondet selects
	 */
	resrd = detrd_res; reswr = detwr_res; resex = detex_res;
	for (int i = 0; i < dmpnfds; i++) {
		if (FD_ISSET(i, &nondetrd_res))
			FD_SET(i, &resrd);
		if (FD_ISSET(i, &nondetwr_res))
			FD_SET(i, &reswr);
		if (FD_ISSET(i, &nondetex_res))
			FD_SET(i, &resex);
	}

	/*
	 * Write the resulting socket sets back to the caller
	 */
	//SHIM_LOG("Returning %d results to the caller.\n", res);
	if (dmprdp) {
		//SHIM_LOG("Writing read set\n");
		timed_dmp_shim_memcpy_sync(&resrd, dmprdp, set_size, TO_DMP, NULL);
		print_fdset(dmpnfds, "read", &resrd);
	}

	if (dmpwrp) {
		//SHIM_LOG("Writing write set\n");
		timed_dmp_shim_memcpy_sync(&reswr, dmpwrp, set_size, TO_DMP, NULL);
		print_fdset(dmpnfds, "write", &reswr);
	}

	if (dmpexp) {
		//SHIM_LOG("Writing except set\n");
		timed_dmp_shim_memcpy_sync(&resex, dmpexp, set_size, TO_DMP, NULL);
		print_fdset(dmpnfds, "except", &resex);
	}

	dmp_shim_emulate_syscall(res, &event->regs);
	return true;
}

bool BasicShim::do_sock_fcntl(shim_event *event)
{
	int dmpfd  = shim_syscall_arg0(&event->regs);
	int dmpcmd = shim_syscall_arg1(&event->regs);
	int dmpval = shim_syscall_arg2(&event->regs);

	long res = -1;

	PFileDescriptor pfile = _fdtable->get(dmpfd);

	SHIM_LOG("@%ld.%d: fcntl(fd:%d, %d, ...) \n", EVTIME(event), dmpfd, dmpcmd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	if (dmpcmd == F_GETFL) {
		/* We only support the O_NONBLOCK flag */
		res = pfile->nonblocking;

	} else if (dmpcmd == F_SETFL) {
		pfile->nonblocking = dmpval & O_NONBLOCK;
		SHIM_LOG("fd:%d is now set to %sO_NONBLOCK\n", dmpfd, (pfile->nonblocking ? "" : "~"));
		res = 0;

	} else {
		SHIM_WARN("Command %d not supported\n", dmpcmd);
		res = -EINVAL;
	}

	dmp_shim_emulate_syscall(res, &event->regs);
	return true;
}

/**
 * int getpeername(int s, struct sockaddr *addr, socklen_t *len) --
 *
 * TODO: Documentation
 */
bool BasicShim::do_sock_getpeername(shim_event *event)
{
	int dmpfd                   = shim_syscall_arg0(&event->regs);
	struct sockaddr_in *dmpaddr = (struct sockaddr_in *)shim_syscall_arg1(&event->regs);
	socklen_t *dmplen           = (socklen_t *)shim_syscall_arg2(&event->regs);

	struct sockaddr_in shimaddr;
	socklen_t shimlen;
	socklen_t tocopy;
	PFileDescriptor shimfd = _fdtable->get(dmpfd);
	PVSock vsock;
	long ret = 0;

	SHIM_LOG("@%ld.%d: getpeername(fd:%d, ...) \n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	if (shimfd == NULL) {
		SHIM_LOG(" ... fd:%d is not deterministic\n", dmpfd);
		return false;
	}

	if (shimfd->type != FDT_SOCKET) {
		SHIM_LOG(" fd:%d is not a socket!\n", dmpfd);
		ret = -ENOTSOCK;
		goto out_ret;
	}

	VSocks->lock();
	vsock = VSocks->get(shimfd->port);
	VSocks->unlock();

	if (!dmpaddr || !dmplen) {
		SHIM_LOG(" One of %p, %p was null\n", dmpaddr, dmplen);
		ret = -EFAULT;
		goto out_ret;
	}

	if (timed_dmp_shim_memcpy_sync((void *)&shimlen, (void *)dmplen, sizeof shimlen, FROM_DMP, NULL) < 0) {
		SHIM_WARN("   Couldn't read dmp len\n");
		ret = -EFAULT;
		goto out_ret;
	}

	if (shimlen < 0) {
		SHIM_WARN("    Got negative socklen (%d)\n", shimlen);
		ret = -EINVAL;
		goto out_ret;
	}


	memset(&shimaddr, 0, sizeof shimaddr);
	shimaddr.sin_family      = shimfd->family;
	shimaddr.sin_port        = htons(vsock->remote_port);
	shimaddr.sin_addr.s_addr = htonl(shimfd->addr);

	tocopy = (shimlen < sizeof(struct sockaddr_in) ? shimlen : sizeof(struct sockaddr_in));
	if (timed_dmp_shim_memcpy_sync((void *)&shimaddr, (void *)dmpaddr, tocopy, TO_DMP, NULL) < 0) {
		SHIM_WARN(" Couldn't write dmp addr\n");
		ret = -EFAULT;
		goto out_ret;
	}

	if (timed_dmp_shim_memcpy_sync((void *)&tocopy, (void *)dmplen, sizeof tocopy, TO_DMP, NULL) < 0) {
		SHIM_WARN(" Couldn't write dmp len\n");
		ret = -EFAULT;
		goto out_ret;
	}

	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;

 out_ret:
 	dmp_shim_emulate_syscall(ret, &event->regs);
 	return false;
}

/**
 * int getpeername(int s, struct sockaddr *addr, socklen_t *len) --
 *
 * TODO: Documentation
 */
bool BasicShim::do_sock_getsockname(shim_event *event)
{
	int dmpfd                   = shim_syscall_arg0(&event->regs);
	struct sockaddr_in *dmpaddr = (struct sockaddr_in *)shim_syscall_arg1(&event->regs);
	socklen_t *dmplen           = (socklen_t *)shim_syscall_arg2(&event->regs);

	struct sockaddr_in shimaddr;
	socklen_t shimlen;
	socklen_t tocopy;
	PFileDescriptor shimfd = _fdtable->get(dmpfd);
	long ret = 0;
	PDNode me = DetNodes->get(node_id);
	assert(me != NULL);

	SHIM_LOG("@%ld.%d: getsockname(fd:%d, ...) \n", EVTIME(event), dmpfd);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	if (shimfd == NULL) {
		SHIM_LOG(" ... fd:%d is not deterministic\n", dmpfd);
		return false;
	}

	if (shimfd->type != FDT_SOCKET) {
		SHIM_LOG(" fd:%d is not a socket!\n", dmpfd);
		ret = -ENOTSOCK;
		goto out_ret;
	}

	if (!dmpaddr || !dmplen) {
		SHIM_LOG(" One of %p, %p was null\n", dmpaddr, dmplen);
		ret = -EFAULT;
		goto out_ret;
	}

	if (timed_dmp_shim_memcpy_sync((void *)&shimlen, (void *)dmplen, sizeof shimlen, FROM_DMP, NULL) < 0) {
		SHIM_WARN("   Couldn't read dmp len\n");
		ret = -EFAULT;
		goto out_ret;
	}

	if (shimlen < 0) {
		SHIM_WARN("    Got negative socklen (%d)\n", shimlen);
		ret = -EINVAL;
		goto out_ret;
	}

	memset(&shimaddr, 0, sizeof shimaddr);
	shimaddr.sin_family      = shimfd->family;
	shimaddr.sin_port        = htons(shimfd->port);
	shimaddr.sin_addr.s_addr = htonl(me->address);

	tocopy = (shimlen < sizeof(struct sockaddr_in) ? shimlen : sizeof(struct sockaddr_in));
	if (timed_dmp_shim_memcpy_sync((void *)&shimaddr, (void *)dmpaddr, tocopy, TO_DMP, NULL) < 0) {
		SHIM_WARN(" Couldn't write dmp addr\n");
		ret = -EFAULT;
		goto out_ret;
	}

	if (timed_dmp_shim_memcpy_sync((void *)&tocopy, (void *)dmplen, sizeof tocopy, TO_DMP, NULL) < 0) {
		SHIM_WARN(" Couldn't write dmp len\n");
		ret = -EFAULT;
		goto out_ret;
	}

	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;

 out_ret:
 	dmp_shim_emulate_syscall(ret, &event->regs);
 	return false;
}


/**
 * int setsockopt(int s, int level, int name,
 *                const void *optval, socklen_t optlen) --
 *
 *   Set socket options for determinsitic fds.
 */
bool BasicShim::do_sock_setsockopt(shim_event *event)
{
	int       __unused dmpfd     = shim_syscall_arg0(&event->regs);
	int       __unused level     = shim_syscall_arg1(&event->regs);
	int       __unused name      = shim_syscall_arg2(&event->regs);
	void *    __unused dmpopt    = (void *)shim_syscall_arg3(&event->regs);
	socklen_t __unused dmpoptlen = shim_syscall_arg4(&event->regs);

	PFileDescriptor shimfd;
	PVSock vsock;
	int val;
	int valbool;
	int size = (dmpoptlen > sizeof(int) ? sizeof(int) : dmpoptlen);

	SHIM_LOG("@%ld.%d: setsockopt(fd:%d, %d (%s), %d (%s), %p, %d) \n", EVTIME(event), dmpfd,
		level, level == SOL_SOCKET  ? "SOL_SOCKET"  :
		       level == IPPROTO_TCP ? "IPPROTO_TCP" : "UNKNOWN",
		name, name == SO_SNDBUF    ? "SO_SNDBUF"    :
		      name == SO_RCVBUF    ? "SO_RCVBUF"    :
		      name == TCP_NODELAY  ? "TCP_NODELAY"  :
		      name == SO_REUSEADDR ? "SO_REUSEADDR" : 
		      name == SO_KEEPALIVE ? "SO_KEEPALIVE" : "UNKNOWN",
		dmpopt, dmpoptlen);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	shimfd = _fdtable->get(dmpfd);
	if (shimfd == NULL) {
		SHIM_LOG(" ... fd:%d is not deterministic\n", dmpfd);
		return false;
	}

	if (shimfd->type != FDT_SOCKET) {
		SHIM_LOG(" fd:%d is not a socket!\n", dmpfd);
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(shimfd->port);
	VSocks->unlock();

	if (vsock == NULL) {
		SHIM_WARN(" fd:%d is a socket, but couldn't find vsock!\n", dmpfd);
		return false;
	}

	timed_dmp_shim_memcpy_sync(&val, dmpopt, size, FROM_DMP, NULL);
	valbool = !!val;

	SHIM_WARN("setsockopt not implemented yet; feigning success and\n");
	SHIM_WARN("hoping this work out alright in the end.\n");
	
	vsock->lock();
	if (level == SOL_SOCKET) {
		switch (name) {
		case SO_SNDBUF:
			vsock->sock_sndbuf = val;
			SHIM_LOG("    sendbuf set to %d\n", vsock->sock_sndbuf);
			break;
		case SO_RCVBUF: 
			vsock->sock_rcvbuf = val;
			SHIM_LOG("    recvbuf set to %d\n", vsock->sock_rcvbuf);
			break;
		case SO_REUSEADDR:
			vsock->sock_reuseaddr = valbool;
			SHIM_LOG("    reuseaddr set to %d\n", vsock->sock_reuseaddr);
			break;
		case SO_KEEPALIVE:
			vsock->sock_keepalive = valbool;
			SHIM_LOG("    keepalive set to %d\n", vsock->sock_keepalive);
			break;
		default:
			SHIM_WARN("Unrecognized socket option %d\n", name);
			break;
		}

	} else if (level == IPPROTO_TCP) {
		switch (name) {
		case TCP_NODELAY:
			vsock->tcp_nodelay = valbool;
			SHIM_LOG("    nodelay set to %d\n", vsock->tcp_nodelay);
			break;
		default:
			SHIM_WARN("Unrecognized TCP option %d\n", name);
			break;
		}

	} else {
		SHIM_WARN("Unrecognized option level %d\n", level);
	}
	vsock->unlock();

	dmp_shim_emulate_syscall(0, &event->regs);
	return true;
}

bool BasicShim::do_sock_getsockopt(shim_event *event)
{
	int       __unused dmpfd     = shim_syscall_arg0(&event->regs);
	int       __unused level     = shim_syscall_arg1(&event->regs);
	int       __unused name      = shim_syscall_arg2(&event->regs);
	void *    __unused dmpopt    = (void *)shim_syscall_arg3(&event->regs);
	socklen_t * __unused dmppoptlen = (socklen_t *)shim_syscall_arg4(&event->regs);

	PFileDescriptor shimfd;
	PVSock vsock;
	int val = 0;
	int valsize = 0;
	int copysize;
	socklen_t dmpoptlen;

	timed_dmp_shim_memcpy_sync((void *)&dmpoptlen, (void *)dmppoptlen, sizeof(socklen_t), FROM_DMP, NULL);

	SHIM_LOG("@%ld.%d: getsockopt(fd:%d, %d (%s), %d (%s), %p, %p (%d)) \n", EVTIME(event), dmpfd,
		level, level == SOL_SOCKET  ? "SOL_SOCKET"  :
		       level == IPPROTO_TCP ? "IPPROTO_TCP" : "UNKNOWN",
		name, name == SO_SNDBUF    ? "SO_SNDBUF"    :
		      name == SO_RCVBUF    ? "SO_RCVBUF"    :
		      name == TCP_NODELAY  ? "TCP_NODELAY"  :
		      name == SO_REUSEADDR ? "SO_REUSEADDR" : 
		      name == SO_KEEPALIVE ? "SO_KEEPALIVE" : "UNKNOWN",
		dmpopt, dmppoptlen, dmpoptlen);
	if (reexec_detnet) {
		SHIM_LOG("  ... reexec_detnet is set: allowing RecPlayShim to continue\n");
		return false;
	}

	shimfd = _fdtable->get(dmpfd);
	if (shimfd == NULL) {
		SHIM_LOG(" ... fd:%d is not deterministic\n", dmpfd);
		return false;
	}

	if (shimfd->type != FDT_SOCKET) {
		SHIM_LOG(" fd:%d is not a socket!\n", dmpfd);
		return false;
	}

	VSocks->lock();
	vsock = VSocks->get(shimfd->port);
	VSocks->unlock();

	if (vsock == NULL) {
		SHIM_WARN(" fd:%d is a socket, but couldn't find vsock!\n", dmpfd);
		return false;
	}

	SHIM_WARN("getsockopt not implemented yet; feigning success and\n");
	SHIM_WARN("hoping this work out alright in the end.\n");
	
	vsock->lock();
	if (level == SOL_SOCKET) {
		switch (name) {
		case SO_SNDBUF:
			val = vsock->sock_sndbuf;
			valsize = sizeof (vsock->sock_sndbuf);
			SHIM_LOG("    sendbuf is %d\n", val);
			break;
		case SO_RCVBUF: 
			val = vsock->sock_rcvbuf;
			valsize = sizeof (vsock->sock_rcvbuf);
			SHIM_LOG("    recvbuf is %d\n", val);
			break;
		case SO_REUSEADDR:
			val = vsock->sock_reuseaddr;
			valsize = sizeof (vsock->sock_reuseaddr);
			SHIM_LOG("    reuseaddr is %d\n", val);
			break;
		case SO_KEEPALIVE:
			val = vsock->sock_keepalive;
			valsize = sizeof (vsock->sock_keepalive);
			SHIM_LOG("    keepalive is %d\n", val);
			break;
		default:
			SHIM_WARN("Unrecognized socket option %d\n", name);
			break;
		}

	} else if (level == IPPROTO_TCP) {
		switch (name) {
		case TCP_NODELAY:
			val = vsock->tcp_nodelay;
			valsize = sizeof (vsock->tcp_nodelay);
			SHIM_LOG("    nodelay is %d\n", val);
			break;
		default:
			SHIM_WARN("Unrecognized TCP option %d\n", name);
			break;
		}

	} else {
		SHIM_WARN("Unrecognized option level %d\n", level);
	}
	vsock->unlock();

	copysize = dmpoptlen < valsize ? dmpoptlen : valsize;

	timed_dmp_shim_memcpy_sync((void *)&copysize, (void *)dmppoptlen, sizeof(socklen_t), TO_DMP, NULL);
	timed_dmp_shim_memcpy_sync((void *)&val, (void *)dmpopt, copysize, TO_DMP, NULL);
	dmp_shim_emulate_syscall(0, &event->regs);

	return true;
}

/******************************************************************************
 *                         Networking stuff for DDOS                          *
 ******************************************************************************/

/**
 * accept_control_connection() --
 * 
 *   Wait for an incoming connection on this socket's control channel. Returns
 *   0 on success and a negative value on error.
 *
 *   Parameters:
 *       nodeid  -- The nodeid we're assinging to this incoming connection
 *
 *   Returns:
 *       0 on success, < 0 on failure
 */
int BasicShim::accept_control_connection(int nodeid)
{
	int client_fd, error = -1;
	struct sockaddr_in client_addr;
	socklen_t client_sz;
	PDNode client = (*DetNodes)[nodeid];
	PDNode me     = DetNodes->get(node_id);

	const int LOCAL1 = 0x7f000001;
	const int LOCAL2 = 0x7f000101;

	/*
	 * Make sure we have some valid input and a listening socket...
	 */
	if (control_sock < 0) {
		SHIM_ERR("Cannot accept connection from a non-listening socket!\n");
		goto out_ret;
	}

	if (!client) {
		SHIM_ERR("Invalid nodeid %d\n", nodeid);
		goto out_ret;
	}

	/*
	 * Wait for the incoming connection...
	 */
	client_sz = sizeof(client_addr);
	client_fd = accept(control_sock, (struct sockaddr *)&client_addr, &client_sz);
	if (client_fd < 0) {
		error = -errno;
		SHIM_ERR("accept() failed: %s\n", strerror(errno));
		goto out_ret;
	}

	client->address = ntohl(client_addr.sin_addr.s_addr);
	if (client->address == LOCAL1 || client->address == LOCAL2)
		client->address = me->address;
	SHIM_LOG("Received new connection from %s:%d\n", uint32_to_ip(client->address), ntohs(client_addr.sin_port));
	client->ctrlfd  = client_fd;
	
	return 0;

 out_ret:
 	return error;
}


bool BasicShim::start_remote_shim(int nodeid, const char *host, const char *cmd)
{
	/*
	 * Perform the remote exec
	 */
	SHIM_LOG("Executing '%s' on '%s'...\n", cmd, host);
	if (remote_exec(host, cmd, 0) < 0) {
		SHIM_ERR("Execute failed!\n");
		return false;
	}

	/*
	 * Wait for the remote shim to "call home" to establish the control connection
	 */
	SHIM_LOG("Waiting for control connection from %s...\n", host);
	if (accept_control_connection(nodeid) < 0) {
		SHIM_ERR("Control connection failed\n");
		return false;
	}

	/*
	 * Now that we've created a remote dpg, bump the num_dpgs count
	 * so we know when it is safe for the master dpg to exit
	 */
	SHIM_LOG("Incrementing dpg count: %d -> %d\n", num_dpgs, num_dpgs + 1);
	++num_dpgs;
	
	/*
	 * Send the initial configuration information to the new remote node
	 */
	PDNode peer = (*DetNodes)[nodeid];
	SHIM_LOG("Writing configuration to node %d...\n", nodeid);
	SHIM_LOG("    node_id: %d\n", peer->nodeid);
	SHIM_LOG("    ctrl_pt: %d\n", peer->control_port);
	SHIM_LOG("    distq  : %ld\n", distq_size);
	writen(peer->ctrlfd, (char *)&peer->nodeid,       sizeof peer->nodeid);
	writen(peer->ctrlfd, (char *)&peer->control_port, sizeof peer->control_port);
	writen(peer->ctrlfd, (char *)&distq_size,         sizeof distq_size);
	SHIM_LOG("Done!\n");

	return true;
}

/**
 * add_manifest(filename) --
 *
 *   Each line of the given file is assumed to be of the form:
 *
 *     [user@]host ports cmd
 *
 *   Add manifest will remotely execute the given command on the remote host,
 *   and wait for the remote machine to establish a control connection back to
 *   this shim.
 *
 *   TODO:
 *   If reexec_detnet is set to true, then the control channels are not created
 *   since we are recording/replaying the communication, rather than enforcing
 *   deterministic communication.
 *
 *   Parameters:
 *       filename  The file to parse
 *
 *   Returns:
 *       Boolean success value
 */
bool BasicShim::add_manifest(string filename)
{
	FILE *mfp;
	bool success = true;
	char buffer[1024];
	int ret;
	DNodeMap::const_iterator i;
	enum {PARAMS, HOSTS} mode = HOSTS;
	PDNode me;
	int flags;
	struct sockaddr_in sin;

	/* Arbitrary default; can be overridden in manifest */
	distq_size = 100;

	/* Initially, we're the only DPG */
	num_dpgs = 1;

	/* Creating a listening control socket */
	control_sock = create_listening_socket(DMP_CONTROL_PORT);
	if (this->control_sock < 0) {
		SHIM_ERR("Could not create listening socket: %s\n", strerror(errno));
		success = false;
		goto out_ret;
	}

	mfp = fopen(filename.c_str(), "r");
	if (mfp == NULL) {
		SHIM_ERR("Couldn't open manifest file: %s\n", strerror(errno));
		success = false;
		goto out_close;
	}

	while (fgets(buffer, sizeof buffer, mfp) != NULL) {
		char *cmd, *host, *tmp, *val, *ports, *tmp2, *tmp3, *ctrlport;

		buffer[strlen(buffer)-1] = '\0'; /* Chomp the newline */
		host = strtok_r(buffer, " \t", &tmp);

		/* Chomp blanks or comments */
		if (host == NULL || *host == '#')
			continue;
	
		/* Detect mode transitions */
		if (strcmp(host, "[params]") == 0) {
			SHIM_LOG("Changing mode to params\n");
			mode = PARAMS;
			continue;

		} else if (strcmp(host, "[hosts]") == 0) {
			SHIM_LOG("Changing mode to hosts\n");
			mode = HOSTS;
			continue;
		}

		if (mode == PARAMS) {
			val = strtok_r(NULL, " \t", &tmp);
			if (strcmp(host, "dqsize") == 0) {
				uint64_t tval = atoi(val);
				SHIM_LOG("Setting distq size to %lu\n", this->distq_size);
				this->distq_size = tval;
			} else {
				SHIM_LOG("Ignoring unknown option %s\n", host);
			}

		} else { /* mode == HOSTS */
			ctrlport = strtok_r(NULL, " \t", &tmp);
			assert(ctrlport);

			ports = strtok_r(NULL, " \t", &tmp);
			assert(ports);
					
			/*
			 * We're adding a new host, so create a DNode struct to hold its meta information 
			 */
			PDNode newnode(new DNode);
			newnode->nodeid  = num_dpgs; /* Will be incremented by start_remote_shim */
			newnode->address = -1; /* Will be filled in by accept_control_connection */
			newnode->ctrlfd  = -1; /*  "   "   */
			newnode->exiting = false;
			newnode->control_port = atoi(ctrlport);
			newnode->ports.clear();

			/*
			 * Parse the list of ports, and append each to newnode's deterministic port set
			 */
			SHIM_LOG("Reading ports from list %s\n", ports);
			for (char *port = strtok_r(ports, ",", &tmp2); port; port = strtok_r(NULL, ",", &tmp2)) {
				char *start_port = strtok_r(port, "-", &tmp3);
				char *stop_port  = strtok_r(NULL, "-", &tmp3);

				assert(start_port);
				int pstart = atoi(start_port);
				int pstop  = stop_port != NULL ? atoi(stop_port) : pstart;

				if (pstop < pstart)
					pstop = pstart;

				for (; pstart <= pstop; pstart++) {
					if (pstart > 0) {
						SHIM_LOG("Adding deterministic port %d to node %d\n", pstart, newnode->nodeid);
						newnode->ports.insert(pstart);
					}
				}
			}
		
			/*
			 * Add this entry to the map of det nodes
			 */
			(*DetNodes)[newnode->nodeid] = newnode;

			/*
			 * Grab the rest of the line and treat it as the command to be executed
			 */
			while (*tmp && isspace(*tmp)) tmp++;
			cmd = tmp;

			/*
			 * Start the remote program
			 */
			if ((ret = start_remote_shim(newnode->nodeid, host, cmd)) < 0) {
				SHIM_ERR("Execute failed\n");
				success = false;
				goto out_fclose;
			}
		}
	}

	/* 
	 * Once all remote nodes have started, we need to give them the
	 * opportunity to establish their own control channels to the other
	 * nodes.
	 */
	for (i = DetNodes->begin(); i != DetNodes->end(); ++i) {
		/*
		 * The master node as a DNode for every peer. The peers
		 * construct a DNode for the master when they are created.
		 */
		uint32_t ndpgs = DetNodes->size() - 1; /* Skip sending mine, since they will create one */
		PDNode peer = i->second;

		if (peer->nodeid == node_id) {
			SHIM_LOG("Skipping myself\n");
			continue;
		}

		/*
		 * First, the master sends his det ports
		 */
		SHIM_LOG("Master node sending %ld ports to node %d\n", (*DetNodes)[0]->ports.size(), peer->nodeid);
		uint32_t nports = (*DetNodes)[0]->ports.size();
		writen(peer->ctrlfd, (char *)&nports, sizeof nports);
		for (PortSet::const_iterator j = (*DetNodes)[0]->ports.begin(); j != (*DetNodes)[0]->ports.end(); ++j) {
			uint16_t port = *j;
			SHIM_LOG("    Sending port %d\n", port);
			writen(peer->ctrlfd, (char *)&port, sizeof port);
		}

		SHIM_LOG("Sending information about %d dpgs to node %d\n", ndpgs, peer->nodeid);
		writen(peer->ctrlfd, (char *)&ndpgs, sizeof ndpgs);
		for (DNodeMap::const_iterator j = DetNodes->begin(); j != DetNodes->end(); ++j) {
			PDNode cur = j->second;
			uint32_t nports = cur->ports.size();

			if (cur->nodeid == 0) {
				/* Skip the master node; they've already created a real one */
				continue;
			}

			SHIM_LOG("    Sending %d: %s\n", cur->nodeid, uint32_to_ip(cur->address));
			writen(peer->ctrlfd, (char *)&cur->nodeid,  sizeof cur->nodeid);
			writen(peer->ctrlfd, (char *)&cur->address, sizeof cur->address);
			writen(peer->ctrlfd, (char *)&cur->control_port, sizeof cur->control_port);
			writen(peer->ctrlfd, (char *)&nports,       sizeof nports);
			for (PortSet::iterator i = cur->ports.begin(); i != cur->ports.end(); i++) {
				uint16_t port = *i;
				SHIM_LOG("        Sending port %d\n", port);
				writen(peer->ctrlfd, (char *)&port, sizeof port);
			}
		}

		SHIM_LOG("Waiting for remote node to finish\n");
		ndpgs = -1;
		dreadn(peer->ctrlfd, (char *)&ndpgs, sizeof ndpgs);
		SHIM_LOG("Received ack of %d/%d\n", ndpgs, num_dpgs);
		if (ndpgs != num_dpgs - 1)
			SHIM_WARN("Expected a different value?\n");
	}

	/*
	 * After the above loop, all peers will create a listening socket and
	 * begin accepting control connections
	 */
	for (i = DetNodes->begin(); i != DetNodes->end(); ++i) {
		int tempfd;
		PDNode peer = i->second;
		const uint8_t go = 1;
		uint8_t ack = -1;

		if (peer->nodeid == 0) {
			/* Skip myself */
			continue;
		}

		if ((tempfd = __connect_to(peer->address, peer->control_port)) < 0) {
			SHIM_ERR("Couldn't connect to node %d\n", peer->nodeid);
			return false;
		}
	
		writen(tempfd, (char *)&node_id, sizeof node_id);
		writen(tempfd, (char *)&go, sizeof go);
		dreadn(tempfd, (char *)&ack, sizeof ack);

		if (ack != 1) {
			SHIM_ERR("Bad ack value %d\n", ack);
			return false;
		}

		close(tempfd);
	}

	/*
	 * Let the master node create a control connection to itself
	 */
	SHIM_LOG("Creating a new connection to myself\n");
	me = DetNodes->get(0);
	if ((me->ctrlfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		SHIM_ERR("Coudln't create a new socket\n");
		return false;
	}

	SHIM_LOG("Getting flags for new fd\n");
	if ((flags = fcntl(me->ctrlfd, F_GETFL)) < 0) {
		SHIM_ERR("Couldn't get flags: %s\n", strerror(errno));
		return false;
	}

	flags |= O_NONBLOCK;
	SHIM_LOG("Making new socket non-blocking\n");
	if ((fcntl(me->ctrlfd, F_SETFL, flags)) < 0) {
		SHIM_ERR("Couldn't set flags: %s\n", strerror(errno));
		return false;
	}

	memset(&sin, 0, sizeof sin);
	sin.sin_family = AF_INET;
	sin.sin_port   = htons(me->control_port);
	sin.sin_addr.s_addr   = inet_addr("127.0.0.1");
	
	SHIM_LOG("My ctrlfd before connect: %d, 2:%d\n", me->ctrlfd, me->ctrlfd2);
	if ((ret = connect(me->ctrlfd, (struct sockaddr *)&sin, sizeof sin)) < 0)
		SHIM_LOG("Connect returned %d\n", ret); 

	if ((me->ctrlfd2 = accept(control_sock, NULL, NULL)) < 0) {
		SHIM_ERR("Couldn't accept new connection: %s\n", strerror(errno));
		return false;
	}

	while (me->ctrlfd < 0) {
		if ((ret = connect(me->ctrlfd, (struct sockaddr *)&sin, sizeof sin)) < 0)
			SHIM_LOG("Connect returned %d\n", ret); 
	}
	SHIM_LOG("My ctrlfd after connect: %d, 2:%d\n", me->ctrlfd, me->ctrlfd2);

	SHIM_LOG("Getting flags for new fd\n");
	if ((flags = fcntl(me->ctrlfd, F_GETFL)) < 0) {
		SHIM_ERR("Couldn't get flags: %s\n", strerror(errno));
		return false;
	}

	flags &= ~O_NONBLOCK;
	SHIM_LOG("Making new socket blocking again\n");
	if ((fcntl(me->ctrlfd, F_SETFL, flags)) < 0) {
		SHIM_ERR("Couldn't set flags: %s\n", strerror(errno));
		return false;
	}

	/*
	 * All peers have now established pair-wise connections; need to let
	 * everyone know we're done.
	 */
	for (i = DetNodes->begin(); i != DetNodes->end(); ++i) {
		int tempfd;
		PDNode peer = i->second;
		const uint8_t done = 2;
		uint8_t ack = -1;
		
		if (peer->nodeid != 0) {
			/* Skip myself */

			if ((tempfd = __connect_to(peer->address, peer->control_port)) < 0) {
				SHIM_ERR("Couldn't connect to node %d\n", peer->nodeid);
				return false;
			}

			writen(tempfd, (char *)&node_id, sizeof node_id);
			writen(tempfd, (char *)&done, sizeof done);
			dreadn(tempfd, (char *)&ack, sizeof ack);

			if (ack != 1) {
				SHIM_ERR("Bad ack value %d\n", ack);
				return false;
			}

			close(tempfd);
		}

		/*
		 * Now that we've created all control channels, we need to
		 * create a managing thread for each control connection
		 */
		ControlManagerArgs *args = new ControlManagerArgs();
		args->shim = this;
		args->peerid = peer->nodeid;
		if (peer->nodeid == node_id)
			args->ctrlfd = peer->ctrlfd2;
		else
			args->ctrlfd = peer->ctrlfd;
		if (pthread_create(&peer->manager, NULL, ControlManagerFn, args) != 0) {
			SHIM_ERR("Couldn't create a managing thread for node:%d\n", peer->nodeid);
			return false;
		}
	}
 
 out_fclose:
	fclose(mfp);
 out_close:
 	close(this->control_sock);
 out_ret:
	return success;
}

/**
 * set_master_node(hostname, port) --
 *
 *   Set the hostname and port of the master node. When the shim first begins
 *   executing, it will establish a control connection to the given node and
 *   port. The shim will wait until a go-ahead message is received from the
 *   master before executing the program. This channal is later used to
 *   globally coordinate the nodes in the system.
 *
 *   Parameters:
 *       hostname  -- Hostname or ip address of master node
 *       port      -- Port on the master to connect to
 *
 *   Returns:
 *       Boolean success value
 */
bool BasicShim::set_master_node(string host, uint16_t port)
{
	uint32_t ndpgs, i;
	int newfd;
	struct sockaddr_in sin;
	socklen_t socklen;
	uint8_t done = 0;
	uint16_t myport;

	/*
	 * Establish a connection to the master node that spawned us
	 */
	newfd = connect_to(host.c_str(), port);
	if (newfd < 0) {
		SHIM_ERR("Could not establish connection to master node: %s\n",
		         strerror(errno));
		return false;
	}

	/*
	 * Now that this node has connected to the master, populate a DNode
	 * entry for the master for future reference. Currently, the initial
	 * master is always node id 0
	 */
	socklen = sizeof sin;
	if (getpeername(newfd, (struct sockaddr *)&sin, &socklen) != 0) {
		SHIM_ERR("Couldn't lookup peer name: %s\n", strerror(errno));
		return false;
	}

	PDNode master(new DNode);
	master->nodeid = 0;
	master->address = ntohl(sin.sin_addr.s_addr);
	FillLocalIP(master);
	master->ctrlfd = newfd;
	master->exiting = false;
	master->ports.clear();
	master->control_port = port;
	(*DetNodes)[0] = master;

	/*
	 * Get our configuration information from the master
	 */
	SHIM_LOG("Waiting for configuration from master (address: %x)...\n", master->address);
	dreadn(master->ctrlfd, (char *)&node_id,    sizeof node_id);
	dreadn(master->ctrlfd, (char *)&myport,     sizeof myport);
	dreadn(master->ctrlfd, (char *)&distq_size, sizeof distq_size);
	SHIM_LOG("My configuration:\n");
	SHIM_LOG("    node_id:    %d\n", node_id);
	SHIM_LOG("    myport:     %d\n", myport);
	SHIM_LOG("    distq_size: %lu\n", distq_size);

	/*
	 * Get the list of the master's det ports
	 */
	uint32_t nports;
	dreadn(master->ctrlfd, (char *)&nports, sizeof nports);
	SHIM_LOG("Reading %d ports from master\n", nports);
	for (int i = 0; i < nports; i++) {
		uint16_t port;
		dreadn(master->ctrlfd, (char *)&port, sizeof port);
		master->ports.insert(port);
		SHIM_LOG("    Got port %d\n", port);
	}

	/*
	 * Now we need to establish the pair-wise control channels with each of
	 * the other distributed nodes.
	 *
	 * We need to:
	 *
	 *   0) Receive the list of all peer nodes in the DDPG from the master
	 *
	 *   1) Create the listening socket to accept new control channel
	 *      requests on
	 *
	 *   2) Receive and/or establish connections until we have a control
	 *      channel to every node
	 *
	 *   3) Close the listening socket (DPGs can't join a DDPG later)
	 */
	/* Step 0 */
	SHIM_LOG("Waiting for DPG count from master...\n");
	dreadn(master->ctrlfd, (char *)&ndpgs, sizeof ndpgs);
	SHIM_LOG("Waiting for information from %d DPGs...\n", ndpgs);
	for (i = 0; i < ndpgs; i++) {
		uint32_t nports;
		PDNode newpeer(new DNode);
		
		dreadn(master->ctrlfd, (char *)&newpeer->nodeid, sizeof newpeer->nodeid);
		SHIM_LOG("    Got node id: %d...\n", newpeer->nodeid);
		dreadn(master->ctrlfd, (char *)&newpeer->address, sizeof newpeer->address);
		SHIM_LOG("    Got address: %s...\n", uint32_to_ip(newpeer->address));
		dreadn(master->ctrlfd, (char *)&newpeer->control_port, sizeof newpeer->control_port);
		SHIM_LOG("    Got control port: %d...\n", newpeer->control_port);
		dreadn(master->ctrlfd, (char *)&nports, sizeof nports);
		SHIM_LOG("    Got number of det ports: %d...\n", nports);
		for (int j = 0; j < nports; j++) {
			uint16_t port;
			dreadn(master->ctrlfd, (char *)&port, sizeof port);
			SHIM_LOG("        Read port %d/%d as %d\n", j+1, nports, port);
			newpeer->ports.insert(port);
		}
		
		newpeer->ctrlfd = -1;
		newpeer->exiting = false;

		(*DetNodes)[newpeer->nodeid] = newpeer;
		SHIM_LOG("Done with peer %d!\n", newpeer->nodeid);
	}
	
	writen(master->ctrlfd, (char *)&ndpgs, sizeof ndpgs);

	/* Step 1 */
	if ((control_sock = create_listening_socket(myport)) < 0) {
		SHIM_ERR("Couldn't create listening control socket: %s\n", strerror(errno));
		return false;
	}


	/* Step 2 */
	SHIM_LOG("Node %d waiting for control channel connections...\n", node_id)
	done = 0;
	while (!done) {
		struct sockaddr_in newsin;
		socklen_t socklen;
		int newfd;
		uint32_t addr;
		uint32_t peerid;

		socklen = sizeof newsin;
		if ((newfd = accept(control_sock, (struct sockaddr *)&newsin, &socklen)) < 0) {
			SHIM_ERR("Error during acceptance: %s\n", strerror(errno));
			return false;
		}
		
		addr = ntohl(newsin.sin_addr.s_addr);
		SHIM_LOG(" Connection from %s:%d\n", uint32_to_ip(addr), ntohs(newsin.sin_port));
		SHIM_LOG("    Waiting for nodeid...\n");
		dreadn(newfd, (char *)&peerid, sizeof peerid);
		SHIM_LOG("    Got nodeid:%d\n", peerid);

		if (peerid == 0) {
			uint8_t status;

			/* Connection was from the master node */
			SHIM_LOG("Got connection from master... reading command.\n");
			dreadn(newfd, (char *)&status, sizeof status);

			if (status == 1) {
				uint8_t success;
				SHIM_LOG("   Our turn to go!\n");

				if (!establish_control_channels()) {
					SHIM_ERR("Couldn't establish control channels!\n");
					done = 2;
					success = 0;

				} else {
					SHIM_LOG("All channels established.\n");
					success = 1;
				}

				writen(newfd, (char *)&success, sizeof success);

			} else if (status == 2) {
				SHIM_LOG("   Everyone is done!\n");
				/* Everyone is finished */
				done = 1;
				writen(newfd, (char *)&done, sizeof done);

			} else {
				/* Bugs, bugs, everywhere... */
				SHIM_ERR("Unknown status %d from master\n", status);
				done = 2;
				writen(newfd, (char *)&done, sizeof done);
			}

			/* We don't need this channel to the master; we already have one */
			close(newfd);

		} else {
			/* The new connection was from another peer node */
			SHIM_LOG("Writing my node_id: %d\n", node_id);
			writen(newfd, (char *)&node_id, sizeof node_id);
	
			SHIM_LOG("New connection from peer %d\n", peerid);
			if ((*DetNodes)[peerid]->ctrlfd >= 0)
				SHIM_WARN("Overriding existing control descriptor %d?\n", (*DetNodes)[peerid]->ctrlfd);

			(*DetNodes)[peerid]->ctrlfd = newfd;
		}
	}

	/* Step 3 */
	close(control_sock);

	/* All done! */
	SHIM_LOG("Node %d going!\n", node_id);
	return done == 1;
}

bool BasicShim::add_det_port_range(const char *range)
{
	char *temp = strdup(range);
	char *first;
	char *last;
	int i, firstn, lastn;

	assert(temp);

	first = strtok(temp, "-");
	last  = strtok(NULL, "-");

	if (!first)
		return false;

	firstn = atoi(first);
	if (!last)
		lastn = firstn;
	else
		lastn = atoi(last);


	printf("Adding ports from %s to %s\n", first, last);
	for (i = firstn; i <= lastn; i++)
		add_det_port(i);

	free(temp);
	return true;
}

bool BasicShim::add_det_ports(const char *str)
{
	char *temp = strdup(str);
	char *tok;
	assert(temp);

	for (tok = strtok(temp, ","); tok != NULL; tok = strtok(NULL, ","))
		add_det_port_range(tok);

	free(temp);
	return true;
}

bool BasicShim::add_det_port(uint16_t port)
{
	DNodeMap::const_iterator pme = DetNodes->find(0);
	assert(pme != DetNodes->end());
	
	SHIM_LOG("Adding %d to portset\n", port);
	PDNode me = pme->second;
	me->ports.insert(port);

	return true;
}

/**
 * step_slotted_buffers() --
 * 
 *   Make data sent in the previous quantum available for the DMP thread to consume.
 *
 *   Returns:
 *       Boolean success value
 */
bool BasicShim::step_slotted_buffers(void)
{
	SHIM_WARN("Deprecated!\n");
	return true;
}

/**
 * establish_control_channels() --
 *
 *   This is a helper function called by set_master_node; this method is called
 *   by peers to finish establishing the control channel connections to the
 *   other nodes in the DDPG. It should only be used once by each peer.
 *
 *   Parameters:
 *       None
 *
 *   Returns:
 *        Boolean success value
 */
bool BasicShim::establish_control_channels(void)
{
	DNodeMap::iterator i;

	SHIM_LOG("Creating missing control channels\n");

	/*
	 * Walk the peer list, connecting to nodes we don't already have a
	 * control channel for.
	 */
	for (i = DetNodes->begin(); i != DetNodes->end(); ++i) {
		int newfd;
		uint32_t their_id;
		int flags, ret;
		struct sockaddr_in sin;
		PDNode cur = i->second;

		SHIM_LOG("Checking node (id %d, address %s, ctrlfd %d, manager %d)...\n",
			cur->nodeid, uint32_to_ip(cur->address), cur->ctrlfd, (int)cur->manager);

		if (cur->nodeid == node_id) {
			SHIM_LOG("Creating control channel to myself\n");
			if (cur->ctrlfd >= 0)
				SHIM_WARN("Already have a socket to myself?\n");

			if ((cur->ctrlfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
				SHIM_ERR("Couldn't create a new socket\n");
				return false;
			}

			SHIM_LOG("Getting flags for new fd\n");
			if ((flags = fcntl(cur->ctrlfd, F_GETFL)) < 0) {
				SHIM_ERR("Couldn't get flags: %s\n", strerror(errno));
				return false;
			}

			flags |= O_NONBLOCK;
			SHIM_LOG("Making new socket non-blocking\n");
			if ((fcntl(cur->ctrlfd, F_SETFL, flags)) < 0) {
				SHIM_ERR("Couldn't set flags: %s\n", strerror(errno));
				return false;
			}

			memset(&sin, 0, sizeof sin);
			sin.sin_family = AF_INET;
			sin.sin_port   = htons(cur->control_port);
			sin.sin_addr.s_addr   = inet_addr("127.0.0.1");
			
			SHIM_LOG("My ctrlfd before connect: %d, 2:%d\n", cur->ctrlfd, cur->ctrlfd2);
			if ((ret = connect(cur->ctrlfd, (struct sockaddr *)&sin, sizeof sin)) < 0)
				SHIM_LOG("Connect returned %d\n", ret); 

			if ((cur->ctrlfd2 = accept(control_sock, NULL, NULL)) < 0) {
				SHIM_ERR("Couldn't accept new connection: %s\n", strerror(errno));
				return false;
			}

			while (cur->ctrlfd < 0) {
				if ((ret = connect(cur->ctrlfd, (struct sockaddr *)&sin, sizeof sin)) < 0)
					SHIM_LOG("Connect returned %d\n", ret); 
			}
			SHIM_LOG("My ctrlfd after connect: %d, 2:%d\n", cur->ctrlfd, cur->ctrlfd2);
			
			SHIM_LOG("Getting flags for new fd\n");
			if ((flags = fcntl(cur->ctrlfd, F_GETFL)) < 0) {
				SHIM_ERR("Couldn't get flags: %s\n", strerror(errno));
				return false;
			}

			flags &= ~O_NONBLOCK;
			SHIM_LOG("Making new socket blocking again\n");
			if ((fcntl(cur->ctrlfd, F_SETFL, flags)) < 0) {
				SHIM_ERR("Couldn't set flags: %s\n", strerror(errno));
				return false;
			}
		}
		
		/* Already have one... */
		if (cur->ctrlfd >= 0) {
			SHIM_LOG("Already have a channel to node %d\n", cur->nodeid);

		} else {
			SHIM_LOG("Connecting to %s:%d\n", uint32_to_ip(cur->address), cur->control_port);
			if ((newfd = __connect_to(cur->address, cur->control_port)) < 0) {
				SHIM_ERR("Connection failed: %s:%d. %s\n", uint32_to_ip(cur->address),
					cur->control_port, strerror(errno));
				return false;
			}

			/* Introduce ourselves... */
			SHIM_LOG("Connection established, introductions are in order...\n");
			SHIM_LOG("   Writing my nodeid: %d\n", node_id);
			writen(newfd, (char *)&node_id, sizeof node_id);
			SHIM_LOG("   Reading their id...\n");
			dreadn(newfd, (char *)&their_id, sizeof their_id);
			SHIM_LOG("       Got %d\n", their_id);
			if (their_id != cur->nodeid) {
				SHIM_ERR("ID mismatch? expected %d, got %d\n", cur->nodeid, their_id);
				return false;
			}

			cur->ctrlfd = newfd;
		}

		/* Create managing threads */
		if (cur->manager == 0) {
			SHIM_LOG("Creating a manager thread for peer:%d\n", cur->nodeid);
			/*
			 * Now that we've created a control channel, we need to
			 * create a managing thread to asynchronously receive
			 * data on this socket.
			 */
			ControlManagerArgs *args = new ControlManagerArgs();
			args->shim   = this;
			args->peerid = cur->nodeid;
			if (cur->nodeid == node_id)
				args->ctrlfd = cur->ctrlfd2;
			else	
				args->ctrlfd = cur->ctrlfd;
			if (pthread_create(&cur->manager, NULL, ControlManagerFn, args) != 0) {
				SHIM_ERR("Couldn't create a managing thread for node:%d\n", cur->nodeid);
				return false;
			}
		}
			
		SHIM_LOG("Next!\n");
	}

	SHIM_LOG("Node %d all done...\n", node_id);
	return true;
}

/**
 * wait_for_global_barrier(status) --
 *
 *   This is a blocking function that waits for all DPGs that we care about
 *   (as defined by bits set in the WaitFor BitSet) to arrive at the
 *   global barrier. This function should only be called by one thread each
 *   distributed quantum (currently this is handled in handle_distq_barrier).
 *
 *   This function has two phases:
 *     
 *     1) Send a ENDQ message from this DPG to all other DPGs, indicating that
 *        we're done with our quantum
 *
 *     2) Wait until DPGs we care about have ended the same quantum
 *
 *   Parameters:
 *       status  -- Indicate our status current status (are we exiting?)
 */
void BasicShim::wait_for_global_barrier(uint32_t status)
{
	uint32_t i;
	DNodeMap::iterator cur;
	PDNode peer;

	/* Phase 1: Flood the ENDQ messages */
	floodEndqTime.start();
	for (cur = DetNodes->begin(); cur != DetNodes->end(); /* Incremented below */) {
		peer = cur->second;
		if (peer == NULL) {
			SHIM_WARN("Why is node NULL?");
			continue;
		}
		
		if (peer->exiting) {
			SHIM_LOG("Node %d exiting; clearing from DetNodes\n", peer->nodeid);
			DetNodes->erase(cur++);
			continue;
		}

		if (peer->nodeid == node_id) {
			++cur;
			continue;
		}

		cc_send_endq(peer, current_distq, status);
		++cur;
	}
	floodEndqTime.stop();

	SHIM_LOG("Node %d done sending ENDQ; waiting for others (%lx)...\n", node_id, WaitFor->to_ulong());
	
	/* Phase 2: Wait for the other DPGs to catch up */
	waitForPeersTime.start();
	for (cur = DetNodes->begin(); cur != DetNodes->end(); ++cur) {
		bool need_to_wait = false;
		uint64_t drift = 0;

		peer = cur->second;
		SHIM_LOG("Checking node %d\n", peer->nodeid);

		/*
		 * N.B. There should only be *one* thread executing at this point; 
		 * all other threads should be waiting for the this thread to complete.
		 * As a result, we can safely access WaitFor without synchronization.
		 */
		if (WaitFor->test(peer->nodeid)) {
			int delta = 0;

			SHIM_LOG("  Need to wait for %d (me: GLT %ld, them: GLT %ld)\n",
				peer->nodeid, current_distq, peer->last_known_quantum);
			need_to_wait = true;

			if (current_distq > peer->last_known_quantum)
				delta = current_distq - peer->last_known_quantum;

			distqDelta.add(delta);
			distqDelta.print();
		}
		
		if (peer->nodeid == node_id) {
			SHIM_LOG("Skipping myself\n");
			need_to_wait = false;
		}

		drift = (current_distq > peer->last_known_quantum ?
			 current_distq - peer->last_known_quantum :
			 peer->last_known_quantum - current_distq);

		if (max_drift != 0 && peer->nodeid != node_id && drift >= max_drift) {
			SHIM_LOG("  Drift of %ld (max %ld); need to wait for %d\n",
				drift, max_drift, peer->nodeid);
			need_to_wait = true;
		}

		/*
		 * Loop early if we do not need to wait for this DPG
		 */
		if (!need_to_wait)
			continue;

		SHIM_LOG("Locking %p...\n", &peer->quantum_lock);
		pthread_mutex_lock(&peer->quantum_lock);
		while (peer->last_known_quantum < current_distq) {
			pthread_cond_wait(&peer->quantum_cv, &peer->quantum_lock);
		}
		pthread_mutex_unlock(&peer->quantum_lock);
	}
	waitForPeersTime.stop();
}

/**
 * wait_for_ddpg_exit() --
 *
 *   This function is called when the last thread in the dpg is exiting. For
 *   the master node in a ddpg, it should either handoff the master privelege
 *   to another node, or it should continue to coordinate distributed barriers
 *   until all remote dpgs have exited.
 *
 *   For non-master dpgs, this function delays the exit until the next
 *   distributed quantum, and informs the master node that the dpg is exiting;
 *   the master uses this to notification to keep track of who is expected to
 *   check in and who is still running.
 *
 *   Parameters:
 *       None.
 *
 *   Returns:
 *       None.
 */
void BasicShim::wait_for_ddpg_exit(void)
{
	if (reexec_detnet) {
		SHIM_LOG("No barrier needed to exit\n");
		return;
	}

	SHIM_LOG("Node %d is attempting to leave the DDPG\n", this->node_id);
	wait_for_global_barrier(DISTQ_EXITING);
	SHIM_LOG("We are now safe to exit...\n");
}

/**
 * wait_for_distq_barrier() --
 *
 *   This function should be called by shim threads that need to wait until the
 *   next distributed quantum in order to continue. 
 */
bool BasicShim::wait_for_distq_barrier(void)
{
	shim_event temp_event;

	SHIM_LOG("Waiting for the end of this distributed quantum\n");
	if (distq_size == 0) {
		SHIM_LOG("This isn't a ddpg; ignoring\n");
		return true;
	}

	waitForDistqTime.start();

	/* Put the DMP thread to sleep and increment the waiting count */
	pthread_mutex_lock(&distq_lock);
	distq_waiting_count++;
	dmp_shim_sleep(0);
	pthread_cond_wait(&distq_waiting_cond, &distq_lock);
	pthread_mutex_unlock(&distq_lock);

	//SHIM_LOG("Distq barrier reached; setting barrier for next round\n");
	dmp_shim_set_barrier(SHIM_BARRIER_SYSCALL /* this is meaningless... */, SHIM_BARRIER_NEXT_MODE, 0);
	//SHIM_LOG("Continuing...\n");

	pthread_mutex_lock(&distq_lock);
	distq_waiting_count--;
	pthread_cond_signal(&distq_ready_cond);
	pthread_mutex_unlock(&distq_lock);

	/* Waiting for our barrier to arrive */
	//SHIM_LOG("Waiting for our barrier to arrive\n");
	dmp_shim_trace(&temp_event);
	if (temp_event.event_type != SHIM_BARRIER_SYSCALL)
		SHIM_WARN("Expecting %d, got %d\n", SHIM_BARRIER_SYSCALL, temp_event.event_type);
	//SHIM_LOG("Got it! Continuing...\n");
	
	waitForDistqTime.stop();
	return true;
}

/**
 * set_distq_handler --
 *
 *   This function should be called by one thread per DPG. The caller will
 *   become responsible for handling the distributed quantum barriers for
 *   this DDPG.
 */
void BasicShim::set_distq_handler(shim_event *event)
{
	long nextbar = distq_size;
	long *ptr = (long *)shim_syscall_arg1(&event->regs);

	/*
	 * We force distq barriers to happen in serial mode; this simplifies
	 * the implementation of distq barrier handling, since we can assume
	 * that the entire box is serialzed and thus the distq handler thread
	 * is the only one running at the that time.
	 *
	 * To simplify setting future barriers, we round distq_size to the
	 * nearest event number and set the first barrier for the corresponding
	 * serial mode. That way we can simply add distq_size to the current
	 * logical time to find the time of the next barrier.
	 */
	if (distq_size % 2 == 0) {
		nextbar = distq_size + 1;

	} else {
		nextbar = distq_size;
		distq_size++;
	}

	/* We need to register the first distq barrier for this thread */
	if (reexec_detnet == false) {
		SHIM_LOG("Setting initial distq barrier for time @%ld.%d (%ld)\n",
			__EVTIME(nextbar), nextbar);
		dmp_shim_set_barrier(SHIM_BARRIER_DISTQ, SHIM_BARRIER_FIXED_TIME, nextbar);
		distq_data = ptr;

		/*
		 * With the barrier set, we put the caller to sleep; this
		 * thread should only wake up to handle the distributed
		 * barriers before being put back to sleep again.
		 */
		printf("Putting the caller to sleep\n");
		if (dmp_shim_sleep(0) < 0)
			SHIM_WARN("Couldn't put caller to sleep?\n");

	} else {
		SHIM_LOG("reexec_detnet is true; not creating a distq barrier\n");
	}
}


/**
 * handle_distq_barrier(event) --
 *
 *   This function is called by the distq handler once for each distributed
 *   quantum.  This function is used as a heartbeat to unbuffer connection
 *   requests and data sent in the previous quantum, making it available
 *   to threads from this quantum onward.
 *
 *   Returns:
 *       Boolean success value
 */
bool BasicShim::handle_distq_barrier(shim_event *event)
{
	uint64_t nextbar = (event->logical_time + distq_size);
	DNodeMap::iterator cur;
	long done = 0;

	SHIM_LOG("@%ld.%d: Distributed quantum barrier reached (nrunning %d)\n", EVTIME(event), nrunning);
	if (event->logical_time % 2 != 1)
		SHIM_WARN("   Barrier arrived during parallel mode!\n");
	//SHIM_LOG("   Setting next distq barrier at time @%ld.%d\n", __EVTIME(nextbar));
	dmp_shim_set_barrier(SHIM_BARRIER_DISTQ, SHIM_BARRIER_FIXED_TIME, nextbar);

	/*
	 * Increment our distributed quantum counter. Although shared, this is
	 * the only place this value is written, and handle_distq_barrier
	 * should only be called in serial mode. Thus, no synchronization is
	 * needed here.
	 */
	//SHIM_LOG("Incrementing distributed quantum %ld -> %ld\n", current_distq, current_distq+1);
	current_distq++;

	/*
	 * Now we need to wait for all of the other DPGs to reach the
	 * same distributed quantum.
	 */
	if (nrunning == 1) {
		SHIM_LOG("We are the last thread alive; bringing down the DPG\n");
		wait_for_ddpg_exit();

		if (distq_data) {
			SHIM_LOG("Setting done flag to true\n");
			done = 1;
			timed_dmp_shim_memcpy_sync(&done, distq_data, sizeof done, TO_DMP, NULL);

		} else {
			SHIM_LOG("No done flag specified\n");
		}

	} else {
		SHIM_LOG("Waiting for remote nodes to catch up\n");
		wait_for_global_barrier(DISTQ_OK);
		SHIM_LOG("Everyone is here!\n");
	}

	/*
	 * Perform any required "heartbeat" functions
	 */
	WaitFor->reset();
	SHIM_LOG("Cleared WaitFor: %lx\n", WaitFor->to_ulong());

	/*
	 * Wake up any threads waiting for the end of the current distributed quantum
	 */
	//SHIM_LOG("Waking distq waiters\n");
	pthread_mutex_lock(&distq_lock);
	pthread_cond_broadcast(&distq_waiting_cond);
	pthread_mutex_unlock(&distq_lock);
	//SHIM_LOG("Done.\n");

	/*
	 * Wait for the woken threads to set their wake-up barriers
	 */
	pthread_mutex_lock(&distq_lock);
	//SHIM_LOG("Waiting for %d distq waiters to get ready\n", distq_waiting_count);
	while (distq_waiting_count > 0) {
		//SHIM_LOG("   %d to go\n", distq_waiting_count);
		pthread_cond_wait(&distq_ready_cond, &distq_lock);
		//SHIM_LOG("       got one\n");
	}
	pthread_mutex_unlock(&distq_lock);
	//SHIM_LOG("Done.\n");

	/*
	 * Continue execution
	 */
	if (!done) {
		SHIM_LOG("   Putting handler back to sleep\n");
		if (dmp_shim_sleep(0) < 0)
			SHIM_WARN("Couldn't put handler to sleep again?\n");
		//SHIM_LOG("   Handler asleep\n");

	} else {
		SHIM_LOG(" Done flag is set; allowing task to continue\n");
	}

	//SHIM_LOG("All done!\n");
	return true;
}

} /* namespace DMP */
