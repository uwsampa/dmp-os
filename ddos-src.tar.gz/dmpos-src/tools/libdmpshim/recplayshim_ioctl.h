#ifndef _RECPLAY_IOCTL_H_
#define _RECPLAY_IOCTL_H_

#include "recplayshim_gen.h"

/* Sockets */
__RECPLAY(ioctl_siocgifconf);
__RECPLAY(ioctl_siocgifflags);
__RECPLAY(ioctl_siocgifindex);
__RECPLAY(ioctl_siocgifaddr);
__RECPLAY(ioctl_siocgifnetmask);

/* Terminals */
__RECPLAY(ioctl_tcgets);
__RECPLAY(ioctl_tcsets);
__RECPLAY(ioctl_tiocgpgrp);
__RECPLAY(ioctl_tiocgptn);
__RECPLAY(ioctl_tiocinq);
__RECPLAY(ioctl_tiocoutq);
__RECPLAY(ioctl_tiocgwinsz);

#endif /* _RECPLAY_IOCTL_H_ */
