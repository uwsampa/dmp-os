/**
 * repshim.cpp --
 *
 *   A shim implementing replay
 *
 *   TODO: System calls that need to be reexecuted, even during replay
 *     - close
 *     - exit family
 *     - exec family
 *     - mmap, mprotect, munmap
 *
 *     - pipes (deterministic)
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstring>

#include "recplayshim_gen.h"
#include "recplayshim.h"

namespace DMP {

/**
 * __shim_id --
 *
 *   This global counter is incremented each time a new RecPlayShim is created.
 *   It is used to give each shim a unique identifier that indicates the order
 *   of creation. The counter's value is used to determine which log file to
 *   read from.
 *
 *   TODO: Is there a better/safer/idiomatic way to do this?
 */
static int __shim_id = 0;

/**
 * RecPlayShim --
 *
 *   Create a new shim capable of record and replay. The mode of operation is
 *   controlled by the replay flag, and compression is controlled by the
 *   compress flag.
 *
 *   TODO: Compression is currently disabled
 */
RecPlayShim::RecPlayShim(RecPlayShim *parent, int clone_flags,
                         const string &logfile, RecPlayTab *table,
                         bool replay, bool compress, bool reexec_detnet)
	: BasicShim(parent, clone_flags, reexec_detnet), logbasename(logfile), table(table),
	  replay(replay), compressed(compress) 
{
	char suffix[20];
	string sigfilename;

	/*  Generate a unique shim_id */
	const int myid = __sync_fetch_and_add(&__shim_id, 1);

	/* TODO: Handle this condition better */
	assert(table);
	
	if (compressed) {
		SHIM_LOG("Ignoring request for compressed log\n");
		compressed = false;
		/* logbasename += ".z"; */
	}

	snprintf(suffix, 20, ".%d", myid);
	logbasename += suffix;
	logfilename  = strdup(logbasename.c_str());
	sigfilename  = logbasename + ".sig";

	/* Open the logfile */
	SHIM_LOG("Using log file %s\n", logfilename);
	if (replay) {
		SHIM_LOG("Opening for replay\n");
		if ((logfd = open(logfilename, O_RDONLY)) < 0)
			perror("open");
		if ((siglogfd = open(sigfilename.c_str(), O_RDONLY)) < 0)
			perror("open");

	} else {
		SHIM_LOG("Opening for record\n");
		if ((logfd = open(logfilename, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
			perror("open");
		if ((siglogfd = open(sigfilename.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
			perror("open");
	}
	
	/*
	 * Mark this as a special FD, outside the control of the MOT
	 */
	dmp_shim_set_nomot(nullfd, NOMOT);
	
	/* TODO: Failure should be handled better */
	assert(logfd != -1);
	assert(siglogfd != -1);

	/* Initialize the zlib engine if our log should be compressed */
	if (compressed) {
		SHIM_LOG("RecPlay log compression not implemented yet.\n");
		/* zbufinit(&zbuf, logfd, ZDECOMPRESS); */
	}
}

RecPlayShim::~RecPlayShim()
{
	SHIM_LOG("Destroying RecPlayShim\n");
	if (compressed)
		zbufdestroy(&zbuf);

	free(logfilename);
	close(logfd);
	close(siglogfd);
	close(nullfd);
}

RecPlayShim *RecPlayShim::clone(int clone_flags)
{
	return new RecPlayShim(this, clone_flags, logbasename, table, replay, compressed, reexec_detnet);
}

bool RecPlayShim::trace_syscall_enter(shim_event *event)
{
	bool handled = false;

	if (replay)
		handled = replay_syscall_enter(event);
	else
		handled = record_syscall_enter(event);

	return handled;
}

void RecPlayShim::trace_syscall_leave(shim_event *event)
{
	if (replay)
		replay_syscall_leave(event);
	else
		record_syscall_leave(event);
}

void RecPlayShim::trace_rdtsc(shim_event *event)
{
	if (replay)
		replay_rdtsc(event);
	else
		record_rdtsc(event);
}

void RecPlayShim::trace_signal(shim_event *event)
{
	SHIM_LOG("Received signal %d\n", event->si_info.si_signo);
	SHIM_WARN("Signal record/replay not implemented\n");
}

/******************************************************************************
 *                          Public utility functions                          *
 ******************************************************************************/
int RecPlayShim::append_buffer(char *buf, int n)
{
	assert(!replay);

	SHIM_LOG("  Appending %d bytes to log\n", n);

	//SHIM_WARN("   Disabled for now...\n");
	//return n;

	if (compressed)
		return zwriten(&zbuf, buf, n);
	else
		return writen(logfd, buf, n);
}

int RecPlayShim::read_buffer(char *buf, int n)
{
	assert(replay);
	SHIM_LOG("  Reading %d bytes from log\n", n);
	return readn(logfd, buf, n);
}

RecPlayTab *RecPlayShim::get_table(void)
{
	return table;
}

int RecPlayShim::get_nullfd(void)
{
	return nullfd;
}

/******************************************************************************
 *                         Private utility functions                          *
 ******************************************************************************/
void RecPlayShim::wait_for_event_time(shim_event *event, rechdr_t *rechdr)
{
	/* Wait for the right time */
	SHIM_LOG("Time now: %ld, @%ld.%d; event time: %ld, @%ld.%d\n",
		event->logical_time, EVTIME(event), rechdr->quantum, __EVTIME(rechdr->quantum));

	if (rechdr->quantum < event->logical_time) {
		SHIM_ERR("Event happened in the past?\n");
		abort();
	
	} else if (rechdr->quantum > event->logical_time) {
		shim_event barevent;
		SHIM_LOG("Event happens in the future; waiting\n");

		SHIM_LOG("Setting exact barrier for %ld, %ld.%d\n", rechdr->quantum, __EVTIME(rechdr->quantum));
		dmp_shim_set_barrier(SHIM_BARRIER_SYSCALL, SHIM_BARRIER_FIXED_TIME, rechdr->quantum);

		SHIM_LOG("Going to sleep\n");
		dmp_shim_sleep(DMP_SLEEP_NORMAL);

		SHIM_LOG("Waiting for next event\n");
		dmp_shim_trace(&barevent);

		if (barevent.event_type != DMP_SHIM_BARRIER) {
			SHIM_ERR("Expecting barrier (%d), got %d\n",
				DMP_SHIM_BARRIER, barevent.event_type);
			abort();
		}

		SHIM_LOG("Time is now @%ld.%d; continuing\n", EVTIME(&barevent));
	}
}

void RecPlayShim::record_rdtsc(shim_event *event)
{
	struct user_regs_struct *regs = &event->regs;
	uint64_t tsc;

	tsc = (regs->rdx << 32) | regs->rax;

	SHIM_LOG("Recording RDTSC result of %ld\n", tsc);
	add_record(this, event->logical_time, LOG_RDTSC, 0, sizeof(tsc));
	this->append_buffer((char *)&tsc, sizeof(tsc));
}

void RecPlayShim::replay_rdtsc(shim_event *event)
{
	rechdr_t rechdr;
	uint64_t tsc;

	/* Get the header */
	SHIM_LOG("Reading in record header\n");
	read_buffer((char *)&rechdr, sizeof(rechdr_t));
	SHIM_LOG("Done (time: @%ld.%d, type: %d, subtype: %d, reclen: %ld)\n",
		__EVTIME(rechdr.quantum), TYPE(rechdr), SUBTYPE(rechdr), rechdr.reclen);

	/* Do some simple checks */
	if (TYPE(rechdr) != TYPE_RDTSC) {
		SHIM_ERR("Unexpected event type; wanted rdtsc\n");
		abort();

	} else if (rechdr.reclen != sizeof(tsc)) {
		SHIM_ERR("Unexpected record length: %ld (wanted %ld)\n",
		         rechdr.reclen, sizeof(tsc));
		abort();
	}
	
	/* Wait for the right logical time */
	wait_for_event_time(event, &rechdr);

	SHIM_LOG("Done2 (time: @%ld.%d, type: %d, subtype: %d, reclen: %ld)\n",
		__EVTIME(rechdr.quantum), TYPE(rechdr), SUBTYPE(rechdr), rechdr.reclen);

	/* Replay it */
	this->read_buffer((char *)&tsc, sizeof(tsc));
	SHIM_LOG("Setting RDTSC result to %ld\n", tsc);
	event->regs.rdx = (tsc >> 32);
	event->regs.rax = (tsc & ((uint32_t)-1));
	dmp_shim_setregs(&event->regs);
}

bool RecPlayShim::record_syscall_enter(shim_event *event)
{
	bool handled = false;

	handled = BasicShim::trace_syscall_enter(event);

	/*
	 * TODO: record return values here on error only?
	 * we won't get a sysleave event since the syscall was emulated
	 */
	if (handled) {
		#if 0
		if (event->regs.rcx < 0) {
			add_record(this, event->logical_time, LOG_SYSCALL, event->regs.orig_rax, sizeof(long));
			append_buffer((char *)&event->regs.rcx, sizeof(event->regs.rcx));
		}
		#endif
	}

	return handled;
}

void RecPlayShim::record_syscall_leave(shim_event *event)
{
	const long __unused syscallnr = event->regs.orig_rax;
	const long __unused retval  = event->regs.rax;

	/* TODO: Only record the result if there was an error */
	/*
		switch(syscallnr) {
		case SYS_mmap:
		case SYS_mprotect:
		case SYS_munmap:
		case SYS_set_tid_address:
		case SYS_set_robust_list:
			if (retval >= 0)
				return;
			break;
		case SYS_futex:
			if (retval >= 0 || retval == -EAGAIN)
				return;
			break;
		}
	*/

	SHIM_LOG("Syscall leave: %s (%ld)\n", GetSyscallName(syscallnr), syscallnr);
	record_syscall(event);
	BasicShim::trace_syscall_leave(event);
}

bool RecPlayShim::replay_syscall_enter(shim_event *event)
{
	uint64_t syscallnr = event->regs.orig_rax;
	bool handled = false;
	consume_log = false;

	SHIM_LOG("replay syscall %ld enter\n", syscallnr);

	/* Let the basic shim handle any deterministic stuff it can */
	handled = BasicShim::trace_syscall_enter(event);
	if (handled) {
		SHIM_LOG("BasicShim handled this event\n");
		return true;
	}

	switch (syscallnr) {
	/* 
	 * Each system call must be considered individually. This is a list of
	 * the ones that have received at least a bit of attention. System calls
	 * not in this list are reexected during replay and are not recorded.
	 * Once everything has been implemented, this can be removed.
	 */

	/* Filesystem */
	case SYS_fstat:
	case SYS_lstat:
	case SYS_stat:
	case SYS_statfs:
	case SYS_write:
	case SYS_read:
	case SYS_writev:
	case SYS_readv:
	case SYS_unlink:
	case SYS_rename:
	case SYS_open:
	case SYS_creat:
	case SYS_close:
	case SYS_lseek:
	case SYS_fcntl:
	case SYS_getdents:
	case SYS_getdents64:
	case SYS_fadvise64:
	case SYS_fsync:
	case SYS_fdatasync:
	case SYS_ftruncate:
	case SYS_umask:
	case SYS_dup:
	case SYS_dup2:
	case SYS_access:
	case SYS_getcwd:
	case SYS_fchmod:
	case SYS_chmod:
	case SYS_readlink:

	/* Memory */
	case SYS_madvise:
	case SYS_mmap:
	case SYS_munmap:
	case SYS_mremap:
	case SYS_mprotect:
	case SYS_brk:
	case SYS_mlock:
	case SYS_munlock:
	case SYS_mlockall:
	case SYS_munlockall:
	case SYS_get_mempolicy:

	/* Idempotent Utility */
	case SYS_getpid:
	case SYS_getppid:
	case SYS_gettid:
	case SYS_getuid:
	case SYS_getgid:
	case SYS_getpgrp:
	case SYS_geteuid:
	case SYS_getegid:
	case SYS_getresgid:
	case SYS_getresuid:
	case SYS_time:
	case SYS_gettimeofday:
	case SYS_clock_gettime:
	case SYS_clock_getres:
	case SYS_clock_settime:
	case SYS_getrusage:
	case SYS_getitimer:
	case SYS_getgroups:
	case SYS_uname:
	case SYS_getrlimit:

	/* Sockets API */
	/* N.B. All socket functions are currently replayed. Once local replay
	 *   is working, the socket implementations will be extended to allow
	 *   for re-execution when communication with distributed DPGs.
	 */
	case SYS_select:
	case SYS_poll:
	case SYS_epoll_create:
	case SYS_epoll_wait:
	case SYS_epoll_ctl:
	case SYS_getsockname:
	case SYS_getpeername:
	case SYS_socket:
	case SYS_socketpair:
	case SYS_bind:
	case SYS_listen:
	case SYS_sendto:
	case SYS_sendmsg:
	case SYS_recvfrom:
	case SYS_recvmsg:
	case SYS_accept:
	case SYS_connect:
	case SYS_getsockopt:
	case SYS_setsockopt: /* TODO: Check this function */

	/* Signals */
	case SYS_rt_sigaction:
	case SYS_rt_sigprocmask:
	
	/* Unclassified */
	case SYS_sched_setaffinity:
	case SYS_sched_getaffinity:
	case SYS_sched_get_priority_min:
	case SYS_sched_get_priority_max:
	case SYS_sched_yield:
	case SYS_nanosleep:
	case SYS_sysinfo:
	case SYS_times:
	case SYS_ustat:
	case SYS_sched_setparam:
	case SYS_sched_getparam:
	case SYS_sched_rr_get_interval:
	case SYS_arch_prctl:
	case SYS_set_robust_list:
	case SYS_fallocate:
	case SYS_getpriority:
	case SYS_setpriority:
	case SYS_sched_getscheduler:
	case SYS_sched_setscheduler:
	case SYS_sysfs:
	case SYS_settimeofday:
	case SYS_ioctl:
	case SYS_set_tid_address:
	case SYS_futex:
	case SYS_pipe:
	case SYS_wait4:
	case SYS_inotify_init:
	case SYS_inotify_add_watch:
	case SYS_inotify_rm_watch:
		break;

	/*
	 * N.B. System calls that exit the task (e.g., sys_exit and
	 *   sys_exit_group) do not generate a syscall_leave event during
	 *   record.  As a result, they do not get a record in the replay log
	 *   and thus there is nothing to replay. Just let the system call
	 *   proceed, and terminate the task.
	 */
	case SYS_exit:       /* Fall through */
	case SYS_exit_group: /* Fall through */
	default:
		consume_log = true;
		handled = false;
		goto out;
	}

	replay_syscall(event);
	handled = true;

  out:
	return handled;
}

void RecPlayShim::replay_syscall_leave(shim_event *event)
{
	long ret, res;
	char *buffer = NULL;
	rechdr_t rechdr;
	long syscallnr = event->regs.orig_rax;
	RecPlayFn recfn = table->get_fn(syscallnr);
	static off_t last_file_offset = 0;
	off_t this_file_offset;

	SHIM_LOG("Syscall leave: %s (%ld)\n", GetSyscallName(syscallnr), syscallnr);

	if (!recfn) {
		SHIM_ERR("Didn't get a replay function from the table\n");
		abort();
	}

	switch (syscallnr) {
	default:
		if (!consume_log)
			SHIM_WARN("Syscall %ld not hooked on leave event, but not consuming log\n", syscallnr);
		break;

	/*
	 * N.B. The get*id() system calls below are currently recorded with the
	 *   recplay_reexec; this means they are reexecuted during replay, but the return
	 *   values are still logged and checked during runtime. As long as rundet
	 *   clones with CLONE_NEWPID, pids should evolve deterministically. Reexec
	 *   makes sure that this assumption holds, and complains when it spots a difference.
	 */
	case SYS_getpid:
	case SYS_getppid:
	case SYS_getsid:

	/* 
	 * Some system calls need to reexecute before being hooked Like
	 * syscall_enter above, this list is just temporary until everything is
	 * implemented. Once all the system calls have been considered, only
	 * the syscalls that should be reexecuetd will make it to syscall_leave
	 * and this list will be unnecessary.
	 * 
	 * TODO: We should save the rechdr from the enter event and pass it
	 *   instead of NULL
	 */
	case SYS_bind:
	case SYS_socket:
	case SYS_listen:
	case SYS_close:
	case SYS_mmap:
	case SYS_mprotect:
	case SYS_munmap:
	case SYS_brk:
	case SYS_mremap:
	case SYS_madvise:
	case SYS_msync:
	case SYS_mlock:
	case SYS_munlock:
	case SYS_mlockall:
	case SYS_munlockall:
	case SYS_alarm:
	case SYS_setuid:
	case SYS_setgid:
	case SYS_setreuid:
	case SYS_setregid:
	case SYS_setresuid:
	case SYS_setresgid:
	case SYS_setfsuid:
	case SYS_setfsgid:
	case SYS_arch_prctl:
	case SYS_set_robust_list:
	case SYS_rt_sigaction:
	case SYS_rt_sigprocmask:
	case SYS_set_tid_address:
	case SYS_pipe:
		recfn(this, event, SHIM_REPLAY, NULL);
		break;
	}
	
	/* Read in the header of the next event */
	if (consume_log) {
		consume_log = false;
		res = read_buffer((char *)&rechdr, sizeof(rechdr));
		assert(res == sizeof(rechdr));

		SHIM_LOG("  Discarding header: @%ld.%d, type:%d, subtype:%d, len:%ld\n",
			__EVTIME(rechdr.quantum), TYPE(rechdr), SUBTYPE(rechdr), rechdr.reclen);

		/* 
		 * TODO: Didn't replay;  skip the extra data by reading in to a garbage
		 *   buffer.
		 */
		SHIM_WARN("Replay not implemented\n");
		if (rechdr.reclen >= sizeof(long)) {
			read_buffer((char *)&ret, sizeof(long));
			if (ret != (long)shim_syscall_return(&event->regs)) {
				SHIM_WARN("Logged return of %ld, actually returned %ld\n", 
					ret, shim_syscall_return(&event->regs));
			}

			rechdr.reclen -= sizeof(long);
		}

		if (rechdr.reclen > 0) {
			buffer = new char[rechdr.reclen];
			assert(buffer);
			read_buffer(buffer, rechdr.reclen);
			delete [] buffer;
		}
	}

	/*
	 * This is just a quick sanity check to make sure we've consumed some
	 * bytes from the log; if we haven't, then something must be wrong.
	 * This doesn't catch every mistake, but its better than nothing. 
	 */
	this_file_offset = lseek(logfd, 0, SEEK_CUR);
	if (this_file_offset - last_file_offset <= 0)
		SHIM_WARN("Log file offset hasn't changed; did you forget to consume bytes?\n");
	last_file_offset = this_file_offset;

	BasicShim::trace_syscall_leave(event);
}

void RecPlayShim::record_syscall(shim_event *event)
{
	long syscallnr    = event->regs.orig_rax;
	RecPlayFn recfn = table->get_fn(syscallnr);

	if (!recfn) {
		SHIM_ERR("Didn't get a record function from the table\n");
		abort();
	}

	recfn(this, event, SHIM_RECORD, NULL);
}

void RecPlayShim::replay_syscall(shim_event *event)
{
	long syscallnr    = event->regs.orig_rax;
	RecPlayFn recfn   = table->get_fn(syscallnr);
	rechdr_t rechdr;

	if (!recfn) {
		SHIM_ERR("Didn't get a replay function from the table\n");
		abort();
	}

	/* Get the header */
	SHIM_LOG("Reading in record header\n");
	read_buffer((char *)&rechdr, sizeof(rechdr_t));
	SHIM_LOG("Record header before (time: @%ld.%d, type: %d, subtype: %d, reclen: %ld)\n",
		__EVTIME(rechdr.quantum), TYPE(rechdr), SUBTYPE(rechdr), rechdr.reclen);

	/* Do some simple checks */
	if (TYPE(rechdr) != TYPE_SYSCALL) {
		SHIM_ERR("Unexpected event type; wanted syscall\n");
		abort();

	} else if (SUBTYPE(rechdr) != syscallnr) {
		SHIM_ERR("Wrong syscall? Actual: %ld, log: %d\n", syscallnr, SUBTYPE(rechdr));
		abort();
	}

	/* Wait for the right logical time */
	wait_for_event_time(event, &rechdr);

	SHIM_LOG("Record header after (time: @%ld.%d, type: %d, subtype: %d, reclen: %ld)\n",
		__EVTIME(rechdr.quantum), TYPE(rechdr), SUBTYPE(rechdr), rechdr.reclen);

	/* Replay it */
	recfn(this, event, SHIM_REPLAY, &rechdr);
}

} /* DMP */
