/*
 * User-land library for DMP shim processes
 */

#ifndef __LIBDMPSHIM_DMPSHIM_H__
#define __LIBDMPSHIM_DMPSHIM_H__

#include <signal.h>
#include <sys/user.h>
#include <stdint.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>

#include "dmp.h"

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

extern FILE *shim_log_file;
extern pthread_mutex_t log_lock;

#define SHIM_LOG_LEVEL(lvl, fmt, args...)                   \
	do {                                                \
		pid_t ____tid = syscall(186);               \
		pthread_mutex_lock(&log_lock);              \
		fprintf(shim_log_file, "[%d] (%s) %s ", ____tid, __func__, lvl); \
		fprintf(shim_log_file, fmt, ##args);               \
		fflush(shim_log_file);                             \
		pthread_mutex_unlock(&log_lock);            \
	} while (0)

#define SHIM_WARN(fmt, args...) \
	SHIM_LOG_LEVEL("**WARNING**", fmt, ##args)

#define SHIM_ERR(fmt, args...) \
	SHIM_LOG_LEVEL("**ERROR**", fmt, ##args)

#define SHIM_PERROR(msg)				\
	do {						\
		fprintf(shim_log_file, "(%s) ERROR %s: %s\n", __func__, msg, strerror(errno));	\
	} while(0)

#ifdef SHIM_DEBUG
	#define SHIM_LOG_CONT(fmt, args...) \
		fprintf(shim_log_file, fmt, ## args)
	#define SHIM_LOG(fmt, args...) \
		SHIM_LOG_LEVEL("", fmt, ##args);
#else   // SHIM_NDEBUG
	#define SHIM_LOG_CONT(fmt, args...)
	#define SHIM_LOG(fmt, args...)
#endif  // SHIM_DEBUG



/* shortcut for printf: print a logical time as quantums.{0,1} */
#define __EVTIME(lt)    ((lt)/2), ((unsigned int)(lt)%2)
#define EVTIME(event)	__EVTIME((event)->logical_time)

/* Magic syscall numbers */
#define SYS_dmp_shim_attach		289
#define SYS_dmp_shim_trace		290
#define SYS_dmp_shim_set_barrier	291
#define SYS_dmp_shim_sleep		292
#define SYS_dmp_shim_ctl		293
#define SYS_dmp_shim_wake               296

/**
 * dmp_call_shim function identifiers
 */
#define SHIM_FN_SET_DISTQ_HANDLER  1001    /* Register the caller as the distq handler */

/*
 * The following values and struct must be kept in sync with
 * include/linux/dmp.h
 */

/* Types of events */
enum ShimEvent {
	DMP_SHIM_SYSCALL_ENTER	= 0,
	DMP_SHIM_SYSCALL_LEAVE	= 1,
	DMP_SHIM_BARRIER	= 2,
	DMP_SHIM_CALL		= 3,
	DMP_SHIM_EXIT		= 4,
	DMP_SHIM_VFORK_WAIT	= 5,
	DMP_SHIM_RDTSC          = 6,
	DMP_SHIM_SIGNAL         = 7,
};

/* Types of ctl functions */
enum ShimCtl {
	DMP_SHIM_CTL_MEMCPY	= 0,
	DMP_SHIM_CTL_STRNCPY	= 1,
	DMP_SHIM_CTL_SETREGS	= 2,
	DMP_SHIM_CTL_DUPFD	= 3,
	DMP_SHIM_CTL_DUPFD2	= 4,
	DMP_SHIM_CTL_CLOSEFD	= 5,
	DMP_SHIM_CTL_CHECKFD    = 6,
	DMP_SHIM_CTL_SET_CLOEXEC = 7,
	DMP_SHIM_CTL_SET_NOMOT  = 8,
	DMP_SHIM_CTL_GET_LOGICAL_TIME = 9,
};

/* Types of barriers */
enum ShimBarrierWhence {
	SHIM_BARRIER_NEXT_MODE		= 0,  /* set barrier ASAP */
	SHIM_BARRIER_NEXT_SERIAL	= 1,  /* set barrier next serial mode */
	SHIM_BARRIER_OFFSET_PARALLEL	= 2,  /* set barrier N rounds from now, in parallel mode */
	SHIM_BARRIER_OFFSET_SERIAL	= 3,  /* set barrier N rounds from now, in serial mode */
	SHIM_BARRIER_FIXED_TIME		= 4,  /* set barrier for specific logical_time */
};


#define SHIM_BARRIER_FLAG_IO      (1<<0)
#define SHIM_BARRIER_FLAG_SYSCALL (1<<1)
#define SHIM_BARRIER_FLAG_DISTQ   (1<<2)

enum ShimBarrierType {
	SHIM_BARRIER_NONE    = 0,
	SHIM_BARRIER_IO      = SHIM_BARRIER_FLAG_IO,
	SHIM_BARRIER_SYSCALL = SHIM_BARRIER_FLAG_SYSCALL,
	SHIM_BARRIER_DISTQ   = SHIM_BARRIER_FLAG_DISTQ,
};

/* For dmp_shim_memcpy and dmp_shim_dupfd */
enum ShimCtlFlag {
	FROM_DMP	= 0,
	TO_DMP		= 1,
	/* For dmp_shim_dupfd */
	DUP_IN_DMP	= 2,
};

enum ShimMotFlag {
	MOT   = 0,
	NOMOT = 1,
};

struct shim_event {
	uint32_t event_type;
	uint64_t logical_time;
	uint32_t prev_sleep;

	/* for syscall and vforkwait events only */
	struct user_regs_struct regs;

	struct siginfo si_info;

	/* for barrier events only */
	uint32_t barrier_type;

	/* for debugging only */
	uint64_t qticks;
};

/**
 * rechdr --
 *   
 *   Every entry in the record log is preceded by one of these headers. The
 *   reclen field indicates how much additional event specific data follows
 *   this header.
 */
struct rechdr_t {
	uint64_t quantum;
	uint32_t fulltype;
	uint64_t reclen;
} __attribute__((__packed__));


/*
 * Syscalls
 */
#define DMP_SLEEP_NORMAL     0 /* Argument to dmp_shim_sleep */
#define DMP_SLEEP_FOR_WAKE   1
long dmp_shim_attach(pid_t pid);
long dmp_shim_trace(struct shim_event *event);
long dmp_shim_set_barrier(enum ShimBarrierType type, enum ShimBarrierWhence whence, uint64_t logical_time);
long __dmp_shim_set_barrier(pid_t pid, enum ShimBarrierType type, enum ShimBarrierWhence whence, uint64_t logical_time);  /* ugly :( */
long dmp_shim_sleep(int sleep_for_wake);
long dmp_shim_ctl(enum ShimCtl func, long arg1, long arg2, long arg3, long arg4, long arg5);
long dmp_shim_wake(void);

/* Ctl shorthands */
long dmp_shim_memcpy(void *shim_buf, void *dmp_buf, long nbyte, enum ShimCtlFlag write_to_dmp, long *bytes_out);
long dmp_shim_strncpy(void *shim_buf, void *dmp_buf, long nbytes, long *bytes_out);
long dmp_shim_setregs(struct user_regs_struct *regs);
long dmp_shim_dupfd(unsigned int dmp_fd, enum ShimCtlFlag dup_to_dmp, int cloexec);
long dmp_shim_dupfd2(unsigned int dmp_fd, unsigned int dmp_fd_2);
long dmp_shim_closefd(unsigned int dmp_fd);
long dmp_shim_checkfd(unsigned int dmp_fd);
long dmp_shim_set_cloexec(unsigned int dmp_fd, int val);
long dmp_shim_set_nomot(unsigned int shim_fd, enum ShimMotFlag val);
long dmp_shim_get_logical_time(void);

/*
 * Library Functions
 */

/* Wrappers that block until serial mode when necessary */
long dmp_shim_memcpy_sync(void *shim_buf, void *dmp_buf, long nbytes, enum ShimCtlFlag write_to_dmp, long *bytes_out);
long dmp_shim_strncpy_sync(void *shim_buf, void *dmp_buf, long nbytes, long *bytes_out);

/* Tracing system calls */
long dmp_shim_emulate_syscall(long ret, struct user_regs_struct *regs);

static inline unsigned long shim_syscall_arg0(struct user_regs_struct* regs) { return regs->rdi; }
static inline unsigned long shim_syscall_arg1(struct user_regs_struct* regs) { return regs->rsi; }
static inline unsigned long shim_syscall_arg2(struct user_regs_struct* regs) { return regs->rdx; }
static inline unsigned long shim_syscall_arg3(struct user_regs_struct* regs) { return regs->r10; }
static inline unsigned long shim_syscall_arg4(struct user_regs_struct* regs) { return regs->r8; }
static inline unsigned long shim_syscall_arg5(struct user_regs_struct* regs) { return regs->r9; }
static inline unsigned long shim_syscall_return(struct user_regs_struct* regs) { return regs->rax; }

#ifdef __cplusplus
}
#endif
#endif
