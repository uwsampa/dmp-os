/**
 * recplayshim_net.h --
 *
 *   Declarations of record/replay functions for network operations.
 */

#ifndef _RECPLAYSHIM_NET_H_
#define _RECPLAYSHIM_NET_H_

#include "recplayshim_gen.h"

/* Sockets API */
__RECPLAY(socket);
__RECPLAY(socketpair);
__RECPLAY(bind);
__RECPLAY(listen);
__RECPLAY(connect);
__RECPLAY(sendto);
__RECPLAY(select);
__RECPLAY(getsockname);
__RECPLAY(sendto);
__RECPLAY(recvfrom);
__RECPLAY(recvmsg);
__RECPLAY(accept);
__RECPLAY(connect);
__RECPLAY(setsockopt);
__RECPLAY(getsockopt);

#endif /* _RECPLAYSHIM_NET_H_ */
