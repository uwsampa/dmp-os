#!/usr/bin/python
import sys

sort_var = 'pid'
vars = ['Parallel time','Serial time','Waiting for parallel exec (sec)',
	'Waiting for serial mode (sec)','Waiting for serial exec (sec)',
	'Waiting for end of round (sec)','Time spent blocked (sec)']

def die(msg):
	print msg
	sys.exit(1)

def prefix(title):
	cols = "=stackcluster"
	for v in vars:
		cols = cols + ";%s" % v
	print cols
	print "=noupperright"
	print "yformat=%g"
	print "title=" + title
	print "colors=dark_green,red,dark_blue,magenta,yellow,light_green,cyan,med_blue,light_blue"
	print "ylabel=Runtime (secs)"
	print "xlabel=Threads"
	print "=nocommas"
	print "=table"
	print ""

def print_result(title, res, divisor):
	print "multimulti=%s" % title 
	bar = "s/p"
	for v in vars:
		bar = bar + "\t%f" % (res[v] / divisor)
	print bar

	bar = "step\t%f" % (res['Stepping time'] / divisor)
	for i in range(len(vars)-1):
		bar = bar + "\t\t0"
	print bar

def print_pid(res):
	print_result("%s" % res['pid'], res, 1)

# Functions for displaying the average thread behavior
average_thread = {}
thread_count   = 0

def accumulate(cur):
	global average_thread, thread_count

	# Initialize the average dictionary on the first call
	if thread_count == 0:
		average_thread['Stepping time'] = 0
		for v in vars:
			average_thread[v] = 0

	thread_count = thread_count + 1

	average_thread['Stepping time'] = average_thread['Stepping time'] + cur['Stepping time']
	for v in vars:
		average_thread[v] = average_thread[v] + cur[v]

def print_average():
	global average_thread, thread_count
	if thread_count == 0:
		return
	
	print_result('Average', average_thread, thread_count)

def key_fn(res_dict):
	return res_dict[sort_var]

def main(argv):
	if len(argv) != 2:
		die("Usage: %s <datafile>" % argv[0])

	# Output the graph prefix and retrieve the results
	prefix(argv[1])
	exec(open(argv[1]).read())

	# Sort the results based on the pid
	results.sort(key=key_fn)

	# Ensure we loaded some data
	if results is None:
		die("`results' is undefined")
	
	# Print each thread
	#   N.B. Because results is sorted by pid (and ignoring the effects
	#        of pid wrap while spawning threads), we skip displaying
	#        the `rundet' thread by ignoring the first result
	first = 1
	for cur in results:
		# Skip box results
		if cur['pid'] == 0:
			continue
		elif first == 1:
			first = 0
			continue
		else:
			accumulate(cur)
			print_pid(cur)

	# Print the 'average' thread
	print_average()
	
	sys.exit(0)

if __name__ == "__main__":
	main(sys.argv)

