/*
 * The DMP shim process.
 *
 * NOTE: by the time the shim is invoked, we have already been
 * attached to the DMP thread, and that thread is stopped.
 */

#include <stdlib.h>
#include <stdio.h>
#include <syscall.h>
#include <sys/user.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>

#include "dmp.h"
#include "basicshim.h"
#include "recshim.h"
#include "pidshim.h"

using namespace DMP;

//-------------------------------------------------------------------------
// Commandline parsing:
//   --
//-------------------------------------------------------------------------

static int argc;
static char** argv;
static string logfile;
static bool compressed = false;
static bool dopid = false;
static bool dotasksummary = false;
static map<int, FileTimingInfo> localfds;

#define DEFAULT_TIME 50

#define USAGE \
"Usage: %s [opts]					\n\
Options:						\n\
   --localdir=dir,[rdtime,wrtime,opentime,closetime]	\n\
   --localfd=fdnum,[rdtime,wrtime,opentime,closetime]	\n\
   --record=logfile					\n\
   --pid						\n\
    -z                                                  \n\
   --task-summary					\n\
"

static void usage()
{
	fprintf(stderr, USAGE, argv[0]);
	exit(1);
}

enum option_t {
	OPT_LOCAL_DIR = 0x100,
	OPT_LOCAL_FD,
	OPT_RECORD, OPT_PID,
	OPT_TASK_SUMMARY,
};

struct option options[] = {
	{ "localdir",		required_argument, NULL, OPT_LOCAL_DIR },
	{ "localfd",		required_argument, NULL, OPT_LOCAL_FD },
	{ "record",		required_argument, NULL, OPT_RECORD },
	{ "pid",		no_argument,       NULL, OPT_PID },
	{ "task-summary",	no_argument,       NULL, OPT_TASK_SUMMARY },
	{ NULL, 0, NULL, 0 },
};

static void parseFileTimingInfo(char *opt, char **path, FileTimingInfo *timing)
{
	char *tmp;
	char *rdtime, *wrtime, *optime, *cltime;

	if (!path)
		return;

	*path  = strtok_r(opt,  ",", &tmp);
	rdtime = strtok_r(NULL, ",", &tmp);
	wrtime = strtok_r(NULL, ",", &tmp);
	optime = strtok_r(NULL, ",", &tmp);
	cltime = strtok_r(NULL, ",", &tmp);

	if (!path)
		usage();

	timing->read  = rdtime ? atoi(rdtime) : DEFAULT_TIME;
	timing->write = wrtime ? atoi(wrtime) : DEFAULT_TIME;
	timing->open  = optime ? atoi(optime) : DEFAULT_TIME;
	timing->close = cltime ? atoi(cltime) : DEFAULT_TIME;
}

static void parseLocalFile(char *opt)
{
	FileTimingInfo timing;
	char *path;

	parseFileTimingInfo(optarg, &path, &timing);
	if (!add_deterministic_file_path(path, timing))
		usage();
}

static void parseLocalFd(char *opt)
{
	FileTimingInfo timing;
	char *path;

	parseFileTimingInfo(optarg, &path, &timing);
	int fd = atoi(path);
	if (fd < 0)
		usage();

	localfds[fd] = timing;
}

static void parseCommandLine()
{
	int opt;

	// Stop at first unknown arg.
	while ((opt = getopt_long(argc, argv, "z", options, NULL)) != -1) {
		switch (opt) {
		case OPT_LOCAL_DIR:
			parseLocalFile(optarg);
			break;
		case OPT_LOCAL_FD:
			parseLocalFd(optarg);
			break;
		case OPT_RECORD:
			logfile = string(optarg); /* RecordShim adds random suffix */
			break;
		case OPT_PID:
			dopid = true;
			break;
		case OPT_TASK_SUMMARY:
			dotasksummary = true;
			break;
		case 'z':
			compressed = true;
			break;
		default:
			usage();
		}
	}

	// Rest of the commandline should be empty.
	if (optind != argc)
		usage();
}

static void initShim(BasicShim *shim)
{
	// Setup deterministic fds
	for (map<int,FileTimingInfo>::const_iterator
			iter = localfds.begin();
			iter != localfds.end();
			++iter) {
		shim->add_deterministic_fd(iter->first, iter->second);
	}

	// Get the pid from environ
	char* pid = getenv("INITIAL_DMP_PID");
	if (pid != NULL) {
		shim->_dmp_pid = atoi(pid);
		SHIM_LOG("connected to dmp task with pid=%d", shim->_dmp_pid);
	} else {
		SHIM_LOG("warning: no INITIAL_DMP_PID specified");
	}
}

//-------------------------------------------------------------------------
// Main
//-------------------------------------------------------------------------

int main(int _argc, char *_argv[])
{
	BasicShim* shim = NULL;

	// Initialize.
	argc = _argc;
	argv = _argv;
	parseCommandLine();

	// Run the shim.
	if (dopid) {
		shim = new PidShim(NULL, 0);
	} else if (!logfile.empty()) {
		shim = new RecordShim(NULL, 0, logfile, compressed);
	} else {
		shim = new BasicShim(NULL, 0);
	}

	initShim(shim);
	shim->loop();
	delete shim;

	WaitForThreadsToDie(dotasksummary);
	return 0;
}
