#!/usr/bin/python
import sys
from getopt import getopt
from subprocess import *
from os import system, popen, path, mkdir

# Configuration variables
base    = "/home/nhunt/sandbox/dmpos/git"
rundet  = base + "/tools/obj/rundet"
readlog = base + "/tools/readlog.sh"
racey   = base + "/test/obj"
parsec  = base + "/benchmarks/parsec-2.0/rundmp.pl"

# Experiment options
quantum = 100003
threads = [2, 4, 8]
modes   = ['native','serial','motfake','mot']
nloops  = 100000
input   = "simlarge"
optims  = ['none','adapts','adaptq','adapts,adaptq'] 

# Which variables are plotted
vars    = ['Parallel time','Serial time']

def die(msg):
	print msg
	sys.exit(1)

def prefix(fout, title):
	cols = "=stackcluster"
	for v in vars:
		cols = cols + ";%s" % v
	fout.write("%s\n" % cols)
	fout.write("yformat=%g\n")
	fout.write("title=" + title + "\n")
	fout.write("=noupperright\n")
	fout.write("colors=dark_green,red,dark_blue,magenta,yellow,light_green,cyan,med_blue,light_blue\n")
	fout.write("ylabel=Runtime (secs)\n")
	fout.write("xlabel=Number of Threads\n")
	fout.write("=table\n")
	fout.write("\n")

def print_box(fout, mode, results):
	res = "%s\t" % mode
	for v in vars:
		res = res + "%f\t" % results[v]

	fout.write("%s\n" % res)

def run_native(fout, bench):
	p = Popen("/usr/bin/time -f \"%%e\" %s > /dev/null" %
		(bench), shell=True, stdin=PIPE, stdout=PIPE,
		stderr=PIPE, close_fds=True)

	dur = p.stderr.read().strip()
	res = "native\t"
	for v in vars:
		if v == 'Parallel time':
			res = res + "%s\t\t" % dur
		else:
			res = res + "0\t\t"

	fout.write("%s\n" % res)

def run_racey_test(fout, bench, mode, nthreads, optims, loops):

	# Clear the syslog
	system("sudo bash -c 'echo "" > /var/log/syslog'")

	# Execute the benchmark
	cmd = "%s --mode=%s -q %d --debug-flags=stats -o %s %s/racey-%s %d %d > /dev/null" % (rundet, mode, quantum, optims, racey, bench, nthreads, loops)
	# cmd = "%s --mode=%s -q %d --debug-flags=stats -o %s %s/racey-%s %d %d" % (rundet, mode, quantum, optims, racey, bench, nthreads, loops)

	# print "Running %s" % cmd
	# return 

	system(cmd)
	system("sleep 1")
	
	# Read the results
	log = readlog + " %s/%s_%s_q%d_n%d_o%s_l%d" % (optims, bench, mode, quantum, nthreads, optims, loops)
	file = popen(log).read().strip()
	exec(open(file).read())

	# Display the box stats
	for cur in results:
		if cur['pid'] == 0:
			print_box(fout, mode, cur)
			break

def run_parsec_test(fout, bench, mode, nthreads, optims, input):

	# Clear the syslog
	system("sudo bash -c 'echo "" > /var/log/syslog'")

	# Execute the benchmark
	cmd = "%s %s -q %d -m %s -o %s -n %d -i %s -f stats > /dev/null" % (parsec, bench, quantum, mode, optims, nthreads, input)
	#cmd = "%s %s -q %d -m %s -n %d -i %s %s -f stats " % (parsec, bench, quantum, mode.upper(), nthreads, input, optims)

	#print "Running %s" % cmd
	#return

	system(cmd)
	system("sleep 1")
	
	# Read the results
	log = readlog + " %s/%s_%s_q%d_n%d_o%s_s%s" % (optims, bench, mode, quantum, nthreads, optims, input)
	file = popen(log).read().strip()
	exec(open(file).read())

	# Display the box stats
	for cur in results:
		if cur['pid'] == 0:
			print_box(fout, mode, cur)
			break

def is_racey(bench):
	return bench == "basic" or bench == "signal" or \
	       bench == "futex" or bench == "mmap"   or \
	       bench == "freqsyscall" or bench == "nobarrier" or \
	       bench == "guarded"

def run_racey(fout, bench, mode, nthreads, optims, loops):
	if mode == 'native':
		run_native(fout, "%s/racey-%s %d %d" % (racey, bench, nthreads, loops))
	else:
		run_racey_test(fout, bench, mode, nthreads, optims, loops)

def run_parsec(fout, bench, mode, nthreads, optims, input):
	if mode == 'native':
		run_native(fout, "%s %s -q 1 -m NONDET -n %d -i %s" % (parsec, bench, nthreads, input))
	else:
		run_parsec_test(fout, bench, mode, nthreads, optims, input)
	

def main(argv):
	global quantum
	global nloops
	global input
	global optims

	if len(argv) < 2:
		die("Usage: %s [options] <benchmark>" % argv[0])

	args = getopt(argv[1:], "q:n:i:")
	for arg in args[0]:
		if arg[0] == '-q':
			quantum = int(arg[1])
		elif arg[0] == '-n':
			nloops = int(arg[1])
		elif arg[0] == '-i':
			input = arg[1]

	bench = args[1][0]
	
	# Output the graph prefix, each set of optimizations
	# will have its own graph
	for o in optims:

		# Keep results for the different optimizations seperate
		if not path.isdir(o):
			mkdir(o)

		file = open(o + '/%s.graph' % bench, 'w+')
		prefix(file, bench)

		for n in threads:
			file.write("multimulti=%d threads\n" % n)
			for m in modes:
				print "--- Running %s with %d threads, mode %s, and %s optimizations..." % (bench, n, m, o)
				if is_racey(bench):
					run_racey(file, bench, m, n, o, nloops)
				else:
					run_parsec(file, bench, m, n, o, input)

		file.close()

	sys.exit(0)

if __name__ == "__main__":
	main(sys.argv)

