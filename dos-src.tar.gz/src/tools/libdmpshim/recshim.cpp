/*
 * A shim implementing the record half of record/replay
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <poll.h>
#include <pthread.h>
#include <sched.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syscall.h>
#include <time.h>
#include <unistd.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <sys/vfs.h>

#include "recshim.h"
#include "zbuf.h"

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))
#endif

#ifndef  MAX_BUF
#define MAX_BUF 8192    // for read/write buffers
#endif

/* Event types */
#define LOG_SYSCALL 0

/* Encoding of RecFnTab */
#define END     0L
#define ARG0    1L
#define ARG1    2L
#define ARG2    3L
#define ARG3    4L
#define ARG4    5L
#define ARG5    6L
#define RAX     7L

#define IMMLONG 1L
#define IMMREG  2L
#define PTR     3L

using namespace DMP;

/* Used for fds that are not deterministic */
static const FileTimingInfo defaultTiming = { -1, -1, -1, -1 };

/******************************************************************************
 *             H E L P E R   F U N C T I O N S   F O R   R D P                *
 ******************************************************************************/
static inline long get_reg(shim_event *event, long reg);
static inline long getlen(long *recstr, shim_event *event, int *i);
static inline long compute_arg_len(long *recstr, shim_event *event, int *i);
static inline void write_immreg(RecordShim *shim, long *recstr, shim_event *event, int *i,long arg);
static inline void write_immlong(RecordShim *shim, long *recstr, shim_event *event, int *i, long arg);
static inline void write_ptr(RecordShim *shim, long *recstr, shim_event *event, int *i, long arg);
static inline void write_arg(RecordShim *shim, long *recstr, shim_event *event, int *i);
static RecFn create_recstr(int ct, ...);
static RecFn create_recfn(void (*fn)(RecordShim *, shim_event*));



/******************************************************************************
 *         S P E C I A L I Z E D   R E C O R D   F U N C T I O N S            *
 ******************************************************************************/
static void record_poll(RecordShim *shim, shim_event *event);
static void record_recvmsg(RecordShim *shim, shim_event *event);
static void record_wait4(RecordShim *shim, shim_event *event);
static void record_uname(RecordShim *shim, shim_event *event);



/******************************************************************************
 *                         M I S C   H E L P E R S                            *
 ******************************************************************************/
static inline int writen(int fd, char *buf, int n);
static void add_record(RecordShim *shim, uint64_t logical_time, char type, long subtype, long len);



/******************************************************************************
 *         M E M B E R   F U N C T I O N S   O F   R E C O R D S H I M        *
 ******************************************************************************/
namespace DMP {
RecordShim::RecordShim(RecordShim* parent, int clone_flags, const string& logfile, bool _compressed)
	: BasicShim(parent, clone_flags), compressed(_compressed), _log_file_template(logfile)
{
	/*
	 * Create our working log file
	 */
	if (compressed)
		_log_file_template += ".z";

	_log_file_template += ".XXXXXX";
	_log_file_name = strdup(_log_file_template.c_str());
	_log_file = mkstemp(_log_file_name);

	SHIM_LOG("Using log file %s\n", _log_file_name);
	assert(_log_file != -1);

	/*
	 * Initialize the zlib engine if our log should be compressed
	 */
	if (compressed)
		zbufinit(&zbuf, _log_file);

	/*
	 * Setup the bindings for recording system calls
	 */
	memset(RecFnTab, 0, sizeof(RecFnTab));

	RecFnTab[SYS_fstat]        = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct stat), END);
	RecFnTab[SYS_getcwd]       = create_recstr(7,  RAX, IMMREG, ARG0, PTR, IMMREG, ARG2, END);
	RecFnTab[SYS_getdents]     = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMREG, ARG2, END);
	RecFnTab[SYS_getrlimit]    = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct rlimit), END);
	RecFnTab[SYS_gettimeofday] = create_recstr(11, RAX, IMMREG, ARG0, PTR, IMMLONG, (long)sizeof(struct timeval),  ARG1, PTR, IMMLONG, (long)sizeof(struct timezone), END);
	RecFnTab[SYS_lstat]        = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct stat), END);
	RecFnTab[SYS_pipe]         = create_recstr(7,  RAX, IMMREG, ARG0, PTR, IMMLONG, (long)(2 * sizeof(int)), END);
	RecFnTab[SYS_poll]         = create_recfn(record_poll);
	RecFnTab[SYS_read]         = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMREG, RAX, END);
	RecFnTab[SYS_readlink]     = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMREG, RAX, END);
	RecFnTab[SYS_recvfrom]     = create_recstr(15, RAX, IMMREG, ARG1, PTR, IMMREG, ARG2, ARG4, PTR, IMMLONG, (long)sizeof(struct sockaddr), ARG5, PTR, IMMLONG, (long)sizeof(socklen_t), END);
	RecFnTab[SYS_recvmsg]      = create_recfn(record_recvmsg);
	RecFnTab[SYS_select]       = create_recstr(19, RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(fd_set), ARG2, PTR, IMMLONG, (long)sizeof(fd_set), ARG3, PTR, IMMLONG, (long)sizeof(fd_set), ARG4, PTR, IMMLONG, (long)sizeof(struct timeval), END);
	RecFnTab[SYS_socketpair]   = create_recstr(7,  RAX, IMMREG, ARG3, PTR, IMMLONG, (long)(2 * sizeof(int)), END);
	RecFnTab[SYS_stat]         = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct stat), END);
	RecFnTab[SYS_time]         = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(time_t), END);
	RecFnTab[SYS_uname]        = create_recfn(record_uname);
	RecFnTab[SYS_wait4]        = create_recfn(record_wait4);
	RecFnTab[SYS_statfs]       = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct statfs), END);
	RecFnTab[SYS_clock_getres] = create_recstr(7,  RAX, IMMREG, ARG1, PTR, IMMLONG, (long)sizeof(struct timespec), END);
	RecFnTab[SYS_sched_getaffinity] = create_recstr(7, RAX, IMMREG, ARG2, PTR, IMMREG, ARG1, END);

	/*
	 * Set the record function to record system calls that don't have a
	 * specific function set.
	 */
	GenericFn                  = create_recstr(3,  RAX, IMMREG, END);
}

RecordShim::~RecordShim()
{
	unsigned int i;

	SHIM_LOG("Destroying recshim\n");

	if (compressed)
		zbufdestroy(&zbuf);

	if (_log_file)
		close(_log_file);

	for (i = 0; i < ARRAY_SIZE(RecFnTab); i++) {
		if (RecFnTab[i].type == RecFn::RECSTR)
			free(RecFnTab[i].recstr);
	}
}

int RecordShim::append_buffer(char *buf, int n)
{
	if (compressed)
		return zaddbuf(&zbuf, buf, n);
	else
		return writen(_log_file, buf, n);
}

RecordShim* RecordShim::clone(int clone_flags)
{
	return new RecordShim(this, clone_flags, _log_file_template, compressed);
}

void RecordShim::record_syscall(long syscall, shim_event *event)
{
	if ((unsigned long)syscall >= ARRAY_SIZE(RecFnTab))
		return;

	const RecFn* r = &RecFnTab[syscall];

	if (r->type == RecFn::RECNONE)
		r = &GenericFn;

	switch (r->type) {
	case RecFn::RECNONE:
		assert(false);
		break;
	case RecFn::RECSTR:
		record_str(r->recstr, event);
		break;
	case RecFn::RECFN:
		assert(r->recfn != NULL);
		r->recfn(this, event);
		break;
	}
}

/*
 * TODO: we need to exec send,recv,write,etc. as we do read()
 */

void RecordShim::trace_syscall_enter(shim_event* event)
{
	const long syscall = event->regs.orig_rax;
	bool ateleave = false;

	switch (syscall) {
	// Forking
	// (BasicShim emulates these calls, so we don't get a leave event)
	case SYS_fork:
	case SYS_clone:
	case SYS_vfork:
		BasicShim::trace_syscall_enter(event);
		record_syscall(syscall, event);
		break;

	// Fileops
	// (BasicShim emulates these calls when they are deterministic)
	case SYS_open:
		ateleave = do_fs_open(event);
		break;
	case SYS_close:
		ateleave = do_fs_close(event);
		break;
	case SYS_read:
		ateleave = do_fs_read(event);
		break;
	case SYS_write:
		ateleave = do_fs_write(event);
		break;
	case SYS_dup:
		ateleave = do_fs_dup(event);
		break;
	case SYS_dup2:
		ateleave = do_fs_dup2(event);
		break;
	default:
		BasicShim::trace_syscall_enter(event);
		break;
	}

	// TODO: record return values here on error only?
	//   we won't get a sysleave event since the syscall was emulated
	if (ateleave) {
		if (event->regs.rcx < 0) {
			add_record(this, event->logical_time, LOG_SYSCALL, event->regs.orig_rax, sizeof(long));
			this->append_buffer((char *)&event->regs.rcx, sizeof(event->regs.rcx));
		}
	}
}

bool RecordShim::do_fs_read(shim_event* event)
{
	const int userfd        = shim_syscall_arg0(&event->regs);
	unsigned long userbuf   = shim_syscall_arg1(&event->regs);
	unsigned long userbufsz = shim_syscall_arg2(&event->regs);
	long ret;

// XXX this function is broken
	return BasicShim::do_fs_read(event);

	SHIM_LOG("@%ld.%d: rec_read(fd:%d, sz:%ld) ...\n", EVTIME(event), userfd, userbufsz);

	/*
	 * To deal with multiple wakes during blocking operations, have the
	 * record shim perform all reads on behalf of the thread, rather than
	 * just the ones that are shadowed
	 */

	/* If this is a deterministic fd, use BasicShim */
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd != NULL && fd->timing.read != -1) {
		SHIM_LOG(" ... already deterministic, calling BasicShim\n");
		return BasicShim::do_fs_read(event);
	}

	/* If this fd has not been seen before, add it */
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed; adding...\n", userfd);
		add_deterministic_fd(userfd, defaultTiming);
		fd = _fdtable->get(userfd);
	}

	/* If we still have a NULL fd, bad things have happened */
	if (fd == NULL) {
		SHIM_LOG(" ... couldn't add fd?\n");
		return false;
	}

	start_io_op(fd->timing.read);

	// Cap the maximum buffer size.
	if (userbufsz > MAX_BUF) {
		userbufsz = MAX_BUF;
		SHIM_LOG(" ... capping buffer to sz:%ld\n", userbufsz);
	}

	/*
	 * Read from the fd
	 * TODO: Expand the logging API to allow for a direct read in to the
	 *   buffer, rather than having to copy it in once the read has finished
	 */
	
	_tmp_buffer.resize(userbufsz);
	char* buf = &_tmp_buffer[0];
	
	ret = read(fd->shadowfd, buf, userbufsz);
	if (ret == 0) {
		// End Of File
		SHIM_LOG("... end-of-file\n");

	} else if (ret < 0) {
		ret = -errno;
	}

	// Copy the result.
	finish_io_op(fd->timing.read);
	if (ret > 0) {
		long out;
		if (dmp_shim_memcpy_sync((void*)buf, (void*)userbuf, ret, TO_DMP, (long*)&out) < 0)
			ret = -errno;
	}

	/* Make an entry in our log */
	int bufsize = ret < 0 ? 0 : ret; /* Compute the size of the buffer to record */
	add_record(this, event->logical_time, LOG_SYSCALL, event->regs.orig_rax, sizeof(long) + bufsize);
	this->append_buffer((char *)&ret, sizeof(ret));
	if (bufsize)
		this->append_buffer(buf, bufsize);

	SHIM_LOG_CONT(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);

	
	return true;
}

void RecordShim::trace_syscall_leave(shim_event* event)
{
	const long syscall = event->regs.orig_rax;
	const long retval  = event->regs.rax;

	switch(syscall) {
	case SYS_mmap:
	case SYS_mprotect:
	case SYS_munmap:
	case SYS_set_tid_address:
	case SYS_set_robust_list:
		/* Only record the result if there was an error */
		if (retval >= 0)
			return;
		break;
	case SYS_futex:
		if (retval >= 0 || retval == -EAGAIN)
			return;
		break;
	}

	SHIM_LOG("Syscall leave: %ld\n", syscall);
	record_syscall(syscall, event);
	BasicShim::trace_syscall_leave(event);
}

void RecordShim::record_str(long *recstr, shim_event *event)
{
	long reclen = 0;
	int i = 0;

	while (recstr[i] != END) {
		reclen += compute_arg_len(recstr, event, &i);
	}
	
	add_record(this, event->logical_time, LOG_SYSCALL, 
		event->regs.orig_rax, reclen);

	i = 0;
	while (recstr[i] != END)
		write_arg(this, recstr, event, &i);
}

}  /* namespace DMP */



/******************************************************************************
 *                        S T A T I C   N O N S E N S E                       *
 ******************************************************************************/
static inline long get_reg(shim_event *event, long reg)
{
	switch (reg) {
	case ARG0: return shim_syscall_arg0(&event->regs); break;
	case ARG1: return shim_syscall_arg1(&event->regs); break;
	case ARG2: return shim_syscall_arg2(&event->regs); break;
	case ARG3: return shim_syscall_arg3(&event->regs); break;
	case ARG4: return shim_syscall_arg4(&event->regs); break;
	case ARG5: return shim_syscall_arg5(&event->regs); break;
	case RAX:  return event->regs.rax; break;
	default:
		return -1;
		break;
	}
}

static long get_string(char *shim_buf, char *dmp_buf, long nbytes, long *out)
{
	long bytes, ret;

	/* Get the string */
	ret = dmp_shim_strncpy_sync(shim_buf, dmp_buf, nbytes, &bytes);

	/* Make sure its NULL-terminated */
	if (bytes > 0)
		shim_buf[bytes - 1] = '\0';
	else
		shim_buf[0] = '\0';

	if (out)
		*out = bytes;

	return ret;
}

static long getlen(long *recstr, shim_event *event, int *i)
{
	long type = recstr[(*i)++], subtype;
	long reclen = 0;
	long temp;
	
	switch (type) {
	case IMMREG:
		reclen += sizeof(long);
		break;
	case IMMLONG:
		temp = recstr[(*i)++];
		reclen += temp;
		break; 
	case PTR:
		subtype = recstr[(*i)++];
		switch (subtype) {
		case IMMREG:  reclen += get_reg(event, recstr[(*i)++]); break;
		case IMMLONG: reclen += recstr[(*i)++]; break;
		};
		break;
	}

	return reclen;
}

static inline long compute_arg_len(long *recstr, shim_event *event, int *i)
{
	long recsize = 0;

	/* Chomp the arg */
	(*i)++;

	recsize = getlen(recstr, event, i);
	return recsize;
}

static inline void write_immreg(RecordShim *shim, long *recstr, shim_event *event, int *i, long arg)
{
	long val = get_reg(event, arg);
	shim->append_buffer((char *)&val, sizeof(val));
}

static inline void write_immlong(RecordShim *shim, long *recstr, shim_event *event, int *i, long arg)
{
	long imm = recstr[(*i)++];
	shim->append_buffer((char *)&imm, sizeof(imm));
}

static inline void write_ptr(RecordShim *shim, long *recstr, shim_event *event, int *i, long arg)
{
	long subtype = recstr[(*i)++];
	long len = -1;
	void *ptr = NULL;
	void *buffer = NULL;

	switch (subtype) {
	case IMMLONG: len = recstr[(*i)++]; break;
	case IMMREG:  len = get_reg(event, (long)recstr[(*i)++]); break;
	default:
		/* Nonsense */
		return;
	}

	if (len <= 0) {
		/* Nothing to record */
		return;
	}

	ptr = (void *)get_reg(event, arg);

	buffer = malloc(len);
	if (buffer == NULL)
		return;

	dmp_shim_memcpy(buffer, ptr, len, FROM_DMP, NULL);

	shim->append_buffer((char *)buffer, len);
}

static inline void write_arg(RecordShim *shim, long *recstr, shim_event *event, int *i)
{
	long arg  = recstr[(*i)++];
	long type = recstr[(*i)++];

	switch (type) {
	case IMMREG:  write_immreg(shim, recstr, event, i, arg); break;
	case IMMLONG: write_immlong(shim, recstr, event, i, arg); break;
	case PTR:     write_ptr(shim, recstr, event, i, arg); break;
	}
}

static RecFn create_recstr(int ct, ...)
{
	RecFn recfn;

	int i;
	va_list va;

	recfn.type = RecFn::RECSTR;
	recfn.recstr = (long *)calloc(ct, sizeof(long));
	if (recfn.recstr == NULL)
		return recfn;

	va_start(va, ct);

	for (i = 0; i < ct; i++)
		recfn.recstr[i] = va_arg(va, long);
	
	va_end(va);

	return recfn;
}

static RecFn create_recfn(void (*fn)(RecordShim *shim, shim_event*))
{
	RecFn recfn;

	recfn.type = RecFn::RECFN;
	recfn.recfn = fn;

	return recfn;
}

static inline int writen(int fd, char *buf, int n)
{
	int left = n, sofar = 0, last = 0;

	while (left > 0) {
		if ((last = write(fd, buf + sofar, left)) < 0) {
			perror("write failed");
			sofar = last;
			break;
		}

		if (last == 0)
			break;

		sofar += last;
		left  -= last;
	};

	return sofar;
}

static void add_record(RecordShim *shim, uint64_t logical_time, char type, long subtype, long len)
{
	int fulltype = type | (subtype << 4);

	/* Don't need to record the syscall number; its deterministic */
	shim->append_buffer((char *)&logical_time, sizeof(logical_time));
	shim->append_buffer((char *)&fulltype, sizeof(fulltype));
	shim->append_buffer((char *)&len, sizeof(len));
}



/******************************************************************************
 *              S P E C I A L   R E C O R D   F U N C T I O N S               *
 ******************************************************************************/
void record_poll(RecordShim *shim, shim_event *event)
{
	long   ret         = shim_syscall_return(&event->regs);
	void  *fds         = (void*)shim_syscall_arg0(&event->regs);
	nfds_t nfds        = shim_syscall_arg1(&event->regs);
	int    timeout     = shim_syscall_arg2(&event->regs);
	int    reclen, fdlen;
	struct pollfd *localfds = NULL;

	/* On error, just record return value */
	if (ret < 0) {
		shim->record_str(shim->GenericFn.recstr, event);
		return;
	}
	
	SHIM_LOG("Recording sys_poll()\n");

	localfds = (struct pollfd*)calloc(nfds, sizeof(struct pollfd));
	assert(localfds != NULL);

	fdlen = nfds * sizeof(struct pollfd);
	dmp_shim_memcpy_sync(localfds, fds, fdlen, FROM_DMP, NULL);

	reclen = sizeof(long)     /* return value */
	       + fdlen            /* the pollfds  */
	       + sizeof(nfds_t)   /* nfds */
	       + sizeof(int);     /* the timeout */

	add_record(shim, event->logical_time, LOG_SYSCALL, event->regs.orig_rax, reclen);
	shim->append_buffer((char *)&event->regs.rax, sizeof(event->regs.rax));
	shim->append_buffer((char *)localfds, fdlen);
	shim->append_buffer((char *)&nfds, sizeof(nfds));
	shim->append_buffer((char *)&timeout, sizeof(int));

	free(localfds);
}

void record_recvmsg(RecordShim *shim, shim_event *event)
{
	long ret = shim_syscall_return(&event->regs);
	unsigned long nrecvd = ret;
	unsigned long reclen, toread, sofar = 0;
	struct msghdr msg;
	struct iovec *curiov, iov;
	char *buffer;

	/* On error, just record return value */
	if (ret < 0) {
		shim->record_str(shim->GenericFn.recstr, event);
		return;
	}

	reclen = sizeof(long)   /* return value */
	       + nrecvd;        /* message contents */

	add_record(shim, event->logical_time, LOG_SYSCALL, event->regs.orig_rax, reclen);
	shim->append_buffer((char *)&event->regs.rax, sizeof(event->regs.rax));

	dmp_shim_memcpy_sync(&msg, (void*)shim_syscall_arg1(&event->regs),
				sizeof(struct msghdr), FROM_DMP, NULL);

	curiov = msg.msg_iov;
	buffer = (char*)calloc(1, nrecvd);
	assert(buffer);

	while (sofar < nrecvd) {
		dmp_shim_memcpy_sync(&iov, curiov, sizeof(iov), FROM_DMP, NULL);
		
		toread = nrecvd - sofar;
		toread = (iov.iov_len < toread ? iov.iov_len : toread);

		dmp_shim_memcpy_sync(buffer + sofar, iov.iov_base, toread,
			FROM_DMP, NULL);

		sofar += toread;
		curiov++;
	}

	shim->append_buffer(buffer, sofar);
	free(buffer);
}

void record_wait4(RecordShim *shim, shim_event *event)
{
	long ret             = shim_syscall_return(&event->regs);
	int *status          = (int *)shim_syscall_arg1(&event->regs);
	struct rusage *usage = (struct rusage *)shim_syscall_arg3(&event->regs);
	struct rusage localusage;
	int localstatus;
	long reclen;

	/* On error, just record return value */
	if (ret < 0) {
		shim->record_str(shim->GenericFn.recstr, event);
		return;
	}

	reclen = sizeof(long)           /* return value */
	       + sizeof(struct rusage); /* resource usage */

	/*
	 * Assume that status the presence of status is deterministic;
	 * only record status if non-NULL, and record it in the same
	 * order as the arguments to wait4.
	 */

	if (status != NULL)
		reclen += sizeof(int);

	dmp_shim_memcpy_sync(&localusage, usage, sizeof(struct rusage),
		FROM_DMP, NULL);

	add_record(shim, event->logical_time, LOG_SYSCALL,
		event->regs.orig_rax, reclen);

	shim->append_buffer((char *)&ret, sizeof(ret));

	if (status != NULL) {
		dmp_shim_memcpy_sync(&localstatus, status, sizeof(int),
			FROM_DMP, NULL);
		shim->append_buffer((char *)&localstatus, sizeof(int));
	}

	shim->append_buffer((char *)&localusage, sizeof(struct rusage));
}

void record_uname(RecordShim *shim, shim_event *event)
{
	long ret             = shim_syscall_return(&event->regs);
	struct utsname *uts  = (struct utsname *)shim_syscall_arg0(&event->regs);
	struct utsname localuts;
	long reclen;
	char buffer[256];
	long out;
	char *sysname, *nodename, *release, *version, *machine, *domainname;

	/* On error, just record return value */
	if (ret < 0) {
		shim->record_str(shim->GenericFn.recstr, event);
		return;
	}

	/*
	 * TODO: The domainname parameter of utsname is only defined if _GNU_SOURCE
	 *   is defined before including sys/utsname. How can we know whether or not
	 *   the dmp task has defined it? For now, assume (erroneously) that if
	 *   its defined in the shim, it is defined in the dmp task.
	 */

	/* Get the uts struct */
	dmp_shim_memcpy_sync(&localuts, uts, sizeof(localuts), FROM_DMP, NULL);

	/* Get each string */
	get_string(buffer, localuts.sysname, 256, &out);
	sysname = strdup(buffer);
	get_string(buffer, localuts.nodename, 256, &out);
	nodename = strdup(buffer);
	get_string(buffer, localuts.release, 256, &out);
	release = strdup(buffer);
	get_string(buffer, localuts.version, 256, &out);
	version = strdup(buffer);
	get_string(buffer, localuts.machine, 256, &out);
	machine = strdup(buffer);

	assert(sysname && nodename && release && version && machine);

	#ifdef _GNU_SOURCE
	get_string(buffer, localuts.domainname, 256, &out);
	domainname = strdup(buffer);
	assert(domainname);
	#endif

	reclen = sizeof(long)           /* return value */
	       + strlen(sysname)
	       + strlen(nodename)
	       + strlen(release)
	       + strlen(version)
	       + strlen(machine);

	#ifdef _GNU_SOURCE
	reclen += strlen(domainname);
	#endif

	add_record(shim, event->logical_time, LOG_SYSCALL,
		event->regs.orig_rax, reclen);

	shim->append_buffer((char *)&ret, sizeof(ret));
	shim->append_buffer(sysname, strlen(sysname));
	shim->append_buffer(nodename, strlen(nodename));
	shim->append_buffer(release, strlen(release));
	shim->append_buffer(version, strlen(version));
	shim->append_buffer(machine, strlen(machine));

	#ifdef _GNU_SOURCE
	shim->append_buffer(domainname, strlen(domainname));
	#endif
}
