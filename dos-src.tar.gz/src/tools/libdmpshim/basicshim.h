/*
 * A library of useful shim functions
 */

#ifndef __LIBDMPSHIM_BASICSHIM_H__
#define __LIBDMPSHIM_BASICSHIM_H__

#ifndef __cplusplus
#error "basic shim requires c++"
#endif

#include <errno.h>
#include <pthread.h>
#include <syscall.h>
#include <sys/user.h>

#include "dmpshim.h"

#include <boost/filesystem/path.hpp>
#include <boost/shared_ptr.hpp>
#include <algorithm>
#include <memory>
#include <map>
#include <set>
#include <string>
#include <vector>

using std::auto_ptr;
using std::map;
using std::set;
using std::string;
using std::vector;
using boost::shared_ptr;

// utils.c
extern "C" const char* GetSyscallName(const long syscall);

namespace DMP {

/* Blocks until all threads die */
void WaitForThreadsToDie(bool printsummary);

/*
 * Deterministic fs ops
 * Must initialize these before spawning any threads.
 */

struct FileTimingInfo {
	// Number of logical time ticks to use for each operation
	//   < 0 :: blocking unbounded (nondeterministic)
	//     0 :: nonblocking
	//   > 0 :: blocking bounded
	int read;
	int write;
	int open;
	int close;
};

bool add_deterministic_file_path(const char* path, const FileTimingInfo& timing);
bool check_for_deterministic_file_path(const boost::filesystem::path &cwd,
				       const char* path, FileTimingInfo* timing);

/*
 * Fd tables
 */

struct FileDescriptor
{
	FileDescriptor();
	~FileDescriptor();

	FileTimingInfo timing;   // how much logical time to spend for each fs op
	int shadowfd;            // shadow file descriptor
	long filesize;           // total file size in bytes
	long filepos;            // position in the file
};

class FileDescriptorTable : protected map<int, shared_ptr<FileDescriptor> >
{
 public:
	FileDescriptorTable();
	shared_ptr<FileDescriptorTable> clone();

	void add(int fd, shared_ptr<FileDescriptor> f)	{ (*this)[fd] = f; }
	void clear()					{ (*this).clear(); }
	shared_ptr<FileDescriptor> get(int fd);
	void remove(int fd);

 private:
	FileDescriptorTable(const FileDescriptorTable& clone);
	bool operator=(FileDescriptorTable&);
	friend class shared_ptr<FileDescriptorTable>;
};


/*
 * An extensible base-class for a basic DMP shim thread
 */

class BasicShim {
 public:
	// info about the dmp task being shimmed
	pid_t _dmp_pid;
	shared_ptr<FileDescriptorTable> _fdtable;
	shared_ptr<boost::filesystem::path> _cwd;

	// a unique, deterministic sort key
	const uint32_t _unique_id;

 public:
	BasicShim(BasicShim* parent, int clone_flags);
	virtual ~BasicShim();

	virtual BasicShim* clone(int clone_flags);

	virtual void loop();
	virtual void trace_syscall_enter(shim_event* event);
	virtual void trace_syscall_leave(shim_event* event);
	virtual void trace_shimcall(shim_event* event);
	virtual void trace_barrier(shim_event* event);
	virtual void trace_signal(shim_event* event);
	virtual void trace_exit(shim_event* event);
	virtual void follow_fork(long syscall, long clone_flags);
	virtual void attach_after_fork();

	// called on sysenter: return true if the event was emulated
	virtual bool do_fs_open(shim_event* event);
	virtual bool do_fs_close(shim_event* event);
	virtual bool do_fs_read(shim_event* event);
	virtual bool do_fs_write(shim_event* event);
	virtual bool do_fs_lseek(shim_event* event);
	virtual bool do_fs_dup(shim_event* event);
	virtual bool do_fs_dup2(shim_event* event);

	// called on sysleave
	virtual void do_fs_chdir(shim_event* event);

	// utils
	bool add_deterministic_fd(int dmp_fd, const FileTimingInfo& timing);

	// for sorting by _unique_id
	struct UniqueSort {
		bool operator()(BasicShim* a, BasicShim* b) {
			return a->_unique_id < b->_unique_id;
		}
	};

 protected:
	// utils
	void start_io_op(int timing);
	void finish_io_op(int timing);

 protected:
 	bool _done_flag;
	vector<char> _tmp_buffer;
};

} // namespace DMP

#endif
