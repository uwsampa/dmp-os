#ifndef __PIDSHIM_H__
#define __PIDSHIM_H__

#ifndef __cplusplus
#error "record shim requires c++"
#endif

#include "dmpshim.h"
#include "basicshim.h"

namespace DMP {

class PidShim : public BasicShim {
 public:
	PidShim(PidShim* parent, int clone_flags);
	virtual ~PidShim();

	virtual PidShim* clone(int clone_flags);

	virtual void trace_syscall_enter(shim_event* event);
	virtual void trace_syscall_leave(shim_event* event);
 
 private:
 	int _done_flag;
};

} // namespace DMP

#endif
