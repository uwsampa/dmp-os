/*
 * User-land library for DMP shim processes
 */

#ifndef __LIBDMPSHIM_DMPSHIM_H__
#define __LIBDMPSHIM_DMPSHIM_H__

#include <signal.h>
#include <sys/user.h>
#include <stdint.h>

#include "dmp.h"

#ifdef SHIM_DEBUG

#define SHIM_LOG_CONT(fmt, args...) \
	fprintf(stderr, fmt, ## args)

#define SHIM_LOG(fmt, args...)	                               \
	do {                                                   \
		fprintf(stderr, "(%s) ", __func__); \
		SHIM_LOG_CONT(fmt, ## args);                   \
	} while(0)

#else   // SHIM_NDEBUG

#define SHIM_LOG_CONT(fmt, args...)
#define SHIM_LOG(fmt, args...)

#endif  // SHIM_DEBUG

#define SHIM_PERROR(msg)				\
	do {						\
		fprintf(stderr, "(%s) ERROR %s: %s\n", __func__, msg, strerror(errno));	\
	} while(0)


/* shortcut for printf: print a logical time as quantums.{0,1} */
#define EVTIME(event)	((event)->logical_time/2), ((int)((event)->logical_time%2))

#ifdef __cplusplus
extern "C" {
#endif

/* Magic syscall numbers */
#define SYS_dmp_shim_attach		289
#define SYS_dmp_shim_trace		290
#define SYS_dmp_shim_set_barrier	291
#define SYS_dmp_shim_sleep		292
#define SYS_dmp_shim_ctl		293

/*
 * The following values and struct must be kept in sync with
 * include/linux/dmp.h
 */

/* Types of events */
enum ShimEvent {
	DMP_SHIM_SYSCALL_ENTER	= 0,
	DMP_SHIM_SYSCALL_LEAVE	= 1,
	DMP_SHIM_BARRIER	= 2,
	DMP_SHIM_CALL		= 3,
	DMP_SHIM_EXIT		= 4,
	DMP_SHIM_VFORK_WAIT	= 5,
};

/* Types of ctl functions */
enum ShimCtl {
	DMP_SHIM_CTL_MEMCPY	= 0,
	DMP_SHIM_CTL_STRNCPY	= 1,
	DMP_SHIM_CTL_SETREGS	= 2,
	DMP_SHIM_CTL_DUPFD	= 3,
	DMP_SHIM_CTL_DUPFD2	= 4,
	DMP_SHIM_CTL_CLOSEFD	= 5,
};

/* Types of barriers */
enum ShimBarrier {
	SHIM_BARRIER_NEXT_MODE		= 0,  /* set barrier ASAP */
	SHIM_BARRIER_NEXT_SERIAL	= 1,  /* set barrier next serial mode */
	SHIM_BARRIER_OFFSET_PARALLEL	= 2,  /* set barrier N rounds from now, in parallel mode */
	SHIM_BARRIER_OFFSET_SERIAL	= 3,  /* set barrier N rounds from now, in serial mode */
	SHIM_BARRIER_FIXED_TIME		= 4,  /* set barrier for specific logical_time */
};

/* For dmp_shim_memcpy and dmp_shim_dupfd */
enum ShimCtlFlag {
	FROM_DMP	= 0,
	TO_DMP		= 1,
	/* For dmp_shim_dupfd */
	DUP_IN_DMP	= 2,
};

struct shim_event {
	uint32_t event_type;
	uint64_t logical_time;

	/* for syscall and vforkwait events only */
	struct user_regs_struct regs;
};


/*
 * Syscalls
 */
long dmp_shim_attach(pid_t pid);
long dmp_shim_trace(struct shim_event *event);
long dmp_shim_set_barrier(enum ShimBarrier type, uint64_t logical_time);
long __dmp_shim_set_barrier(pid_t pid, enum ShimBarrier type, uint64_t logical_time);  /* ugly :( */
long dmp_shim_sleep(void);
long dmp_shim_ctl(enum ShimCtl func, long arg1, long arg2, long arg3, long arg4, long arg5);

/* Ctl shorthands */
long dmp_shim_memcpy(void *shim_buf, void *dmp_buf, long nbyte, enum ShimCtlFlag write_to_dmp, long *bytes_out);
long dmp_shim_strncpy(void *shim_buf, void *dmp_buf, long nbytes, long *bytes_out);
long dmp_shim_setregs(struct user_regs_struct *regs);
long dmp_shim_dupfd(unsigned int dmp_fd, enum ShimCtlFlag dup_to_dmp);
long dmp_shim_dupfd2(unsigned int dmp_fd, unsigned int dmp_fd_2);
long dmp_shim_closefd(unsigned int dmp_fd);

/*
 * Library Functions
 */

/* Wrappers that block until serial mode when necessary */
long dmp_shim_memcpy_sync(void *shim_buf, void *dmp_buf, long nbytes, enum ShimCtlFlag write_to_dmp, long *bytes_out);
long dmp_shim_strncpy_sync(void *shim_buf, void *dmp_buf, long nbytes, long *bytes_out);

/* Tracing system calls */
long dmp_shim_emulate_syscall(long ret, struct user_regs_struct *regs);

static inline unsigned long shim_syscall_arg0(struct user_regs_struct* regs) { return regs->rdi; }
static inline unsigned long shim_syscall_arg1(struct user_regs_struct* regs) { return regs->rsi; }
static inline unsigned long shim_syscall_arg2(struct user_regs_struct* regs) { return regs->rdx; }
static inline unsigned long shim_syscall_arg3(struct user_regs_struct* regs) { return regs->r10; }
static inline unsigned long shim_syscall_arg4(struct user_regs_struct* regs) { return regs->r8; }
static inline unsigned long shim_syscall_arg5(struct user_regs_struct* regs) { return regs->r9; }
static inline unsigned long shim_syscall_return(struct user_regs_struct* regs) { return regs->rax; }

#ifdef __cplusplus
}
#endif
#endif
