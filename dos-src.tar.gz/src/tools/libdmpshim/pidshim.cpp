#include "pidshim.h"

namespace DMP {

PidShim::PidShim(PidShim* parent, int clone_flags)
	: BasicShim(parent, clone_flags), _done_flag(0)
{ } 

PidShim::~PidShim()
{ }

PidShim* PidShim::clone(int clone_flags)
{
	return new PidShim(this, clone_flags);
}

void PidShim::trace_syscall_enter(shim_event* event)
{
	const long syscall = event->regs.orig_rax;
	
	BasicShim::trace_syscall_enter(event);

	switch (syscall) {
	case SYS_getpid:
		SHIM_LOG("getpid() called; setting barrier\n");
		dmp_shim_set_barrier(SHIM_BARRIER_OFFSET_PARALLEL, 5);

		SHIM_LOG("putting to sleep\n");
		dmp_shim_sleep();
		SHIM_LOG("dmp thread is now sleeping\n");

		SHIM_LOG("waiting for barrier notification\n");
		dmp_shim_trace(event);
		if (event->event_type != DMP_SHIM_BARRIER) {
			SHIM_LOG("non-barrier event received: %d\n", event->event_type);
		} else {
			SHIM_LOG("got barrier event\n");
		}

		SHIM_LOG("emulating call\n");
		dmp_shim_emulate_syscall(1984, &event->regs);

		SHIM_LOG("done\n");
		break;
	}
}

void PidShim::trace_syscall_leave(shim_event* event)
{
	const long syscall = event->regs.orig_rax;
	SHIM_LOG("Syscall leave: %ld\n", syscall);
}

}  // namespace DMP
