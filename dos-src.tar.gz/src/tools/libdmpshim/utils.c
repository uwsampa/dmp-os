/*
 * Misc utils
 */

#undef  __SYSCALL
#define __SYSCALL(nr, name)  [nr] = #name,

static const char* SyscallNames[300] = {
#include <syscall.h>
};

const char* GetSyscallName(const long syscall)
{
	if (syscall >= 300)
		return "?";
	else
		return SyscallNames[syscall] ? : "?";
}
