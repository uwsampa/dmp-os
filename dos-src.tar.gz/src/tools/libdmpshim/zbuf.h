#ifndef _ZBUF_H_
#define _ZBUF_H_

#include <zlib.h>

#define ZCHUNK (256 * 1024)

typedef struct {
	int fd;

	unsigned char inbuf[ZCHUNK];
	int  inlen;
	int  inavail;

	unsigned char outbuf[ZCHUNK];
	int  outlen;
	int  outavail;

	z_stream strm;
} ZBuf;

int  zbufinit(ZBuf *zbuf, int fd);
void zbufdestroy(ZBuf *zbuf);

int zaddbuf(ZBuf *zbuf, char *buf, int n);
int zbufflush(ZBuf *zbuf, int flush);

#endif /* _ZBUF_H_ */
