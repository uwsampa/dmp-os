/*
 * A library of useful shim functions
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "basicshim.h"

#ifdef SHIM_DEBUG

#undef  SHIM_LOG
#define SHIM_LOG(fmt, args...)						\
	do {								\
		fprintf(stderr, "[%d] (%s) ", _dmp_pid, __func__);	\
		SHIM_LOG_CONT(fmt, ## args);				\
	} while(0)

#endif  // SHIM_DEBUG

#undef  MAX_BUF
#define MAX_BUF		(16<<20)  // for read/write buffers

#ifndef PATH_MAX
#define PATH_MAX	4096      // matches PATH_MAX in the kernel
#endif

static uint32_t uniquekey;

namespace DMP {

//-------------------------------------------------------------------------
// Local stuff
//-------------------------------------------------------------------------

static boost::filesystem::path join_paths(const boost::filesystem::path &root, const char* sub)
{
	if (sub[0] == '/') {
		return boost::filesystem::path(sub);
	} else {
		return root / sub;
	}
}

static uint32_t nprocesses;
static uint32_t nthreads;
static uint32_t nrunning;
static pthread_mutex_t nrunning_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  nrunning_cond = PTHREAD_COND_INITIALIZER;

static inline void AddProcess()
{
	__sync_fetch_and_add(&nprocesses, 1);
}

static inline void AddThread()
{
	__sync_fetch_and_add(&nthreads, 1);
}

static inline void UpdateNRunning(int diff)
{
	pthread_mutex_lock(&nrunning_lock);
	nrunning += diff;
	pthread_cond_signal(&nrunning_cond);
	pthread_mutex_unlock(&nrunning_lock);
}

void WaitForThreadsToDie(bool printsummary)
{
	pthread_mutex_lock(&nrunning_lock);
	while (nrunning != 0) {
		pthread_cond_wait(&nrunning_cond, &nrunning_lock);
	}
	pthread_mutex_unlock(&nrunning_lock);

	printf("DMP spawned %d threads\n", nthreads);
	printf("DMP spawned %d processes\n", nprocesses);
}

//-------------------------------------------------------------------------
// Deterministic FS ops
// NB: always return (-errno) on error.
// TODO:
//   -- readv/writev
//   -- readlink
//   -- stat/fstat/access?
//-------------------------------------------------------------------------

static map<string, FileTimingInfo>  FsTimings;

bool add_deterministic_file_path(const char* path, const FileTimingInfo& timing)
{
	char *real_path = realpath(path, NULL);	

	if (real_path == NULL) {
		SHIM_PERROR("realpath failed");
		return false;
	}

	FsTimings[real_path] = timing;
	free(real_path);

	return true;
}

bool check_for_deterministic_file_path(const string &fullpath, FileTimingInfo* timing)
{
	// Look for a prefix.
	map<string, FileTimingInfo>::iterator i;
	for (i = FsTimings.begin(); i != FsTimings.end(); ++i) {
		if (strncmp(i->first.c_str(), fullpath.c_str(), i->first.length()) == 0) {
			*timing = i->second;
			return true;
		}
	}

	return false;
}

bool check_for_deterministic_file_path(const boost::filesystem::path &cwd,
				       const char* path, FileTimingInfo* timing)
{
	// Normalize the full path (the "/" operator appends two paths)
	string full = join_paths(cwd, path).normalize().string();
	return check_for_deterministic_file_path(full, timing);
}

void BasicShim::start_io_op(int timing)
{
	SHIM_LOG("timing=%d\n", timing);

	// Nonblocking
	if (timing == 0)
		return;
	// Blocking unbounded
	else if (timing < 0) {
		if (dmp_shim_sleep() != 0)
			SHIM_PERROR("dmp_shim_sleep");
	// Blocking bounded
	} else {
		if (dmp_shim_set_barrier(SHIM_BARRIER_OFFSET_PARALLEL, timing) < 0)
			SHIM_PERROR("dmp_shim_set_barrier");
		if (dmp_shim_sleep() != 0)
			SHIM_PERROR("dmp_shim_sleep");
	}
}

void BasicShim::finish_io_op(int timing)
{
	SHIM_LOG("timing=%d\n", timing);

	// Nonblocking
	if (timing == 0)
		return;

	// Blocking unbounded: set a barrier for right now
	// Blocking bounded: we set a barrier in start_io_op()
	if (timing < 0) {
		if (dmp_shim_set_barrier(SHIM_BARRIER_NEXT_SERIAL, 0) < 0) {
			SHIM_PERROR("dmp_shim_set_barrier");
			return;
		}
	}

	shim_event event;
	SHIM_LOG("waiting for barrier...\n");
	if (dmp_shim_trace(&event) < 0)
		SHIM_PERROR("dmp_shim_trace");

	SHIM_LOG("@%ld.%d: event received\n", EVTIME(&event));
	if (event.event_type != DMP_SHIM_BARRIER)
		SHIM_LOG("expected a barrier event, got: %d", event.event_type);
}

bool BasicShim::do_fs_open(shim_event* event)
{
	char pathname[PATH_MAX];
	unsigned long arg0 =      shim_syscall_arg0(&event->regs);
	const int flags    = (int)shim_syscall_arg1(&event->regs);
	const int mode     = (int)shim_syscall_arg2(&event->regs);
	long ret;

	// Check if this file should be treated deterministically.
	if (dmp_shim_strncpy_sync((void*)pathname, (void*)arg0, sizeof pathname, NULL) != 0) {
		SHIM_PERROR("dmp_shim_strcpy");
		return false;
	}

	if (strnlen(pathname, PATH_MAX) >= PATH_MAX-1) {
		fprintf(stderr, "PATH_MAX too big? %ld\n", (long)PATH_MAX);
	}

	// N.B.: need to normalize the path to the CWD.
	const string fullpath = join_paths(*_cwd, pathname).normalize().string();

	SHIM_LOG("@%ld.%d: open(%s, 0x%x, 0%o) ...\n", EVTIME(event), fullpath.c_str(), flags, mode);

	shared_ptr<FileDescriptor> fd(new FileDescriptor);

	if (!check_for_deterministic_file_path(fullpath, &fd->timing)) {
		SHIM_LOG(" ... (nondeterminstic path)\n");
		return false;
	}

	if (flags & O_NONBLOCK) {
		SHIM_LOG(" ... (WARNING: requested nonblocking I/O; ignoring)\n");
		return false;
	}

	// Now execute the open.
	start_io_op(fd->timing.open);
	fd->shadowfd = open(fullpath.c_str(), flags, mode);

	// Failure here is a failure for the user.
	if (fd->shadowfd < 0) {
		ret = -errno;
		if (errno != ENOENT)
			SHIM_PERROR("open");
		goto out;
	}

	// Get the filesize.
	// We assume the filesize is a deterministic input.
	struct stat stat;
	if (fstat(fd->shadowfd, &stat) != 0) {
		ret = -errno;
		SHIM_PERROR("fstat");
		goto out;
	}

	fd->filesize = stat.st_size;
	fd->filepos = 0;

	// Now shadow the new file descriptor.
	ret = dmp_shim_dupfd(fd->shadowfd, TO_DMP);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd");
		goto out;
	}

	SHIM_LOG("Adding dmp_fd:%ld -> shim_fd:%d mapping\n", ret, fd->shadowfd);
	_fdtable->add(ret, fd);

out:
	finish_io_op(fd->timing.open);
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_close(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	long ret;

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	SHIM_LOG("@%ld.%d: close(%d)\n", EVTIME(event), userfd);
	ret = 0;

	// Remove file from the dmp task before closing it (ugly: kernel code assumes this order).
	if (dmp_shim_closefd(userfd) < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_closefd");
		goto out;
	}

	_fdtable->remove(userfd);

	// Close the file in the shim if this is the last reference.
	// NB: if shimming multiple procs there can be >1 references.
	start_io_op(fd->timing.close);

	if (fd.unique()) {
		// Ignore failures here: we already closed in the dmptask.
		if (close(fd->shadowfd) < 0)
			SHIM_PERROR("close");
		fd->shadowfd = -1;
	}

	finish_io_op(fd->timing.close);

out:
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_read(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	unsigned long userbuf = shim_syscall_arg1(&event->regs);
	unsigned long userbufsz = shim_syscall_arg2(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: read(fd:%d, sz:%ld) ...\n", EVTIME(event), userfd, userbufsz);

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	SHIM_LOG(" ... filepos %ld / %ld\n", fd->filepos, fd->filesize);

	// Cap the maximum buffer size.
	if (userbufsz > MAX_BUF) {
		userbufsz = MAX_BUF;
		SHIM_LOG(" ... capping buffer to sz:%ld\n", userbufsz);
	}

	start_io_op(fd->timing.read);

	// Read the file.
	_tmp_buffer.resize(userbufsz);
	char* buf = &_tmp_buffer[0];
	char* bufptr = buf;
	size_t bytes = 0;

	while (bytes < userbufsz) {
		SHIM_LOG("... read %ld bytes sofar (of %ld)\n", bytes, userbufsz);
		ret = read(fd->shadowfd, bufptr, userbufsz - bytes);
		if (ret == 0) {
			// End Of File
			SHIM_LOG("... end-of-file\n");
			break;
		}
		if (ret < 0) {
			// Ignore transient errors
			if (errno == EINTR)
				continue;
			// TODO: should seek back to where we started
			ret = -errno;
			SHIM_LOG(" ... (ret: %ld)\n", ret);
			finish_io_op(fd->timing.read);
			dmp_shim_emulate_syscall(ret, &event->regs);
			return true;
		}

		bufptr += ret;
		bytes += ret;
		fd->filepos += ret;
		SHIM_LOG("... read %ld bytes sofar (of %ld)\n", bytes, userbufsz);
	}

	ret = 0;

	// Copy the result.
	finish_io_op(fd->timing.read);
	if (dmp_shim_memcpy_sync((void*)buf, (void*)userbuf, bytes, TO_DMP, (long*)&bytes) < 0)
		ret = -errno;

	// Ignore access errors if >0 bytes were written.
	if (bytes > 0)
		ret = bytes;
	
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_write(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	unsigned long userbuf = shim_syscall_arg1(&event->regs);
	unsigned long userbufsz = shim_syscall_arg2(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: write(fd:%d, sz:%ld) ...\n", EVTIME(event), userfd, userbufsz);

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	// Cap the maximum buffer size.
	if (userbufsz > MAX_BUF) {
		userbufsz = MAX_BUF;
		SHIM_LOG(" ... capping buffer to sz:%ld\n", userbufsz);
	}

	// Copy the buffer.
	_tmp_buffer.resize(userbufsz);
	char* buf = &_tmp_buffer[0];

	if (dmp_shim_memcpy_sync((void*)buf, (void*)userbuf, userbufsz, FROM_DMP, NULL) < 0) {
		ret = -errno;
		dmp_shim_emulate_syscall(ret, &event->regs);
		return true;
	}

	start_io_op(fd->timing.write);

	// Write the file.
	char* bufptr = buf;
	size_t bytes = 0;

	while (bytes < userbufsz) {
		ret = write(fd->shadowfd, bufptr, userbufsz - bytes);
		if (ret < 0) {
			if (errno == EINTR)
				continue;
			ret = -errno;
			goto out;
		}

		bufptr += ret;
		bytes += ret;
		fd->filepos += ret;
	}

	ret = bytes;

out:
	if (fd->filepos > fd->filesize)
		fd->filesize = fd->filepos;

	SHIM_LOG(" ... (ret: %ld)\n", ret);

	finish_io_op(fd->timing.write);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_lseek(shim_event* event)
{
	const int timing = 0;
	const int userfd = shim_syscall_arg0(&event->regs);
	const off_t offset = shim_syscall_arg1(&event->regs);
	const int whence = shim_syscall_arg2(&event->regs);
	long ret;

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL)
		return false;

	SHIM_LOG("@%ld.%d: lseek(%d, %ld, %d)n", EVTIME(event), userfd, offset, whence);

	// Seek the file.
	// N.B.: since the shadowfd is a dup of the userfd, this will apply to both.
	start_io_op(timing);

	ret = lseek(fd->shadowfd, offset, whence);
	if (ret >= 0) {
		switch (whence) {
		case SEEK_SET:
			fd->filepos = offset;
			break;
		case SEEK_CUR:
			fd->filepos += offset;
			break;
		case SEEK_END:
			fd->filepos = fd->filesize - offset;
			break;
		}
	} else {
		ret = -errno;
	}

	finish_io_op(timing);
	dmp_shim_emulate_syscall(ret, &event->regs);

	return true;
}

bool BasicShim::do_fs_dup(shim_event* event)
{
	const int userfd = shim_syscall_arg0(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: dup(%d)\n", EVTIME(event), userfd);

	// Are we shadowing this fd?
	shared_ptr<FileDescriptor> fd = _fdtable->get(userfd);
	if (fd == NULL) {
		SHIM_LOG(" ... fd:%d is not shadowed\n", userfd);
		return false;
	}

	// Dup in the dmptask.
	ret = dmp_shim_dupfd(userfd, DUP_IN_DMP);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd");
		goto out;
	}

	if (_fdtable->get(ret) != NULL)
		fprintf(stderr, "ERROR? already have fd:%ld\n", ret);

	SHIM_LOG("Adding dmp_fd:%ld -> shim_fd:%d mapping\n", ret, fd->shadowfd);
	_fdtable->add(ret, fd);

out:
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

bool BasicShim::do_fs_dup2(shim_event* event)
{
	const int userfdfrom = shim_syscall_arg0(&event->regs);
	const int userfdto   = shim_syscall_arg1(&event->regs);
	long ret;

	SHIM_LOG("@%ld.%d: dup2(%d, %d)\n", EVTIME(event), userfdfrom, userfdto);

	// Are we shadowing either fd?
	shared_ptr<FileDescriptor> fdfrom = _fdtable->get(userfdfrom);
	shared_ptr<FileDescriptor> fdto   = _fdtable->get(userfdto);

	if (fdfrom == NULL && fdto == NULL) {
		SHIM_LOG(" ... fd:%d fd:%d are not shadowed\n", userfdfrom, userfdto);
		return false;
	}

	// Same fds: always succeed.
	if (userfdfrom == userfdto) {
		ret = userfdto;
		goto out;
	}

	if (fdfrom == fdto) {
		ret = userfdto;
		goto out;
	}

	// Dup in dmptask.
	ret = dmp_shim_dupfd2(userfdfrom, userfdto);
	if (ret < 0) {
		ret = -errno;
		SHIM_PERROR("dmp_shim_dupfd2");
		goto out;
	}

	if (ret != userfdto) {
		fprintf(stderr, "ERROR: unexpected value from dmp_shim_dupfd2: %ld != %d\n", ret, userfdto);
	}

	// Dup in shimtask, if shadowed.
	if (fdto != NULL) {
		SHIM_LOG("Removing dmp_fd:%ld -> shim_fd:%d mapping\n", userfdto, fdto->shadowfd);
		_fdtable->remove(userfdto);
	}
	if (fdfrom != NULL) {
		SHIM_LOG("Adding dmp_fd:%ld -> shim_fd:%d mapping\n", userfdto, fdfrom->shadowfd);
		_fdtable->add(userfdto, fdfrom);
	}

	// Close target in the shimtask, if shadowed.
	if (fdto != NULL && fdto.unique()) {
		start_io_op(fdto->timing.close);

		// Ignore failures here: we already dup'd in the dmptask.
		if (close(fdto->shadowfd) < 0)
			SHIM_PERROR("close");
		fdto->shadowfd = -1;

		finish_io_op(fdto->timing.close);
	}

out:
	SHIM_LOG(" ... (ret: %ld)\n", ret);
	dmp_shim_emulate_syscall(ret, &event->regs);
	return true;
}

void BasicShim::do_fs_chdir(shim_event* event)
{
	char pathname[PATH_MAX];
	unsigned long arg0 = shim_syscall_arg0(&event->regs);
	unsigned long ret = shim_syscall_return(&event->regs);

	if (dmp_shim_strncpy_sync((void*)pathname, (void*)arg0, sizeof pathname, NULL) != 0) {
		SHIM_PERROR("dmp_shim_strcpy");
		return;
	}

	if (strnlen(pathname, PATH_MAX) >= PATH_MAX-1) {
		fprintf(stderr, "PATH_MAX too big? %ld\n", (long)PATH_MAX);
	}

	SHIM_LOG("@%ld.%d: chdir(%s) (ret:%ld)\n", EVTIME(event), pathname, ret);

	// Update if the syscall succeeded.
	if (ret == 0) {
		*_cwd = join_paths(*_cwd, pathname);
	}
}

//-------------------------------------------------------------------------
// FileDescriptor
//-------------------------------------------------------------------------

FileDescriptor::FileDescriptor()
	: shadowfd(-1), filesize(0), filepos(0)
{
	timing.read  = -1;
	timing.write = -1;
	timing.open  = -1;
	timing.close = -1;
}

FileDescriptor::~FileDescriptor()
{
	if (shadowfd >= 0)
		close(shadowfd);
}

//-------------------------------------------------------------------------
// FileDescriptorTable
//-------------------------------------------------------------------------

FileDescriptorTable::FileDescriptorTable()
	: map<int,shared_ptr<FileDescriptor> >()
{}

shared_ptr<FileDescriptorTable> FileDescriptorTable::clone()
{
	shared_ptr<FileDescriptorTable> clone(new FileDescriptorTable);
	for (const_iterator i = begin(); i != end(); ++i)
		clone->add(i->first, i->second);
	return clone;
}

shared_ptr<FileDescriptor> FileDescriptorTable::get(int fd)
{
	iterator i = this->find(fd);
	if (i != this->end())
		return i->second;
	else
		return shared_ptr<FileDescriptor>();
}

void FileDescriptorTable::remove(int fd)
{
	iterator i = this->find(fd);
	if (i != this->end())
		this->erase(i);
}

//-------------------------------------------------------------------------
// BasicShim
//-------------------------------------------------------------------------

BasicShim::BasicShim(BasicShim* parent, int clone_flags)
	: _dmp_pid(0), _unique_id(__sync_fetch_and_add(&uniquekey, 1)),
	  _done_flag(false)
{
	// Count running threads.
	UpdateNRunning(1);

	// If no parent, then initialize from scratch.
	if (parent == NULL) {
		_fdtable.reset(new FileDescriptorTable);

		char dir[PATH_MAX];
		if (getcwd(dir, sizeof dir)) {
			_cwd.reset(new boost::filesystem::path(dir));
		} else {
			SHIM_PERROR("getcwd");
			_cwd.reset(new boost::filesystem::path("/"));
		}

		return;
	}

	// Reuse or clone the file descriptor table?
	if (clone_flags & CLONE_FILES)
		_fdtable = parent->_fdtable;
	else
		_fdtable = parent->_fdtable->clone();

	// Reuse or clone the filesystem info?
	// NOTE: no reference counting on _cwd because I'm lazy.
	if (clone_flags & CLONE_FS)
		_cwd = parent->_cwd;
	else
		_cwd.reset(new boost::filesystem::path(*parent->_cwd));
}

BasicShim::~BasicShim()
{}

BasicShim* BasicShim::clone(int clone_flags)
{
	return new BasicShim(this, clone_flags);
}

void BasicShim::loop()
{
	shim_event event;
#ifdef SHIM_DEBUG
	user_regs_struct *const regs = &event.regs;
#endif

	while (!_done_flag) {
		int r = dmp_shim_trace(&event);
		if (r != 0) {
			SHIM_PERROR("dmp_shim_trace");
			continue;
		}
		SHIM_LOG("@%ld.%d ", EVTIME(&event));

		switch (event.event_type) {
		case DMP_SHIM_SYSCALL_ENTER:
			SHIM_LOG_CONT("sysenter rax:%ld orig_rax:%ld (%s)\n", regs->rax, regs->orig_rax, GetSyscallName(regs->orig_rax));
			trace_syscall_enter(&event);
			break;

		case DMP_SHIM_SYSCALL_LEAVE:
			SHIM_LOG_CONT("sysleave rax:%ld orig_rax:%ld (%s)\n", regs->rax, regs->orig_rax, GetSyscallName(regs->orig_rax));
			trace_syscall_leave(&event);
			break;

		case DMP_SHIM_CALL:
			SHIM_LOG_CONT("call func:%ld\n", shim_syscall_arg0(regs));
			trace_shimcall(&event);
			break;

		case DMP_SHIM_BARRIER:
			SHIM_LOG_CONT("barrier\n");
			trace_barrier(&event);
			break;

		case DMP_SHIM_EXIT:
			SHIM_LOG_CONT("exit event received\n");
			trace_exit(&event);
			break;

		default:
			SHIM_LOG_CONT("unknown event type: %d\n", event.event_type);
			break;
		}
	}

	// Count running threads.
	UpdateNRunning(-1);
}

void BasicShim::trace_syscall_enter(shim_event* event)
{
	const long syscall = event->regs.orig_rax;

	switch (syscall) {
	// Forking
	case SYS_fork:
		follow_fork(syscall, 0);
		break;
	case SYS_clone:
		follow_fork(syscall, shim_syscall_arg0(&event->regs));
		break;
	case SYS_vfork:
		follow_fork(syscall, CLONE_VFORK | CLONE_VM);
		break;

	// Fileops
	case SYS_open:
		do_fs_open(event);
		break;
	case SYS_close:
		do_fs_close(event);
		break;
	case SYS_read:
		do_fs_read(event);
		break;
	case SYS_write:
		do_fs_write(event);
		break;
	case SYS_lseek:
		do_fs_lseek(event);
		break;
	case SYS_dup:
		do_fs_dup(event);
		break;
	case SYS_dup2:
		do_fs_dup2(event);
		break;

	// Some debugging
#ifdef SHIM_DEBUG
	case SYS_execve:
		{
			char pathname[PATH_MAX];
			unsigned long arg0 = shim_syscall_arg0(&event->regs);

			if (dmp_shim_strncpy_sync((void*)pathname, (void*)arg0, sizeof pathname, NULL) != 0) {
				SHIM_PERROR("dmp_shim_strcpy");
				break;
			}

			SHIM_LOG("@%ld.%d: execve(%s, ...)\n", EVTIME(event), pathname);
		}
		break;
#endif
	}
}

void BasicShim::trace_syscall_leave(shim_event* event)
{
	const long syscall = event->regs.orig_rax;

	switch (syscall) {
	// Fileops
	case SYS_chdir:
		do_fs_chdir(event);
		break;
	}
}

void BasicShim::trace_shimcall(shim_event* event)
{
	// nop
}

void BasicShim::trace_barrier(shim_event* event)
{
	// nop
}

void BasicShim::trace_signal(shim_event* event)
{
	// nop
}

void BasicShim::trace_exit(shim_event* event)
{
	_done_flag = true;
}

bool BasicShim::add_deterministic_fd(int dmp_fd, const FileTimingInfo& timing)
{
	long ret;

	// Dup the fd into the shim.
	ret = dmp_shim_dupfd(dmp_fd, FROM_DMP);
	if (ret < 0) {
		SHIM_PERROR("dmp_shim_dupfd");
		return false;
	}

	shared_ptr<FileDescriptor> fd(new FileDescriptor);

	fd->timing = timing;
	fd->shadowfd = ret;

	// Get the filesize.
	// We assume the filesize is a constant.
	struct stat stat;
	if (fstat(fd->shadowfd, &stat) != 0) {
		/* Could be a pipe, or socket, or ...; Do nothing? */
		fd->filesize = -1;
		fd->filepos  =  0;
	} else {
		fd->filesize = stat.st_size;

		// Get the current file position.
		ret = lseek(fd->shadowfd, 0, SEEK_CUR);
		if (ret < 0) {
			SHIM_PERROR("lseek");
			fd->filepos = 0;
		} else {
			fd->filepos = ret;
		}
	}

	// Now shadow the fd.
	SHIM_LOG("Adding dmp_fd[%d] -> shim_fd[%d] mapping\n", dmp_fd, fd->shadowfd);
	_fdtable->add(dmp_fd, fd);

	return true;
}

static void* shim_pthread(void *_shim)
{
	BasicShim *shim = reinterpret_cast<BasicShim*>(_shim);
	shim->attach_after_fork();
	delete shim;
	return NULL;
}

void BasicShim::follow_fork(long syscall, long clone_flags)
{
	shim_event event;
	pthread_t th;

	SHIM_LOG("syscall=%ld clone_flags=%lx\n", syscall, clone_flags);

	if (syscall == SYS_fork || syscall == SYS_vfork || !(clone_flags & CLONE_VM))
		AddProcess();
	else
		AddThread();

	// Wait for the system call to return.
	dmp_shim_trace(&event);

	// vfork is special: the parent task blocks and waits for the
	// child to call exec or exit *before* returning from vfork.
	// Thus, the parent triggers a special event saying "I'm about
	// to wait for the child".  At this point we learn the child's
	// pid and can fork a shim to attach to the child.  ugly ugly.
	if (syscall == SYS_vfork) {
		if (event.event_type != DMP_SHIM_VFORK_WAIT) {
			SHIM_LOG("bad event type (vfork wait): %d\n", event.event_type);
			return;
		}
	}
	// The sane normal case of fork() or clone().
	else {
		if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
			SHIM_LOG("bad event type: %d\n", event.event_type);
			return;
		}
	}

	const int rax = shim_syscall_return(&event.regs);
	if (rax < 0) {
		SHIM_LOG("fork call failed err=%d\n", rax);
		return;
	}

	SHIM_LOG("forked dmp thread pid=%d\n", rax);

	// Spawn a new shim thread.
	BasicShim* shim = clone(clone_flags);
	shim->_dmp_pid = rax;

	if (pthread_create(&th, NULL, shim_pthread, reinterpret_cast<void*>(shim)) != 0)
		SHIM_PERROR("pthread_create");

	// vfork is special: now wait for vfork to exit.
	if (syscall == SYS_vfork) {
		dmp_shim_trace(&event);
		if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
			SHIM_LOG("bad event type (vfork leave): %d\n", event.event_type);
			return;
		}
		SHIM_LOG("vfork returned for dmp thread pid=%d\n", rax);
	}
}

void BasicShim::attach_after_fork()
{
	shim_event event;

	SHIM_LOG("new shim created\n");

	// Attach to the deterministic thread
	long ret = dmp_shim_attach(_dmp_pid);
	if (ret < 0) {
		SHIM_PERROR("dmp_shim_attach");
		return;
	}

	SHIM_LOG("shim attached to pid=%d\n", _dmp_pid);

	// Wait for the system call to return in the dmp thread.
	dmp_shim_trace(&event);
	if (event.event_type != DMP_SHIM_SYSCALL_LEAVE) {
		SHIM_LOG("bad event type: %d\n", event.event_type);
		return;
	}

	SHIM_LOG("pid=%d returned from fork\n", _dmp_pid);
	loop();
}

}  // namespace DMP
