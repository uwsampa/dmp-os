#include <zlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>

#include "dmpshim.h"
#include "zbuf.h"

#ifndef MIN
#  define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

/*
 * Initialize a ZBuf for use.
 */
int zbufinit(ZBuf *zbuf, int fd)
{
	int ret;

	if (!zbuf)
		return -EINVAL;

	/* Open the output file */
	zbuf->fd = fd;

	/* Input and output buffers are initially empty */
	zbuf->inlen   = 0;
	zbuf->inavail = ZCHUNK;

	zbuf->outlen   = 0;
	zbuf->outavail = ZCHUNK;

	/* Initialize zlib */
	zbuf->strm.zalloc = Z_NULL;
	zbuf->strm.zfree  = Z_NULL;
	zbuf->strm.opaque = Z_NULL;

	if ((ret = deflateInit(&zbuf->strm, Z_DEFAULT_COMPRESSION)) != Z_OK)
		return ret;

	return 0;
}



/*
 * Flush all pending output to disk, and destroy the zlib stream.
 */
void zbufdestroy(ZBuf *zbuf)
{
	if (!zbuf)
		return;
	
	/* Flush all pending input and output */
	zbufflush(zbuf, Z_FINISH);

	/* Destroy the zlib data structures */
	deflateEnd(&zbuf->strm);
}



/*
 * Compress all pending input and store the results in an output
 * buffer. Once ZCHUNK bytes of compressed data have accumulated
 * the data is flushed to disk. If end is nonzero, the ZBuf is
 * flushed for closing, and can safely be destroyed.
 */
int zbufflush(ZBuf *zbuf, int end)
{
	z_stream *strm = NULL;
	int ngot, ret;
	int flush = end ? Z_FINISH : Z_NO_FLUSH;

	if (!zbuf)
		return -EINVAL;

	strm = &zbuf->strm;

	SHIM_LOG("  Flushing input buffer %s(have %d/%d bytes)...\n",
		flush ? "for close " : "", zbuf->inlen, zbuf->inavail);

	/* Tell zlib what and how much to compress */
	strm->next_in  = zbuf->inbuf;
	strm->avail_in = zbuf->inlen;

	do {

		/* Append new output to what we already have */
		strm->next_out  = zbuf->outbuf + zbuf->outlen;
		strm->avail_out = zbuf->outavail;

		/* Compress as much input as possible */
		ret = deflate(strm, flush);
		if (ret == Z_STREAM_ERROR)
			return ret;

		ngot = zbuf->outavail - strm->avail_out;
		zbuf->outlen   += ngot;
		zbuf->outavail -= ngot;

		SHIM_LOG("    Got %d bytes of output\n", ngot);

		/* If our output buffer is full, write it to disk */
		if (strm->avail_out == 0 || flush == Z_FINISH) {
			SHIM_LOG("      Flushing output buffer\n");
			ret = write(zbuf->fd, zbuf->outbuf, zbuf->outlen);
			zbuf->outlen = 0;
			zbuf->outavail = ZCHUNK;
		}
	
	} while (strm->avail_out == 0);

	if (flush == Z_FINISH && ret != Z_STREAM_END)
		return Z_STREAM_ERROR;

	/* We wrote all of our input buffer */
	zbuf->inlen = 0;
	zbuf->inavail = ZCHUNK;

	return 0;
}


/*
 * Add n bytes from buf to the zbuf object. All input is buffered
 * until ZCHUNK bytes have accumulated, at which point the pending
 * input is compressed and buffered. 
 */
int zaddbuf(ZBuf *zbuf, char *buf, int n)
{
	int left = n, sofar = 0, last;

	SHIM_LOG("  Adding %d bytes to zbuf...\n", n);

	/* While there is still unprocessed data in buf ... */
	while (left > 0) {

		last = MIN(left, zbuf->inavail);
		memcpy(&zbuf->inbuf[zbuf->inlen], buf + sofar, last);

		SHIM_LOG("    Wrote %d / %d\n", last, left);

		sofar += last;
		left  -= last;

		zbuf->inlen   += last;
		zbuf->inavail -= last;

		/* Do we need to flush the zbuf to disk now? */
		if (zbuf->inavail == 0)
			zbufflush(zbuf, Z_NO_FLUSH);

	}

	return sofar;
}
