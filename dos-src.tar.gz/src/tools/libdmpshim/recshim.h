/*
 * A library of useful shim functions
 */

#ifndef __RECORDSHIM_H__
#define __RECORDSHIM_H__

#ifndef __cplusplus
#error "record shim requires c++"
#endif

#include "dmpshim.h"
#include "basicshim.h"
#include "zbuf.h"

namespace DMP {

class RecordShim;
struct RecFn {
	RecFn() : type(RECNONE) {}
	enum { RECNONE, RECSTR, RECFN } type;
	union {
		long *recstr;
		void (*recfn)(RecordShim *shim, shim_event*);
	};
};

class RecordShim : public BasicShim {
 public:
	RecordShim(RecordShim* parent, int clone_flags, const string& logfile, bool compressed);
	virtual ~RecordShim();

	virtual RecordShim* clone(int clone_flags);

	virtual void trace_syscall_enter(shim_event* event);
	virtual void trace_syscall_leave(shim_event* event);

	virtual bool do_fs_read(shim_event *event);
 
	void record_syscall(long syscall, shim_event *event);
	void record_str(long *recstr, shim_event *event);

	int append_buffer(char *buf, int n);

 private:
	bool compressed;
	ZBuf zbuf;

	int _log_file;

	string _log_file_template;
	char* _log_file_name;

 public:
	/* One entry for each system call in asm/unistd.h */
	RecFn RecFnTab[295];
	RecFn GenericFn;
};

} // namespace DMP

#endif
