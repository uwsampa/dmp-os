#!/bin/bash

prefix=$1

if [ "$prefix" != "" ]; then
	prefix=${prefix}_
fi

file=${prefix}$(date +"%Y-%m-%d_%H:%M:%S.dat")

grep 'DMP stats:' /var/log/syslog |
	sed -e 's/.*DMP stats: \(.*\)/\1/' |
	sed -e "s/'box': \([0-9a-f]\+\)/'box': 0x\1/" | 
	awk 'BEGIN { print "results = [" } { print $0 ", " } END { print "]\n" }' > $file

echo $file
