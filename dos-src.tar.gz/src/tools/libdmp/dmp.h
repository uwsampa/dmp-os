/*
 * User-land library for DMP processes
 */

#ifndef __DMP_H__
#define __DMP_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Magic syscall numbers */
#define SYS_make_deterministic		286
#define SYS_dmp_set_options		287
#define SYS_dmp_call_shim		288
#define SYS_dmp_maybe_endquantum	294
#define SYS_dmp_endquantum		295

/*
 * Userland options struct
 */
struct dmpopts {
	const char *debug_flags;
	const char *optims;
	uint64_t debug_quiet;
	uint64_t start, stop;
	uint64_t verify_mm_freq;
	uint64_t adapts_min;
	uint64_t adapts_max;
	uint64_t adapts_max_fault;
	uint64_t adaptq_min;
	uint64_t adaptq_max;
	uint64_t adaptq_delta;
	uint64_t default_quantum_size;
	uint64_t maybe_endq_thresh;
	uint64_t syscall_tick_penalty;
};

/*
 * Options struct passed to kernel -- all fields must be valid
 *   N.B. Must be kept in sync with include/linux/dmp.h
 */
struct dmpkopts {
	uint64_t debug_flags;
	uint8_t  debug_quiet;
	uint8_t  optims;
	uint64_t start, stop;
	uint64_t verify_mm_freq;
	uint64_t adapts_min;
	uint64_t adapts_max;
	uint64_t adapts_max_fault;
	uint64_t adaptq_min;
	uint64_t adaptq_max;
	uint64_t adaptq_delta;
	uint64_t default_quantum_size;
	uint64_t maybe_endq_thresh;
	uint64_t syscall_tick_penalty;
};

long dmp_make_deterministic(const char *str_mode, int shimmed);
long dmp_set_options(struct dmpopts *opts);

long dmp_call_shim(int func, long arg1, long arg2, long arg3, long arg4, long arg5);
long dmp_call_shim0(int func);
long dmp_call_shim1(int func, long arg1);
long dmp_call_shim2(int func, long arg1, long arg2);
long dmp_call_shim3(int func, long arg1, long arg2, long arg3);

long dmp_maybe_endquantum(void);
long dmp_endquantum(void);

#ifdef __cplusplus
}
#endif
#endif
