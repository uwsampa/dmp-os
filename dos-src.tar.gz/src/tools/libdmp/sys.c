/*
 * User-land wrappers for DMP syscalls
 */

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "dmp.h"

/*
 * These flag maps have been copied from the #define's in
 * include/kernel/dmp.h ... make sure the two stay in sync
 * or debugging won't behave as expected.
 */

typedef struct NameMap NameMap;
struct NameMap {
	const char *name;
	int bit;
};

static NameMap mode_map[] = {
	{ "SERIAL",	0 }, /* DMP_STRAT_SERIAL */
	{ "MOT",	1 }, /* DMP_STRAT_MOT */
	{ "MOTFAKE",	2 }, /* DMP_STRAT_MOT_FAKE */
	{ NULL,	0      }  /* Must be the last element  */
};

static NameMap flag_map[] = {
	{ "ALL",    0xffffffff },
	{ "SYS",    (1<<0)  }, /* Syscall related messages  */
	{ "SIGNAL", (1<<1)  }, /* Signal delivery messages  */
	{ "SLEEP",  (1<<2)  }, /* Sleep/wake messages       */
	{ "VM",     (1<<3)  }, 
	{ "MOT",    (1<<4)  }, 
	{ "LIST",   (1<<5)  }, /* dmpgroup list debugging   */
	{ "TICK",   (1<<6)  }, /* TICK messages             */
	{ "STEP",   (1<<7)  }, /* Single step messages      */
	{ "TF",     (1<<8)  }, /* Toggling of TF            */
	{ "SWITCH", (1<<9)  }, /* Context switch messages   */
	{ "TASK",   (1<<10) }, /* Task creation/deletion    */
	{ "STATE",  (1<<11) }, /* DMP state change messages */
	{ "ENDQ",   (1<<12) }, /* End of quantum messages   */
	{ "ENDR",   (1<<13) }, /* End of round messages     */
	{ "STATS",  (1<<14) }, /* Display task stats        */
	{ "OPTIMS", (1<<15) }, /* Display optimization msgs */
	{ "STATSV", (1<<16) }, /* Noisy (i.e., round) stats */
	{ "MOTV",   (1<<17) }, /* Noisy MOT debugging (i.e., pte changes) */
	{ "HPC",    (1<<18) }, /* Display HPC values        */
	{ "SHIM",   (1<<19) }, /* Display shim activitity   */
	{ "RMAP",   (1<<20) }, /* NOISY rmap messages   */
	{ "NOPIDSTATS", (1<<21) }, /* NO noisy pidstats messages   */
	{ NULL,      0      }  /* Keep last! */
};

static NameMap opt_map[] = {
	{ "ADAPTS",		(1<<0)  }, /* Enable dynamic small serial */
	{ "ADAPTQ",		(1<<1)  }, /* Enable dynamic quantum      */
	{ "ADAPTS_SYSCALL",	(1<<2)  }, /* Enable ADAPTS for kobjects  */
	{ "FASTHANDOFF",	(1<<3)  }, /* Enable fasthandoff optimization */
	{ "FASTMOT",		(1<<4)  }, /* Enable single-threaded MOT optimization */
	{ "LOADBALANCE",        (1<<5)  }, /* Enable cpu load balancing */
	{ "WORKBALANCE",        (1<<6)  }, /* Enable cpu work balancing */
	{ "PINDMP",             (1<<7)  }, /* Enable cpu pinning of dmptasks  */
	{ "PINSHIM",            (1<<8)  }, /* Enable cpu pinning of shimtasks */
	{ "MOTINHERIT",         (1<<9)  }, /* Enable inheritance of MOT permissions during sleep */
	{ NULL,			0       }, /* Must be the last element    */
};

static inline void upper(char *str)
{
	int idx;

	for(idx = 0; str[idx] != '\0'; idx++)
		str[idx] = toupper(str[idx]);
}

/* For testing */
#if 0
static void print_flags(const char *name, int flags, struct NameMap *map)
{
	int i;

	printf("%s: %x ", name, flags);
	for(i = 0; map[i].name; i++) {
		if(flags & map[i].bit)
			printf("%s ", map[i].name);
	}
	printf("\n");
}
#endif

static int parse_flags(const char *str, struct NameMap *map, int excl)
{
	char *tmp, *cur, *save;
	int flags = 0, i, not = 0;

	tmp = strdup(str);
	if (!tmp) {
		fprintf(stderr, "Out of memory in parse_flags\n");
		return -ENOMEM;
	}

	upper(tmp);
	for (cur = strtok_r(tmp, ",", &save); cur; cur = strtok_r(NULL, ",", &save)) {
		if (cur[0] == '-') {
			not = 1;
			cur++;
		} else {
			not = 0;
		}

		for (i = 0; map[i].name; i++) {
			if (strcmp(map[i].name, cur) == 0) {
				flags = (not ? (flags & ~map[i].bit) : (flags | map[i].bit));
				break;
			}
		}
		if (!map[i].name) {
			fprintf(stderr, "Unknown flag '%s'\n", cur);
			return -EINVAL;
		}

		if(excl && flags)
			break;
	}

	free(tmp);
	return flags;
}

/*
 * Syscalls
 */
long dmp_make_deterministic(const char *_str_mode, int shimmed)
{
	int mode = 0;
	long ret = 0;

	// Parse 'str_mode'.
	mode = parse_flags(_str_mode, mode_map, 1);
	if (mode < 0) {
		ret = mode;
		goto done;
	}

	//print_flags("  Mode", mode, mode_map);

	// Finally make the syscall.
	ret = syscall(SYS_make_deterministic, mode, shimmed);

done:
	if (ret < 0)
		errno = -ret;
	return ret;
}

long dmp_set_options(struct dmpopts *opts)
{
	struct dmpkopts kopts;
	int flags, optims;
	int ret = 0;

	flags  = parse_flags(opts->debug_flags, flag_map, 0);
	optims = parse_flags(opts->optims, opt_map, 0);

	if (flags < 0) {
		ret = flags;
		goto done;
	}
	if (optims < 0) {
		ret = optims;
		goto done;
	}

	//print_flags(" Debug", flags, flag_map);
	//print_flags("Optims", optims, opt_map);
	
	kopts.debug_flags      = flags;
	kopts.debug_quiet      = opts->debug_quiet;
	kopts.optims           = optims;
	kopts.start            = opts->start;
	kopts.stop             = opts->stop;
	kopts.verify_mm_freq   = opts->verify_mm_freq;
	kopts.adapts_min       = opts->adapts_min;
	kopts.adapts_max       = opts->adapts_max;
	kopts.adapts_max_fault = opts->adapts_max_fault;
	kopts.adaptq_min       = opts->adaptq_min;
	kopts.adaptq_max       = opts->adaptq_max;
	kopts.adaptq_delta     = opts->adaptq_delta;

	kopts.default_quantum_size = opts->default_quantum_size;
	kopts.maybe_endq_thresh    = opts->maybe_endq_thresh;
	kopts.syscall_tick_penalty = opts->syscall_tick_penalty;

	// Finally make the syscall.
	syscall(SYS_dmp_set_options, &kopts);
done:
	if (ret < 0)
		errno = -ret;
	return ret;
}

long dmp_call_shim(int func, long arg1, long arg2, long arg3, long arg4, long arg5)
{
	const long ret = syscall(SYS_dmp_call_shim, func, arg1, arg2, arg3, arg4, arg5);
	if (ret < 0)
		errno = -ret;
	return ret;
}

long dmp_call_shim0(int func)
{
	return dmp_call_shim(func, 0, 0, 0, 0, 0);
}

long dmp_call_shim1(int func, long arg1)
{
	return dmp_call_shim(func, arg1, 0, 0, 0, 0);
}

long dmp_call_shim2(int func, long arg1, long arg2)
{
	return dmp_call_shim(func, arg1, arg2, 0, 0, 0);
}

long dmp_call_shim3(int func, long arg1, long arg2, long arg3)
{
	return dmp_call_shim(func, arg1, arg2, arg3, 0, 0);
}

long dmp_maybe_endquantum(void)
{
	const long ret = syscall(SYS_dmp_maybe_endquantum);
	if (ret < 0)
		errno = -ret;
	return ret;
}

long dmp_endquantum(void)
{
	const long ret = syscall(SYS_dmp_endquantum);
	if (ret < 0)
		errno = -ret;
	return ret;
}
