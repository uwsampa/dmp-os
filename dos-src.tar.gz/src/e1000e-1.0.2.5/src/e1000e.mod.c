#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xd40c79bb, "struct_module" },
	{ 0x3ce4ca6f, "disable_irq" },
	{ 0x72a877a8, "kmalloc_caches" },
	{ 0xa440b734, "pci_bus_read_config_byte" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0xfb35a368, "mem_map" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x349cba85, "strchr" },
	{ 0x81a47317, "set_acceptable_latency" },
	{ 0xa5423cc4, "param_get_int" },
	{ 0x91eb9b4, "round_jiffies" },
	{ 0x25ec1b28, "strlen" },
	{ 0x8892ac2c, "pci_disable_device" },
	{ 0xfd5f1a52, "pci_disable_msix" },
	{ 0x81ff6b9b, "netif_carrier_on" },
	{ 0xbed60566, "sub_preempt_count" },
	{ 0x80844a96, "ethtool_op_get_sg" },
	{ 0x8675e937, "schedule_work" },
	{ 0xeeb1717c, "param_array_get" },
	{ 0x8713be68, "netif_carrier_off" },
	{ 0x60ce47de, "modify_acceptable_latency" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xacfb31f1, "mutex_unlock" },
	{ 0x8dd70e88, "pci_enable_wake" },
	{ 0x2fd1d81c, "vfree" },
	{ 0x47d9b560, "pci_bus_write_config_word" },
	{ 0xcb32da10, "param_set_int" },
	{ 0x1d26aa98, "sprintf" },
	{ 0xab471003, "param_array_set" },
	{ 0xd697e69a, "trace_hardirqs_on" },
	{ 0x7d11c268, "jiffies" },
	{ 0xd533bec7, "__might_sleep" },
	{ 0xf87e3548, "__spin_lock_init" },
	{ 0x47d24805, "__netdev_alloc_skb" },
	{ 0x27c33efe, "csum_ipv6_magic" },
	{ 0xe287174c, "__pskb_pull_tail" },
	{ 0x909f3eec, "pci_set_master" },
	{ 0x66e364cf, "__alloc_pages" },
	{ 0xc6ab8b17, "del_timer_sync" },
	{ 0xde0bdcff, "memset" },
	{ 0x9d6b71f2, "alloc_etherdev_mq" },
	{ 0x500d4326, "pci_enable_pcie_error_reporting" },
	{ 0x1143a770, "pci_set_dma_mask" },
	{ 0xea459834, "pci_enable_msix" },
	{ 0x70e5b164, "pci_restore_state" },
	{ 0xdd132261, "printk" },
	{ 0x3b49f128, "ethtool_op_set_flags" },
	{ 0x1e22b2a9, "free_netdev" },
	{ 0x7ec9bfbc, "strncpy" },
	{ 0xe389bb01, "register_netdev" },
	{ 0x1b91d223, "dma_free_coherent" },
	{ 0x6b82f39b, "netif_receive_skb" },
	{ 0x1ff288f1, "dev_close" },
	{ 0x521445b, "list_del" },
	{ 0x4c6ff041, "add_preempt_count" },
	{ 0xe08575a5, "mod_timer" },
	{ 0x43b0c9c3, "preempt_schedule" },
	{ 0x9eac042a, "__ioremap" },
	{ 0x11fabb94, "ethtool_op_get_flags" },
	{ 0x835f0ada, "pci_enable_msi" },
	{ 0x610e1ff5, "dev_kfree_skb_any" },
	{ 0xd5fb9bc3, "contig_page_data" },
	{ 0xd0189769, "dma_alloc_coherent" },
	{ 0x32bbec8f, "dev_open" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0xd971029e, "pci_find_capability" },
	{ 0xf37122cd, "dev_kfree_skb_irq" },
	{ 0x69910b43, "skb_over_panic" },
	{ 0xa90a7f6c, "pci_select_bars" },
	{ 0x7dceceac, "capable" },
	{ 0xd2fc59e8, "netif_device_attach" },
	{ 0x36d2668, "kmem_cache_alloc" },
	{ 0x2262a1f6, "netif_device_detach" },
	{ 0xad70b986, "__alloc_skb" },
	{ 0xdb96e3a1, "pci_bus_read_config_word" },
	{ 0x1e70b68b, "ethtool_op_set_sg" },
	{ 0x3053991c, "__napi_schedule" },
	{ 0x54be0407, "pci_cleanup_aer_uncorrect_error_status" },
	{ 0xedd14538, "param_get_uint" },
	{ 0x2cf190e3, "request_irq" },
	{ 0x869d26dd, "kfree_skb" },
	{ 0xb4e32191, "dump_stack" },
	{ 0xc549454d, "eth_type_trans" },
	{ 0x426cae2b, "dev_driver_string" },
	{ 0x7158092c, "pskb_expand_head" },
	{ 0xa4f76bbc, "pci_unregister_driver" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0x5145f46d, "init_timer" },
	{ 0xf6ebc03b, "net_ratelimit" },
	{ 0xd5b61c5a, "pci_set_power_state" },
	{ 0xc965dffe, "mutex_lock_nested" },
	{ 0xccf71e35, "pci_disable_pcie_error_reporting" },
	{ 0xfcec0987, "enable_irq" },
	{ 0x37a0cba, "kfree" },
	{ 0x236c8c64, "memcpy" },
	{ 0x801678, "flush_scheduled_work" },
	{ 0x522dbbde, "___pskb_trim" },
	{ 0x34810ad1, "pci_disable_msi" },
	{ 0x126970ed, "param_set_uint" },
	{ 0xedc03953, "iounmap" },
	{ 0x46d33fe1, "list_add" },
	{ 0xa08188fe, "__pci_register_driver" },
	{ 0x89c24a43, "put_page" },
	{ 0x1faa03fd, "lockdep_init_map" },
	{ 0xdb9548b0, "unregister_netdev" },
	{ 0x6689b8a2, "remove_acceptable_latency" },
	{ 0x1675606f, "bad_dma_address" },
	{ 0x3caf1d9c, "ethtool_op_get_tso" },
	{ 0xbda18b2b, "pci_choose_state" },
	{ 0x363db3f8, "__netif_schedule" },
	{ 0xbe180bc, "pci_enable_device" },
	{ 0xda1b1777, "pci_set_consistent_dma_mask" },
	{ 0x8be1c7cf, "pci_release_selected_regions" },
	{ 0x5a917b69, "pci_request_selected_regions" },
	{ 0xec3d2e1b, "trace_hardirqs_off" },
	{ 0x9e7d6bd0, "__udelay" },
	{ 0x359c2ed6, "dma_ops" },
	{ 0xf20dabd8, "free_irq" },
	{ 0x6e3f9d52, "pci_save_state" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("pci:v00008086d0000105Esv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000105Fsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010A4sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010BCsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010A5sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001060sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010D9sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010DAsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010D5sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010B9sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000107Dsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000107Esv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000107Fsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000108Bsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000108Csv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000109Asv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010D3sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F6sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000150Csv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001096sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010BAsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001098sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010BBsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000104Csv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C5sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C4sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000104Asv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000104Bsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000104Dsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001049sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C2sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C3sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010BDsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000294Csv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010E5sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010BFsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F5sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010CBsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010CCsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010CDsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010CEsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010DEsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010DFsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010EAsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010EBsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010EFsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F0sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "DDEDB7A50AA70D823257BD7");
