// Single-process version of nullhttp

#include <getopt.h>
#include <assert.h>
#include <iostream>

#include "lib.h"

FILE *logfile = NULL; /* Log to stderr */

// Shim connections

static pthread_mutex_t reqlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  reqsig  = PTHREAD_COND_INITIALIZER;
static queue<Request*> pendingreqs;

// Client connections

struct Connection {
	pthread_mutex_t lock;
	pthread_cond_t sig;

	int id;
	int nready; /* Number of replicas that have supplied their response */
	// int session?
	Socket sock;
	Request in;
	Response out; /* One response for each replica */
};

static pthread_mutex_t connlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  freesig  = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  readysig = PTHREAD_COND_INITIALIZER;
static queue<Connection*> freeconn;
static queue<Connection*> readyconn;
static Connection** allconn;

//------------------------------------------------------------------------------
// Worker Threads
//------------------------------------------------------------------------------

static void* HttpWorker(void*)
{
	// don't allocate these on the stack: not enough room!
	char *buffer = new char[MAX_REQSIZE];
	Request *req;
	Response resp;

	for (;;)
	{
		LOG_LEVEL(2, "Waiting for a new request\n");
		pthread_mutex_lock(&reqlock);
		while (pendingreqs.empty()) {
			pthread_cond_wait(&reqsig, &reqlock);
		}
		req = pendingreqs.front();
		pendingreqs.pop();
		pthread_mutex_unlock(&reqlock);

		LOG_LEVEL(2, "Request: id=%d length=%d method=%s URI=%s\n",
			req->ClientID, req->ContentLength, req->Method.c_str(), req->URI.c_str());

		/* Build the response */
		DoRequest(req, &resp);

		/* Forward the response to the arbiter */
		Connection *c = allconn[req->ClientID];
		c->out = resp;
		pthread_cond_signal(&c->sig);
	}

	delete [] buffer;
	return NULL;
}

static void HandleConnection(Connection* c)
{
	bool alive = true;

	LOG_LEVEL(2, "<%d> alive with %s:%d\n",
		c->id, inet_ntoa(c->sock.addr.sin_addr), (int)ntohs(c->sock.addr.sin_port));

	while (alive)
	{
		// Read a request.
		ResetRequest(&c->in);
		if (!ReadHttpRequest(&c->sock, &c->in)) {
			LOG("<%d> ReadHttpRequest failed\n", c->id);
			break;
		}
		LOG_LEVEL(2, "<%d> ReadHttpRequest success\n", c->id);

		if (strcasecmp(c->in.Connection.c_str(), "close") == 0)
			alive = false;

		if (c->in.error_status != 0) {
			// TODO: send a reply directly from here
		}

		// Forward to the RequestWorker.
		LOG_LEVEL(2, "<%d> Signalling request worker\n", c->id);
		pthread_mutex_lock(&reqlock);
		c->in.ClientID = c->id;
		c->nready = 0;
		pendingreqs.push(&c->in);
		pthread_cond_signal(&reqsig);
		pthread_mutex_unlock(&reqlock);

		// Wait for a response.
		pthread_mutex_lock(&c->lock);
		LOG_LEVEL(2, "<%d> Waiting for response\n", c->id);
		pthread_cond_wait(&c->sig, &c->lock);
		pthread_mutex_unlock(&c->lock);

		LOG_LEVEL(2, "<%d> HttpResponses received\n", c->id);

		// Check that all responses match.
		LOG_LEVEL(2, "<%d> HttpResponses match\n", c->id);

		// Forward to the client.
		SocketWrite(&c->sock, &c->out.reply[0], c->out.reply.size());

		if (strcmp(c->in.Connection.c_str(), "Keep-Alive") != 0) {
			LOG_LEVEL(1, "<%d> Closing non-keepalive connection\n", c->id);
			alive = 0;
		}
	}

	LOG_LEVEL(2, "<%d> dead\n", c->id);
}

static void* ClientWorker(void*)
{
	Connection* c;

	for (;;)
	{
		// Wait for a ready connection.
		LOG_LEVEL(2, "Waiting for ready connection...\n");
		pthread_mutex_lock(&connlock);
		while (readyconn.empty()) {
			pthread_cond_wait(&readysig, &connlock);
		}
		c = readyconn.front();
		readyconn.pop();
		pthread_mutex_unlock(&connlock);

		// Process.
		LOG_LEVEL(2, "Handling connection %d\n", c->id);
		HandleConnection(c);
		CloseSocket(&c->sock);

		pthread_mutex_lock(&connlock);
		freeconn.push(c);
		pthread_cond_signal(&freesig);
		pthread_mutex_unlock(&connlock);
	}

	return NULL;
}

//------------------------------------------------------------------------------
// Listener Thread
//------------------------------------------------------------------------------

static void* Listener(void*)
{
	Socket sock;
	OpenListenSocket("http-server", config.server_port, &sock);

	for (;;)
	{
		Connection* c;

		// Get a free connection slot.
		pthread_mutex_lock(&connlock);
		while (freeconn.empty()) {
			pthread_cond_wait(&freesig, &connlock);
		}
		c = freeconn.front();
		freeconn.pop();
		pthread_mutex_unlock(&connlock);

		// Accept the next connection.
		AcceptSocket("client", sock.s, &c->sock);

		// Signal a worker thread.
		pthread_mutex_lock(&connlock);
		readyconn.push(c);
		pthread_cond_signal(&readysig);
		pthread_mutex_unlock(&connlock);
	}

	return NULL;
}

//------------------------------------------------------------------------------
// Main
//------------------------------------------------------------------------------

static void SetupConnectionQueue()
{
	assert(config.server_maxconn >= 1);
	allconn = new Connection*[config.server_maxconn];

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		Connection* c = new Connection;
		allconn[i] = c;

		c->id = i;
		pthread_mutex_init(&c->lock, NULL);
		pthread_cond_init(&c->sig, NULL);

		freeconn.push(c);
	}
}

static void SpawnWorkers()
{
	pthread_t thread;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		if (pthread_create(&thread, &attr, ClientWorker, NULL) < 0) {
			PERROR("pthread_create ClientWorker");
			exit(1);
		}
	}

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		if (pthread_create(&thread, &attr, HttpWorker, NULL) < 0) {
			PERROR("pthread_create HttpWorker");
			exit(1);
		}
	}
}

static void SpawnListener()
{
	pthread_t thread;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_create(&thread, &attr, Listener, NULL) < 0) {
		PERROR("pthread_create Listener");
		exit(1);
	}
}

int main(int argc, char* argv[])
{
	string msg;

	// Init
	ParseHttpdCommandLine(argc, argv);
	SetupConnectionQueue();
	SpawnWorkers();

	// Run
	SpawnListener();

	// Wait for kill message on stdin.
	while (true) {
		printf("Type 'kill' to exit\n");
		std::cin >> msg;
		if (msg == "kill")
			return 0;
	}
}
