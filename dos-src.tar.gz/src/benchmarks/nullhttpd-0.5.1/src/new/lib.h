/*
    Null httpd -- simple http server
    Copyright (C) 2001-2002 Dan Cahill

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef _NULLHTTPD_LIB_H_
#define _NULLHTTPD_LIB_H_

#include <arpa/inet.h>
#include <assert.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <paths.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <memory>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>

using std::auto_ptr;
using std::map;
using std::queue;
using std::set;
using std::string;
using std::vector;

extern FILE *logfile;

#define LOG_CONT(fmt, args...) do {                       \
		FILE *tmp = (logfile ? logfile : stderr); \
		fprintf(tmp, fmt, ## args);               \
	} while(0)

#define LOG(fmt, args...)				  \
	do {						  \
		FILE *tmp = (logfile ? logfile : stderr); \
		fprintf(tmp, "(%s) ", __func__);	  \
		LOG_CONT(fmt, ## args);			  \
	} while(0)

#define PERROR(msg)					  \
	do {						  \
		FILE *tmp = (logfile ? logfile : stderr); \
		fprintf(tmp, "(%s) %s: %s\n", __func__, msg, strerror(errno)); \
	} while(0)

#define LOG_ASSERT(cond, fmt, args...)						\
	do {									\
		if (!(cond)) {							\
			FILE *tmp = (logfile ? logfile : stderr); \
			fprintf(tmp, "(%s:%d) ", __func__, __LINE__);	\
			fprintf(tmp, "assertion failed [%s] ", #cond);	\
			LOG_CONT(fmt, ## args);					\
			abort();						\
		}								\
	} while(0)

#define LOG_LEVEL(level, fmt, args...)				\
	do {							\
		if (config.server_loglevel >= (level)) {	\
			FILE *tmp = (logfile ? logfile : stderr); \
			fprintf(tmp, "(%s) ", __func__);	\
			LOG_CONT(fmt, ## args);			\
		}						\
	} while(0)

#define REPLICA_MAGIC_NUM 0xdeadbeef

/* #defines and typedefs */
#define RFC1123FMT "%a, %d %b %Y %H:%M:%S GMT" 
#define SERVER_NAME	"Null httpd 0.5.1"

#define MAX_POSTSIZE	(8UL<<20) /* arbitrary 8 MB limit for POST request sizes */
#define MAX_REQSIZE	((1UL<<10) + MAX_POSTSIZE) /* arbitrary 4 KB limit for request headers */


/* Shim commands */
enum {SERVER_RECV, SERVER_SEND, SERVER_ACCEPT};

struct Config {
	string config_filename;
	string server_base_dir;
	string server_bin_dir;
	string server_cgi_dir;
	string server_etc_dir;
	string server_htdocs_dir;
	string server_hostname;
	string server_arbiter;
	int server_port;
	int server_maxconn;
	int server_maxidle;
	int server_nreplicas;
	int server_loglevel;
	int server_req_port;   // of arbiter
	int server_resp_port;  // of arbiter
};

struct Socket {
	int s;
	sockaddr_in addr;
	size_t addrlen;
};

struct Buffer {
	char *buf;
	ssize_t size;
};

struct LineBuf {
	char buf[2048];
	ssize_t size;	// total used space
	ssize_t next;	// index of the next line in buf[]
};

struct Request {
	// http headers first line
	string Method;
	string URI;
	string Protocol;
	// http headers
	string Connection;
	int ContentLength;
	string ContentType;
	string Cookie;
	string Host;
	string IfModifiedSince;
	string UserAgent;
	// http POST
	char postbuf[MAX_POSTSIZE];
	// for parsing errors
	int error_status;
	string error_title;
	string error_msg;

	int ClientID; /* Set to the Connection->id of the corresponding connection */
};

struct Response {
	// http headers
	string CacheControl;
	string Date;
	string Expires;
	string LastModified;
	string Pragma;
	string Protocol;
	string Connection;
	string Server;
	string ContentType;
	int Status;
	int ContentLength;
	// http response in full
	vector<char> reply;

	void print(const char *text);
	void prints(const char *format, ...);
	void printhex(const char *format, ...);
	void printht(const char *format, ...);
};

// config.cpp
extern Config config;
int ParseHttpdCommandLine(int argc, char** argv);
void ConfigInit();
bool ConfigRead(const char* cfgfile);

// socket.cpp
void Lookup(const char *hostname, char *ipout, int len);
void OpenListenSocket(const char* dbgmsg, int localport, Socket* sock);
void OpenConnectSocket(const char* dbgmsg, const char* ip, int port, Socket* sock);
void AcceptSocket(const char* dbgmsg, int listen, Socket* sock);
void CloseSocket(Socket* sock);

void AdvanceLine(LineBuf* line);
void ResetLine(LineBuf* line);
bool SocketReadLine(Socket* sock, LineBuf* line);
bool SocketReadBuffer(Socket* sock, char* buf, ssize_t size);

ssize_t SocketWrite(Socket* sock, const char *buf, ssize_t nbytes);

// http.cpp
void ResetRequest(Request* r);
void ResetResponse(Response* r);
bool ReadHttpRequest(Socket* sock, Request* r);
void DoRequest(Request *req, Response *resp);
void AddHeaders(Request *req, Response *resp);

// files.cpp
bool MakeFilePage(Request *req, Response *resp);

// format.cpp
void decodeurl(string *url);
void fixslashes(char *pOriginal);
int hex2int(char *pChars);
void striprn(char *string);
void swapchar(char *string, char oldchar, char newchar);
char *strcatf(char *dest, const char *format, ...);






/////////////////////////////////////////////////

struct pipe_fd {
	int in;
	int out;
};

/* cgi.c */
int cgi_main(void);

#endif  // _NULLHTTPD_LIB_H_
