//
// The nullhttpd shim
//

#ifndef __NULLHTTPD_SHIM_H__
#define __NULLHTTPD_SHIM_H__

#include "lib.h"
#include "basicshim.h"

namespace DMP {

class ReplicaShim : public BasicShim
{
 public:
	ReplicaShim(ReplicaShim* parent, int clone_flags);
	virtual ~ReplicaShim();

	virtual ReplicaShim* clone(int clone_flags);

	//virtual void trace_syscall_enter(shim_event* event);
	//virtual void trace_syscall_leave(shim_event* event);
	virtual void trace_shimcall(shim_event* event);
	//virtual void trace_serial(shim_event* event);
	//virtual void trace_signal(shim_event* event);
	//virtual void trace_exit(shim_event* event);

	virtual void do_accept(shim_event* event);
	virtual void do_recv(shim_event* event);
	virtual void do_send(shim_event* event);

 public:
	// Global initialization.
	static void init_all(const char* arbiter, int arbiter_req_port, int arbiter_resp_port);

 public:
	pthread_mutex_t _lock;  // guards all fields below
	pthread_cond_t  _sig;   // signaled by BgWorker

	// For "RECV" shimcalls
	queue<Buffer> _readyqueue;

	// For "ACCEPT" shimcalls
	uint64_t _skip_epoch;   // (mid of 2phase commit): skip the barrier at this quantum
	uint64_t _recv_epoch;   // (end of 2phase commit): initiate RECVs at this quantum
};

} // namespace DMP

#endif  // __NULLHTTPD_SHIM_H__
