//
// The replicated nullhttpd webserver
//

#include <getopt.h>
#include "lib.h"
#include "dmp.h"

FILE *logfile = NULL;

//------------------------------------------------------------------------------
// Worker Threads
//------------------------------------------------------------------------------

static void* ClientWorker(void*)
{
	char *tmp;

	// don't allocate these on the stack: not enough room!
	char *buffer = new char[MAX_REQSIZE];
	Request *req = new Request;
	Response *resp = new Response;

	for (;;)
	{
		ResetRequest(req);

		LOG_LEVEL(2, "calling SERVER_RECV\n");
		dmp_call_shim2(SERVER_RECV, (long int)buffer, MAX_REQSIZE);

		req->ClientID      = *((int *)buffer);
		req->ContentLength = *((int *)(buffer + sizeof(int)));

		tmp = buffer + 2 * sizeof(int);
		req->Method          = string(tmp);   tmp += strlen(tmp) + 1;
		req->URI             = string(tmp);   tmp += strlen(tmp) + 1;
		req->Protocol        = string(tmp);   tmp += strlen(tmp) + 1;
		req->Connection      = string(tmp);   tmp += strlen(tmp) + 1;
		req->ContentType     = string(tmp);   tmp += strlen(tmp) + 1;
		req->Cookie          = string(tmp);   tmp += strlen(tmp) + 1;
		req->Host            = string(tmp);   tmp += strlen(tmp) + 1;
		req->IfModifiedSince = string(tmp);   tmp += strlen(tmp) + 1;
		req->UserAgent       = string(tmp);   tmp += strlen(tmp) + 1;
		strncpy(req->postbuf, tmp, req->ContentLength);

		LOG_LEVEL(2, "Request: id=%d length=%d method=%s URI=%s\n",
			req->ClientID, req->ContentLength, req->Method.c_str(), req->URI.c_str());

		/* Build the response */
		DoRequest(req, resp);

		/* Ignore nullHTTPd for now; send static responses */
		//string respstr = "HTTP/1.1 200 OK\r\n\r\nIt worked!\r\n";
		//resp->reply.clear();
		//resp->reply.insert(resp->reply.end(), respstr.begin(), respstr.end());

		/* Forward the response to the arbiter */
		dmp_call_shim3(SERVER_SEND, req->ClientID, (long int)&resp->reply[0], resp->reply.size());
	}

	delete req;
	delete resp;
	delete [] buffer;

	return NULL;
}

//------------------------------------------------------------------------------
// Main
//------------------------------------------------------------------------------

static void* Listener(void*)
{
	printf("Made it to listener\n");
	// Just loop forever making ACCEPT calls.  This does two-phase commit
	// magic and distributes incoming requests to workers doing RECV calls.
	for (;;) {
		dmp_call_shim1(SERVER_ACCEPT, 0);
	}
}

static void SpawnWorkers()
{
	pthread_t thread;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		if (pthread_create(&thread, &attr, ClientWorker, NULL) < 0) {
			PERROR("pthread_create ClientWorker");
			exit(1);
		}
	}

	if (pthread_create(&thread, &attr, Listener, NULL) < 0) {
		PERROR("pthread_create Listener");
		exit(1);
	}
}

int main(int argc, char* argv[])
{
	ParseHttpdCommandLine(argc, argv);
	SpawnWorkers();

	char foo[10];
	printf("Press enter to exit...\n");
	fgets(foo, 10, stdin);

	exit(EXIT_SUCCESS);
}
