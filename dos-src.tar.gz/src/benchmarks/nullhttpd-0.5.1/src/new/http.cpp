/*
    Null httpd -- simple http server
    Copyright (C) 2001-2002 Dan Cahill

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>

#include "lib.h"

static inline bool ParseHeaderLine(const char* line, const char* prefix, string* out)
{
	size_t len = strlen(prefix);
	if (strncasecmp(line, prefix, len) == 0) {
		out->assign(line + len);
		return true;
	} else {
		return false;
	}
}

static inline bool ParseHeaderLineInt(const char* line, const char* prefix, int* out)
{
	size_t len = strlen(prefix);
	if (strncasecmp(line, prefix, len) == 0) {
		*out = atoi(line + len);
		return true;
	} else {
		return false;
	}
}

static bool ParseError(Request* r, int status, const char* msg)
{
	r->error_status = status;
	r->error_msg = msg;

	switch (status) {
	case 400:
	case 413:
		r->error_title = "Bad Request";
		break;
	default:
		r->error_title = "Error";
		break;
	}

	// Don't necessarily close the connection.
	return true;
}

void ResetRequest(Request* r)
{
	r->Method.clear();
	r->URI.clear();
	r->Protocol.clear();
	// http headers
	r->Connection.clear();
	r->ContentLength = 0;
	r->ContentType.clear();
	r->Cookie.clear();
	r->Host.clear();
	r->IfModifiedSince.clear();
	r->UserAgent.clear();
	// for parsing errors
	r->error_status = 0;
	r->error_title.clear();
	r->error_msg.clear();
}

bool ReadHttpRequest(Socket* sock, Request* r)
{
	LineBuf line;

	ResetLine(&line);
	r->error_msg.clear();

	// Look for the first line, ignoring empty lines.
	// TODO: timeouts?
	for (;;) {
		if (!SocketReadLine(sock, &line))
			return false;

		if (line.buf[0] == '\0') {
			AdvanceLine(&line);
			continue;
		} else {
			break;
		}
	}

	// Parse the first line
	char method[128];
	char protocol[128];
	char uri[2048];
	if (sscanf(line.buf, "%127[^ ] %2047[^ ] %127[^ ]", method, uri, protocol) != 3)
		return ParseError(r, 400, "Can't Parse Request");

	r->Method = string(method);
	r->Protocol = string(protocol);
	r->URI = string(uri);
	LOG_LEVEL(2, "GOT HEADER LINE: %s# (%ld/%ld)\n", line.buf, strlen(line.buf), line.size);

	// Parse the rest of the header.
	for (AdvanceLine(&line);; AdvanceLine(&line))
	{
		if (!SocketReadLine(sock, &line))
			return false;
		LOG_LEVEL(2, "GOT HEADER LINE: %s#\n", line.buf);

		if (ParseHeaderLineInt(line.buf, "Content-Length: ", &r->ContentLength)) {
			if (r->ContentLength < 0) {
				r->ContentLength = 0;
				LOG("WARNING: ignoring negative Content-Length from client %s:%d\n",
					inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
			}
		}
		else if (ParseHeaderLine(line.buf, "Connection: ", &r->Connection)) {}
		else if (ParseHeaderLine(line.buf, "Cookie: ", &r->Cookie)) {}
		else if (ParseHeaderLine(line.buf, "Host: ", &r->Host)) {}
		else if (ParseHeaderLine(line.buf, "If-Modified-Since: ", &r->IfModifiedSince)) {}
		else if (ParseHeaderLine(line.buf, "User-Agent: ", &r->UserAgent)) {}

		if (line.buf[0] == '\0')
			break;
	}

	// Parse the POST data.
	if (r->ContentLength > 0) {
		if (r->ContentLength > (int)sizeof(r->postbuf)) {
			LOG("ERROR: large POST data from client %s:%d\n",
				inet_ntoa(sock->addr.sin_addr), ntohs(sock->addr.sin_port));
			ParseError(r, 413, "Request entity too large.");
			return false;
		}

		if (!SocketReadBuffer(sock, r->postbuf, r->ContentLength))
			return false;
	}

	return true;
}

/*
 *******************************************************************************
 * Request processing
 *******************************************************************************
 */

static void MakeErrorPage(Request *req, Response *resp, int status, const char* title, const char* msg);
static void Make404Page(Request *req, Response *resp);

void DoRequest(Request *req, Response *resp)
{
	assert(req);
	assert(resp);

	ResetResponse(resp);
	LOG_LEVEL(2, "HTTP Request: %s %s", req->Method.c_str(), req->URI.c_str());

	if (req->URI.empty() || req->URI[0] != '/') {
		MakeErrorPage(req, resp, 400, "Bad Request", "Bad filename.");

	/*} else if (strncmp(req->URI.c_str(), "/cgi-bin/", 9) == 0) {
		cgi_main(); */

	} else if (MakeFilePage(req, resp)) {
		/* nop */

	} else {
		Make404Page(req, resp);
	}
}

void ResetResponse(Response *r)
{
	r->Status = 200;
	r->ContentLength = 0;

	r->CacheControl.clear();
	r->Date.clear();
	r->Expires.clear();
	r->LastModified.clear();
	r->Pragma.clear();
	r->Protocol.clear();
	r->Connection.clear();
	r->Server.clear();
	r->ContentType.clear();
	r->reply.clear();

	// Can't call time().
	// Really we should get the time from the arbiter.
	if (false) {
		char timebuf[1024];
		long now = time((time_t*)0);
		strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime(&now));
		r->Date = timebuf;
	} else {
		r->Date.clear();
	}
}

void AddHeaders(Request *req, Response *resp)
{
	// Setup defaults
	if (strcasestr(req->Protocol.c_str(), "HTTP/1.1") == NULL) {
		resp->Protocol = "HTTP/1.0";
	} else {
		resp->Protocol = "HTTP/1.1";
	}

	if (strcasecmp(req->Connection.c_str(), "Keep-Alive") == 0) {
		resp->Connection = "Keep-Alive";
	} else {
		resp->Connection = "Close";
	}

	// Print the headers.
	resp->prints("%s %d OK\r\n", resp->Protocol.c_str(), resp->Status);
	resp->prints("Connection: %s\r\n", resp->Connection.c_str());
	resp->prints("Server: %s\r\n", SERVER_NAME);

	if (!resp->CacheControl.empty()) {
		resp->prints("Cache-Control: %s\r\n", resp->CacheControl.c_str());
	}

	if (!resp->Date.empty()) {
		resp->prints("Date: %s\r\n", resp->Date.c_str());
	}

	if (!resp->Expires.empty()) {
		resp->prints("Expires: %s\r\n", resp->Expires.c_str());
	}

	if (!resp->LastModified.empty()) {
		resp->prints("Last-Modified: %s\r\n", resp->LastModified.c_str());
	}

	if (!resp->Pragma.empty()) {
		resp->prints("Pragma: %s\r\n", resp->Pragma.c_str());
	}

	if (!resp->ContentType.empty()) {
		resp->prints("Content-Type: %s\r\n", resp->ContentType.c_str());

	} else {
		resp->prints("Content-Type: text/plain\r\n");
	}

	if (resp->ContentLength > 0) {
		resp->prints("Content-Length: %d\r\n", resp->ContentLength);
	}

	resp->prints("\r\n");
}

static void MakeErrorPage(Request *req, Response *resp, int status, const char* title, const char* msg)
{
	resp->Status = status;
	resp->ContentType = "text/html";

	resp->prints("<html>\n<head><title>%s</title></head>\n<body>\n", title);
	resp->prints(msg);
	resp->prints("</body>\n</html>\n");
	resp->prints("\r\n");

	vector<char> tmp;
	tmp.reserve(resp->reply.capacity());
	tmp.swap(resp->reply);

	resp->ContentType = "text/html";
	resp->ContentLength = tmp.size();
	
	AddHeaders(req, resp);
	resp->reply.insert(resp->reply.end(), tmp.begin(), tmp.end());
}

static void Make404Page(Request *req, Response *resp)
{
	resp->Status = 404;
	resp->ContentType = "text/html";

	resp->print("<html>\n<head><title>Error: Not Found</title></head>\n"
		    "<body>\n<br/><center>The URL '");
	resp->printht("%s", req->URI.c_str());
	resp->print("' could not be found.</center><br/>\n</body>\n</html>\n");
	
	vector<char> tmp;
	tmp.reserve(resp->reply.capacity());
	tmp.swap(resp->reply);

	resp->ContentLength = tmp.size();

	AddHeaders(req, resp);
	resp->reply.insert(resp->reply.end(), tmp.begin(), tmp.end());

	LOG_LEVEL(2, "Returned 404 for URI = '%s'", req->URI.c_str());
}
