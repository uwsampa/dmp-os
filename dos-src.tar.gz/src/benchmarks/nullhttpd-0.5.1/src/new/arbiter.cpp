//
// The two-phase commit arbiter
// Overview:
//                     -----------------
//                     | Listener <----|---connect--+
//                     |     |         |            +-----+
//                     |     V         |                  + client
//                     | ClientWorker <|--req------resp-->+
//                     |  |        ^   |
//                     |  V        |   |
//         + <--req--->| ReqWorker |   |
//    shim +           |           |   |
//         + ---resp-->| RespWorker+   |
//                     -----------------
//

#include <getopt.h>
#include <assert.h>

#include "lib.h"

#define STAT_MSG_FREQ 100   /* Print average skew every ___ requests */

FILE *logfile = NULL; /* Log to stderr */

// Shim connections

struct Replica {
	int id;
	Socket req_sock;   // send requests via two-phase commit here
	Socket resp_sock;  // wait for responses here
};

static pthread_mutex_t reqlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  reqsig  = PTHREAD_COND_INITIALIZER;
static vector<Request*> pendingreqs;
static vector<Request*> outgoingreqs;

struct Replica** allreplica;

// Client connections

struct Connection {
	pthread_mutex_t lock;
	pthread_cond_t sig;

	int id;
	int nready; /* Number of replicas that have supplied their response */
	// int session?
	Socket sock;
	Request in;
	Response *out; /* One response for each replica */
};

static pthread_mutex_t connlock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  freesig  = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  readysig = PTHREAD_COND_INITIALIZER;
static queue<Connection*> freeconn;
static queue<Connection*> readyconn;
static Connection** allconn;

//------------------------------------------------------------------------------
// Worker Threads
//------------------------------------------------------------------------------

static uint64_t SyncReplicas()
{
	int magic = htonl(REPLICA_MAGIC_NUM);

	static uint64_t skewSum   = 0; /* Current average skew between replicas */
	static uint64_t skewCount = 0;   /* Number of samples in average */

	LOG_LEVEL(2, "starting sync\n");

	// Send start messages.
	for (int i = 0; i < config.server_nreplicas; ++i)
	{
		Replica* r = allreplica[i];
		SocketWrite(&r->req_sock, (char *)&magic, sizeof(magic));
	}

	LOG_LEVEL(2, "gathering quantums\n");

	// Gather replica quantums.
	uint64_t minepoch = (uint64_t)(-1);
	uint64_t maxepoch = 0;

	for (int i = 0; i < config.server_nreplicas; ++i)
	{
		Replica* r = allreplica[i];
		uint64_t e = 0;

		SocketReadBuffer(&r->req_sock, (char *)&e, sizeof(e));

		if (i == 0 || e < minepoch)
			minepoch = e;

		if (e > maxepoch)
			maxepoch = e;
	}

	/* Accumulate the latest skew */
	uint64_t skew = maxepoch - minepoch;
	skewSum += skew;
	skewCount++;

	LOG_LEVEL(2, "finishing sync at quantum %ld (skew %ld)\n", maxepoch, skew);

	if (skewCount == STAT_MSG_FREQ) {
		LOG("Average replica skew: %g ticks\n", (double)skewSum / (double)skewCount);
		skewSum   = 0;
		skewCount = 0;
	}

	return maxepoch;
}

static size_t BuildRequest(Request *r, iovec *iov)
{
	size_t rlen = 0;
	char *buf;

	// Compute the size of the request
	rlen = sizeof(r->ContentLength) + sizeof(r->ClientID)
	     + r->Method.length()       + r->URI.length()
	     + r->Protocol.length()     + r->Connection.length()
	     + r->ContentType.length()  + r->Cookie.length()
	     + r->Host.length()         + r->IfModifiedSince.length()
	     + r->UserAgent.length()    + strlen(r->postbuf)
	     + 10; /* 1 NULL-byte for each str */

	iov->iov_len = rlen + sizeof(rlen);
	iov->iov_base = malloc(iov->iov_len);
	buf = (char*)iov->iov_base;
	assert(buf);

	#define PUTDATA(data) 						\
		do {							\
			memcpy(buf, (char*)&(data), sizeof(data));	\
			buf += sizeof(data);				\
		} while (0)

	#define PUTSTRING(str) 						\
		do {							\
			memcpy(buf, (str).c_str(), (str).length()+1);	\
			buf += (str).length()+1;			\
		} while (0)

	PUTDATA(rlen);
	PUTDATA(r->ClientID);
	PUTDATA(r->ContentLength);

	PUTSTRING(r->Method);
	PUTSTRING(r->URI);
	PUTSTRING(r->Protocol);
	PUTSTRING(r->Connection);
	PUTSTRING(r->ContentType);
	PUTSTRING(r->Cookie);
	PUTSTRING(r->Host);
	PUTSTRING(r->IfModifiedSince);
	PUTSTRING(r->UserAgent);

	#undef PUTDATA
	#undef PUTSTRING

	return rlen;
}

static void PushReqsToReplicas(const uint64_t maxepoch)
{
	std::vector<Request*>::iterator iter;
	struct msghdr msg;
	uint32_t nrequests;  // type is important!
	int i;

	static uint64_t nreqSum = 0;
	static uint64_t nreqCt  = 0;

	nrequests = outgoingreqs.size();
	LOG_LEVEL(2, "sending %d requests\n", nrequests);

	// Stats
	nreqSum += nrequests;
	nreqCt++;

	if (nreqCt == STAT_MSG_FREQ) {
		LOG("Average number of requests per push: %g\n", (double)nreqSum / (double)nreqCt);
		nreqSum = 0;
		nreqCt = 0;
	}

	// Deliver {maxepoch, nreqs, {req1, req2, ...}} to each replica
	memset(&msg, 0, sizeof msg);
	msg.msg_iovlen = nrequests + 2;
	msg.msg_iov = (struct iovec*)calloc(msg.msg_iovlen, sizeof(*msg.msg_iov));

	msg.msg_iov[0].iov_base = (void*)&maxepoch;
	msg.msg_iov[0].iov_len = sizeof(maxepoch);
	msg.msg_iov[1].iov_base = (void*)&nrequests;
	msg.msg_iov[1].iov_len = sizeof(nrequests);

	for (i = 2, iter = outgoingreqs.begin(); iter != outgoingreqs.end(); ++iter, ++i)
		BuildRequest(*iter, &msg.msg_iov[i]);

	for (i = 0; i < config.server_nreplicas; ++i) {
		Replica* r = allreplica[i];

		// Write all requests in batch
		if (sendmsg(r->req_sock.s, &msg, 0) < 0) {
			perror("sendmsg");
			assert(false);
		}
	}

	outgoingreqs.clear();
}

static void* RequestWorker(void*)
{
	for (;;)
	{
		// Wait for a queued request.
		pthread_mutex_lock(&reqlock);
		while (pendingreqs.empty()) {
			pthread_cond_wait(&reqsig, &reqlock);
		}
		pthread_mutex_unlock(&reqlock);

		// Sync replicas for the next input arrival epoch.
		const uint64_t maxepoch = SyncReplicas();

		// Dump all pending requests to the shims.
		pthread_mutex_lock(&reqlock);
		outgoingreqs.swap(pendingreqs);
		pthread_mutex_unlock(&reqlock);

		PushReqsToReplicas(maxepoch);
	}

	return NULL;
}

static void* ResponseWorker(void* _r)
{
	Replica* r = reinterpret_cast<Replica*>(_r);
	assert(r);

	Response *resp = new Response();
	assert(resp);

	const int sock = r->resp_sock.s;
	assert(sock >= 0);

	ssize_t len;
	int connid;
	Connection *c = NULL;

	for (;;)
	{
		// Read a response.
		SocketReadBuffer(&r->resp_sock, (char *)&connid, sizeof(connid));
		SocketReadBuffer(&r->resp_sock, (char *)&len, sizeof(len));

		c = allconn[connid];
		c->out[r->id].reply.resize(len);

		// Parse a Response out of buffer
		SocketReadBuffer(&r->resp_sock, &c->out[r->id].reply[0], len);

		LOG_LEVEL(2, "<%d> RESPONSE from %d: %*s\n",
			connid, r->id, (int)len, &c->out[r->id].reply[0]);

		// Wake the connection handler.
		pthread_mutex_lock(&c->lock);
		c->nready++;
		pthread_cond_signal(&c->sig);
		pthread_mutex_unlock(&c->lock);
	}

	return NULL;
}

static void HandleConnection(Connection* c)
{
	bool alive = true;

	LOG_LEVEL(2, "<%d> alive with %s:%d\n",
		c->id, inet_ntoa(c->sock.addr.sin_addr), (int)ntohs(c->sock.addr.sin_port));

	while (alive)
	{
		// Read a request.
		ResetRequest(&c->in);
		if (!ReadHttpRequest(&c->sock, &c->in)) {
			LOG_LEVEL(2, "<%d> ReadHttpRequest failed\n", c->id);
			break;
		}
		LOG_LEVEL(2, "<%d> ReadHttpRequest success\n", c->id);

		if (strcasecmp(c->in.Connection.c_str(), "close") == 0)
			alive = false;

		if (c->in.error_status != 0) {
			// TODO: send a reply directly from here
		}

		// Forward to the RequestWorker.
		pthread_mutex_lock(&reqlock);
		c->in.ClientID = c->id;
		c->nready = 0;
		pendingreqs.push_back(&c->in);
		pthread_cond_signal(&reqsig);
		pthread_mutex_unlock(&reqlock);

		// Wait for a response.
		pthread_mutex_lock(&c->lock);
		while (c->nready < config.server_nreplicas) {
			LOG_LEVEL(2, "<%d> WAIT: %d of %d\n", c->id, c->nready, config.server_nreplicas);
			pthread_cond_wait(&c->sig, &c->lock);
		}
		pthread_mutex_unlock(&c->lock);

		LOG_LEVEL(2, "<%d> HttpResponses received from %d replicas\n", c->id, c->nready);

		// Check that all responses match.
		char *resp = &c->out[0].reply[0];
		size_t len = c->out[0].reply.size();

		for (int i = 1; i < config.server_nreplicas; i++)  {
			bool same = true;

			if (c->out[i].reply.size() != len)
				same = false;

			else if (memcmp(&c->out[i].reply[0], resp, len) != 0)
				same = false;

			LOG_ASSERT(same, "<%d> mismatched responses\n", c->id);
		}

		LOG_LEVEL(2, "<%d> HttpResponses match\n", c->id);

		// Forward to the client.
		SocketWrite(&c->sock, resp, len);
	}

	LOG_LEVEL(2, "<%d> dead\n", c->id);
}

static void* ClientWorker(void*)
{
	Connection* c;

	for (;;)
	{
		// Wait for a ready connection.
		pthread_mutex_lock(&connlock);
		while (readyconn.empty()) {
			pthread_cond_wait(&readysig, &connlock);
		}
		c = readyconn.front();
		readyconn.pop();
		pthread_mutex_unlock(&connlock);

		// Process.
		HandleConnection(c);
		CloseSocket(&c->sock);

		pthread_mutex_lock(&connlock);
		freeconn.push(c);
		pthread_cond_signal(&freesig);
		pthread_mutex_unlock(&connlock);
	}

	return NULL;
}

//------------------------------------------------------------------------------
// Listener Thread
//------------------------------------------------------------------------------

static void Listener(void)
{
	Socket sock;
	OpenListenSocket("http-server", config.server_port, &sock);

	for (;;)
	{
		Connection* c;

		// Get a free connection slot.
		pthread_mutex_lock(&connlock);
		while (freeconn.empty()) {
			pthread_cond_wait(&freesig, &connlock);
		}
		c = freeconn.front();
		freeconn.pop();
		pthread_mutex_unlock(&connlock);

		// Accept the next connection.
		AcceptSocket("client", sock.s, &c->sock);

		// Signal a worker thread.
		pthread_mutex_lock(&connlock);
		readyconn.push(c);
		pthread_cond_signal(&readysig);
		pthread_mutex_unlock(&connlock);
	}
}

//------------------------------------------------------------------------------
// Main
//------------------------------------------------------------------------------

static void SetupConnectionQueue()
{
	assert(config.server_maxconn >= 1);
	allconn = new Connection*[config.server_maxconn];

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		Connection* c = new Connection;
		allconn[i] = c;

		c->id = i;
		pthread_mutex_init(&c->lock, NULL);
		pthread_cond_init(&c->sig, NULL);

		c->out = new Response[config.server_nreplicas];
		assert(c->out);

		freeconn.push(c);
	}
}

static void WaitForReplicas()
{
	Socket req_sock;
	Socket resp_sock;

	OpenListenSocket("shim-req-connect", config.server_req_port, &req_sock);
	OpenListenSocket("shim-resp-connect", config.server_resp_port, &resp_sock);
	LOG_LEVEL(1, "Waiting for replicas ...\n");

	assert(config.server_nreplicas >= 1);
	allreplica = new Replica*[config.server_nreplicas];

	for (int i = 0; i < config.server_nreplicas; ++i)
	{
		Replica* r = new Replica;
		allreplica[i] = r;
		r->id = i;

		// Wait for this replica to connect.
		AcceptSocket("shim-req", req_sock.s, &r->req_sock);
		AcceptSocket("shim-resp", resp_sock.s, &r->resp_sock);
		LOG_LEVEL(1, "Connected to replica #%d\n", i+1);
	}

	CloseSocket(&req_sock);
	CloseSocket(&resp_sock);
}

static void SpawnWorkers()
{
	pthread_t thread;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	for (int i = 0; i < config.server_maxconn; ++i)
	{
		if (pthread_create(&thread, &attr, ClientWorker, NULL) < 0) {
			PERROR("pthread_create ClientWorker");
			exit(1);
		}
	}

	for (int i = 0; i < config.server_nreplicas; ++i)
	{
		if (pthread_create(&thread, &attr, ResponseWorker, allreplica[i]) < 0) {
			PERROR("pthread_create ResponseWorker");
			exit(1);
		}
	}

	if (pthread_create(&thread, &attr, RequestWorker, NULL) < 0) {
		PERROR("pthread_create RequestWorker");
		exit(1);
	}
}

int main(int argc, char* argv[])
{
	// Init
	ParseHttpdCommandLine(argc, argv);
	SetupConnectionQueue();
	WaitForReplicas();
	SpawnWorkers();

	// Run
	Listener();
}
